package net.hachimi.eventbus;

import net.hachimi.eventbus.event.Event;

public interface EventHandler {
    public void subscribe(Object var1);

    public void unsubscribe(Object var1);

    public boolean dispatch(Event var1);
}
