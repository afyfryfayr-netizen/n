package net.hachimi.eventbus;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.hachimi.eventbus.EventHandler;
import net.hachimi.eventbus.Listener;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.Event;

public class EventBus
implements EventHandler {
    public static final EventBus INSTANCE = new EventBus();
    private final Set<Object> subscribers = Collections.synchronizedSet(new HashSet());
    private final Map<Object, PriorityQueue<Listener>> listeners = new ConcurrentHashMap<Object, PriorityQueue<Listener>>();

    @Override
    public void subscribe(Object obj) {
        if (this.subscribers.contains(obj)) {
            return;
        }
        this.subscribers.add(obj);
        for (Method method : obj.getClass().getMethods()) {
            Class<?>[] params;
            method.trySetAccessible();
            if (!method.isAnnotationPresent(EventListener.class)) continue;
            EventListener listener = method.getAnnotation(EventListener.class);
            if (method.getReturnType() != Void.TYPE || (params = method.getParameterTypes()).length != 1) continue;
            PriorityQueue active = this.listeners.computeIfAbsent(params[0], v -> new PriorityQueue());
            active.add(new Listener(method, obj, listener.receiveCanceled(), listener.priority()));
        }
    }

    @Override
    public void unsubscribe(Object obj) {
        if (this.subscribers.remove(obj)) {
            this.listeners.values().forEach(set -> set.removeIf(l -> l.getSubscriber() == obj));
            this.listeners.entrySet().removeIf(e -> ((PriorityQueue)e.getValue()).isEmpty());
        }
    }

    @Override
    public boolean dispatch(Event event) {
        if (event == null) {
            return false;
        }
        PriorityQueue<Listener> active = this.listeners.get(event.getClass());
        if (active == null || active.isEmpty()) {
            return false;
        }
        for (Listener listener : new ArrayList<Listener>(active)) {
            if (event.isCanceled() && !listener.isReceiveCanceled()) continue;
            listener.invokeSubscriber(event);
        }
        return event.isCanceled();
    }
}
