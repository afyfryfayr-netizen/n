package net.hachimi.eventbus.event;

import net.hachimi.eventbus.event.Event;

public class StageEvent
extends Event {
    private EventStage stage;

    public EventStage getStage() {
        return this.stage;
    }

    public void setStage(EventStage stage) {
        this.stage = stage;
    }

    public static enum EventStage {
        PRE,
        POST;

    }
}
