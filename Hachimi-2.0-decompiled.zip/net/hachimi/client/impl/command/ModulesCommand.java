package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class ModulesCommand
extends Command {
    public ModulesCommand() {
        super("Modules", "Displays all client modules", ModulesCommand.literal("modules"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(c -> {
            ArrayList<CallSite> modulesList = new ArrayList<CallSite>();
            for (Module module : Managers.MODULE.getModules()) {
                ToggleModule t;
                String formatting = module instanceof ToggleModule && (t = (ToggleModule)module).isEnabled() ? "\u00a7s" : "\u00a7f";
                modulesList.add((CallSite)((Object)(formatting + module.getName())));
            }
            ChatUtil.clientSendMessageRaw(" \u00a77Modules:\u00a7f " + String.join((CharSequence)", ", modulesList));
            return 1;
        });
    }
}
