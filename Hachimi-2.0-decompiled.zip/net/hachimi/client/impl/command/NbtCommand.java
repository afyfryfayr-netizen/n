package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_1799;
import net.minecraft.class_2172;

public class NbtCommand
extends Command {
    public NbtCommand() {
        super("Nbt", "Displays all nbt tags on the held item", NbtCommand.literal("nbt"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            class_1799 mainhand = NbtCommand.mc.field_1724.method_6047();
            if (!mainhand.method_57353().method_57837()) {
                ChatUtil.error("No Nbt tags on this item!");
                return 0;
            }
            ChatUtil.clientSendMessage(mainhand.method_57353().toString());
            return 1;
        });
    }
}
