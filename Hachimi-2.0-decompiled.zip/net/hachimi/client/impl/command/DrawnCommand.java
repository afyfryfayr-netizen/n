package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.ModuleArgumentType;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_124;
import net.minecraft.class_2172;

public class DrawnCommand
extends Command {
    public DrawnCommand() {
        super("Drawn", "Toggles the drawn state of the module", DrawnCommand.literal("drawn"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(DrawnCommand.argument("module", ModuleArgumentType.module()).executes(c -> {
            Module module = ModuleArgumentType.getModule(c, "module");
            if (module instanceof ToggleModule) {
                ToggleModule toggle = (ToggleModule)module;
                boolean hide = !toggle.isHidden();
                toggle.setHidden(hide);
                ChatUtil.clientSendMessage("\u00a77" + module.getName() + "\u00a7f is now " + (hide ? "\u00a7chidden\u00a7f" : "\u00a7svisible\u00a7f") + String.valueOf(class_124.field_1070) + " in the Hud");
            }
            return 1;
        }))).executes(c -> {
            ChatUtil.error("Must provide module to draw!");
            return 1;
        });
    }
}
