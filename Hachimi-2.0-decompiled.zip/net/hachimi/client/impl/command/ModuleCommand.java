package net.hachimi.client.impl.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.ConfigArgumentType;
import net.hachimi.client.api.command.ListArgumentType;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BlockListConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EntityListConfig;
import net.hachimi.client.api.config.setting.ItemListConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.macro.Macro;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.util.KeyboardUtil;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2172;
import net.minecraft.class_2248;

public class ModuleCommand
extends Command {
    private final Module module;

    public ModuleCommand(Module module) {
        super(module.getName(), module.getDescription(), ModuleCommand.literal(module.getName().toLowerCase()));
        this.module = module;
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(((RequiredArgumentBuilder)ModuleCommand.argument("setting", ConfigArgumentType.config(this.module)).then(((RequiredArgumentBuilder)ModuleCommand.argument("value", StringArgumentType.string()).suggests((c, b) -> {
            Config<?> config = ConfigArgumentType.getConfig(c, "setting");
            if (config instanceof BlockListConfig || config instanceof ItemListConfig || config instanceof EntityListConfig) {
                b.suggest("add");
                b.suggest("del");
                b.suggest("remove");
                b.suggest("clear");
                b.suggest("list");
            }
            return b.buildFuture();
        }).executes(c -> {
            Config<?> config = ConfigArgumentType.getConfig(c, "setting");
            String value = StringArgumentType.getString((CommandContext)c, (String)"value");
            if (value.equalsIgnoreCase("list")) {
                return this.listItems(config, value);
            }
            if (value.equalsIgnoreCase("reset")) {
                config.resetValue();
                ChatUtil.clientSendMessage("\u00a77%s\u00a7f was reset to default value", config.getName());
                return 1;
            }
            if (value.equalsIgnoreCase("clear")) {
                if (config instanceof ItemListConfig) {
                    ((ItemListConfig)config).clear();
                } else if (config instanceof BlockListConfig) {
                    ((BlockListConfig)config).clear();
                } else if (config instanceof EntityListConfig) {
                    ((EntityListConfig)config).clear();
                }
                ChatUtil.clientSendMessage("\u00a77%s\u00a7f was cleared", config.getName());
                return 1;
            }
            return this.updateValue(config, value);
        })).then(ModuleCommand.argument("list", ListArgumentType.list()).executes(c -> {
            Config<?> config = ConfigArgumentType.getConfig(c, "setting");
            if (config instanceof BlockListConfig || config instanceof ItemListConfig || config instanceof EntityListConfig) {
                String action = StringArgumentType.getString((CommandContext)c, (String)"value");
                Object value = ListArgumentType.getListItem(c, "list");
                return this.addDeleteItem(config, action, value);
            }
            return 0;
        })))).executes(c -> {
            ChatUtil.error("Must provide a value!");
            return 1;
        }))).executes(c -> {
            Module patt0$temp = this.module;
            if (patt0$temp instanceof ToggleModule) {
                ToggleModule m = (ToggleModule)patt0$temp;
                m.toggle();
                ChatUtil.clientSendMessage("%s is now %s", "\u00a77" + m.getName() + "\u00a7f", m.isEnabled() ? "\u00a7senabled\u00a7f" : "\u00a7cdisabled\u00a7f");
            }
            return 1;
        });
    }

    private int addDeleteItem(Config<?> config, String action, Object value) {
        if (config instanceof ItemListConfig) {
            if (!(value instanceof class_1792)) {
                ChatUtil.error("Not an item!");
                return 0;
            }
            class_1792 item = (class_1792)value;
            if (action.equalsIgnoreCase("add")) {
                ((ItemListConfig)config).add(item);
                ChatUtil.clientSendMessage("Added \u00a7s" + item.method_7848().getString() + "\u00a7f to \u00a77" + config.getName());
            } else if (action.equalsIgnoreCase("del") || action.equalsIgnoreCase("remove")) {
                ((ItemListConfig)config).remove(item);
                ChatUtil.clientSendMessage("Removed \u00a7c" + item.method_7848().getString() + "\u00a7f from \u00a77" + config.getName());
            }
        } else if (config instanceof BlockListConfig) {
            if (value instanceof class_1792) {
                class_1792 item = (class_1792)value;
                value = class_2248.method_9503((class_1792)item);
            }
            if (!(value instanceof class_2248)) {
                ChatUtil.error("Not a block!");
                return 0;
            }
            class_2248 block = (class_2248)value;
            if (action.equalsIgnoreCase("add")) {
                ((BlockListConfig)config).add(block);
                ChatUtil.clientSendMessage("Added \u00a7s" + block.method_9518().getString() + "\u00a7f to \u00a77" + config.getName());
            } else if (action.equalsIgnoreCase("del") || action.equalsIgnoreCase("remove")) {
                ((BlockListConfig)config).remove(block);
                ChatUtil.clientSendMessage("Removed \u00a7c" + block.method_9518().getString() + "\u00a7f from \u00a77" + config.getName());
            }
        } else if (config instanceof EntityListConfig) {
            if (!(value instanceof class_1299)) {
                ChatUtil.error("Not an entity type!");
                return 0;
            }
            class_1299 entity = (class_1299)value;
            if (action.equalsIgnoreCase("add")) {
                ((EntityListConfig)config).add(entity);
                ChatUtil.clientSendMessage("Added \u00a7s" + entity.method_5897().getString() + "\u00a7f to \u00a77" + config.getName());
            } else if (action.equalsIgnoreCase("del") || action.equalsIgnoreCase("remove")) {
                ((EntityListConfig)config).remove(entity);
                ChatUtil.clientSendMessage("Removed \u00a7c" + entity.method_5897().getString() + "\u00a7f from \u00a77" + config.getName());
            }
        }
        return 1;
    }

    private int listItems(Config<?> config, String action) {
        if (config instanceof ItemListConfig) {
            List list = (List)config.getValue();
            if (action.equalsIgnoreCase("list")) {
                if (list.isEmpty()) {
                    ChatUtil.error("There are no items in the list!");
                    return 1;
                }
                ArrayList<String> listString = new ArrayList<String>();
                for (class_1792 item : list) {
                    listString.add(item.method_7848().getString());
                }
                ChatUtil.clientSendMessage("\u00a77" + config.getName() + "\u00a7f: " + String.join((CharSequence)", ", listString));
            }
        } else if (config instanceof BlockListConfig) {
            List list = (List)config.getValue();
            if (action.equalsIgnoreCase("list")) {
                if (list.isEmpty()) {
                    ChatUtil.error("There are no blocks in the list!");
                    return 1;
                }
                ArrayList<String> listString = new ArrayList<String>();
                for (class_2248 block : list) {
                    listString.add(block.method_9518().getString());
                }
                ChatUtil.clientSendMessage("\u00a77" + config.getName() + "\u00a7f: " + String.join((CharSequence)", ", listString));
            }
        } else if (config instanceof EntityListConfig) {
            List list = (List)config.getValue();
            if (action.equalsIgnoreCase("list")) {
                if (list.isEmpty()) {
                    ChatUtil.error("There are no entities in the list!");
                    return 1;
                }
                ArrayList<String> listString = new ArrayList<String>();
                for (class_1299 entityType : list) {
                    listString.add(entityType.method_5897().getString());
                }
                ChatUtil.clientSendMessage("\u00a77" + config.getName() + "\u00a7f: " + String.join((CharSequence)", ", listString));
            }
        }
        return 1;
    }

    private int updateValue(Config<?> config, String value) {
        if (config == null || value == null) {
            return 0;
        }
        try {
            if (config.getValue() instanceof Integer) {
                val = Integer.parseInt(value);
                if (((Integer)val).doubleValue() < ((Number)((NumberConfig)config).getMin()).doubleValue()) {
                    ChatUtil.error("Value less than min!");
                    return 0;
                }
                if (((Integer)val).doubleValue() > ((Number)((NumberConfig)config).getMax()).doubleValue()) {
                    ChatUtil.error("Value greater than max!");
                    return 0;
                }
                config.setValue(val);
                ChatUtil.clientSendMessage("\u00a77%s\u00a7f was set to \u00a7s%s", config.getName(), ((Integer)val).toString());
            } else if (config.getValue() instanceof Float) {
                val = Float.valueOf(Float.parseFloat(value));
                if (((Float)val).doubleValue() < ((Number)((NumberConfig)config).getMin()).doubleValue()) {
                    ChatUtil.error("Value less than min!");
                    return 0;
                }
                if (((Float)val).doubleValue() > ((Number)((NumberConfig)config).getMax()).doubleValue()) {
                    ChatUtil.error("Value greater than max!");
                    return 0;
                }
                config.setValue(val);
                ChatUtil.clientSendMessage("\u00a77%s\u00a7f was set to \u00a7s%s", config.getName(), ((Float)val).toString());
            } else if (config.getValue() instanceof Double) {
                val = Double.parseDouble(value);
                if ((Double)val < ((Number)((NumberConfig)config).getMin()).doubleValue()) {
                    ChatUtil.error("Value less than min!");
                    return 0;
                }
                if ((Double)val > ((Number)((NumberConfig)config).getMax()).doubleValue()) {
                    ChatUtil.error("Value greater than max!");
                    return 0;
                }
                config.setValue(val);
                ChatUtil.clientSendMessage("\u00a77%s\u00a7f was set to \u00a7s%s", config.getName(), ((Double)val).toString());
            }
        }
        catch (NumberFormatException e) {
            ChatUtil.error("Not a number!");
        }
        if (config.getValue() instanceof Boolean) {
            Boolean val = this.parseBoolean(value);
            if (val == null) {
                ChatUtil.error("Invalid value!");
                return 0;
            }
            config.setValue(val);
            ChatUtil.clientSendMessage("\u00a77%s\u00a7f was set to \u00a7s%s", config.getName(), val != false ? "True" : "False");
        } else if (config.getValue() instanceof Enum) {
            String[] values = (String[])Arrays.stream((Enum[])((Enum)config.getValue()).getClass().getEnumConstants()).map(Enum::name).toArray(String[]::new);
            int ix = -1;
            for (int i = 0; i < values.length; ++i) {
                if (!values[i].equalsIgnoreCase(value)) continue;
                ix = i;
                break;
            }
            if (ix == -1) {
                ChatUtil.error("Not a valid mode!");
                return 0;
            }
            Object val = Enum.valueOf(((Enum)config.getValue()).getClass(), values[ix]);
            config.setValue(val);
            ChatUtil.clientSendMessage("\u00a77%s\u00a7f was set to mode \u00a7s%s", config.getName(), value);
        } else {
            Object values = config.getValue();
            if (values instanceof Macro) {
                Macro macro = (Macro)values;
                if (config.getName().equalsIgnoreCase("Keybind")) {
                    ChatUtil.error("Use the 'bind' command to keybind modules!");
                    return 0;
                }
                config.setValue(new Macro(config.getId(), KeyboardUtil.getKeyCode(value), macro.getRunnable()));
                ChatUtil.clientSendMessage("\u00a77%s\u00a7f was set to key \u00a7s%s", config.getName(), value);
            } else if (config.getValue() instanceof String) {
                config.setValue(value);
            } else if (config.getValue() instanceof Color) {
                try {
                    Color color = ((ColorConfig)config).parseColor(value);
                    config.setValue(color);
                    ChatUtil.clientSendMessage("\u00a77%s\u00a7f was set to \u00a7s%s", config.getName(), value);
                }
                catch (IllegalArgumentException e) {
                    ChatUtil.error("Invalid color!");
                }
            }
        }
        return 1;
    }

    private Boolean parseBoolean(String string) {
        if (string.equalsIgnoreCase("True") || string.equalsIgnoreCase("On")) {
            return true;
        }
        if (string.equalsIgnoreCase("False") || string.equalsIgnoreCase("Off")) {
            return false;
        }
        return null;
    }
}
