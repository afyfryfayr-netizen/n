package net.hachimi.client.impl.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.ModuleArgumentType;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.util.KeyboardUtil;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class BindCommand
extends Command {
    public BindCommand() {
        super("Bind", "Keybinds a module", BindCommand.literal("bind"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(((RequiredArgumentBuilder)BindCommand.argument("module", ModuleArgumentType.module()).then(BindCommand.argument("key", StringArgumentType.string()).executes(c -> {
            Module module = ModuleArgumentType.getModule(c, "module");
            if (module instanceof ToggleModule) {
                ToggleModule t = (ToggleModule)module;
                String key = StringArgumentType.getString((CommandContext)c, (String)"key");
                if (key == null) {
                    ChatUtil.error("Invalid key!");
                    return 0;
                }
                int keycode = KeyboardUtil.getKeyCode(key);
                if (keycode == -1) {
                    ChatUtil.error("Failed to parse key!");
                    return 0;
                }
                t.keybind(keycode);
                ChatUtil.clientSendMessage("\u00a77%s\u00a7f is now bound to \u00a7s%s", module.getName(), key.toUpperCase());
            }
            return 1;
        }))).executes(c -> {
            ChatUtil.error("Must provide a module to keybind!");
            return 1;
        }))).executes(c -> {
            ChatUtil.error("Invalid usage! Usage: " + this.getUsage());
            return 1;
        });
    }
}
