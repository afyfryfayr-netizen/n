package net.hachimi.client.impl.command;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class VClipCommand
extends Command {
    public VClipCommand() {
        super("VClip", "Vertically clips the player", VClipCommand.literal("vclip"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(VClipCommand.argument("distance", DoubleArgumentType.doubleArg()).executes(c -> {
            double dist = DoubleArgumentType.getDouble((CommandContext)c, (String)"distance");
            double y = Managers.POSITION.getY();
            if (Math.abs(y) != 256.0) {
                Managers.POSITION.setPositionY(y + dist);
                ChatUtil.clientSendMessage("Vertically clipped \u00a7s" + dist + "\u00a7f blocks");
            }
            return 1;
        }))).executes(c -> {
            ChatUtil.error("Must provide distance!");
            return 1;
        });
    }
}
