package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.CommandArgumentType;
import net.hachimi.client.impl.command.ModuleCommand;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class HelpCommand
extends Command {
    public HelpCommand() {
        super("Help", "Displays command functionality", HelpCommand.literal("help"));
    }

    private static String toHelpMessage(Command command) {
        return String.format("%s %s- %s", command.getName(), command.getUsage(), command.getDescription());
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(HelpCommand.argument("command", CommandArgumentType.command()).executes(c -> {
            Command command = CommandArgumentType.getCommand(c, "command");
            ChatUtil.clientSendMessage(HelpCommand.toHelpMessage(command));
            return 1;
        }))).executes(c -> {
            ChatUtil.clientSendMessageRaw("\u00a7s[Commands Help]");
            for (Command c1 : Managers.COMMAND.getCommands()) {
                if (c1 instanceof ModuleCommand) continue;
                ChatUtil.clientSendMessageRaw(HelpCommand.toHelpMessage(c1));
            }
            return 1;
        });
    }
}
