package net.hachimi.client.impl.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.mixin.accessor.AccessorEntity;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_1297;
import net.minecraft.class_2172;

public class VanishCommand
extends Command {
    private class_1297 mount;

    public VanishCommand() {
        super("Vanish", "Desyncs the riding entity", VanishCommand.literal("vanish"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(VanishCommand.argument("mount", StringArgumentType.string()).suggests(VanishCommand.suggest("mount", "remount")).executes(c -> {
            String dismount = StringArgumentType.getString((CommandContext)c, (String)"mount");
            if (dismount.equalsIgnoreCase("dismount")) {
                if (VanishCommand.mc.field_1724.method_3144() && VanishCommand.mc.field_1724.method_5854() != null) {
                    if (this.mount != null) {
                        ChatUtil.error("Entity vanished, must remount before mounting!");
                        return 0;
                    }
                    this.mount = VanishCommand.mc.field_1724.method_5854();
                    VanishCommand.mc.field_1724.method_29239();
                    VanishCommand.mc.field_1687.method_2945(this.mount.method_5628(), class_1297.class_5529.field_26999);
                }
            } else if (dismount.equalsIgnoreCase("remount")) {
                if (this.mount == null) {
                    ChatUtil.error("No vanished entity!");
                    return 0;
                }
                ((AccessorEntity)this.mount).hookUnsetRemoved();
                VanishCommand.mc.field_1687.method_53875(this.mount);
                VanishCommand.mc.field_1724.method_5873(this.mount, true);
                this.mount = null;
            }
            return 1;
        }))).executes(c -> {
            ChatUtil.error("Invalid usage! Usage: " + this.getUsage());
            return 1;
        });
    }
}
