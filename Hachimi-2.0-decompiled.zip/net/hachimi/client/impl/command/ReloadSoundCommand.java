package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class ReloadSoundCommand
extends Command {
    public ReloadSoundCommand() {
        super("ReloadSound", "Reloads the Minecraft sound system", ReloadSoundCommand.literal("reloadsound"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            mc.method_1483().method_38566();
            ChatUtil.clientSendMessage("Reloaded the SoundSystem");
            return 1;
        });
    }
}
