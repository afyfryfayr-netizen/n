package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.ModuleArgumentType;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class ResetCommand
extends Command {
    public ResetCommand() {
        super("Reset", "Resets the values of modules", ResetCommand.literal("reset"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(ResetCommand.argument("module", ModuleArgumentType.module()).executes(context -> {
            Module module = ModuleArgumentType.getModule(context, "module");
            if (module == null) {
                ChatUtil.error("Invalid module!");
                return 0;
            }
            for (Config<?> config : module.getConfigs()) {
                if (config.getName().equalsIgnoreCase("Enabled") || config.getName().equalsIgnoreCase("Keybind") || config.getName().equalsIgnoreCase("Hidden")) continue;
                config.resetValue();
            }
            ChatUtil.clientSendMessage("\u00a77" + module.getName() + "\u00a7f settings were reset to default values");
            return 1;
        }))).executes(context -> {
            ChatUtil.error("Must provide module to reset!");
            return 1;
        });
    }
}
