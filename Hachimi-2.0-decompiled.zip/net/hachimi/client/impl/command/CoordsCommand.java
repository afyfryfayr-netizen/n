package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.text.DecimalFormat;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.PlayerArgumentType;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class CoordsCommand
extends Command {
    public CoordsCommand() {
        super("Coords", "Sends player coordinates", CoordsCommand.literal("coords"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(CoordsCommand.argument("player", PlayerArgumentType.player()).executes(c -> {
            String playerName = PlayerArgumentType.getPlayer(c, "player");
            ChatUtil.serverSendCommand("w " + playerName + " " + this.getCoords());
            return 1;
        }))).executes(c -> {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            StringSelection transferable = new StringSelection(this.getCoords());
            clipboard.setContents(transferable, null);
            ChatUtil.clientSendMessage("Copied player coordinates to clipboard!");
            return 1;
        });
    }

    public String getCoords() {
        DecimalFormat decimal = new DecimalFormat("0.0");
        double x = CoordsCommand.mc.field_1724.method_23317();
        double y = CoordsCommand.mc.field_1724.method_23318();
        double z = CoordsCommand.mc.field_1724.method_23321();
        return decimal.format(x) + ", " + decimal.format(y) + ", " + decimal.format(z);
    }
}
