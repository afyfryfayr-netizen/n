package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.minecraft.class_1799;
import net.minecraft.class_2172;

public class PeekCommand
extends Command {
    public PeekCommand() {
        super("Peek", "Shows the contents of held shulkers", PeekCommand.literal("peek"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
    }

    public void displayShulkerInventory(class_1799 stack) {
    }
}
