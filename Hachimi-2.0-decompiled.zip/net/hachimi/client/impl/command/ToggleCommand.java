package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.ModuleArgumentType;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class ToggleCommand
extends Command {
    public ToggleCommand() {
        super("Toggle", "Enables/Disables a module", ToggleCommand.literal("toggle"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
        ((LiteralArgumentBuilder)builder.then(ToggleCommand.argument("module", ModuleArgumentType.module()).executes(c -> {
            Module module = ModuleArgumentType.getModule(c, "module");
            if (module instanceof ToggleModule) {
                ToggleModule t = (ToggleModule)module;
                t.toggle();
                ChatUtil.clientSendMessage("%s is now %s", "\u00a77" + t.getName() + "\u00a7f", t.isEnabled() ? "\u00a7senabled\u00a7f" : "\u00a7cdisabled\u00a7f");
            }
            return 1;
        }))).executes(c -> {
            ChatUtil.error("Must provide module to toggle!");
            return 1;
        });
    }
}
