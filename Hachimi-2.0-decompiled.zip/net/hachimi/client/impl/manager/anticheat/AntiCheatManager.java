package net.hachimi.client.impl.manager.anticheat;

import java.util.Arrays;
import net.hachimi.client.Hachimi;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.manager.anticheat.SetbackData;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_6373;

public final class AntiCheatManager
implements Globals {
    private SetbackData lastSetback;
    private final int[] transactions = new int[4];
    private int index;
    private boolean isGrim;

    public AntiCheatManager() {
        EventBus.INSTANCE.subscribe(this);
        Arrays.fill(this.transactions, -1);
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_6373) {
            int uid;
            class_6373 packet = (class_6373)class_25962;
            if (this.index > 3) {
                return;
            }
            this.transactions[this.index] = uid = packet.method_36950();
            ++this.index;
            if (this.index == 4) {
                this.grimCheck();
            }
        } else {
            class_25962 = event.getPacket();
            if (class_25962 instanceof class_2708) {
                class_2708 packet = (class_2708)class_25962;
                this.lastSetback = new SetbackData(new class_243(packet.method_11734(), packet.method_11735(), packet.method_11738()), System.currentTimeMillis(), packet.method_11737());
            }
        }
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        Arrays.fill(this.transactions, -1);
        this.index = 0;
        this.isGrim = false;
    }

    private void grimCheck() {
        for (int i = 0; i < 4 && this.transactions[i] == -i; ++i) {
        }
        this.isGrim = true;
        Hachimi.info("Server is running GrimAC.");
    }

    public boolean isGrim() {
        return this.isGrim;
    }

    public boolean hasPassed(long timeMS) {
        return this.lastSetback != null && this.lastSetback.timeSince() >= timeMS;
    }
}
