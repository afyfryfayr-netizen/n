package net.hachimi.client.impl.manager.world;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.player.SpeedmineModule;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.render.animation.EasingPlus;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2620;
import net.minecraft.class_3532;

public class BreakManager
implements Globals {
    public static BreakManager INSTANCE;
    public final ConcurrentHashMap<Integer, BreakData> breakMap = new ConcurrentHashMap();
    public final ConcurrentHashMap<Integer, BreakData> doubleMap = new ConcurrentHashMap();
    private static final double BREAK_TIMEOUT = 10.0;
    private static final double DOUBLE_TIMEOUT = 10.0;
    private static final long MIN_TIMEOUT_MS = 3000L;

    public BreakManager() {
        INSTANCE = this;
        EventBus.INSTANCE.subscribe(this);
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        this.breakMap.clear();
        this.doubleMap.clear();
    }

    @EventListener
    public void onTick(PlayerTickEvent event) {
        if (BreakManager.mc.field_1724 == null || BreakManager.mc.field_1687 == null) {
            return;
        }
        Iterator<Object> iterator = ((ConcurrentHashMap.KeySetView)this.doubleMap.keySet()).iterator();
        while (iterator.hasNext()) {
            int i = (Integer)iterator.next();
            BreakData d = this.doubleMap.get(i);
            if (d != null && d.getEntity() != null && !BreakManager.mc.field_1687.method_22347(d.pos) && !d.timer.passedMs(Math.max(3000L, (long)(d.breakTime * 10.0)))) continue;
            this.doubleMap.remove(i);
        }
        for (BreakData d : this.breakMap.values()) {
            d.breakTime = Math.max(BreakManager.getBreakTime(d.pos), 50.0);
            if (BreakManager.isUnbreakable(d.pos)) {
                d.fade.setLength(0L);
                d.complete = false;
                d.failed = true;
                continue;
            }
            if (BreakManager.mc.field_1687.method_22347(d.pos)) {
                d.fade.setLength(0L);
                d.complete = true;
                d.failed = false;
                continue;
            }
            if (!d.complete && d.timer.passedMs((long)(d.breakTime * 10.0))) {
                d.fade.setLength(0L);
                d.failed = true;
                continue;
            }
            d.fade.setLength((long)d.breakTime);
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        BreakData current;
        if (BreakManager.mc.field_1724 == null || BreakManager.mc.field_1687 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (!(class_25962 instanceof class_2620)) {
            return;
        }
        class_2620 packet = (class_2620)class_25962;
        if (packet.method_11277() == null) {
            return;
        }
        class_2338 pos = packet.method_11277();
        int entityId = packet.method_11280();
        int progress = packet.method_11278();
        class_1297 entity = BreakManager.mc.field_1687.method_8469(entityId);
        if (!(entity instanceof class_1657)) {
            return;
        }
        if (class_3532.method_15355((float)((float)entity.method_33571().method_1025(pos.method_46558()))) > 8.0f) {
            return;
        }
        if (progress != 255) {
            if (progress != 0) {
                BreakData doublePos = this.doubleMap.get(entityId);
                if (doublePos != null) {
                    doublePos.pos = pos;
                    doublePos.timer.reset();
                } else if (!BreakManager.isUnbreakable(pos)) {
                    this.doubleMap.put(entityId, new BreakData(pos, entityId, true));
                }
                return;
            }
            BreakData doublePos = this.doubleMap.get(entityId);
            if (doublePos != null && doublePos.pos.equals((Object)pos) && !doublePos.timer.passedMs(150L)) {
                return;
            }
        }
        if ((current = this.breakMap.get(entityId)) != null && !current.failed && current.pos.equals((Object)pos)) {
            return;
        }
        if (progress == 255 && current == null) {
            return;
        }
        if (progress == 255) {
            return;
        }
        this.breakMap.put(entityId, new BreakData(pos, entityId, false));
        if (!this.doubleMap.containsKey(entityId) && !BreakManager.isUnbreakable(pos)) {
            this.doubleMap.put(entityId, new BreakData(pos, entityId, true));
        }
    }

    public static double getBreakTime(class_2338 pos) {
        if (BreakManager.mc.field_1687 == null) {
            return Double.MAX_VALUE;
        }
        float delta = SpeedmineModule.getInstance().calcBlockBreakingDelta(BreakManager.mc.field_1687.method_8320(pos), (class_1922)BreakManager.mc.field_1687, pos);
        if (delta <= 0.0f) {
            return Double.MAX_VALUE;
        }
        return 1.0 / (double)delta / 20.0 * 1000.0;
    }

    public static boolean isUnbreakable(class_2338 pos) {
        if (BreakManager.mc.field_1687 == null) {
            return false;
        }
        return BreakManager.mc.field_1687.method_8320(pos).method_26214((class_1922)BreakManager.mc.field_1687, pos) < 0.0f;
    }

    public boolean isMining(class_2338 pos) {
        return this.isMining(pos, false);
    }

    public boolean isMining(class_2338 pos, boolean self) {
        for (BreakData d : this.breakMap.values()) {
            if (d.getEntity() == null || d.failed || d.getEntity().method_33571().method_1022(pos.method_46558()) > 7.0 || !d.pos.equals((Object)pos)) continue;
            return true;
        }
        return false;
    }

    public static class BreakData {
        public class_2338 pos;
        private final int entityId;
        public final FadeTimer fade;
        public final SimpleTimer timer;
        public double breakTime;
        public boolean failed = false;
        public boolean complete = false;

        public BreakData(class_2338 pos, int entityId, boolean extraBreak) {
            this.pos = pos;
            this.entityId = entityId;
            this.breakTime = Math.max(BreakManager.getBreakTime(pos), 50.0);
            this.fade = new FadeTimer((long)this.breakTime);
            this.timer = new SimpleTimer();
        }

        public class_1297 getEntity() {
            if (Globals.mc.field_1687 == null) {
                return null;
            }
            class_1297 e = Globals.mc.field_1687.method_8469(this.entityId);
            return e instanceof class_1657 ? e : null;
        }

        public int getEntityId() {
            return this.entityId;
        }
    }

    public static class SimpleTimer {
        private long start = System.currentTimeMillis();

        public void reset() {
            this.start = System.currentTimeMillis();
        }

        public long getMs() {
            return System.currentTimeMillis() - this.start;
        }

        public long getElapsedTime() {
            return this.getMs();
        }

        public boolean passedMs(long ms) {
            return this.getMs() > ms;
        }
    }

    public static class FadeTimer {
        private long length;
        private long startMs;
        private boolean active;

        public FadeTimer(long length) {
            this.length = length;
            this.startMs = System.currentTimeMillis();
            this.active = length > 0L;
        }

        public void setLength(long length) {
            if (this.length == length) {
                return;
            }
            this.length = length;
            this.startMs = System.currentTimeMillis();
            this.active = length > 0L;
        }

        public double getFactor() {
            if (this.length <= 0L) {
                return 0.0;
            }
            double t = (double)(System.currentTimeMillis() - this.startMs) / (double)this.length;
            return this.active ? Math.min(t, 1.0) : Math.max(1.0 - t, 0.0);
        }

        public double ease(EasingPlus easing) {
            return easing.ease(this.getFactor());
        }
    }
}
