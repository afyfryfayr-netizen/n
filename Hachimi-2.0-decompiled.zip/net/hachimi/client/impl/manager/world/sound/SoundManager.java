package net.hachimi.client.impl.manager.world.sound;

import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import net.hachimi.client.util.Globals;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class SoundManager
implements Globals {
    private static final Set<String> REGISTERED_SOUND_FILES = new HashSet<String>();
    public static final class_3414 GUI_CLICK = SoundManager.registerSound("gui_click");
    public static final class_3414 TWITTER = SoundManager.registerSound("twitter");
    public static final class_3414 IOS = SoundManager.registerSound("ios");
    public static final class_3414 DISCORD = SoundManager.registerSound("discord");
    public static final class_3414 STEAM = SoundManager.registerSound("steam");

    private static class_3414 registerSound(String name) {
        SoundManager.registerSoundFile(name + ".ogg");
        class_2960 id = class_2960.method_60655((String)"hachimi", (String)name);
        return (class_3414)class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)id, (Object)class_3414.method_47908((class_2960)id));
    }

    private static void registerSoundFile(String soundFile) {
        REGISTERED_SOUND_FILES.add(soundFile);
    }

    private static InputStream loadResource(String resourcePath) {
        try {
            return SoundManager.class.getClassLoader().getResourceAsStream(resourcePath);
        }
        catch (Exception e) {
            return null;
        }
    }

    public void playSound(class_3414 sound) {
        this.playSound(sound, 1.2f, 0.75f);
    }

    public void playSound(class_3414 sound, float volume, float pitch) {
        if (SoundManager.mc.field_1724 != null) {
            mc.method_40000(() -> SoundManager.mc.field_1724.method_5783(sound, volume, pitch));
        }
    }

    public static Set<String> getRegisteredSoundFiles() {
        return new HashSet<String>(REGISTERED_SOUND_FILES);
    }
}
