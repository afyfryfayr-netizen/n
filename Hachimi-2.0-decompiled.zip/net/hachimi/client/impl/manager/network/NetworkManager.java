package net.hachimi.client.impl.manager.network;

import java.util.HashSet;
import java.util.Set;
import net.hachimi.client.impl.event.gui.screen.ConnectScreenEvent;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.imixin.IClientPlayNetworkHandler;
import net.hachimi.client.mixin.accessor.AccessorClientWorld;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.math.PerSecondCounter;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_2596;
import net.minecraft.class_2896;
import net.minecraft.class_635;
import net.minecraft.class_639;
import net.minecraft.class_640;
import net.minecraft.class_642;
import net.minecraft.class_7202;
import net.minecraft.class_7204;

public class NetworkManager
implements Globals {
    private static final Set<class_2596<?>> PACKET_CACHE = new HashSet();
    private class_639 address;
    private class_642 info;
    private final PerSecondCounter outgoingCounter = new PerSecondCounter();
    private final PerSecondCounter incomingCounter = new PerSecondCounter();

    public NetworkManager() {
        EventBus.INSTANCE.subscribe(this);
    }

    @EventListener
    public void onConnect(ConnectScreenEvent event) {
        this.address = event.getAddress();
        this.info = event.getInfo();
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        PACKET_CACHE.clear();
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Outbound event) {
        this.outgoingCounter.updateCounter();
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Inbound event) {
        this.incomingCounter.updateCounter();
    }

    public void connect(class_639 address, class_642 info) {
        if (mc.method_1562() == null) {
            return;
        }
        mc.method_1562().method_48296().method_52902(address.method_2952(), address.method_2954(), (class_2896)new class_635(mc.method_1562().method_48296(), mc, info, null, false, null, null, null));
    }

    public void sendPacket(class_2596<?> p) {
        if (mc.method_1562() != null) {
            PACKET_CACHE.add(p);
            mc.method_1562().method_52787(p);
        }
    }

    public void sendQuietPacket(class_2596<?> p) {
        if (mc.method_1562() != null) {
            PACKET_CACHE.add(p);
            ((IClientPlayNetworkHandler)mc.method_1562()).sendQuietPacket(p);
        }
    }

    public void sendSequencedPacket(class_7204 p) {
        if (NetworkManager.mc.field_1687 != null) {
            class_7202 updater = ((AccessorClientWorld)NetworkManager.mc.field_1687).hookGetPendingUpdateManager().method_41937();
            try {
                int i = updater.method_41942();
                class_2596 packet = p.predict(i);
                this.sendPacket(packet);
            }
            catch (Throwable e) {
                e.printStackTrace();
                if (updater != null) {
                    try {
                        updater.close();
                    }
                    catch (Throwable e1) {
                        e1.printStackTrace();
                        e.addSuppressed(e1);
                    }
                }
                throw e;
            }
            if (updater != null) {
                updater.close();
            }
        }
    }

    public int getClientLatency() {
        class_640 playerEntry;
        if (mc.method_1562() != null && (playerEntry = mc.method_1562().method_2871(NetworkManager.mc.field_1724.method_7334().getId())) != null) {
            return playerEntry.method_2959();
        }
        return 0;
    }

    public class_639 getAddress() {
        return this.address;
    }

    public void setAddress(class_639 address) {
        this.address = address;
    }

    public class_642 getInfo() {
        return this.info;
    }

    public void setInfo(class_642 info) {
        this.info = info;
    }

    public boolean isCrystalPvpCC() {
        return this.getServerIp().contains("crystalpvp.cc");
    }

    public boolean is2b2t() {
        return this.getServerIp().contains("2b2t.org");
    }

    public int getOutgoingPPS() {
        return this.outgoingCounter.getPerSecond();
    }

    public int getIncomingPPS() {
        return this.incomingCounter.getPerSecond();
    }

    public String getServerIp() {
        if (this.info != null) {
            return this.info.field_3761;
        }
        return "Singleplayer";
    }

    public boolean isCached(class_2596<?> p) {
        return PACKET_CACHE.contains(p);
    }
}
