package net.hachimi.client.impl.manager.player.interaction;

public interface RotationCallback {
    public void handleRotation(boolean var1, float[] var2);
}
