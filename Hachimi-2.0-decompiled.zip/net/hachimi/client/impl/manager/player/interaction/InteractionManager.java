package net.hachimi.client.impl.manager.player.interaction;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.hachimi.client.impl.manager.player.interaction.RotationCallback;
import net.hachimi.client.impl.module.client.AnticheatModule;
import net.hachimi.client.impl.module.player.AirPlaceModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.player.MovementUtil;
import net.hachimi.client.util.player.RotationUtil;
import net.hachimi.client.util.world.SneakBlocks;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

public final class InteractionManager
implements Globals {
    private final Map<Integer, Integer> placedOnEntities = new ConcurrentHashMap<Integer, Integer>();

    public InteractionManager() {
        EventBus.INSTANCE.subscribe(this);
    }

    public boolean canPlace(class_2338 pos, class_2248 block) {
        class_2680 state = block.method_9564();
        class_265 shape = block.method_9530(state, (class_1922)InteractionManager.mc.field_1687, pos, class_3726.method_16194()).method_1096((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260());
        if (!shape.method_1110()) {
            for (class_1297 entity : InteractionManager.mc.field_1687.method_8335(null, shape.method_1107())) {
                if (entity.method_7325() || !entity.method_5805() || !class_259.method_1074((class_265)shape, (class_265)class_259.method_1078((class_238)entity.method_5829()), (class_247)class_247.field_16896) || entity instanceof class_1533 && (!this.placedOnEntities.containsKey(entity.method_5628()) || this.placedOnEntities.get(entity.method_5628()) <= AnticheatModule.getInstance().getEntityPlaceThreshold())) continue;
                return false;
            }
        }
        return true;
    }

    public boolean placeBlock(class_2338 pos, int slot, boolean strictDirection, boolean clientSwing, RotationCallback rotationCallback) {
        return this.placeBlock(pos, slot, strictDirection, clientSwing, rotationCallback, false);
    }

    public boolean placeBlock(class_2338 pos, int slot, boolean strictDirection, boolean clientSwing, RotationCallback rotationCallback, boolean airPlace) {
        class_2680 airState = class_2246.field_10124.method_9564();
        class_265 shape = airState.method_26172((class_1922)InteractionManager.mc.field_1687, pos, class_3726.method_16194()).method_1096((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260());
        boolean isEntityBlockingPlacement = false;
        if (!shape.method_1110()) {
            for (class_1297 entity : InteractionManager.mc.field_1687.method_8335(null, shape.method_1107())) {
                if (entity.method_7325() || !entity.method_5805() || !class_259.method_1074((class_265)shape, (class_265)class_259.method_1078((class_238)entity.method_5829()), (class_247)class_247.field_16896)) continue;
                if (entity instanceof class_1533) {
                    this.placedOnEntities.compute(entity.method_5628(), (k, attempts) -> attempts != null ? attempts + 1 : 1);
                    if (this.placedOnEntities.getOrDefault(entity.method_5628(), 0) <= AnticheatModule.getInstance().getEntityPlaceThreshold()) continue;
                }
                isEntityBlockingPlacement = true;
                break;
            }
        }
        if (isEntityBlockingPlacement) {
            return false;
        }
        class_2350 direction = this.getInteractDirectionInternal(pos, strictDirection);
        if (airPlace || AirPlaceModule.getInstance().isEnabled() && direction == null) {
            direction = class_2350.field_11033;
            return this.placeBlock(pos, direction, slot, clientSwing, AnticheatModule.getInstance().isGrim(), rotationCallback);
        }
        if (direction == null) {
            return false;
        }
        class_2338 neighbor = pos.method_10093(direction.method_10153());
        return this.placeBlock(neighbor, direction, slot, clientSwing, false, rotationCallback);
    }

    public boolean placeBlock(class_2338 pos, int slot, boolean strictDirection, boolean clientSwing, boolean packet, RotationCallback rotationCallback) {
        return this.placeBlock(pos, slot, strictDirection, clientSwing, packet, false, rotationCallback);
    }

    public boolean placeBlock(class_2338 pos, int slot, boolean strictDirection, boolean clientSwing, boolean packet, boolean airPlace, RotationCallback rotationCallback) {
        class_2680 airState = class_2246.field_10124.method_9564();
        class_265 shape = airState.method_26172((class_1922)InteractionManager.mc.field_1687, pos, class_3726.method_16194()).method_1096((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260());
        boolean isEntityBlockingPlacement = false;
        if (!shape.method_1110()) {
            for (class_1297 entity : InteractionManager.mc.field_1687.method_8335(null, shape.method_1107())) {
                if (entity.method_7325() || !entity.method_5805() || !class_259.method_1074((class_265)shape, (class_265)class_259.method_1078((class_238)entity.method_5829()), (class_247)class_247.field_16896)) continue;
                if (entity instanceof class_1533) {
                    this.placedOnEntities.compute(entity.method_5628(), (k, attempts) -> attempts != null ? attempts + 1 : 1);
                    if (this.placedOnEntities.getOrDefault(entity.method_5628(), 0) <= AnticheatModule.getInstance().getEntityPlaceThreshold()) continue;
                }
                isEntityBlockingPlacement = true;
                break;
            }
        }
        if (isEntityBlockingPlacement) {
            return false;
        }
        class_2350 direction = this.getInteractDirectionInternal(pos, strictDirection);
        if (airPlace || AirPlaceModule.getInstance().isEnabled() && direction == null) {
            direction = class_2350.field_11033;
            return this.placeBlock(pos, direction, slot, clientSwing, AnticheatModule.getInstance().isGrim(), rotationCallback);
        }
        if (direction == null) {
            return false;
        }
        class_2338 neighbor = pos.method_10093(direction.method_10153());
        return this.placeBlock(neighbor, direction, slot, clientSwing, false, packet, rotationCallback);
    }

    public boolean placeBlock(class_2338 pos, class_2350 direction, int slot, boolean clientSwing, boolean grimAirPlace, boolean packet, RotationCallback rotationCallback) {
        class_243 hitVec = pos.method_46558().method_1019(new class_243(direction.method_23955()).method_1021(0.5));
        return this.placeBlock(new class_3965(hitVec, direction, pos, false), slot, clientSwing, grimAirPlace, packet, rotationCallback);
    }

    public boolean placeBlock(class_2338 pos, class_2350 direction, int slot, boolean clientSwing, boolean grimAirPlace, RotationCallback rotationCallback) {
        class_243 hitVec = pos.method_46558().method_1019(new class_243(direction.method_23955()).method_1021(0.5));
        return this.placeBlock(new class_3965(hitVec, direction, pos, false), slot, clientSwing, grimAirPlace, rotationCallback);
    }

    public boolean placeBlock(class_3965 hitResult, int slot, boolean clientSwing, boolean grimAirPlace, boolean packet, RotationCallback rotationCallback) {
        boolean isRotating;
        boolean isSpoofing;
        boolean bl = isSpoofing = slot != Managers.INVENTORY.getServerSlot();
        if (isSpoofing) {
            Managers.INVENTORY.setSlot(slot);
        }
        if (grimAirPlace) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
        }
        boolean bl2 = isRotating = rotationCallback != null;
        if (isRotating) {
            float[] angles = RotationUtil.getRotationsTo(InteractionManager.mc.field_1724.method_33571(), hitResult.method_17784());
            rotationCallback.handleRotation(true, angles);
        }
        boolean result = this.placeBlockImmediately(hitResult, grimAirPlace ? class_1268.field_5810 : class_1268.field_5808, clientSwing, packet);
        if (isRotating) {
            float[] angles = RotationUtil.getRotationsTo(InteractionManager.mc.field_1724.method_33571(), hitResult.method_17784());
            rotationCallback.handleRotation(false, angles);
        }
        if (grimAirPlace) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
        }
        if (isSpoofing) {
            Managers.INVENTORY.syncToClient();
        }
        return result;
    }

    public boolean placeBlock(class_3965 hitResult, int slot, boolean clientSwing, boolean grimAirPlace, RotationCallback rotationCallback) {
        boolean isRotating;
        boolean isSpoofing;
        boolean bl = isSpoofing = slot != Managers.INVENTORY.getServerSlot();
        if (isSpoofing) {
            Managers.INVENTORY.setSlot(slot);
        }
        if (grimAirPlace) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
        }
        boolean bl2 = isRotating = rotationCallback != null;
        if (isRotating) {
            float[] angles = RotationUtil.getRotationsTo(InteractionManager.mc.field_1724.method_33571(), hitResult.method_17784());
            rotationCallback.handleRotation(true, angles);
        }
        boolean result = this.placeBlockImmediately(hitResult, grimAirPlace ? class_1268.field_5810 : class_1268.field_5808, clientSwing, true);
        if (isRotating) {
            float[] angles = RotationUtil.getRotationsTo(InteractionManager.mc.field_1724.method_33571(), hitResult.method_17784());
            rotationCallback.handleRotation(false, angles);
        }
        if (grimAirPlace) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
        }
        if (isSpoofing) {
            Managers.INVENTORY.syncToClient();
        }
        return result;
    }

    public boolean placeBlockImmediately(class_3965 result, class_1268 hand, boolean clientSwing, boolean packet) {
        class_1269 actionResult;
        boolean shouldSneak;
        AnticheatModule ac = AnticheatModule.getInstance();
        class_2680 state = InteractionManager.mc.field_1687.method_8320(result.method_17777());
        boolean bl = shouldSneak = (ac.isSneakingSpoof() || SneakBlocks.isSneakBlock(state)) && !InteractionManager.mc.field_1724.method_5715();
        if (shouldSneak) {
            Managers.MOVEMENT.setPacketSneaking(true);
            MovementUtil.applySneak();
        }
        boolean usePacket = packet || ac.getPlacePacketMode() == AnticheatModule.PlacePacketMode.Packet;
        class_1269 class_12692 = actionResult = usePacket ? this.placeBlockPacket(result, hand) : this.placeBlockInternally(result, hand);
        if (actionResult.method_23665() && actionResult.method_23666()) {
            switch (ac.getPlaceSwing()) {
                case Normal: {
                    if (clientSwing) {
                        InteractionManager.mc.field_1724.method_6104(class_1268.field_5808);
                        break;
                    }
                    Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
                    break;
                }
                case Packet: {
                    Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
                    break;
                }
            }
        }
        if (shouldSneak) {
            Managers.MOVEMENT.setPacketSneaking(false);
        }
        return actionResult.method_23665();
    }

    private class_1269 placeBlockInternally(class_3965 hitResult, class_1268 hand) {
        return InteractionManager.mc.field_1761.method_2896(InteractionManager.mc.field_1724, hand, hitResult);
    }

    public class_1269 placeBlockPacket(class_3965 hitResult, class_1268 hand) {
        Managers.NETWORK.sendSequencedPacket(id -> new class_2885(hand, hitResult, id));
        return class_1269.field_5812;
    }

    public class_2350 getInteractDirection(class_2338 blockPos, boolean strictDirection) {
        class_2350 direction = this.getInteractDirectionInternal(blockPos, strictDirection);
        return direction == null ? class_2350.field_11036 : direction;
    }

    public class_2350 getInteractDirectionInternal(class_2338 blockPos, boolean strictDirection) {
        class_2350[] candidates;
        AnticheatModule ac = AnticheatModule.getInstance();
        class_243 eyePos = InteractionManager.mc.field_1724.method_33571();
        Set<class_2350> validDirections = this.getPlaceDirectionsNCP(eyePos, blockPos.method_46558());
        class_2350 interactDirection = null;
        double bestDot = -2.0;
        for (class_2350 direction : candidates = class_2350.values()) {
            class_2680 state = InteractionManager.mc.field_1687.method_8320(blockPos.method_10093(direction));
            if (state.method_26215() || !state.method_26227().method_15769() || state.method_26204() == class_2246.field_10535 || state.method_26204() == class_2246.field_10105 || state.method_26204() == class_2246.field_10414 || strictDirection && !validDirections.contains(direction.method_10153())) continue;
            if (ac.isClosestDirection()) {
                class_243 normal;
                class_243 faceCenter = blockPos.method_10093(direction).method_46558();
                class_243 toEye = eyePos.method_1020(faceCenter).method_1029();
                double dot = toEye.method_1026(normal = new class_243(direction.method_23955()));
                if (!(dot > bestDot)) continue;
                bestDot = dot;
                interactDirection = direction;
                continue;
            }
            interactDirection = direction;
            break;
        }
        if (interactDirection == null) {
            return null;
        }
        return interactDirection.method_10153();
    }

    public class_2350 getPlaceDirectionNCP(class_2338 blockPos, boolean visible) {
        class_243 eyePos = new class_243(InteractionManager.mc.field_1724.method_23317(), InteractionManager.mc.field_1724.method_23318() + (double)InteractionManager.mc.field_1724.method_5751(), InteractionManager.mc.field_1724.method_23321());
        if ((double)blockPos.method_10263() == eyePos.method_10216() && (double)blockPos.method_10264() == eyePos.method_10214() && (double)blockPos.method_10260() == eyePos.method_10215()) {
            return class_2350.field_11033;
        }
        Set<class_2350> ncpDirections = this.getPlaceDirectionsNCP(eyePos, blockPos.method_46558());
        for (class_2350 dir : ncpDirections) {
            if (visible && !InteractionManager.mc.field_1687.method_22347(blockPos.method_10093(dir))) continue;
            return dir;
        }
        return class_2350.field_11036;
    }

    public Set<class_2350> getPlaceDirectionsNCP(class_243 eyePos, class_243 blockPos) {
        return this.getPlaceDirectionsNCP(eyePos.field_1352, eyePos.field_1351, eyePos.field_1350, blockPos.field_1352, blockPos.field_1351, blockPos.field_1350);
    }

    public Set<class_2350> getPlaceDirectionsNCP(double x, double y, double z, double dx, double dy, double dz) {
        double xdiff = x - dx;
        double ydiff = y - dy;
        double zdiff = z - dz;
        HashSet<class_2350> dirs = new HashSet<class_2350>(6);
        if (ydiff > 0.5) {
            dirs.add(class_2350.field_11036);
        } else if (ydiff < -0.5) {
            dirs.add(class_2350.field_11033);
        } else {
            dirs.add(class_2350.field_11036);
            dirs.add(class_2350.field_11033);
        }
        if (xdiff > 0.5) {
            dirs.add(class_2350.field_11034);
        } else if (xdiff < -0.5) {
            dirs.add(class_2350.field_11039);
        } else {
            dirs.add(class_2350.field_11034);
            dirs.add(class_2350.field_11039);
        }
        if (zdiff > 0.5) {
            dirs.add(class_2350.field_11035);
        } else if (zdiff < -0.5) {
            dirs.add(class_2350.field_11043);
        } else {
            dirs.add(class_2350.field_11035);
            dirs.add(class_2350.field_11043);
        }
        return dirs;
    }

    public boolean isInEyeRange(class_2338 pos) {
        return (double)pos.method_10264() > InteractionManager.mc.field_1724.method_23318() + (double)InteractionManager.mc.field_1724.method_5751();
    }
}
