package net.hachimi.client.impl.manager.combat.hole;

import io.netty.util.internal.ConcurrentSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.manager.combat.hole.Hole;
import net.hachimi.client.impl.manager.combat.hole.HoleType;
import net.hachimi.client.impl.module.render.HoleESPModule;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.world.BlastResistantBlocks;
import net.hachimi.client.util.world.BlockUtil;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;

public class HoleManager
implements Globals {
    private final ExecutorService executor = Executors.newFixedThreadPool(1);
    private Future<Set<Hole>> result;
    private Set<Hole> holes = new ConcurrentSet();

    public HoleManager() {
        EventBus.INSTANCE.subscribe(this);
    }

    @EventListener
    public void onTickEvent(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        HoleTask runnable = new HoleTask(this.getSphere(HoleManager.mc.field_1724.method_19538()));
        this.result = this.executor.submit(runnable);
    }

    public List<class_2338> getSphere(class_243 start) {
        ArrayList<class_2338> sphere = new ArrayList<class_2338>();
        double rad = Math.ceil(Math.max(5.0, HoleESPModule.getInstance().getRange()));
        for (double x = -rad; x <= rad; x += 1.0) {
            for (double y = -rad; y <= rad; y += 1.0) {
                for (double z = -rad; z <= rad; z += 1.0) {
                    class_2382 pos = new class_2382((int)(start.method_10216() + x), (int)(start.method_10214() + y), (int)(start.method_10215() + z));
                    class_2338 p = new class_2338(pos);
                    sphere.add(p);
                }
            }
        }
        return sphere;
    }

    public Hole checkHole(class_2338 pos) {
        if (pos.method_10264() == HoleManager.mc.field_1687.method_31607() && !BlastResistantBlocks.isUnbreakable(pos)) {
            return new Hole(pos, HoleType.VOID, new class_2338[0]);
        }
        int resistant = 0;
        int unbreakable = 0;
        if (BlockUtil.isBlockAccessible(pos)) {
            class_2338 pos1 = pos.method_10069(-1, 0, 0);
            class_2338 pos2 = pos.method_10069(0, 0, -1);
            if (BlastResistantBlocks.isBlastResistant(pos1)) {
                ++resistant;
            } else if (BlastResistantBlocks.isUnbreakable(pos1)) {
                ++unbreakable;
            }
            if (BlastResistantBlocks.isBlastResistant(pos2)) {
                ++resistant;
            } else if (BlastResistantBlocks.isUnbreakable(pos2)) {
                ++unbreakable;
            }
            if (resistant + unbreakable < 2) {
                return null;
            }
            class_2338 pos3 = pos.method_10069(0, 0, 1);
            class_2338 pos4 = pos.method_10069(1, 0, 0);
            boolean air3 = HoleManager.mc.field_1687.method_22347(pos3);
            boolean air4 = HoleManager.mc.field_1687.method_22347(pos4);
            if (air3 && air4) {
                class_2338[] quad;
                class_2338 pos5 = pos.method_10069(1, 0, 1);
                if (!HoleManager.mc.field_1687.method_22347(pos5)) {
                    return null;
                }
                for (class_2338 p : quad = new class_2338[]{pos.method_10069(-1, 0, 1), pos.method_10069(0, 0, 2), pos.method_10069(1, 0, 2), pos.method_10069(2, 0, 1), pos.method_10069(2, 0, 0), pos.method_10069(1, 0, -1)}) {
                    if (BlastResistantBlocks.isBlastResistant(p)) {
                        ++resistant;
                        continue;
                    }
                    if (!BlastResistantBlocks.isUnbreakable(p)) continue;
                    ++unbreakable;
                }
                if (resistant != 8 && unbreakable != 8 && resistant + unbreakable != 8) {
                    return null;
                }
                Hole quadHole = new Hole(pos, resistant == 8 ? HoleType.OBSIDIAN : (unbreakable == 8 ? HoleType.BEDROCK : HoleType.OBSIDIAN_BEDROCK), pos1, pos2, pos3, pos4, pos5);
                quadHole.addHoleOffsets(quad);
                return quadHole;
            }
            if (air3 && BlockUtil.isBlockAccessible(pos3)) {
                class_2338[] doubleZ;
                for (class_2338 p : doubleZ = new class_2338[]{pos.method_10069(-1, 0, 1), pos.method_10069(0, 0, 2), pos.method_10069(1, 0, 1), pos.method_10069(1, 0, 0)}) {
                    if (BlastResistantBlocks.isBlastResistant(p)) {
                        ++resistant;
                        continue;
                    }
                    if (!BlastResistantBlocks.isUnbreakable(p)) continue;
                    ++unbreakable;
                }
                if (resistant != 6 && unbreakable != 6 && resistant + unbreakable != 6) {
                    return null;
                }
                Hole doubleZHole = new Hole(pos, resistant == 6 ? HoleType.OBSIDIAN : (unbreakable == 6 ? HoleType.BEDROCK : HoleType.OBSIDIAN_BEDROCK), pos1, pos2, pos3);
                doubleZHole.addHoleOffsets(doubleZ);
                return doubleZHole;
            }
            if (air4 && BlockUtil.isBlockAccessible(pos4)) {
                class_2338[] doubleX;
                for (class_2338 p : doubleX = new class_2338[]{pos.method_10069(0, 0, 1), pos.method_10069(1, 0, 1), pos.method_10069(2, 0, 0), pos.method_10069(1, 0, -1)}) {
                    if (BlastResistantBlocks.isBlastResistant(p)) {
                        ++resistant;
                        continue;
                    }
                    if (!BlastResistantBlocks.isUnbreakable(p)) continue;
                    ++unbreakable;
                }
                if (resistant != 6 && unbreakable != 6 && resistant + unbreakable != 6) {
                    return null;
                }
                Hole doubleXHole = new Hole(pos, resistant == 6 ? HoleType.OBSIDIAN : (unbreakable == 6 ? HoleType.BEDROCK : HoleType.OBSIDIAN_BEDROCK), pos1, pos2, pos4);
                doubleXHole.addHoleOffsets(doubleX);
                return doubleXHole;
            }
            if (BlastResistantBlocks.isBlastResistant(pos3)) {
                ++resistant;
            } else if (BlastResistantBlocks.isUnbreakable(pos3)) {
                ++unbreakable;
            }
            if (BlastResistantBlocks.isBlastResistant(pos4)) {
                ++resistant;
            } else if (BlastResistantBlocks.isUnbreakable(pos4)) {
                ++unbreakable;
            }
            if (resistant != 4 && unbreakable != 4 && resistant + unbreakable != 4) {
                return null;
            }
            return new Hole(pos, resistant == 4 ? HoleType.OBSIDIAN : (unbreakable == 4 ? HoleType.BEDROCK : HoleType.OBSIDIAN_BEDROCK), pos1, pos2, pos3, pos4);
        }
        return null;
    }

    public Set<Hole> getHoles() {
        if (this.result != null) {
            try {
                this.holes = this.result.get();
            }
            catch (InterruptedException | ExecutionException exception) {
                // empty catch block
            }
        }
        return this.holes;
    }

    public class HoleTask
    implements Callable<Set<Hole>> {
        private final List<class_2338> blocks;

        public HoleTask(List<class_2338> blocks) {
            this.blocks = blocks;
        }

        @Override
        public Set<Hole> call() throws Exception {
            HashSet<Hole> holes1 = new HashSet<Hole>();
            for (class_2338 blockPos : this.blocks) {
                Hole hole = HoleManager.this.checkHole(blockPos);
                if (hole == null) continue;
                holes1.add(hole);
            }
            return holes1;
        }
    }
}
