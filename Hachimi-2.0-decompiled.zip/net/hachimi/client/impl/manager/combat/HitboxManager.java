package net.hachimi.client.impl.manager.combat;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2739;
import net.minecraft.class_2945;
import net.minecraft.class_4050;

public class HitboxManager
implements Globals {
    private final List<class_1297> serverCrawling = new CopyOnWriteArrayList<class_1297>();

    public HitboxManager() {
        EventBus.INSTANCE.subscribe(this);
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (HitboxManager.mc.field_1724 == null || HitboxManager.mc.field_1687 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2739) {
            class_2739 packet = (class_2739)class_25962;
            class_1297 entity = HitboxManager.mc.field_1687.method_8469(packet.comp_1127());
            if (!(entity instanceof class_1657)) {
                return;
            }
            for (class_2945.class_7834 serializedEntry : packet.comp_1128()) {
                class_2945.class_2946 entry = entity.method_5841().field_13331[serializedEntry.comp_1115()];
                if (!entry.method_12797().equals((Object)class_1297.field_18064)) continue;
                if (!serializedEntry.comp_1117().equals(class_4050.field_18079)) {
                    this.serverCrawling.remove(entity);
                    continue;
                }
                if (this.serverCrawling.contains(entity)) continue;
                this.serverCrawling.add(entity);
            }
        }
    }

    public boolean isServerCrawling(class_1297 entity) {
        return this.serverCrawling.contains(entity);
    }

    public class_238 getCrawlingBoundingBox(class_1297 entity) {
        return entity.method_18377(class_4050.field_18079).method_30757(entity.method_19538());
    }
}
