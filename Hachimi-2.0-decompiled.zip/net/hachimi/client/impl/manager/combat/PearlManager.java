package net.hachimi.client.impl.manager.combat;

import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.module.exploit.PhaseModule;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.player.RayCastUtil;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2793;
import net.minecraft.class_2828;
import net.minecraft.class_3965;

public class PearlManager
implements Globals {
    private float[] lastThrownAngles;
    private class_238 pearlBB;

    public PearlManager() {
        EventBus.INSTANCE.subscribe(this);
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (PearlManager.mc.field_1724 == null || !PhaseModule.getInstance().shouldRaytrace()) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2708) {
            class_2708 packet = (class_2708)class_25962;
            if (this.lastThrownAngles != null) {
                class_3965 hitResult = (class_3965)RayCastUtil.rayCast(3.0, this.lastThrownAngles);
                this.pearlBB = new class_238(hitResult.method_17784().method_1023(0.4, 0.4, 0.4), hitResult.method_17784().method_1031(0.4, 0.4, 0.4));
                if (PearlManager.mc.field_1687.method_8320(hitResult.method_17777()).method_26215()) {
                    return;
                }
                if (!this.pearlBB.method_1008(packet.method_11734(), packet.method_11735(), packet.method_11738())) {
                    event.cancel();
                    mc.method_1562().method_48296().method_10743((class_2596)new class_2793(packet.method_11737()));
                    mc.method_1562().method_48296().method_10743((class_2596)new class_2828.class_2830(PearlManager.mc.field_1724.method_23317(), PearlManager.mc.field_1724.method_23318(), PearlManager.mc.field_1724.method_23321(), PearlManager.mc.field_1724.method_36454(), PearlManager.mc.field_1724.method_36455(), false));
                }
                this.lastThrownAngles = null;
            }
        }
    }

    public void setLastThrownAngles(float[] lastThrownAngles) {
        this.lastThrownAngles = lastThrownAngles;
    }
}
