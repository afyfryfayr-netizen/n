package net.hachimi.client.impl.manager.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.hachimi.client.api.social.SocialRelation;
import net.hachimi.client.impl.module.client.SocialsModule;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2561;
import net.minecraft.class_640;

public class SocialManager
implements Globals {
    private final ConcurrentMap<String, SocialRelation> relationships = new ConcurrentHashMap<String, SocialRelation>();

    public boolean isRelation(String name, SocialRelation relation) {
        return this.relationships.get(name) == relation;
    }

    public boolean isFriend(String name) {
        if (!SocialsModule.getInstance().isFriendsEnabled()) {
            return false;
        }
        return this.isRelation(name, SocialRelation.FRIEND);
    }

    public boolean isFriendInternal(String name) {
        return this.isRelation(name, SocialRelation.FRIEND);
    }

    public boolean isFriend(class_2561 name) {
        if (!SocialsModule.getInstance().isFriendsEnabled()) {
            return false;
        }
        return name != null && this.isRelation(name.getString(), SocialRelation.FRIEND);
    }

    public void addRelation(String name, SocialRelation relation) {
        if (SocialManager.mc.field_1724 != null && name.equals(SocialManager.mc.field_1724.method_5476().getString())) {
            return;
        }
        SocialRelation relationship = (SocialRelation)((Object)this.relationships.get(name));
        if (relationship != null) {
            this.relationships.replace(name, relation);
            return;
        }
        this.relationships.put(name, relation);
    }

    public void addFriend(String name) {
        this.addRelation(name, SocialRelation.FRIEND);
        if (SocialsModule.getInstance().shouldNotify() && SocialManager.mc.field_1687 != null) {
            Collection playerListEntries = SocialManager.mc.field_1724.field_3944.method_2880();
            block0: for (class_640 playerListEntry : playerListEntries) {
                String[] names;
                String playerName = playerListEntry.method_2966().getName();
                for (String name1 : names = playerName.split(" ")) {
                    if (!name1.equals(name)) continue;
                    ChatUtil.serverSendCommand("msg " + name + " I just added you as a friend on Hachimi!");
                    continue block0;
                }
            }
        }
    }

    public void addFriend(class_2561 name) {
        this.addFriend(name.getString());
    }

    public SocialRelation remove(String playerName) {
        return (SocialRelation)((Object)this.relationships.remove(playerName));
    }

    public SocialRelation remove(class_2561 playerName) {
        return (SocialRelation)((Object)this.relationships.remove(playerName.getString()));
    }

    public Collection<String> getRelations(SocialRelation relation) {
        ArrayList<String> friends = new ArrayList<String>();
        for (Map.Entry relationship : this.relationships.entrySet()) {
            if (relationship.getValue() != relation) continue;
            friends.add((String)relationship.getKey());
        }
        return friends;
    }

    public Collection<String> getFriends() {
        return this.getRelations(SocialRelation.FRIEND);
    }
}
