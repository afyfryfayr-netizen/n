package net.hachimi.client.impl.manager.client.cape;

import com.mojang.authlib.GameProfile;
import java.io.InputStream;
import java.net.URL;
import net.hachimi.client.impl.event.network.LoadCapeEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_156;
import net.minecraft.class_2960;

public class CapeManager
implements Globals {
    public CapeManager() {
        EventBus.INSTANCE.subscribe(this);
    }

    @EventListener
    public void onLoadCape(LoadCapeEvent event) {
        this.loadPlayerCape(event.getGameProfile(), event.getTexture());
    }

    public void loadPlayerCape(GameProfile profile, CapeTexture texture) {
        class_156.method_18349().execute(() -> {
            String uuid = profile.getId().toString();
            String url = String.format("http://s.optifine.net/capes/%s.png", profile.getName());
            try {
                URL optifineUrl = new URL(url);
                InputStream stream = optifineUrl.openStream();
                class_1011 cape = class_1011.method_4309((InputStream)stream);
                class_1011 nativeImage = this.imageFromStream(cape);
                class_1043 t = new class_1043(nativeImage);
                class_2960 identifier = mc.method_1531().method_4617("of-capes-" + uuid, t);
                texture.callback(identifier);
                stream.close();
            }
            catch (Exception exception) {
                // empty catch block
            }
        });
    }

    private class_1011 imageFromStream(class_1011 image) {
        int imageHeight;
        int imageWidth = 64;
        int imageSrcWidth = image.method_4307();
        int srcHeight = image.method_4323();
        int imageSrcHeight = image.method_4323();
        for (imageHeight = 32; imageWidth < imageSrcWidth || imageHeight < imageSrcHeight; imageWidth *= 2, imageHeight *= 2) {
        }
        class_1011 img = new class_1011(imageWidth, imageHeight, true);
        for (int x = 0; x < imageSrcWidth; ++x) {
            for (int y = 0; y < srcHeight; ++y) {
                img.method_4305(x, y, image.method_4315(x, y));
            }
        }
        image.close();
        return img;
    }

    public static interface CapeTexture {
        public void callback(class_2960 var1);
    }
}
