package net.hachimi.client.impl.module.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BlockListConfig;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.AttackBlockEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.player.SpeedmineModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.timer.TickTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.RotationUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2879;

public final class AutoMineModule
extends ToggleModule {
    public static AutoMineModule INSTANCE;
    private final Config<SelectionMode> selection = this.register(new EnumConfig("Selection", "Block filter mode", (Enum)SelectionMode.BLACKLIST, (Enum[])SelectionMode.values()));
    private final Config<List<class_2248>> whitelist = this.register(new BlockListConfig("Whitelist", "Blocks to mine (whitelist mode)", class_2246.field_10540, class_2246.field_10443));
    private final Config<List<class_2248>> blacklist = this.register(new BlockListConfig("Blacklist", "Blocks to skip (blacklist mode)", class_2246.field_9987, class_2246.field_9983, class_2246.field_16492, class_2246.field_10036, class_2246.field_10343, class_2246.field_10120, class_2246.field_10410, class_2246.field_10230, class_2246.field_10621, class_2246.field_10356, class_2246.field_10180, class_2246.field_10610, class_2246.field_10141, class_2246.field_10326, class_2246.field_10109, class_2246.field_10019, class_2246.field_10527, class_2246.field_10288, class_2246.field_10561, class_2246.field_10069, class_2246.field_10461));
    private final Config<Float> targetRange = this.register(new NumberConfig<Float>("TargetRange", "Range to find target", Float.valueOf(1.0f), Float.valueOf(6.0f), Float.valueOf(12.0f)));
    private final Config<Float> mineRange = this.register(new NumberConfig<Float>("MineRange", "Range to mine blocks", Float.valueOf(1.0f), Float.valueOf(6.0f), Float.valueOf(6.0f)));
    private final Config<SortMode> sort = this.register(new EnumConfig("Sort", "Target sorting", (Enum)SortMode.LOWEST_DISTANCE, (Enum[])SortMode.values()));
    private final Config<Boolean> wait = this.register(new BooleanConfig("Wait", "Wait for block to break before mining next", true));
    private final Config<Boolean> burrow = this.register(new BooleanConfig("Burrow", "Mine block player is standing inside", true));
    private final Config<Boolean> surround = this.register(new BooleanConfig("Surround", "Mine surround blocks around enemy", true));
    private final Config<Boolean> under = this.register(new BooleanConfig("Under", "Mine block below target's feet", false));
    private final Config<Boolean> face = this.register(new BooleanConfig("Face", "Rotate to block before mining", false));
    private final Config<Integer> priority = this.register(new NumberConfig<Integer>("Priority", "Mining priority (higher = mine first)", 0, 8, 10));
    private static final Set<class_2248> ALWAYS_SKIP;
    private final Timer tickTimer = new TickTimer();
    private final Map<class_2338, class_2350> miningMap = new LinkedHashMap<class_2338, class_2350>();
    private class_1657 currentTarget;
    private class_2338 lastMinePos;
    private class_2338 manualMinePos;
    private boolean silentSwapping = false;

    public AutoMineModule() {
        super("AutoMine", "Automatically mine blocks around enemies", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static AutoMineModule getInstance() {
        return INSTANCE;
    }

    public class_2338 getMiningBlock() {
        return this.lastMinePos;
    }

    public boolean isSilentSwapping() {
        return this.silentSwapping;
    }

    @Override
    public void onEnable() {
        this.miningMap.clear();
        this.currentTarget = null;
        this.lastMinePos = null;
        this.manualMinePos = null;
        this.silentSwapping = false;
    }

    @Override
    public void onDisable() {
        for (Map.Entry<class_2338, class_2350> e : this.miningMap.entrySet()) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, e.getKey(), e.getValue()));
        }
        this.miningMap.clear();
        this.currentTarget = null;
        this.lastMinePos = null;
        this.manualMinePos = null;
        this.silentSwapping = false;
    }

    @EventListener
    public void onAttackBlock(AttackBlockEvent event) {
        if (AutoMineModule.mc.field_1724 == null || AutoMineModule.mc.field_1687 == null) {
            return;
        }
        class_2338 pos = event.getPos();
        if (this.lastMinePos != null && pos.equals((Object)this.lastMinePos)) {
            return;
        }
        this.manualMinePos = pos;
        if (this.lastMinePos != null && this.miningMap.containsKey(this.lastMinePos) && !this.lastMinePos.equals((Object)pos)) {
            class_2350 dir = this.miningMap.remove(this.lastMinePos);
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, this.lastMinePos, dir));
            this.lastMinePos = null;
        }
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (AutoMineModule.mc.field_1724 == null || AutoMineModule.mc.field_1687 == null) {
            return;
        }
        this.miningMap.entrySet().removeIf(e -> AutoMineModule.mc.field_1687.method_8320((class_2338)e.getKey()).method_26215());
        if (this.manualMinePos != null) {
            boolean stillMining;
            class_2680 manualState = AutoMineModule.mc.field_1687.method_8320(this.manualMinePos);
            boolean bl = stillMining = !manualState.method_26215() && AutoMineModule.mc.field_1724.method_5707(this.manualMinePos.method_46558()) <= (double)(this.mineRange.getValue().floatValue() * this.mineRange.getValue().floatValue());
            if (stillMining) {
                return;
            }
            this.manualMinePos = null;
        }
        this.currentTarget = this.getBestTarget();
        if (this.wait.getValue().booleanValue() && this.lastMinePos != null && this.miningMap.containsKey(this.lastMinePos) && this.isStillMinable(this.lastMinePos)) {
            this.doMine(this.lastMinePos);
            return;
        }
        if (this.currentTarget == null) {
            if (!this.miningMap.isEmpty()) {
                this.abortAll();
            }
            this.lastMinePos = null;
            return;
        }
        List<class_2338> toMine = this.getBlocksToMine(this.currentTarget);
        if (toMine.isEmpty()) {
            if (!this.miningMap.isEmpty()) {
                this.abortAll();
            }
            this.lastMinePos = null;
            return;
        }
        if (this.wait.getValue().booleanValue()) {
            if (this.lastMinePos != null && !AutoMineModule.mc.field_1687.method_8320(this.lastMinePos).method_26215() && this.miningMap.containsKey(this.lastMinePos)) {
                this.doMine(this.lastMinePos);
                return;
            }
            class_2338 next = toMine.stream().filter(p -> !this.miningMap.containsKey(p)).findFirst().orElse(null);
            if (next == null) {
                return;
            }
            this.doMine(next);
        } else {
            for (class_2338 pos : toMine) {
                this.doMine(pos);
            }
        }
    }

    private void doMine(class_2338 pos) {
        SpeedmineModule speedmine;
        if (AutoMineModule.mc.field_1687.method_8320(pos).method_26215()) {
            return;
        }
        class_2350 bestFace = this.getBestFace(pos);
        if (this.face.getValue().booleanValue()) {
            float[] rot = RotationUtil.getRotationsTo(AutoMineModule.mc.field_1724.method_33571(), pos.method_46558().method_1031((double)bestFace.method_10148() * 0.5, (double)bestFace.method_10164() * 0.5, (double)bestFace.method_10165() * 0.5));
            this.silentSwapping = true;
            Managers.ROTATION.setRotationSilent(rot[0], rot[1]);
            this.silentSwapping = false;
        }
        if ((speedmine = SpeedmineModule.getInstance()) != null && speedmine.isEnabled()) {
            speedmine.clickMine(new SpeedmineModule.MiningData(pos, bestFace));
            this.miningMap.putIfAbsent(pos, bestFace);
            this.lastMinePos = pos;
            return;
        }
        if (!this.miningMap.containsKey(pos)) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12968, pos, bestFace));
            this.miningMap.put(pos, bestFace);
        }
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, pos, bestFace));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        this.lastMinePos = pos;
    }

    private void abortAll() {
        for (Map.Entry<class_2338, class_2350> e : this.miningMap.entrySet()) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, e.getKey(), e.getValue()));
        }
        this.miningMap.clear();
    }

    private List<class_2338> getBlocksToMine(class_1657 target) {
        ArrayList<Object> candidates = new ArrayList<Object>();
        class_2338 feet = target.method_24515();
        if (this.burrow.getValue().booleanValue() && this.isBurrowed(target, feet) && this.isValid(feet)) {
            candidates.add(feet);
        }
        if (this.surround.getValue().booleanValue()) {
            ArrayList<class_2338> sides = new ArrayList<class_2338>();
            for (class_2350 dir : class_2350.class_2353.field_11062) {
                class_2338 side = feet.method_10093(dir);
                if (!this.isValid(side)) continue;
                sides.add(side);
            }
            sides.sort(Comparator.comparingDouble(p -> AutoMineModule.mc.field_1724.method_5707(p.method_46558())));
            candidates.addAll(sides);
        }
        class_2338 under = feet.method_10074();
        if (this.under.getValue().booleanValue() && this.isValid(under) && !candidates.contains(under)) {
            candidates.add(under);
        }
        double maxDistSq = this.mineRange.getValue().floatValue() * this.mineRange.getValue().floatValue();
        return candidates.stream().filter(p -> AutoMineModule.mc.field_1724.method_5707(p.method_46558()) <= maxDistSq).collect(Collectors.toList());
    }

    private boolean isStillMinable(class_2338 pos) {
        if (AutoMineModule.mc.field_1687.method_8320(pos).method_26215()) {
            return false;
        }
        return AutoMineModule.mc.field_1724.method_5707(pos.method_46558()) <= (double)(this.mineRange.getValue().floatValue() * this.mineRange.getValue().floatValue());
    }

    private boolean isBurrowed(class_1657 player, class_2338 feet) {
        return !AutoMineModule.mc.field_1687.method_8320(feet).method_26215() && player.method_5829().method_994(new class_238(feet));
    }

    private boolean isValid(class_2338 pos) {
        class_2680 state = AutoMineModule.mc.field_1687.method_8320(pos);
        if (state.method_26215()) {
            return false;
        }
        class_2248 block = state.method_26204();
        if (ALWAYS_SKIP.contains(block)) {
            return false;
        }
        if (state.method_26214((class_1922)AutoMineModule.mc.field_1687, pos) < 0.0f) {
            return false;
        }
        return switch (this.selection.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 1 -> this.whitelist.getValue().contains(block);
            case 2 -> {
                if (!this.blacklist.getValue().contains(block)) {
                    yield true;
                }
                yield false;
            }
            case 0 -> true;
        };
    }

    private class_2350 getBestFace(class_2338 pos) {
        class_2350 best = class_2350.field_11036;
        double min = Double.MAX_VALUE;
        for (class_2350 d : class_2350.values()) {
            double dist = AutoMineModule.mc.field_1724.method_33571().method_1025(pos.method_46558().method_1031((double)d.method_10148() * 0.5, (double)d.method_10164() * 0.5, (double)d.method_10165() * 0.5));
            if (!(dist < min)) continue;
            min = dist;
            best = d;
        }
        return best;
    }

    private class_1657 getBestTarget() {
        double r = this.targetRange.getValue().floatValue();
        return AutoMineModule.mc.field_1687.method_18456().stream().filter(p -> p != AutoMineModule.mc.field_1724).filter(p -> !p.method_7325() && !p.method_29504()).filter(p -> !Managers.SOCIAL.isFriend(p.method_5477().getString())).filter(p -> AutoMineModule.mc.field_1724.method_5858((class_1297)p) <= r * r).min(this.getComparator()).orElse(null);
    }

    private Comparator<class_1657> getComparator() {
        return switch (this.sort.getValue().ordinal()) {
            case 1 -> Comparator.comparingDouble(p -> p.method_6032() + p.method_6067());
            case 2 -> Comparator.comparingDouble(this::getAngleTo);
            default -> Comparator.comparingDouble(p -> AutoMineModule.mc.field_1724.method_5858((class_1297)p));
        };
    }

    private double getAngleTo(class_1657 target) {
        float[] rot = RotationUtil.getRotationsTo(AutoMineModule.mc.field_1724.method_33571(), target.method_33571());
        float deltaYaw = Math.abs(rot[0] - AutoMineModule.mc.field_1724.method_36454()) % 360.0f;
        if (deltaYaw > 180.0f) {
            deltaYaw = 360.0f - deltaYaw;
        }
        return deltaYaw + Math.abs(rot[1] - AutoMineModule.mc.field_1724.method_36455());
    }

    static {
        ALWAYS_SKIP = Set.of(class_2246.field_9987, class_2246.field_10499, class_2246.field_10525, class_2246.field_10395, class_2246.field_10263, class_2246.field_10465, class_2246.field_16540, class_2246.field_10036, class_2246.field_10124, class_2246.field_10243, class_2246.field_10543);
    }

    public static enum SelectionMode {
        ANY,
        WHITELIST,
        BLACKLIST;

    }

    public static enum SortMode {
        LOWEST_DISTANCE,
        LOWEST_HEALTH,
        CLOSEST_ANGLE;

    }
}
