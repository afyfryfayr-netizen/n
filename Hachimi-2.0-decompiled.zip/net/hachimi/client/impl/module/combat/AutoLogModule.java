package net.hachimi.client.impl.module.combat;

import java.time.Instant;
import java.util.BitSet;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.network.GameJoinEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.FakePlayerEntity;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.InventoryUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2797;
import net.minecraft.class_3515;
import net.minecraft.class_742;
import net.minecraft.class_7635;

public class AutoLogModule
extends ToggleModule {
    Config<Float> healthConfig = this.register(new NumberConfig<Float>("Health", "Disconnects when player reaches this health", Float.valueOf(0.1f), Float.valueOf(5.0f), Float.valueOf(19.0f)));
    Config<Boolean> healthTotemConfig = this.register(new BooleanConfig("HealthTotems", "Totem check for health config", true));
    Config<Boolean> onRenderConfig = this.register(new BooleanConfig("OnRender", "Disconnects when a player enters render distance", false));
    Config<Boolean> noTotemConfig = this.register(new BooleanConfig("NoTotems", "Disconnects when player has no totems in the inventory", false));
    Config<Integer> totemsConfig = this.register(new NumberConfig<Integer>("Totems", "The number of totems before disconnecting", 0, 1, 5));
    Config<Boolean> invincibilityConfig = this.register(new BooleanConfig("SpawnInvincibility", "Accounts for spawn invincibility for logout", false));
    Config<Float> invincibilityTimeConfig = this.register(new NumberConfig<Float>("InvincibilityTime", "The spawn invincibility time ", Float.valueOf(0.1f), Float.valueOf(2.9f), Float.valueOf(5.0f), () -> this.invincibilityConfig.getValue()));
    Config<Boolean> illegalDisconnectConfig = this.register(new BooleanConfig("IllegalDisconnect", "Disconnects from the server using invalid packets", false));
    Config<Boolean> autoDisableConfig = this.register(new BooleanConfig("AutoDisable", "Automatically disables", true));
    private final Timer invincibilityTimer = new CacheTimer();

    public AutoLogModule() {
        super("AutoLog", "Automatically disconnects from server during combat", ModuleCategory.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent event) {
        boolean b2;
        class_742 player;
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (this.invincibilityConfig.getValue().booleanValue() && !this.invincibilityTimer.passed(Float.valueOf(this.invincibilityTimeConfig.getValue().floatValue() * 1000.0f))) {
            return;
        }
        if (this.onRenderConfig.getValue().booleanValue() && (player = (class_742)AutoLogModule.mc.field_1687.method_18456().stream().filter(p -> this.checkEnemy((class_742)p)).findFirst().orElse(null)) != null) {
            this.playerDisconnect("[AutoLog] %s came into render distance.", player.method_5477().getString());
            return;
        }
        float health = AutoLogModule.mc.field_1724.method_6032() + AutoLogModule.mc.field_1724.method_6067();
        int totems = InventoryUtil.count(class_1802.field_8288);
        boolean bl = b2 = totems <= this.totemsConfig.getValue();
        if (health <= this.healthConfig.getValue().floatValue()) {
            if (!this.healthTotemConfig.getValue().booleanValue()) {
                this.playerDisconnect("[AutoLog] logged out with %d hearts remaining.", (int)health);
                return;
            }
            if (b2) {
                this.playerDisconnect("[AutoLog] logged out with %d totems and %d hearts remaining.", totems, (int)health);
                return;
            }
        }
        if (b2 && this.noTotemConfig.getValue().booleanValue()) {
            this.playerDisconnect("[AutoLog] logged out with %d totems remaining.", totems);
        }
    }

    @EventListener
    public void onGameJoin(GameJoinEvent event) {
        this.invincibilityTimer.reset();
    }

    private void playerDisconnect(String disconnectReason, Object ... args) {
        if (this.illegalDisconnectConfig.getValue().booleanValue()) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2797("\u00a7", Instant.now(), class_3515.class_7426.method_43531(), null, new class_7635.class_7636(1, new BitSet(2))));
            if (this.autoDisableConfig.getValue().booleanValue()) {
                this.disable();
            }
            return;
        }
        if (mc.method_1562() == null) {
            AutoLogModule.mc.field_1687.method_8525();
            if (this.autoDisableConfig.getValue().booleanValue()) {
                this.disable();
            }
            return;
        }
        disconnectReason = String.format(disconnectReason, args);
        mc.method_1562().method_48296().method_10747(class_2561.method_30163((String)disconnectReason));
        if (this.autoDisableConfig.getValue().booleanValue()) {
            this.disable();
        }
    }

    private boolean checkEnemy(class_742 player) {
        return player != AutoLogModule.mc.field_1724 && !Managers.SOCIAL.isFriend(player.method_5477()) && !(player instanceof FakePlayerEntity);
    }
}
