package net.hachimi.client.impl.module.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.NumberDisplay;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.BlockPlacerModule;
import net.hachimi.client.impl.module.player.AirPlaceModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.InventoryUtil;
import net.hachimi.client.util.player.RotationUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.world.ExplosionUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2879;
import net.minecraft.class_3965;
import net.minecraft.class_4969;

public class AutoAnchorModule
extends BlockPlacerModule {
    private static AutoAnchorModule INSTANCE;
    Config<Float> targetRangeConfig = this.register(new NumberConfig<Float>("EnemyRange", "Range to search for potential enemies", Float.valueOf(1.0f), Float.valueOf(10.0f), Float.valueOf(13.0f)));
    Config<Boolean> swingConfig = this.register(new BooleanConfig("Swing", "Swing hand when exploding anchors", true));
    Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Rotate before exploding", false));
    Config<Boolean> airPlaceConfig = this.register(new BooleanConfig("AirPlace", "Allows placing anchors against air when no valid surface is visible", false));
    Config<SwitchMode> placeSwitchConfig = this.register(new EnumConfig("PlaceSwitch", "How to switch to the anchor item when placing", (Enum)SwitchMode.Hotbar, (Enum[])SwitchMode.values()));
    Config<SwitchMode> explodeSwitchConfig = this.register(new EnumConfig("ExplodeSwitch", "How to switch to the glowstone item when exploding", (Enum)SwitchMode.Hotbar, (Enum[])SwitchMode.values()));
    Config<Boolean> playersConfig = this.register(new BooleanConfig("Players", "Target players", true));
    Config<Boolean> monstersConfig = this.register(new BooleanConfig("Monsters", "Target monsters", false));
    Config<Boolean> neutralsConfig = this.register(new BooleanConfig("Neutrals", "Target neutrals", false));
    Config<Boolean> animalsConfig = this.register(new BooleanConfig("Animals", "Target animals", false));
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "Range to explode anchors", Float.valueOf(0.1f), Float.valueOf(4.0f), Float.valueOf(6.0f)));
    Config<Float> explodeSpeedConfig = this.register(new NumberConfig<Float>("ExplodeSpeed", "Speed to explode anchors", Float.valueOf(0.1f), Float.valueOf(18.0f), Float.valueOf(20.0f)));
    Config<Boolean> placeConfig = this.register(new BooleanConfig("Place", "Places anchors to damage enemies", true));
    Config<Float> placeRangeConfig = this.register(new NumberConfig<Float>("PlaceRange", "Range to place anchors", Float.valueOf(0.1f), Float.valueOf(4.5f), Float.valueOf(6.0f), () -> this.placeConfig.getValue()));
    Config<Float> placeSpeedConfig = this.register(new NumberConfig<Float>("PlaceSpeed", "Speed to place anchors", Float.valueOf(0.1f), Float.valueOf(18.0f), Float.valueOf(20.0f), () -> this.placeConfig.getValue()));
    Config<Float> placeDelayConfig = this.register(new NumberConfig<Float>("PlaceDelay", "Additional delay before placing anchors", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(20.0f), () -> this.placeConfig.getValue()));
    Config<Boolean> spamPlaceConfig = this.register(new BooleanConfig("SpamPlace", "Sends multiple place interactions to fight packet loss", true, () -> this.placeConfig.getValue()));
    Config<Boolean> strictDirectionConfig = this.register(new BooleanConfig("StrictDirection", "Interacts with only visible directions when placing crystals", false, () -> this.placeConfig.getValue()));
    Config<Boolean> grimConfig = this.register(new BooleanConfig("Grim", "Places using grim instant rotations", false, () -> this.placeConfig.getValue()));
    Config<Boolean> detectMiningConfig = this.register(new BooleanConfig("DetectMining", "Avoids placing anchors where an enemy is currently mining", true, () -> this.placeConfig.getValue()));
    Config<Boolean> breakCrystalConfig = this.register(new BooleanConfig("BreakCrystal", "Mines placed anchors with no charges left to reclaim them", false));
    Config<Float> breakRangeConfig = this.register(new NumberConfig<Float>("BreakRange", "Range to break anchors", Float.valueOf(0.1f), Float.valueOf(4.0f), Float.valueOf(6.0f), () -> this.breakCrystalConfig.getValue()));
    Config<Boolean> assumeArmorConfig = this.register(new BooleanConfig("AssumeBestArmor", "Assumes Prot 0 armor is max armor", false));
    Config<Float> minDamageConfig = this.register(new NumberConfig<Float>("MinDamage", "Minimum damage required to consider exploding anchors", Float.valueOf(1.0f), Float.valueOf(4.0f), Float.valueOf(10.0f)));
    Config<Boolean> safetyConfig = this.register(new BooleanConfig("Safety", "Accounts for total player safety when exploding anchors", true));
    Config<Float> maxLocalDamageConfig = this.register(new NumberConfig<Float>("MaxLocalDamage", "The maximum player damage", Float.valueOf(4.0f), Float.valueOf(12.0f), Float.valueOf(20.0f)));
    Config<Float> damageRatioConfig = this.register(new NumberConfig<Float>("DamageRatio", "Minimum ratio of enemy damage to self damage required to explode", Float.valueOf(0.1f), Float.valueOf(1.2f), Float.valueOf(10.0f)));
    Config<Boolean> blockDestructionConfig = this.register(new BooleanConfig("BlockDestruction", "Accounts for explosion block destruction when calculating damages", false));
    Config<Boolean> selfExtrapolateConfig = this.register(new BooleanConfig("SelfExtrapolate", "Accounts for motion when calculating self damage", false));
    Config<Integer> extrapolateTicksConfig = this.register(new NumberConfig<Integer>("ExtrapolationTicks", "Accounts for motion when calculating enemy positions, not fully accurate.", 0, 0, 10));
    Config<Boolean> asynchronousConfig = this.register(new BooleanConfig("Asynchronous", "Calculates anchor placements/explosions asynchronously", true));
    Config<Boolean> renderConfig = this.register(new BooleanConfig("Render", "Renders where anchors will be placed", true));
    Config<BoxMode> boxModeConfig = this.register(new EnumConfig("BoxMode", "How the render box is displayed", (Enum)BoxMode.Both, (Enum[])BoxMode.values(), () -> this.renderConfig.getValue()));
    Config<Color> boxColorConfig = this.register(new ColorConfig("BoxColor", "The color of the render box outline", new Color(245, 138, 231, 100), true, true, () -> this.renderConfig.getValue()));
    Config<Color> fillColorConfig = this.register(new ColorConfig("FillColor", "The color of the render box fill", new Color(245, 138, 231, 70), true, true, () -> this.renderConfig.getValue()));
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "The line width of the render box", Float.valueOf(0.5f), Float.valueOf(1.0f), Float.valueOf(5.0f), () -> this.renderConfig.getValue()));
    Config<Boolean> shrinkConfig = this.register(new BooleanConfig("Shrink", "Shrinks the render box slightly", false, () -> this.renderConfig.getValue()));
    Config<Float> sliderSpeedConfig = this.register(new NumberConfig<Float>("SliderSpeed", "The speed of the box fade animation", Float.valueOf(0.05f), Float.valueOf(0.5f), Float.valueOf(2.0f), () -> this.renderConfig.getValue()));
    Config<Float> startFadeConfig = this.register(new NumberConfig<Float>("StartFade", "The starting opacity factor for the fade animation", Float.valueOf(0.0f), Float.valueOf(0.2f), Float.valueOf(1.0f), NumberDisplay.PERCENT, () -> this.renderConfig.getValue()));
    Config<Float> fadeSpeedConfig = this.register(new NumberConfig<Float>("FadeSpeed", "The speed of the fade-out after the box disappears", Float.valueOf(0.05f), Float.valueOf(0.3f), Float.valueOf(2.0f), () -> this.renderConfig.getValue()));
    Config<Boolean> renderDamageConfig = this.register(new BooleanConfig("RenderDamage", "Renders calculated damage values above the box", false, () -> this.renderConfig.getValue()));
    Config<Boolean> targetDamageConfig = this.register(new BooleanConfig("TargetDamage", "Renders the damage that would be dealt to the target", true, () -> this.renderConfig.getValue() != false && this.renderDamageConfig.getValue() != false));
    Config<Boolean> selfDamageConfig = this.register(new BooleanConfig("SelfDamage", "Renders the damage that would be dealt to yourself", true, () -> this.renderConfig.getValue() != false && this.renderDamageConfig.getValue() != false));
    private volatile AnchorCalc anchorCalc;
    private final Timer explodeTimer = new CacheTimer();
    private final Timer placeTimer = new CacheTimer();
    private final Timer breakTimer = new CacheTimer();
    private final Map<class_2338, Animation> fadeList = new HashMap<class_2338, Animation>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Future<?> calculationFuture;

    public AutoAnchorModule() {
        super("AutoAnchor", "Automatically places and explodes respawn anchors", ModuleCategory.COMBAT, 740);
        INSTANCE = this;
    }

    public static AutoAnchorModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        this.anchorCalc = null;
        this.fadeList.clear();
        if (this.calculationFuture != null) {
            this.calculationFuture.cancel(true);
            this.calculationFuture = null;
        }
    }

    @EventListener
    public void onPlayerTick(TickEvent event) {
        AnchorCalc calc;
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (!InventoryUtil.hasItemInHotbar(class_1802.field_23141) || !InventoryUtil.hasItemInHotbar(class_1802.field_8801)) {
            this.anchorCalc = null;
            return;
        }
        if (!((Boolean)this.multitaskConfig.getValue()).booleanValue() && this.checkMultitask() || ((Boolean)this.stopMotionConfig.getValue()).booleanValue() && !AutoAnchorModule.mc.field_1724.method_24828()) {
            this.anchorCalc = null;
            return;
        }
        if (this.asynchronousConfig.getValue().booleanValue()) {
            if (this.calculationFuture == null || this.calculationFuture.isDone()) {
                this.calculationFuture = this.executor.submit(() -> {
                    this.anchorCalc = this.calculateAnchorExplosion();
                    return this.anchorCalc;
                });
            }
        } else {
            this.anchorCalc = this.calculateAnchorExplosion();
        }
        if ((calc = this.anchorCalc) == null) {
            return;
        }
        class_2338 anchorPos = calc.pos();
        if (calc.isAnchor()) {
            if (this.rotateConfig.getValue().booleanValue()) {
                float[] rotations = RotationUtil.getRotationsTo(AutoAnchorModule.mc.field_1724.method_33571(), anchorPos.method_46558());
                this.setRotation(rotations[0], rotations[1]);
            }
            if (this.explodeTimer.passed(Float.valueOf(1000.0f - this.explodeSpeedConfig.getValue().floatValue() * 50.0f))) {
                this.setAnchor(anchorPos);
                this.explodeTimer.reset();
            }
        } else {
            if (AutoAnchorModule.mc.field_1687.method_8320(anchorPos).method_26204() == class_2246.field_23152) {
                return;
            }
            int slot = this.getBlockItemSlot(class_2246.field_23152);
            if (slot == -1) {
                return;
            }
            if (this.placeTimer.passed(Float.valueOf(1000.0f - this.placeSpeedConfig.getValue().floatValue() * 50.0f + this.placeDelayConfig.getValue().floatValue() * 50.0f))) {
                this.switchToSlot(slot, this.placeSwitchConfig.getValue());
                class_243 prevMotion = AutoAnchorModule.mc.field_1724.method_18798();
                if (((Boolean)this.stopMotionConfig.getValue()).booleanValue()) {
                    AutoAnchorModule.mc.field_1724.method_18799(class_243.field_1353);
                }
                Managers.INTERACT.placeBlock(anchorPos, slot, this.grimConfig.getValue(), (boolean)this.strictDirectionConfig.getValue(), false, (boolean)this.airPlaceConfig.getValue(), (state, angles) -> {
                    if (this.rotateConfig.getValue().booleanValue()) {
                        if (state) {
                            Managers.ROTATION.setRotationSilent(angles[0], angles[1]);
                        } else if (this.grimConfig.getValue().booleanValue()) {
                            Managers.ROTATION.setRotationSilentSync();
                        }
                    }
                });
                if (this.spamPlaceConfig.getValue().booleanValue()) {
                    class_3965 spamResult = new class_3965(anchorPos.method_46558(), Managers.INTERACT.getInteractDirection(anchorPos, this.strictDirectionConfig.getValue()), anchorPos, true);
                    for (int i = 0; i < 2; ++i) {
                        AutoAnchorModule.mc.field_1761.method_2896(AutoAnchorModule.mc.field_1724, class_1268.field_5808, spamResult);
                    }
                }
                if (((Boolean)this.stopMotionConfig.getValue()).booleanValue()) {
                    AutoAnchorModule.mc.field_1724.method_18799(prevMotion);
                }
                Managers.INVENTORY.syncToClient();
                this.placeTimer.reset();
            }
        }
        if (this.breakCrystalConfig.getValue().booleanValue()) {
            this.handleBreakAnchors();
        }
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (this.renderConfig.getValue().booleanValue() && this.boxModeConfig.getValue() != BoxMode.None) {
            RenderBuffers.preRender();
            AnchorCalc calc = this.anchorCalc;
            for (Map.Entry<class_2338, Animation> set : this.fadeList.entrySet()) {
                if (calc != null && set.getKey().equals((Object)calc.pos())) continue;
                set.getValue().setState(false);
                this.renderAnchorBox(event, set.getKey(), set.getValue(), null);
            }
            RenderBuffers.postRender();
            this.fadeList.entrySet().removeIf(e -> ((Animation)e.getValue()).getFactor() == 0.0);
            if (calc != null) {
                Animation animation = this.fadeList.computeIfAbsent(calc.pos(), p -> new Animation(true, this.sliderSpeedConfig.getValue().floatValue() * 1000.0f));
                animation.setLength(this.sliderSpeedConfig.getValue().floatValue() * 1000.0f);
                animation.setState(true);
                RenderBuffers.preRender();
                this.renderAnchorBox(event, calc.pos(), animation, calc);
                RenderBuffers.postRender();
            }
        }
    }

    private void renderAnchorBox(RenderWorldEvent event, class_2338 pos, Animation animation, AnchorCalc calc) {
        BoxMode mode;
        double factor = Math.max(animation.getFactor(), (double)this.startFadeConfig.getValue().floatValue());
        int boxAlpha = (int)((double)this.boxColorConfig.getValue().getAlpha() * factor);
        int fillAlpha = (int)((double)this.fillColorConfig.getValue().getAlpha() * factor);
        ColorConfig boxColor = (ColorConfig)this.boxColorConfig;
        ColorConfig fillColor = (ColorConfig)this.fillColorConfig;
        class_238 box = new class_238(pos);
        if (this.shrinkConfig.getValue().booleanValue()) {
            box = box.method_1011(0.05);
        }
        if ((mode = this.boxModeConfig.getValue()) == BoxMode.Both || mode == BoxMode.Fill) {
            RenderManager.renderBox(event.getMatrices(), box, fillColor.getRgb(fillAlpha));
        }
        if (mode == BoxMode.Both || mode == BoxMode.Box) {
            RenderManager.renderBoundingBox(event.getMatrices(), box, this.widthConfig.getValue().floatValue(), boxColor.getRgb(boxAlpha));
        }
        if (this.renderDamageConfig.getValue().booleanValue() && calc != null) {
            StringBuilder text = new StringBuilder();
            if (this.targetDamageConfig.getValue().booleanValue()) {
                text.append(String.format("%.1f", calc.targetDamage()));
            }
            if (this.selfDamageConfig.getValue().booleanValue()) {
                if (!text.isEmpty()) {
                    text.append(" / ");
                }
                text.append(String.format("%.1f", calc.selfDamage()));
            }
            if (!text.isEmpty()) {
                RenderManager.renderSign(text.toString(), pos.method_46558().method_1031(0.0, 1.4, 0.0), boxColor.getRgb(255));
            }
        }
    }

    private void setAnchor(class_2338 pos) {
        class_2680 state = AutoAnchorModule.mc.field_1687.method_8320(pos);
        if (!(state.method_26204() instanceof class_4969)) {
            return;
        }
        int slot1 = this.findNonBlockSlot();
        if (slot1 == -1) {
            return;
        }
        int charges = (Integer)state.method_11654((class_2769)class_4969.field_23153);
        if (charges <= 0) {
            int slot = this.getBlockItemSlot(class_2246.field_10171);
            if (slot == -1) {
                return;
            }
            this.switchToSlot(slot, this.explodeSwitchConfig.getValue());
            class_3965 result = new class_3965(pos.method_46558(), Managers.INTERACT.getInteractDirection(pos, this.strictDirectionConfig.getValue()), pos, true);
            AutoAnchorModule.mc.field_1761.method_2896(AutoAnchorModule.mc.field_1724, class_1268.field_5808, result);
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
            this.switchToSlot(slot1, this.explodeSwitchConfig.getValue());
            AutoAnchorModule.mc.field_1761.method_2896(AutoAnchorModule.mc.field_1724, class_1268.field_5808, result);
            if (this.swingConfig.getValue().booleanValue()) {
                AutoAnchorModule.mc.field_1724.method_6104(class_1268.field_5808);
            } else {
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
            }
            Managers.INVENTORY.syncToClient();
        } else {
            this.switchToSlot(slot1, this.explodeSwitchConfig.getValue());
            class_3965 result1 = new class_3965(pos.method_46558(), Managers.INTERACT.getInteractDirection(pos, this.strictDirectionConfig.getValue()), pos, true);
            AutoAnchorModule.mc.field_1761.method_2896(AutoAnchorModule.mc.field_1724, class_1268.field_5808, result1);
            if (this.swingConfig.getValue().booleanValue()) {
                AutoAnchorModule.mc.field_1724.method_6104(class_1268.field_5808);
            } else {
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
            }
            Managers.INVENTORY.syncToClient();
        }
    }

    private void switchToSlot(int slot, SwitchMode mode) {
        if (mode == SwitchMode.Inventory) {
            int syncId = AutoAnchorModule.mc.field_1724.field_7498.field_7763;
            int curHotbar = AutoAnchorModule.mc.field_1724.method_31548().field_7545;
            if (slot == curHotbar) {
                return;
            }
            int handlerSource = slot + 36;
            AutoAnchorModule.mc.field_1761.method_2906(syncId, handlerSource, curHotbar, class_1713.field_7791, (class_1657)AutoAnchorModule.mc.field_1724);
            return;
        }
        Managers.INVENTORY.setSlot(slot);
    }

    private void handleBreakAnchors() {
        if (!this.breakTimer.passed(Float.valueOf(200.0f))) {
            return;
        }
        class_2338 origin = AutoAnchorModule.mc.field_1724.method_24515();
        double rad = Math.ceil(this.breakRangeConfig.getValue().floatValue());
        for (double x = -rad; x <= rad; x += 1.0) {
            for (double y = -rad; y <= rad; y += 1.0) {
                for (double z = -rad; z <= rad; z += 1.0) {
                    class_2680 state;
                    class_2338 pos = new class_2338((int)((double)origin.method_10263() + x), (int)((double)origin.method_10264() + y), (int)((double)origin.method_10260() + z));
                    if (AutoAnchorModule.mc.field_1724.method_33571().method_1025(pos.method_46558()) > ((NumberConfig)this.breakRangeConfig).getValueSq() || !((state = AutoAnchorModule.mc.field_1687.method_8320(pos)).method_26204() instanceof class_4969) || (Integer)state.method_11654((class_2769)class_4969.field_23153) > 0) continue;
                    class_3965 result = new class_3965(pos.method_46558(), Managers.INTERACT.getInteractDirection(pos, this.strictDirectionConfig.getValue()), pos, true);
                    AutoAnchorModule.mc.field_1761.method_2910(pos, result.method_17780());
                    AutoAnchorModule.mc.field_1724.method_6104(class_1268.field_5808);
                    this.breakTimer.reset();
                    return;
                }
            }
        }
    }

    private AnchorCalc calculateAnchorExplosion() {
        class_2338 data = null;
        double bestAnchorDamage = 0.0;
        double bestSelfDamage = 0.0;
        boolean isAnchor = false;
        for (class_2338 pos : this.getSphere(AutoAnchorModule.mc.field_1724.method_19538())) {
            double selfDamage;
            boolean unsafeToPlayer;
            class_2680 state = AutoAnchorModule.mc.field_1687.method_8320(pos);
            double dist1 = AutoAnchorModule.mc.field_1724.method_33571().method_1025(pos.method_46558());
            if (dist1 > ((NumberConfig)this.rangeConfig).getValueSq()) continue;
            boolean explosion = state.method_26204() instanceof class_4969;
            if (!state.method_45474() && !explosion || (!explosion && this.placeConfig.getValue() != false ? dist1 > ((NumberConfig)this.placeRangeConfig).getValueSq() || this.detectMiningConfig.getValue() != false && Managers.BREAK.isMining(pos) : !explosion) || (unsafeToPlayer = this.playerDamageCheck(selfDamage = ExplosionUtil.getDamageTo((class_1297)AutoAnchorModule.mc.field_1724, pos.method_46558(), this.blockDestructionConfig.getValue(), 10.0f, Set.of(pos), this.selfExtrapolateConfig.getValue() != false ? this.extrapolateTicksConfig.getValue() : 0, false))) || !AirPlaceModule.getInstance().isEnabled() && !this.airPlaceConfig.getValue().booleanValue() && Managers.INTERACT.getInteractDirectionInternal(pos, false) == null || !Managers.INTERACT.canPlace(pos, class_2246.field_23152)) continue;
            for (class_1297 entity : AutoAnchorModule.mc.field_1687.method_18112()) {
                double damage;
                if (entity.method_5829().method_994(new class_238(pos)) || entity == null || !entity.method_5805() || entity == AutoAnchorModule.mc.field_1724 || !this.isValidTarget(entity) || Managers.SOCIAL.isFriend(entity.method_5477())) continue;
                double blockDist = pos.method_19770((class_2374)entity.method_19538());
                double dist = AutoAnchorModule.mc.field_1724.method_5858(entity);
                if (blockDist > 144.0 || dist > (double)(this.targetRangeConfig.getValue().floatValue() * this.targetRangeConfig.getValue().floatValue()) || !(ExplosionUtil.getDamageTo(entity, pos.method_46558(), this.blockDestructionConfig.getValue(), 10.0f, Set.of(pos), (int)this.extrapolateTicksConfig.getValue(), (boolean)this.assumeArmorConfig.getValue()) > bestAnchorDamage) || (damage = ExplosionUtil.getDamageTo(entity, pos.method_46558(), this.blockDestructionConfig.getValue(), 10.0f, Set.of(pos), (int)this.extrapolateTicksConfig.getValue(), (boolean)this.assumeArmorConfig.getValue())) < selfDamage * (double)this.damageRatioConfig.getValue().floatValue() && selfDamage > 0.5) continue;
                data = pos;
                bestAnchorDamage = damage;
                bestSelfDamage = selfDamage;
                isAnchor = explosion;
            }
        }
        if (data != null && bestAnchorDamage >= (double)this.minDamageConfig.getValue().floatValue()) {
            return new AnchorCalc(data, isAnchor, bestAnchorDamage, bestSelfDamage);
        }
        return null;
    }

    private boolean playerDamageCheck(double playerDamage) {
        if (!AutoAnchorModule.mc.field_1724.method_7337()) {
            float health = AutoAnchorModule.mc.field_1724.method_6032() + AutoAnchorModule.mc.field_1724.method_6067();
            if (this.safetyConfig.getValue().booleanValue() && playerDamage >= (double)(health + 0.5f)) {
                return true;
            }
            return playerDamage > (double)this.maxLocalDamageConfig.getValue().floatValue();
        }
        return false;
    }

    private List<class_2338> getSphere(class_243 origin) {
        ArrayList<class_2338> sphere = new ArrayList<class_2338>();
        double rad = Math.ceil(Math.max(this.rangeConfig.getValue().floatValue(), this.placeRangeConfig.getValue().floatValue()));
        for (double x = -rad; x <= rad; x += 1.0) {
            for (double y = -rad; y <= rad; y += 1.0) {
                for (double z = -rad; z <= rad; z += 1.0) {
                    class_2382 pos = new class_2382((int)(origin.method_10216() + x), (int)(origin.method_10214() + y), (int)(origin.method_10215() + z));
                    sphere.add(new class_2338(pos));
                }
            }
        }
        return sphere;
    }

    private boolean isValidTarget(class_1297 e) {
        return e instanceof class_1657 && this.playersConfig.getValue() != false || EntityUtil.isMonster(e) && this.monstersConfig.getValue() != false || EntityUtil.isNeutral(e) && this.neutralsConfig.getValue() != false || EntityUtil.isPassive(e) && this.animalsConfig.getValue() != false;
    }

    private int findNonBlockSlot() {
        int slot = -1;
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = AutoAnchorModule.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() instanceof class_1747) continue;
            slot = i;
            break;
        }
        return slot;
    }

    public static enum SwitchMode {
        Hotbar,
        Inventory;

    }

    public static enum BoxMode {
        Both,
        Box,
        Fill,
        None;

    }

    private record AnchorCalc(class_2338 pos, boolean isAnchor, double targetDamage, double selfDamage) {
    }
}
