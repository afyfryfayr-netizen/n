package net.hachimi.client.impl.module.combat;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.CombatModule;
import net.hachimi.client.impl.module.combat.AutoCrystalModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.EnchantmentUtil;
import net.hachimi.client.util.player.PlayerUtil;
import net.hachimi.client.util.player.RotationUtil;
import net.hachimi.client.util.string.EnumFormatter;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1429;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_1621;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1683;
import net.minecraft.class_1713;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import org.apache.commons.lang3.mutable.MutableDouble;

public class AuraModule
extends CombatModule {
    private static AuraModule INSTANCE;
    Config<Weapon> weaponConfig = this.register(new EnumConfig("Weapon", "Weapon type to use for attacking", (Enum)Weapon.ALL, (Enum[])Weapon.values()));
    Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Silently rotate to target before attacking", false));
    Config<SwingMode> swingConfig = this.register(new EnumConfig("Swing", "Hand swing mode when attacking", (Enum)SwingMode.NORMAL, (Enum[])SwingMode.values()));
    Config<AutoSwitch> autoSwitchConfig = this.register(new EnumConfig("AutoSwitch", "Automatically switch to best weapon before attacking", (Enum)AutoSwitch.NONE, (Enum[])AutoSwitch.values()));
    Config<SwapAction> swapActionConfig = this.register(new EnumConfig("SwapAction", "Swap method when switching weapon", (Enum)SwapAction.HOTBAR, (Enum[])SwapAction.values()));
    Config<ShieldMode> shieldModeConfig = this.register(new EnumConfig("ShieldMode", "How to handle the targets shield", (Enum)ShieldMode.IGNORE, (Enum[])ShieldMode.values()));
    Config<SortPriority> sortPriorityConfig = this.register(new EnumConfig("SortPriority", "Priority when selecting target", (Enum)SortPriority.LOWEST_HEALTH, (Enum[])SortPriority.values()));
    Config<TargetMode> modeConfig = this.register(new EnumConfig("Mode", "Target lock mode", (Enum)TargetMode.SWITCH, (Enum[])TargetMode.values()));
    Config<Integer> maxTargetConfig = this.register(new NumberConfig<Integer>("MaxTarget", "Maximum targets to attack per tick", 1, 1, 5));
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "Range to attack entities", Float.valueOf(1.0f), Float.valueOf(4.5f), Float.valueOf(6.0f)));
    Config<Float> wallRangeConfig = this.register(new NumberConfig<Float>("WallsRange", "Range to attack through walls", Float.valueOf(1.0f), Float.valueOf(4.5f), Float.valueOf(6.0f)));
    Config<MobAgeFilter> mobAgeFilterConfig = this.register(new EnumConfig("MobAgeFilter", "Filter mobs by age", (Enum)MobAgeFilter.BOTH, (Enum[])MobAgeFilter.values()));
    Config<Boolean> ignoreNamedConfig = this.register(new BooleanConfig("IgnoreNamed", "Ignore named entities", false));
    Config<Boolean> ignorePassiveConfig = this.register(new BooleanConfig("IgnorePassive", "Ignore passive entities", false));
    Config<Boolean> ignoreTamedConfig = this.register(new BooleanConfig("IgnoreTamed", "Ignore tamed entities", false));
    Config<Boolean> reverseConfig = this.register(new BooleanConfig("Reverse", "Reverse target priority", false));
    Config<Boolean> customDelayConfig = this.register(new BooleanConfig("CustomDelay", "Use custom hit delay instead of attack cooldown", false));
    Config<Float> hitDelayConfig = this.register(new NumberConfig<Float>("HitDelay", "Custom delay between hits (ms)", Float.valueOf(0.0f), Float.valueOf(50.0f), Float.valueOf(500.0f), () -> this.customDelayConfig.getValue()));
    Config<Boolean> attackCdConfig = this.register(new BooleanConfig("AttackCD", "Wait for full attack cooldown before hitting", true, () -> this.customDelayConfig.getValue() == false));
    Config<Float> switchDelayConfig = this.register(new NumberConfig<Float>("SwitchDelay", "Delay after swapping items before attacking (ms)", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(500.0f)));
    Config<Boolean> playersConfig = this.register(new BooleanConfig("Players", "Target players", true));
    Config<Boolean> mobsConfig = this.register(new BooleanConfig("Mobs", "Target hostile mobs", false));
    Config<Boolean> animalsConfig = this.register(new BooleanConfig("Animals", "Target passive animals", false));
    Config<Boolean> villagersConfig = this.register(new BooleanConfig("Villagers", "Target villagers", false));
    Config<Boolean> slimesConfig = this.register(new BooleanConfig("Slimes", "Target slimes and magma cubes", false));
    private class_1297 entityTarget;
    private long lastAttackTime;
    private final Timer autoSwapTimer = new CacheTimer();
    private final Timer switchTimer = new CacheTimer();

    public AuraModule() {
        super("Aura", "Attacks nearby entities", ModuleCategory.COMBAT, 700);
        INSTANCE = this;
    }

    public static AuraModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        return EnumFormatter.formatEnum(this.modeConfig.getValue());
    }

    @Override
    public void onDisable() {
        this.entityTarget = null;
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Outbound event) {
        if (AuraModule.mc.field_1724 == null) {
            return;
        }
        if (event.getPacket() instanceof class_2868) {
            this.switchTimer.reset();
        }
    }

    @EventListener
    public void onPlayerUpdate(PlayerTickEvent event) {
        class_1297 axeSlot2;
        int axeSlot2;
        class_1309 living;
        class_1297 class_12972;
        if (AuraModule.mc.field_1724 == null || AuraModule.mc.field_1687 == null) {
            return;
        }
        if (AutoCrystalModule.getInstance().isAttacking() || AutoCrystalModule.getInstance().isPlacing() || AuraModule.mc.field_1724.method_7325()) {
            return;
        }
        if (!((Boolean)this.multitaskConfig.getValue()).booleanValue() && this.checkMultitask(true)) {
            return;
        }
        class_243 eyepos = Managers.POSITION.getEyePos();
        switch (this.modeConfig.getValue().ordinal()) {
            default: {
                throw new MatchException(null, null);
            }
            case 1: {
                class_1297 class_12973 = this.getAttackTarget(eyepos);
                break;
            }
            case 0: {
                class_1297 class_12973 = this.entityTarget = this.entityTarget == null || !this.entityTarget.method_5805() || !this.isInAttackRange(eyepos, this.entityTarget) ? this.getAttackTarget(eyepos) : this.entityTarget;
            }
        }
        if (this.entityTarget == null || !this.switchTimer.passed(Float.valueOf(this.switchDelayConfig.getValue().floatValue() * 25.0f))) {
            return;
        }
        if (AuraModule.mc.field_1724.method_6115() && AuraModule.mc.field_1724.method_6058() == class_1268.field_5808 || AuraModule.mc.field_1690.field_1886.method_1434() || PlayerUtil.isHotbarKeysPressed()) {
            this.autoSwapTimer.reset();
        }
        int slot = this.getWeaponSlot();
        boolean silentSwapped = false;
        if (!this.isHoldingWeapon() && slot != -1) {
            block4 : switch (this.autoSwitchConfig.getValue().ordinal()) {
                case 1: {
                    if (!this.autoSwapTimer.passed(500)) break;
                    Managers.INVENTORY.setClientSlot(slot);
                    break;
                }
                case 2: {
                    switch (this.swapActionConfig.getValue().ordinal()) {
                        case 0: {
                            if (slot >= 9) break block4;
                            Managers.INVENTORY.setSlot(slot);
                            silentSwapped = true;
                            break block4;
                        }
                        case 1: {
                            if (slot < 9) {
                                Managers.INVENTORY.setSlot(slot);
                            } else {
                                AuraModule.mc.field_1761.method_2906(AuraModule.mc.field_1724.field_7498.field_7763, slot, AuraModule.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)AuraModule.mc.field_1724);
                            }
                            silentSwapped = true;
                            break block4;
                        }
                        case 2: {
                            break block4;
                        }
                    }
                    Managers.INVENTORY.setSlot(slot);
                    silentSwapped = true;
                    break;
                }
                case 3: {
                    if (this.swapActionConfig.getValue() == SwapAction.HOTBAR && slot < 9) {
                        Managers.INVENTORY.setSlot(slot);
                        silentSwapped = true;
                        break;
                    }
                    if (this.swapActionConfig.getValue() != SwapAction.SCREEN) break;
                    if (slot < 9) {
                        Managers.INVENTORY.setSlot(slot);
                    } else {
                        AuraModule.mc.field_1761.method_2906(AuraModule.mc.field_1724.field_7498.field_7763, slot, AuraModule.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)AuraModule.mc.field_1724);
                    }
                    silentSwapped = true;
                    break;
                }
            }
        }
        if (!this.isHoldingWeapon() && this.autoSwitchConfig.getValue() != AutoSwitch.SILENT && this.autoSwitchConfig.getValue() != AutoSwitch.SILENT_ALT) {
            return;
        }
        if (this.rotateConfig.getValue().booleanValue()) {
            float[] rot = RotationUtil.getRotationsTo(AuraModule.mc.field_1724.method_33571(), this.entityTarget.method_33571());
            this.setRotationSilent(rot[0], rot[1]);
        }
        if (!this.isInAttackRange(eyepos, this.entityTarget)) {
            Managers.INVENTORY.syncToClient();
            return;
        }
        if (this.shieldModeConfig.getValue() == ShieldMode.BREAK && (class_12972 = this.entityTarget) instanceof class_1309 && (living = (class_1309)class_12972).method_6039() && (axeSlot2 = this.getAxeSlot()) != -1) {
            Managers.INVENTORY.setSlot(axeSlot2);
            Managers.NETWORK.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)this.entityTarget, (boolean)AuraModule.mc.field_1724.method_5715()));
            AuraModule.mc.field_1724.method_6104(class_1268.field_5808);
            Managers.INVENTORY.syncToClient();
            if ((this.autoSwitchConfig.getValue() == AutoSwitch.SILENT || this.autoSwitchConfig.getValue() == AutoSwitch.SILENT_ALT) && silentSwapped) {
                Managers.INVENTORY.syncToClient();
            }
            return;
        }
        if (this.shieldModeConfig.getValue() == ShieldMode.WAIT && (axeSlot2 = this.entityTarget) instanceof class_1309 && (living = (class_1309)axeSlot2).method_6039()) {
            if ((this.autoSwitchConfig.getValue() == AutoSwitch.SILENT || this.autoSwitchConfig.getValue() == AutoSwitch.SILENT_ALT) && silentSwapped) {
                Managers.INVENTORY.syncToClient();
            }
            return;
        }
        boolean didAttack = false;
        if (this.customDelayConfig.getValue().booleanValue()) {
            if ((float)(System.currentTimeMillis() - this.lastAttackTime) >= this.hitDelayConfig.getValue().floatValue()) {
                didAttack = this.attackTarget(this.entityTarget);
            }
        } else if (this.attackCdConfig.getValue().booleanValue()) {
            int useSlot = slot == -1 ? AuraModule.mc.field_1724.method_31548().field_7545 : slot;
            class_1799 stack = AuraModule.mc.field_1724.method_31548().method_5438(useSlot);
            MutableDouble attackSpeed = new MutableDouble(AuraModule.mc.field_1724.method_45326(class_5134.field_23723));
            class_9285 attrMod = (class_9285)stack.method_57824(class_9334.field_49636);
            if (attrMod != null) {
                attrMod.method_57482(class_1304.field_6173, (entry, modifier) -> {
                    if (entry == class_5134.field_23723) {
                        attackSpeed.add(modifier.comp_2449());
                    }
                });
            }
            double cooldownTicks = 1.0 / attackSpeed.getValue() * 20.0;
            if ((double)((float)(System.currentTimeMillis() - this.lastAttackTime) / 50.0f) >= cooldownTicks) {
                didAttack = this.attackTarget(this.entityTarget);
            }
        } else {
            didAttack = this.attackTarget(this.entityTarget);
        }
        if (didAttack) {
            this.lastAttackTime = System.currentTimeMillis();
        }
        if ((this.autoSwitchConfig.getValue() == AutoSwitch.SILENT || this.autoSwitchConfig.getValue() == AutoSwitch.SILENT_ALT) && silentSwapped) {
            Managers.INVENTORY.syncToClient();
        }
    }

    private boolean attackTarget(class_1297 entity) {
        Managers.NETWORK.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)entity, (boolean)AuraModule.mc.field_1724.method_5715()));
        switch (this.swingConfig.getValue().ordinal()) {
            case 1: {
                AuraModule.mc.field_1724.method_6104(class_1268.field_5808);
                break;
            }
            case 2: {
                AuraModule.mc.field_1724.method_6104(class_1268.field_5808);
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
                break;
            }
        }
        return true;
    }

    private int getWeaponSlot() {
        float best = 0.0f;
        int slot = -1;
        for (int i = 0; i < 9; ++i) {
            float dmg;
            class_1792 item;
            class_1799 stack = AuraModule.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() || !this.isWeaponAllowed(item = stack.method_7909()) || !((dmg = this.getItemDamage(stack, item)) > best)) continue;
            best = dmg;
            slot = i;
        }
        return slot;
    }

    private int getAxeSlot() {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = AuraModule.mc.field_1724.method_31548().method_5438(i);
            if (!(stack.method_7909() instanceof class_1743)) continue;
            return i;
        }
        return -1;
    }

    private float getItemDamage(class_1799 stack, class_1792 item) {
        float sharp = (float)EnchantmentUtil.getLevel(stack, (class_5321<class_1887>)class_1893.field_9118) * 0.5f + 0.5f;
        if (item instanceof class_1829) {
            class_1829 s = (class_1829)item;
            return s.method_8022().method_8028() + sharp;
        }
        if (item instanceof class_1743) {
            class_1743 a = (class_1743)item;
            return a.method_8022().method_8028() + sharp;
        }
        if (item instanceof class_1835) {
            return 8.0f + sharp;
        }
        if (item instanceof class_9362) {
            return 5.0f + sharp;
        }
        return 0.0f;
    }

    private boolean isWeaponAllowed(class_1792 item) {
        return switch (this.weaponConfig.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> {
                if (item instanceof class_1829 || item instanceof class_1743 || item instanceof class_1835 || item instanceof class_9362) {
                    yield true;
                }
                yield false;
            }
            case 1 -> item instanceof class_1829;
            case 2 -> item instanceof class_1743;
            case 3 -> item instanceof class_9362;
            case 4 -> item instanceof class_1835;
        };
    }

    public boolean isHoldingWeapon() {
        return this.isWeaponAllowed(AuraModule.mc.field_1724.method_6047().method_7909());
    }

    public boolean isInAttackRange(class_243 pos, class_1297 entity) {
        if (entity == null || entity.method_19538() == null) {
            return false;
        }
        class_243 entityPos = entity.method_33571();
        double dist = pos.method_1022(entityPos);
        if (dist > (double)this.rangeConfig.getValue().floatValue()) {
            return false;
        }
        class_3965 result = AuraModule.mc.field_1687.method_17742(new class_3959(pos, entityPos, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)AuraModule.mc.field_1724));
        return result == null || result.method_17777().equals((Object)class_2338.method_49638((class_2374)entityPos)) || !(dist > (double)this.wallRangeConfig.getValue().floatValue());
    }

    private class_1297 getAttackTarget(class_243 pos) {
        double best = this.reverseConfig.getValue() != false ? -1.7976931348623157E308 : Double.MAX_VALUE;
        class_1297 found = null;
        for (class_1297 entity : AuraModule.mc.field_1687.method_18112()) {
            double val;
            double dist;
            class_1321 t;
            boolean enemy;
            if (entity == null || entity == AuraModule.mc.field_1724 || !entity.method_5805() || entity.method_19538() == null || entity instanceof class_1511 || entity instanceof class_1542 || entity instanceof class_1667 || entity instanceof class_1683) continue;
            try {
                enemy = this.isEnemy(entity);
            }
            catch (Exception e) {
                continue;
            }
            if (!enemy || Managers.SOCIAL.isFriend(entity.method_5477()) || this.ignoreNamedConfig.getValue().booleanValue() && entity.method_16914() || this.ignoreTamedConfig.getValue().booleanValue() && entity instanceof class_1321 && (t = (class_1321)entity).method_6181()) continue;
            if (this.ignorePassiveConfig.getValue().booleanValue()) {
                boolean passive;
                try {
                    passive = EntityUtil.isPassive(entity);
                }
                catch (Exception e) {
                    passive = false;
                }
                if (passive) continue;
            }
            if (entity instanceof class_1309) {
                class_1309 living = (class_1309)entity;
                if (this.mobAgeFilterConfig.getValue() == MobAgeFilter.BABY && !living.method_6109() || this.mobAgeFilterConfig.getValue() == MobAgeFilter.ADULT && living.method_6109()) continue;
            }
            if ((dist = pos.method_1022(entity.method_19538())) > (double)this.rangeConfig.getValue().floatValue()) continue;
            try {
                val = switch (this.sortPriorityConfig.getValue().ordinal()) {
                    default -> throw new MatchException(null, null);
                    case 1 -> dist;
                    case 2 -> {
                        if (entity instanceof class_1309) {
                            class_1309 le = (class_1309)entity;
                            yield le.method_6032() + le.method_6067();
                        }
                        yield dist;
                    }
                    case 0 -> {
                        float[] rots = RotationUtil.getRotationsTo(pos, entity.method_19538());
                        yield Math.abs(class_3532.method_15393((float)AuraModule.mc.field_1724.method_36454()) - rots[0]);
                    }
                };
            }
            catch (Exception e) {
                val = dist;
            }
            boolean bl = this.reverseConfig.getValue().booleanValue() ? val > best : val < best;
            boolean better = bl;
            if (!better) continue;
            best = val;
            found = entity;
        }
        return found;
    }

    private boolean isEnemy(class_1297 e) {
        if (e instanceof class_1657) {
            return this.playersConfig.getValue();
        }
        if (e instanceof class_1621) {
            return this.slimesConfig.getValue();
        }
        if (e instanceof class_1646) {
            return this.villagersConfig.getValue();
        }
        if (e instanceof class_1429) {
            return this.animalsConfig.getValue();
        }
        if (EntityUtil.isMonster(e)) {
            return this.mobsConfig.getValue();
        }
        return false;
    }

    public class_1297 getEntityTarget() {
        return this.entityTarget;
    }

    public static enum Weapon {
        ALL,
        SWORD,
        AXE,
        MACE,
        TRIDENT;

    }

    public static enum SwingMode {
        NONE,
        NORMAL,
        ALL;

    }

    public static enum AutoSwitch {
        NONE,
        NORMAL,
        SILENT,
        SILENT_ALT;

    }

    public static enum SwapAction {
        HOTBAR,
        SCREEN,
        NONE;

    }

    public static enum ShieldMode {
        IGNORE,
        BREAK,
        WAIT;

    }

    public static enum SortPriority {
        CLOSE_ANGLE,
        LOWEST_DISTANCE,
        LOWEST_HEALTH;

    }

    public static enum TargetMode {
        SINGLE,
        SWITCH;

    }

    public static enum MobAgeFilter {
        BOTH,
        BABY,
        ADULT;

    }
}
