package net.hachimi.client.impl.module.combat;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.PlayerUtil;
import net.hachimi.client.util.world.ExplosionUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1829;
import net.minecraft.class_243;

public final class OffhandModule
extends ToggleModule {
    private static OffhandModule INSTANCE;
    Config<OffhandItem> itemConfig = this.register(new EnumConfig("Item", "The item to keep in your offhand", (Enum)OffhandItem.TOTEM, (Enum[])OffhandItem.values()));
    Config<Float> healthConfig = this.register(new NumberConfig<Float>("Health", "Health threshold below which a totem is forced into the offhand", Float.valueOf(0.0f), Float.valueOf(16.0f), Float.valueOf(36.0f)));
    Config<Boolean> lethalConfig = this.register(new BooleanConfig("LethalCrystal", "Forces a totem if an end crystal could kill you", true));
    Config<Boolean> swordGapConfig = this.register(new BooleanConfig("SwordGap", "Equips a golden apple while holding a sword and right-clicking", true));
    Config<Boolean> pickaxeGapConfig = this.register(new BooleanConfig("PickaxeGap", "Equips a golden apple while holding a pickaxe and right-clicking", false));
    Config<Boolean> totemGapConfig = this.register(new BooleanConfig("Gap-Totem", "Equips a golden apple while holding a totem and right-clicking", false));
    Config<Boolean> alwaysGapConfig = this.register(new BooleanConfig("Always", "Always equip gapple when not already holding one", false));
    Config<Boolean> crappleConfig = this.register(new BooleanConfig("Crapple", "Prefers a normal golden apple over an enchanted one", true));
    Config<Boolean> alternativeConfig = this.register(new BooleanConfig("Alternative", "Uses an alternative (ClickSlot) swap method", true));
    Config<Integer> chorusConfig = this.register(new NumberConfig<Integer>("Chorus", "Hotbar slot for Chorus Fruit (-1 = search inventory)", Integer.valueOf(-1), Integer.valueOf(-1), Integer.valueOf(8), () -> this.itemConfig.getValue() == OffhandItem.CHORUS));
    Config<Integer> shieldConfig = this.register(new NumberConfig<Integer>("Shield", "Hotbar slot for Shield (-1 = search inventory)", Integer.valueOf(-1), Integer.valueOf(-1), Integer.valueOf(8), () -> this.itemConfig.getValue() == OffhandItem.SHIELD));
    private final Timer timer = new CacheTimer();

    public OffhandModule() {
        super("Offhand", "Automatically manages the item held in your offhand", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static OffhandModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        return this.itemConfig.getValue().name();
    }

    public boolean isUnsafe() {
        return PlayerUtil.getLocalPlayerHealth() < this.healthConfig.getValue().floatValue() || this.lethalCrystal();
    }

    private boolean lethalCrystal() {
        if (!this.lethalConfig.getValue().booleanValue()) {
            return false;
        }
        ArrayList<class_1297> entities = Lists.newArrayList(OffhandModule.mc.field_1687.method_18112());
        for (class_1297 entity : entities) {
            if (!(entity instanceof class_1511) || !entity.method_5805() || !(OffhandModule.mc.field_1724.method_5739(entity) <= 12.0f)) continue;
            class_243 class_2432 = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
            if (!(ExplosionUtil.getDamageTo((class_1297)OffhandModule.mc.field_1724, class_2432, false) >= (double)EntityUtil.getHealth((class_1297)OffhandModule.mc.field_1724))) continue;
            return true;
        }
        return false;
    }

    @EventListener
    public void onTick(TickEvent event) {
        boolean wantsGap;
        if (OffhandModule.mc.field_1724 == null || OffhandModule.mc.field_1687 == null || event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (!this.timer.passed(50)) {
            return;
        }
        if (OffhandModule.mc.field_1724.field_7512 != OffhandModule.mc.field_1724.field_7498) {
            return;
        }
        boolean unsafe = this.isUnsafe();
        if (unsafe) {
            if (OffhandModule.mc.field_1724.method_6079().method_7909() != class_1802.field_8288) {
                this.swap(class_1802.field_8288);
                this.timer.reset();
            }
            return;
        }
        class_1792 mainHand = OffhandModule.mc.field_1724.method_6047().method_7909();
        boolean bl = wantsGap = this.swordGapConfig.getValue() != false && mainHand instanceof class_1829 || this.pickaxeGapConfig.getValue() != false && mainHand instanceof class_1810 || this.totemGapConfig.getValue() != false && mainHand == class_1802.field_8288 || this.alwaysGapConfig.getValue() != false && mainHand != class_1802.field_8463 && mainHand != class_1802.field_8367;
        if (wantsGap && OffhandModule.mc.field_1690.field_1904.method_1434()) {
            this.swap(this.getGappleType());
            this.timer.reset();
            return;
        }
        switch (this.itemConfig.getValue().ordinal()) {
            case 0: {
                break;
            }
            case 1: {
                this.swap(class_1802.field_8288);
                this.timer.reset();
                break;
            }
            case 2: {
                this.swap(class_1802.field_8301);
                this.timer.reset();
                break;
            }
            case 3: {
                this.swap(this.getGappleType());
                this.timer.reset();
                break;
            }
            case 4: {
                this.swap(class_1802.field_8255, this.shieldConfig.getValue());
                this.timer.reset();
                break;
            }
            case 5: {
                this.swap(class_1802.field_8233, this.chorusConfig.getValue());
                this.timer.reset();
            }
        }
    }

    void swap(class_1792 item) {
        this.swap(item, -1);
    }

    void swap(class_1792 item, int pinnedSlot) {
        int itemSlot;
        if (pinnedSlot >= 0) {
            if (OffhandModule.mc.field_1724.method_31548().method_5438(pinnedSlot).method_7909() != item) {
                return;
            }
            itemSlot = pinnedSlot + 36;
        } else {
            int n = itemSlot = item == class_1802.field_8463 ? this.getGappleSlot() : this.findItemInventorySlot(item);
        }
        if (itemSlot == -1) {
            return;
        }
        if (this.alternativeConfig.getValue().booleanValue()) {
            int syncId = OffhandModule.mc.field_1724.field_7512.field_7763;
            OffhandModule.mc.field_1761.method_2906(syncId, itemSlot, 0, class_1713.field_7790, (class_1657)OffhandModule.mc.field_1724);
            OffhandModule.mc.field_1761.method_2906(syncId, 45, 0, class_1713.field_7790, (class_1657)OffhandModule.mc.field_1724);
            OffhandModule.mc.field_1761.method_2906(syncId, itemSlot, 0, class_1713.field_7790, (class_1657)OffhandModule.mc.field_1724);
            Managers.INVENTORY.syncToClient();
        } else {
            OffhandModule.mc.field_1761.method_2906(OffhandModule.mc.field_1724.field_7512.field_7763, itemSlot, 40, class_1713.field_7791, (class_1657)OffhandModule.mc.field_1724);
            Managers.INVENTORY.syncToClient();
        }
    }

    int findItemInventorySlot(class_1792 item) {
        class_1792 offhand = OffhandModule.mc.field_1724.method_6079().method_7909();
        if (offhand == class_1802.field_8463 && item == class_1802.field_8463) {
            return -1;
        }
        if (offhand == class_1802.field_8367 && (item == class_1802.field_8463 || item == class_1802.field_8367)) {
            return -1;
        }
        if (item == offhand) {
            return -1;
        }
        for (int i = 44; i >= 0; --i) {
            class_1799 stack = OffhandModule.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() != item) continue;
            return i < 9 ? i + 36 : i;
        }
        return -1;
    }

    private int getGappleSlot() {
        if (this.crappleConfig.getValue().booleanValue()) {
            int normal = this.findItemInventorySlot(class_1802.field_8463);
            return normal != -1 ? normal : this.findItemInventorySlot(class_1802.field_8367);
        }
        int enchanted = this.findItemInventorySlot(class_1802.field_8367);
        return enchanted != -1 ? enchanted : this.findItemInventorySlot(class_1802.field_8463);
    }

    class_1792 getGappleType() {
        if (this.crappleConfig.getValue().booleanValue()) {
            return this.findItemInventorySlot(class_1802.field_8463) != -1 ? class_1802.field_8463 : class_1802.field_8367;
        }
        return this.findItemInventorySlot(class_1802.field_8367) != -1 ? class_1802.field_8367 : class_1802.field_8463;
    }

    public static enum OffhandItem {
        NONE,
        TOTEM,
        CRYSTAL,
        GAPPLE,
        SHIELD,
        CHORUS;

    }
}
