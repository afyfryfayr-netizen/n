package net.hachimi.client.impl.module.combat;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.module.misc.KitModule;
import net.hachimi.client.impl.module.player.SpeedmineModule;
import net.hachimi.client.util.world.BlockUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2480;
import net.minecraft.class_2586;
import net.minecraft.class_2627;
import net.minecraft.class_3532;

public final class AntiRegearModule
extends ToggleModule {
    private static AntiRegearModule INSTANCE;
    Config<Float> safeRangeConfig = this.register(new NumberConfig<Float>("SafeRange", "Shulker boxes within this range of you are ignored", Float.valueOf(0.0f), Float.valueOf(2.0f), Float.valueOf(8.0f)));
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "Maximum range to destroy enemy shulker boxes", Float.valueOf(0.0f), Float.valueOf(5.0f), Float.valueOf(8.0f)));
    Config<Boolean> checkSelfConfig = this.register(new BooleanConfig("CheckSelf", "Ignore shulker boxes placed by your own KitModule", true));

    public AntiRegearModule() {
        super("AntiRegear", "Destroys nearby enemy shulker boxes using Speedmine", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static AntiRegearModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        SpeedmineModule sm = SpeedmineModule.getInstance();
        return sm != null && sm.isEnabled() ? "Mining" : "Ready";
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (AntiRegearModule.mc.field_1724 == null || AntiRegearModule.mc.field_1687 == null) {
            return;
        }
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        class_2627 target = this.findTarget();
        if (target == null) {
            this.disableSpeedmine();
            return;
        }
        class_2338 pos = target.method_11016();
        SpeedmineModule sm = SpeedmineModule.getInstance();
        if (sm != null && !sm.isEnabled()) {
            sm.enable();
        }
        class_2350 side = this.getBreakSide(pos);
        AntiRegearModule.mc.field_1761.method_2910(pos, side);
    }

    @Override
    protected void onDisable() {
        this.disableSpeedmine();
    }

    private class_2627 findTarget() {
        float safeRange = this.safeRangeConfig.getValue().floatValue();
        float range = this.rangeConfig.getValue().floatValue();
        for (class_2586 entity : BlockUtil.blockEntities()) {
            KitModule kit;
            float dist;
            class_2627 shulker;
            if (!(entity instanceof class_2627) || !(AntiRegearModule.mc.field_1687.method_8320((shulker = (class_2627)entity).method_11016()).method_26204() instanceof class_2480) || (dist = class_3532.method_15355((float)((float)AntiRegearModule.mc.field_1724.method_5707(shulker.method_11016().method_46558())))) <= safeRange || this.checkSelfConfig.getValue().booleanValue() && (kit = KitModule.getInstance()) != null && kit.isOwnShulker(shulker.method_11016()) || !(dist <= range)) continue;
            return shulker;
        }
        return null;
    }

    private class_2350 getBreakSide(class_2338 pos) {
        class_2350 best = class_2350.field_11036;
        double bestDist = Double.MAX_VALUE;
        for (class_2350 dir : class_2350.values()) {
            double d = AntiRegearModule.mc.field_1724.method_33571().method_1025(pos.method_46558().method_1031((double)dir.method_10148() * 0.5, (double)dir.method_10164() * 0.5, (double)dir.method_10165() * 0.5));
            if (!(d < bestDist)) continue;
            bestDist = d;
            best = dir;
        }
        return best;
    }

    private void disableSpeedmine() {
        SpeedmineModule sm = SpeedmineModule.getInstance();
        if (sm != null && sm.isEnabled()) {
            sm.disable();
        }
    }
}
