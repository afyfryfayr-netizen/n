package net.hachimi.client.impl.module.combat;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.ObsidianPlacerModule;
import net.hachimi.client.impl.module.combat.SelfTrapModule;
import net.hachimi.client.impl.module.combat.SurroundModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.position.PositionUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.world.BlockUtilPlus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_3726;

public final class BlockerModule
extends ObsidianPlacerModule {
    private static BlockerModule INSTANCE;
    Config<Page> pageConfig = this.register(new EnumConfig("Page", "Settings page", (Enum)Page.General, (Enum[])Page.values()));
    Config<Integer> delayConfig = this.register(new NumberConfig<Integer>("PlaceDelay", "Milliseconds between place batches", Integer.valueOf(0), Integer.valueOf(50), Integer.valueOf(500), () -> this.pageConfig.getValue() == Page.General));
    Config<Integer> blocksPerConfig = this.register(new NumberConfig<Integer>("BlocksPer", "Maximum blocks placed per batch", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(8), () -> this.pageConfig.getValue() == Page.General));
    Config<Boolean> rotatePlaceConfig = this.register(new BooleanConfig("Rotate", "Silently rotates to the block before placing", true, () -> this.pageConfig.getValue() == Page.General));
    Config<Boolean> breakCrystalConfig = this.register(new BooleanConfig("Break", "Attacks crystals blocking a placement before placing", true, () -> this.pageConfig.getValue() == Page.General));
    Config<Boolean> bevelCevConfig = this.register(new BooleanConfig("BevelCev", "Blocks diagonal-above corners next to your head", true, () -> this.pageConfig.getValue() == Page.Target));
    Config<Boolean> faceConfig = this.register(new BooleanConfig("Face", "Blocks crystal placements around your body", true, () -> this.pageConfig.getValue() == Page.Target));
    Config<Boolean> faceUpConfig = this.register(new BooleanConfig("FaceUp", "Also blocks straight above your head", false, () -> this.pageConfig.getValue() == Page.Target && this.faceConfig.getValue() != false));
    Config<Boolean> feetConfig = this.register(new BooleanConfig("Feet", "Watches blocks around your feet for mining and pre-places blockers", true, () -> this.pageConfig.getValue() == Page.Target));
    Config<Boolean> extendConfig = this.register(new BooleanConfig("Extend", "Extends the blocker one extra layer out from the mined block", false, () -> this.pageConfig.getValue() == Page.Target && this.feetConfig.getValue() != false));
    Config<Boolean> burrowConfig = this.register(new BooleanConfig("Burrow", "Also reacts to blocks being mined from directly below/above", true, () -> this.pageConfig.getValue() == Page.Target));
    Config<Boolean> onlySurroundConfig = this.register(new BooleanConfig("OnlySurround", "Only run Face/Feet detection while Surround or SelfTrap is enabled", true, () -> this.pageConfig.getValue() == Page.Target));
    Config<Boolean> inAirPauseConfig = this.register(new BooleanConfig("InAirPause", "Pauses placement while airborne", false, () -> this.pageConfig.getValue() == Page.Check));
    Config<Boolean> detectMiningConfig = this.register(new BooleanConfig("DetectMining", "Don't place into a block that is still being mined", true, () -> this.pageConfig.getValue() == Page.Check));
    Config<Boolean> eatingPauseConfig = this.register(new BooleanConfig("EatingPause", "Pauses placement while eating/using an item", true, () -> this.pageConfig.getValue() == Page.Check));
    private static final double SCAN_OFFSET = 0.3;
    private final Timer placeTimer = new CacheTimer();
    private final List<class_2338> placePos = new ArrayList<class_2338>();
    private final List<class_2338> blockerPos = new ArrayList<class_2338>();
    private final Set<class_2338> placedThisBatch = new LinkedHashSet<class_2338>();
    private class_2338 lastPlayerPos;

    public BlockerModule() {
        super("Blocker", "Blocks crystal placements and mining spots around you", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static BlockerModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        this.placePos.clear();
        this.blockerPos.clear();
        this.placedThisBatch.clear();
        this.lastPlayerPos = null;
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        ObsidianPlacerModule.BlockSlot blockSlot;
        if (BlockerModule.mc.field_1724 == null || BlockerModule.mc.field_1687 == null) {
            return;
        }
        if (this.eatingPauseConfig.getValue().booleanValue() && BlockerModule.mc.field_1724.method_6115()) {
            return;
        }
        if (!this.placeTimer.passed(this.delayConfig.getValue())) {
            return;
        }
        this.placedThisBatch.clear();
        class_2338 playerPos = PositionUtil.getRoundedBlockPos(BlockerModule.mc.field_1724.method_23317(), BlockerModule.mc.field_1724.method_23318(), BlockerModule.mc.field_1724.method_23321());
        if (this.lastPlayerPos != null && !this.lastPlayerPos.equals((Object)playerPos)) {
            this.placePos.clear();
            this.blockerPos.clear();
        }
        this.lastPlayerPos = playerPos;
        boolean surroundActive = this.onlySurroundConfig.getValue() == false || SurroundModule.getInstance() != null && SurroundModule.getInstance().isEnabled() || SelfTrapModule.getInstance() != null && SelfTrapModule.getInstance().isEnabled();
        double[] offsets = new double[]{0.3, -0.3, 0.0};
        if (this.bevelCevConfig.getValue().booleanValue()) {
            for (class_2350 dir : class_2350.values()) {
                class_2338 pos2;
                if (dir == class_2350.field_11033 || this.isBedrock(playerPos.method_10093(dir).method_10084()) || !BlockUtilPlus.hasCrystal(pos2 = playerPos.method_10093(dir).method_10086(2)) || this.placePos.contains(pos2)) continue;
                this.placePos.add(pos2);
            }
        }
        if (this.faceConfig.getValue().booleanValue() && surroundActive) {
            for (double x : offsets) {
                for (double z : offsets) {
                    for (class_2350 dir : class_2350.values()) {
                        for (int d = 0; d < 3; ++d) {
                            class_2338 pos3 = PositionUtil.getRoundedBlockPos(BlockerModule.mc.field_1724.method_23317() + x, BlockerModule.mc.field_1724.method_23318() + 0.5, BlockerModule.mc.field_1724.method_23321() + z).method_10079(dir, d).method_10084();
                            if (!BlockUtilPlus.hasCrystal(pos3) || this.placePos.contains(pos3)) continue;
                            this.placePos.add(pos3);
                        }
                    }
                }
            }
            if (this.faceUpConfig.getValue().booleanValue()) {
                for (class_2350 dir : class_2350.values()) {
                    class_2338 pos2;
                    if (dir == class_2350.field_11033 || this.isBedrock(playerPos.method_10093(dir).method_10084()) || !BlockUtilPlus.hasCrystal(pos2 = playerPos.method_10093(dir).method_10086(2)) || this.placePos.contains(pos2)) continue;
                    this.placePos.add(pos2);
                }
            }
        }
        if ((blockSlot = this.getResistantBlockItem()) == null) {
            return;
        }
        this.placePos.removeIf(pos -> !BlockUtilPlus.clientCanPlace(pos, true));
        if (this.burrowConfig.getValue().booleanValue()) {
            for (double x : offsets) {
                for (double z : offsets) {
                    class_2338 surroundPos = PositionUtil.getRoundedBlockPos(BlockerModule.mc.field_1724.method_23317() + x, BlockerModule.mc.field_1724.method_23318(), BlockerModule.mc.field_1724.method_23321() + z);
                    if (this.isBedrock(surroundPos) || !Managers.BLOCK.isBreaking(surroundPos)) continue;
                    for (class_2350 dir : class_2350.values()) {
                        if (dir == class_2350.field_11036 || dir == class_2350.field_11033) continue;
                        class_2338 defensePos = surroundPos.method_10093(dir);
                        if (this.detectMiningConfig.getValue().booleanValue() && Managers.BLOCK.isBreaking(defensePos)) continue;
                        if (this.breakCrystalConfig.getValue().booleanValue()) {
                            this.attackCrystalAt(defensePos);
                        }
                        if (!BlockUtilPlus.canPlace(defensePos) || this.blockerPos.contains(defensePos)) continue;
                        this.blockerPos.add(defensePos);
                    }
                }
            }
        }
        if (this.feetConfig.getValue().booleanValue() && surroundActive) {
            class_2338 surroundPos;
            for (double x : offsets) {
                for (double z : offsets) {
                    for (class_2350 i : class_2350.values()) {
                        surroundPos = PositionUtil.getRoundedBlockPos(BlockerModule.mc.field_1724.method_23317() + x, BlockerModule.mc.field_1724.method_23318() + 0.5, BlockerModule.mc.field_1724.method_23321() + z).method_10093(i);
                        if (this.isBedrock(surroundPos) || !Managers.BLOCK.isBreaking(surroundPos)) continue;
                        for (class_2350 dir : class_2350.values()) {
                            class_2338 defensePos = surroundPos.method_10093(dir);
                            if (this.detectMiningConfig.getValue().booleanValue() && Managers.BLOCK.isBreaking(defensePos)) continue;
                            if (this.breakCrystalConfig.getValue().booleanValue()) {
                                this.attackCrystalAt(defensePos);
                            }
                            if (!BlockUtilPlus.canPlace(defensePos) || this.blockerPos.contains(defensePos)) continue;
                            this.blockerPos.add(defensePos);
                        }
                    }
                }
            }
            if (this.extendConfig.getValue().booleanValue()) {
                for (double x : offsets) {
                    for (double z : offsets) {
                        for (class_2350 i : class_2350.values()) {
                            if (i == class_2350.field_11036 || i == class_2350.field_11033 || this.isBedrock(surroundPos = PositionUtil.getRoundedBlockPos(BlockerModule.mc.field_1724.method_23317() + x, BlockerModule.mc.field_1724.method_23318() + 0.5, BlockerModule.mc.field_1724.method_23321() + z).method_10093(i))) continue;
                            for (class_2350 dir : class_2350.values()) {
                                class_2338 blockPos;
                                if (dir == class_2350.field_11036 || dir == class_2350.field_11033 || !BlockUtilPlus.canPlaceCrystal(blockPos = surroundPos.method_10093(dir)) || this.detectMiningConfig.getValue().booleanValue() && Managers.BLOCK.isBreaking(blockPos)) continue;
                                if (this.breakCrystalConfig.getValue().booleanValue()) {
                                    this.attackCrystalAt(blockPos);
                                }
                                if (!BlockUtilPlus.canPlace(blockPos) || this.blockerPos.contains(blockPos)) continue;
                                this.blockerPos.add(blockPos);
                            }
                        }
                    }
                }
            }
        }
        this.blockerPos.removeIf(pos -> !BlockUtilPlus.clientCanPlace(pos, true));
        if (this.inAirPauseConfig.getValue().booleanValue() && !BlockerModule.mc.field_1724.method_24828()) {
            return;
        }
        if (this.blockerPos.isEmpty() && this.placePos.isEmpty()) {
            return;
        }
        int placed = 0;
        for (class_2338 pos4 : this.placePos) {
            if (placed >= this.blocksPerConfig.getValue()) break;
            if (!this.tryPlace(pos4, blockSlot)) continue;
            ++placed;
        }
        for (class_2338 pos5 : this.blockerPos) {
            if (placed >= this.blocksPerConfig.getValue()) break;
            if (!this.tryPlace(pos5, blockSlot)) continue;
            ++placed;
        }
        if (placed > 0) {
            this.placeTimer.reset();
        }
    }

    private boolean tryPlace(class_2338 pos, ObsidianPlacerModule.BlockSlot slot) {
        if (this.placedThisBatch.contains(pos)) {
            return false;
        }
        if (!BlockerModule.mc.field_1687.method_8628(DEFAULT_OBSIDIAN_STATE, pos, class_3726.method_16194())) {
            return false;
        }
        Managers.INTERACT.placeBlock(pos, slot.slot(), (boolean)((Boolean)this.strictDirectionConfig.getValue()), false, true, (state, angles) -> {
            if (this.rotatePlaceConfig.getValue().booleanValue() && state) {
                Managers.ROTATION.setRotationSilent(angles[0], angles[1]);
            }
        });
        this.placedThisBatch.add(pos);
        return true;
    }

    private void attackCrystalAt(class_2338 pos) {
        class_1297 crystalEntity = BlockerModule.mc.field_1687.method_8335(null, new class_238(pos)).stream().filter(e -> e instanceof class_1511).findFirst().orElse(null);
        if (crystalEntity == null) {
            return;
        }
        Managers.NETWORK.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)crystalEntity, (boolean)BlockerModule.mc.field_1724.method_5715()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
    }

    private boolean isBedrock(class_2338 pos) {
        return BlockerModule.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_9987;
    }

    public static enum Page {
        General,
        Target,
        Check;

    }
}
