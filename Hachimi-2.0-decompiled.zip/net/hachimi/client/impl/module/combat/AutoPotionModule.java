package net.hachimi.client.impl.module.combat;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2596;
import net.minecraft.class_2815;
import net.minecraft.class_2886;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public class AutoPotionModule
extends ToggleModule {
    private static AutoPotionModule INSTANCE;
    private final Config<Float> delayConfig = this.register(new NumberConfig<Float>("Delay", "Delay between throws (seconds)", Float.valueOf(0.0f), Float.valueOf(5.0f), Float.valueOf(10.0f)));
    private final Config<Boolean> speedConfig = this.register(new BooleanConfig("Speed", "Auto-throw Speed potion", false));
    private final Config<Boolean> resistanceConfig = this.register(new BooleanConfig("Resistance", "Auto-throw Resistance potion", false));
    private final Config<Boolean> strengthConfig = this.register(new BooleanConfig("Strength", "Auto-throw Strength potion", false));
    private final Config<Boolean> slowFallingConfig = this.register(new BooleanConfig("SlowFalling", "Auto-throw Slow Falling potion", false));
    private final Config<Boolean> healthConfig = this.register(new BooleanConfig("Health", "Auto-throw Healing potion when low health", false));
    private final Config<Float> healthThresholdConfig = this.register(new NumberConfig<Float>("HealthThreshold", "Throw healing potion when health is below this value", Float.valueOf(10.0f), Float.valueOf(1.0f), Float.valueOf(20.0f)));
    private final Config<Boolean> usingPauseConfig = this.register(new BooleanConfig("UsingPause", "Pause throwing while using an item", true));
    private final Config<Boolean> onlyGroundConfig = this.register(new BooleanConfig("OnlyGround", "Only throw while on ground", false));
    private final Config<Boolean> inventorySwapConfig = this.register(new BooleanConfig("InventorySwap", "Search full inventory (not just hotbar)", true));
    private final Timer delayTimer = new CacheTimer();

    public AutoPotionModule() {
        super("AutoPotion", "Automatically throws splash potions to maintain effects", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static AutoPotionModule getInstance() {
        return INSTANCE;
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (AutoPotionModule.mc.field_1724 == null || AutoPotionModule.mc.field_1687 == null) {
            return;
        }
        if (!this.delayTimer.passed((long)(this.delayConfig.getValue().floatValue() * 1000.0f))) {
            return;
        }
        if (this.usingPauseConfig.getValue().booleanValue() && AutoPotionModule.mc.field_1724.method_6115()) {
            return;
        }
        if (this.onlyGroundConfig.getValue().booleanValue() && !AutoPotionModule.mc.field_1724.method_24828()) {
            return;
        }
        if (this.healthConfig.getValue().booleanValue()) {
            boolean needsHealing;
            boolean bl = needsHealing = AutoPotionModule.mc.field_1724.method_6032() <= this.healthThresholdConfig.getValue().floatValue();
            if (needsHealing && this.tryThrow((class_6880<class_1291>)class_1294.field_5915)) {
                return;
            }
        }
        if (this.resistanceConfig.getValue().booleanValue()) {
            boolean needs;
            boolean bl = needs = !AutoPotionModule.mc.field_1724.method_6059(class_1294.field_5907) || AutoPotionModule.mc.field_1724.method_6112(class_1294.field_5907).method_5578() < 2;
            if (needs && this.tryThrow((class_6880<class_1291>)class_1294.field_5907)) {
                return;
            }
        }
        if (this.speedConfig.getValue().booleanValue() && !AutoPotionModule.mc.field_1724.method_6059(class_1294.field_5904) && this.tryThrow((class_6880<class_1291>)class_1294.field_5904)) {
            return;
        }
        if (this.strengthConfig.getValue().booleanValue() && !AutoPotionModule.mc.field_1724.method_6059(class_1294.field_5910) && this.tryThrow((class_6880<class_1291>)class_1294.field_5910)) {
            return;
        }
        if (this.slowFallingConfig.getValue().booleanValue() && !AutoPotionModule.mc.field_1724.method_6059(class_1294.field_5906)) {
            this.tryThrow((class_6880<class_1291>)class_1294.field_5906);
        }
    }

    private boolean tryThrow(class_6880<class_1291> targetEffect) {
        int invSlot;
        int hotbarSlot = this.findPotionHotbar(targetEffect);
        if (hotbarSlot != -1) {
            this.throwFromHotbar(hotbarSlot);
            return true;
        }
        if (this.inventorySwapConfig.getValue().booleanValue() && (invSlot = this.findPotionInventory(targetEffect)) != -1) {
            this.throwFromInventory(invSlot);
            return true;
        }
        return false;
    }

    private int findPotionHotbar(class_6880<class_1291> targetEffect) {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = AutoPotionModule.mc.field_1724.method_31548().method_5438(i);
            if (!AutoPotionModule.isSplashPotion(stack) || !AutoPotionModule.hasEffect(stack, targetEffect)) continue;
            return i;
        }
        return -1;
    }

    private int findPotionInventory(class_6880<class_1291> targetEffect) {
        for (int i = 35; i >= 9; --i) {
            class_1799 stack = AutoPotionModule.mc.field_1724.method_31548().method_5438(i);
            if (!AutoPotionModule.isSplashPotion(stack) || !AutoPotionModule.hasEffect(stack, targetEffect)) continue;
            return i;
        }
        return -1;
    }

    private void throwFromHotbar(int slot) {
        int oldSlot = AutoPotionModule.mc.field_1724.method_31548().field_7545;
        Managers.INVENTORY.setSlotForced(slot);
        Managers.ROTATION.setRotationSilent(AutoPotionModule.mc.field_1724.method_36454(), 90.0f);
        Managers.NETWORK.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, AutoPotionModule.mc.field_1724.method_36454(), 90.0f));
        Managers.INVENTORY.setSlotForced(oldSlot);
        Managers.INVENTORY.syncToClient();
        this.delayTimer.reset();
    }

    private void throwFromInventory(int invSlot) {
        int syncId = AutoPotionModule.mc.field_1724.field_7498.field_7763;
        int curHotbar = AutoPotionModule.mc.field_1724.method_31548().field_7545;
        AutoPotionModule.mc.field_1761.method_2906(syncId, invSlot, curHotbar, class_1713.field_7791, (class_1657)AutoPotionModule.mc.field_1724);
        Managers.ROTATION.setRotationSilent(AutoPotionModule.mc.field_1724.method_36454(), 90.0f);
        Managers.NETWORK.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, AutoPotionModule.mc.field_1724.method_36454(), 90.0f));
        AutoPotionModule.mc.field_1761.method_2906(syncId, invSlot, curHotbar, class_1713.field_7791, (class_1657)AutoPotionModule.mc.field_1724);
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2815(syncId));
        this.delayTimer.reset();
    }

    private static boolean isSplashPotion(class_1799 stack) {
        return !stack.method_7960() && class_1792.method_7880((class_1792)stack.method_7909()) == class_1792.method_7880((class_1792)class_1802.field_8436);
    }

    private static boolean hasEffect(class_1799 stack, class_6880<class_1291> targetEffect) {
        class_1844 contents = (class_1844)stack.method_57825(class_9334.field_49651, (Object)class_1844.field_49274);
        for (class_1293 effect : contents.method_57397()) {
            if (!effect.method_5579().equals(targetEffect)) continue;
            return true;
        }
        return false;
    }
}
