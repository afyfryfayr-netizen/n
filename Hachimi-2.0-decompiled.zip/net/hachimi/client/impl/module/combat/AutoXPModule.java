package net.hachimi.client.impl.module.combat;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.NumberDisplay;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.RotationModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.timer.TickTimer;
import net.hachimi.client.util.player.InventoryUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1779;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2815;
import net.minecraft.class_2886;

public class AutoXPModule
extends RotationModule {
    private static AutoXPModule INSTANCE;
    Config<Boolean> multiTaskConfig = this.register(new BooleanConfig("MultiTask", "Allows you to throw xp while using items", false));
    Config<Float> delayConfig = this.register(new NumberConfig<Float>("Delay", "Delay to throw xp in ticks", Float.valueOf(1.0f), Float.valueOf(1.0f), Float.valueOf(10.0f), NumberDisplay.DEFAULT));
    Config<Integer> shiftTicksConfig = this.register(new NumberConfig<Integer>("ShiftTicks", "The number of xp bottles to throw in one tick", 1, 1, 64));
    Config<Boolean> durabilityCheckConfig = this.register(new BooleanConfig("DurabilityCheck", "Disables when armor and held item durability is full", true));
    Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Rotates the player while throwing xp", false));
    Config<Swing> swingConfig = this.register(new EnumConfig("Swing", "Hand swing mode while throwing xp", (Enum)Swing.NONE, (Enum[])Swing.values()));
    Config<SwapAction> swapActionConfig = this.register(new EnumConfig("SwapAction", "HOTBAR: find bottle in hotbar slots 0-8. SCREEN: find anywhere in inventory via swap click", (Enum)SwapAction.HOTBAR, (Enum[])SwapAction.values()));
    Config<Boolean> autoDisableConfig = this.register(new BooleanConfig("AutoDisable", "Disable when no xp bottles are found", true));
    private final TickTimer delayTimer = new TickTimer();

    public AutoXPModule() {
        super("AutoXP", "Automatically throws xp silently.", ModuleCategory.COMBAT, 850);
        INSTANCE = this;
    }

    public static AutoXPModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        return String.valueOf(InventoryUtil.count(class_1802.field_8287));
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (AutoXPModule.mc.field_1724 == null || !this.delayTimer.passed(this.delayConfig.getValue())) {
            return;
        }
        if (AutoXPModule.mc.field_1724.method_6115() && !this.multiTaskConfig.getValue().booleanValue()) {
            return;
        }
        if (this.durabilityCheckConfig.getValue().booleanValue() && this.areItemsFullDura((class_1657)AutoXPModule.mc.field_1724)) {
            this.disable();
            return;
        }
        if (this.rotateConfig.getValue().booleanValue()) {
            this.setRotation(AutoXPModule.mc.field_1724.method_36454(), 90.0f);
            if (this.isRotationBlocked()) {
                return;
            }
        }
        if (this.swapActionConfig.getValue() == SwapAction.HOTBAR) {
            this.throwHotbar();
        } else {
            this.throwScreen();
        }
        this.delayTimer.reset();
    }

    private void throwHotbar() {
        int slot = this.findBottleHotbar();
        if (slot == -1) {
            if (this.autoDisableConfig.getValue().booleanValue()) {
                this.disable();
            }
            return;
        }
        int prevSlot = AutoXPModule.mc.field_1724.method_31548().field_7545;
        Managers.INVENTORY.setSlotForced(slot);
        this.sendThrow();
        if (prevSlot != slot) {
            Managers.INVENTORY.setSlotForced(prevSlot);
        }
    }

    private void throwScreen() {
        int slot = this.findBottleHotbar();
        if (slot != -1) {
            this.throwHotbar();
            return;
        }
        int invSlot = this.findBottleInventory();
        if (invSlot == -1) {
            if (this.autoDisableConfig.getValue().booleanValue()) {
                this.disable();
            }
            return;
        }
        int syncId = AutoXPModule.mc.field_1724.field_7498.field_7763;
        int curHotbar = AutoXPModule.mc.field_1724.method_31548().field_7545;
        AutoXPModule.mc.field_1761.method_2906(syncId, invSlot, curHotbar, class_1713.field_7791, (class_1657)AutoXPModule.mc.field_1724);
        Managers.INVENTORY.setSlotForced(curHotbar);
        this.sendThrow();
        AutoXPModule.mc.field_1761.method_2906(syncId, invSlot, curHotbar, class_1713.field_7791, (class_1657)AutoXPModule.mc.field_1724);
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2815(syncId));
        Managers.INVENTORY.syncToClient();
    }

    private void sendThrow() {
        for (int i = 0; i < this.shiftTicksConfig.getValue(); ++i) {
            Managers.NETWORK.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, AutoXPModule.mc.field_1724.method_36454(), AutoXPModule.mc.field_1724.method_36455()));
            this.doSwing();
        }
    }

    private void doSwing() {
        switch (this.swingConfig.getValue().ordinal()) {
            case 1: {
                AutoXPModule.mc.field_1724.method_6104(class_1268.field_5808);
                break;
            }
            case 2: {
                AutoXPModule.mc.field_1724.method_6104(class_1268.field_5810);
                break;
            }
        }
    }

    private int findBottleHotbar() {
        for (int i = 0; i < 9; ++i) {
            if (!(AutoXPModule.mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1779)) continue;
            return i;
        }
        return -1;
    }

    private int findBottleInventory() {
        for (int i = 9; i < 36; ++i) {
            if (!(AutoXPModule.mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1779)) continue;
            return i;
        }
        return -1;
    }

    private boolean areItemsFullDura(class_1657 player) {
        if (!this.isItemFullDura(player.method_6047()) || !this.isItemFullDura(player.method_6079())) {
            return false;
        }
        for (class_1799 stack : player.method_5661()) {
            if (this.isItemFullDura(stack)) continue;
            return false;
        }
        return true;
    }

    private boolean isItemFullDura(class_1799 stack) {
        if (stack.method_7960() || stack.method_7936() == 0) {
            return true;
        }
        return stack.method_7919() == 0;
    }

    public static enum Swing {
        NONE,
        MAIN,
        OFFHAND;

    }

    public static enum SwapAction {
        HOTBAR,
        SCREEN;

    }
}
