package net.hachimi.client.impl.module.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.BlockPlacerModule;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;

public class AutoWebModule
extends BlockPlacerModule {
    private static AutoWebModule INSTANCE;
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("PlaceRange", "The range to fill nearby holes", Float.valueOf(0.1f), Float.valueOf(4.0f), Float.valueOf(6.0f)));
    Config<Float> enemyRangeConfig = this.register(new NumberConfig<Float>("EnemyRange", "The maximum range of targets", Float.valueOf(0.1f), Float.valueOf(10.0f), Float.valueOf(15.0f)));
    Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Rotates to block before placing", false));
    Config<Boolean> coverHeadConfig = this.register(new BooleanConfig("CoverHead", "Places webs on the targets head", false));
    Config<Integer> shiftTicksConfig = this.register(new NumberConfig<Integer>("ShiftTicks", "The number of blocks to place per tick", 1, 2, 5));
    Config<Integer> shiftDelayConfig = this.register(new NumberConfig<Integer>("ShiftDelay", "The delay between each block placement interval", 0, 1, 5));
    Config<Boolean> renderConfig = this.register(new BooleanConfig("Render", "Renders web placements", false));
    Config<Integer> fadeTimeConfig = this.register(new NumberConfig<Integer>("Fade-Time", "Time to fade", Integer.valueOf(0), Integer.valueOf(250), Integer.valueOf(1000), () -> false));
    private int shiftDelay;
    private List<class_2338> webs = new ArrayList<class_2338>();
    private final Map<class_2338, Animation> fadeList = new HashMap<class_2338, Animation>();

    public AutoWebModule() {
        super("AutoWeb", "Automatically traps nearby entities in webs", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static AutoWebModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        this.fadeList.clear();
        this.webs.clear();
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        this.disable();
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (!((Boolean)this.multitaskConfig.getValue()).booleanValue() && this.checkMultitask()) {
            this.webs.clear();
            return;
        }
        int blocksPlaced = 0;
        int slot = this.getBlockItemSlot(class_2246.field_10343);
        if (slot == -1) {
            this.webs.clear();
            return;
        }
        if (this.shiftDelay < this.shiftDelayConfig.getValue()) {
            ++this.shiftDelay;
            return;
        }
        ArrayList<class_2338> webPlacements = new ArrayList<class_2338>();
        for (class_1657 entity : AutoWebModule.mc.field_1687.method_18456()) {
            double d;
            if (entity == AutoWebModule.mc.field_1724 || Managers.SOCIAL.isFriend(entity.method_5477()) || (d = (double)AutoWebModule.mc.field_1724.method_5739((class_1297)entity)) > (double)this.enemyRangeConfig.getValue().floatValue()) continue;
            class_2338 feetPos = entity.method_24515();
            double dist = AutoWebModule.mc.field_1724.method_33571().method_1025(feetPos.method_46558());
            if (AutoWebModule.mc.field_1687.method_8320(feetPos).method_26215() && dist <= ((NumberConfig)this.rangeConfig).getValueSq()) {
                webPlacements.add(feetPos);
            }
            if (!this.coverHeadConfig.getValue().booleanValue()) continue;
            class_2338 headPos = feetPos.method_10084();
            double dist2 = AutoWebModule.mc.field_1724.method_33571().method_1025(headPos.method_46558());
            if (!AutoWebModule.mc.field_1687.method_8320(headPos).method_26215() || !(dist2 <= ((NumberConfig)this.rangeConfig).getValueSq())) continue;
            webPlacements.add(headPos);
        }
        this.webs = webPlacements;
        if (this.webs.isEmpty()) {
            return;
        }
        while (blocksPlaced < this.shiftTicksConfig.getValue() && blocksPlaced < this.webs.size()) {
            class_2338 targetPos = this.webs.get(blocksPlaced);
            ++blocksPlaced;
            this.shiftDelay = 0;
            this.placeWeb(targetPos, slot);
        }
        if (this.rotateConfig.getValue().booleanValue()) {
            Managers.ROTATION.setRotationSilentSync();
        }
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (this.renderConfig.getValue().booleanValue()) {
            RenderBuffers.preRender();
            for (Map.Entry<class_2338, Animation> set : this.fadeList.entrySet()) {
                set.getValue().setState(false);
                int lineAlpha = (int)(120.0 * set.getValue().getFactor());
                Color lineColor = ColorsModule.getInstance().getColor(lineAlpha);
                class_2338 blockPos = set.getKey();
                double x1 = blockPos.method_10263();
                double y1 = blockPos.method_10264();
                double z1 = blockPos.method_10260();
                double x2 = (double)blockPos.method_10263() + 1.0;
                double y2 = (double)blockPos.method_10264() + 1.0;
                double z2 = (double)blockPos.method_10260() + 1.0;
                RenderManager.renderPlane(event.getMatrices(), x1, y1, z1, x2, y2, z2, lineColor.getRGB());
                RenderManager.renderPlane(event.getMatrices(), x2, y1, z1, x1, y2, z2, lineColor.getRGB());
            }
            RenderBuffers.postRender();
            if (this.webs.isEmpty()) {
                return;
            }
            for (class_2338 pos : this.webs) {
                Animation animation = new Animation(true, this.fadeTimeConfig.getValue().intValue());
                this.fadeList.put(pos, animation);
            }
        }
        this.fadeList.entrySet().removeIf(e -> ((Animation)e.getValue()).getFactor() == 0.0);
    }

    private void placeWeb(class_2338 pos, int slot) {
        Managers.INTERACT.placeBlock(pos, slot, (boolean)((Boolean)this.strictDirectionConfig.getValue()), false, (state, angles) -> {
            if (this.rotateConfig.getValue().booleanValue() && state) {
                Managers.ROTATION.setRotationSilent(angles[0], angles[1]);
            }
        });
    }

    public boolean isPlacing() {
        return !this.webs.isEmpty();
    }
}
