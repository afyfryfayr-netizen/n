package net.hachimi.client.impl.module.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.CombatModule;
import net.hachimi.client.impl.module.client.AnticheatModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.player.SnapRotation;
import net.hachimi.client.util.world.BlockUtilPlus;
import net.hachimi.client.util.world.ExplosionUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2436;
import net.minecraft.class_2459;
import net.minecraft.class_2596;
import net.minecraft.class_2665;
import net.minecraft.class_2671;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_746;

public class PistonCrystalModule
extends CombatModule {
    private final Config<Float> minDamage = this.register(new NumberConfig<Float>("MinDamage", "Minimum damage to attempt a sequence", Float.valueOf(1.0f), Float.valueOf(6.0f), Float.valueOf(20.0f)));
    private final Config<Float> maxLocalDamage = this.register(new NumberConfig<Float>("MaxLocalDamage", "Max self-damage allowed", Float.valueOf(1.0f), Float.valueOf(12.0f), Float.valueOf(20.0f)));
    private final Config<Integer> delay = this.register(new NumberConfig<Integer>("Delay", "Delay between place actions (ticks)", 0, 0, 10));
    private final Config<Sort> sort = this.register(new EnumConfig("Sort", "How to pick target", (Enum)Sort.CLOSE_ANGLE, (Enum[])Sort.values()));
    private final Config<Float> targetRange = this.register(new NumberConfig<Float>("TargetRange", "Max target range", Float.valueOf(1.0f), Float.valueOf(6.0f), Float.valueOf(20.0f)));
    private final Config<Boolean> inAirTarget = this.register(new BooleanConfig("InAirTarget", "Target players in the air", true));
    private final Config<Boolean> breakCrystal = this.register(new BooleanConfig("BreakCrystal", "Attack crystal after placing it", true));
    private final Config<Float> placeRange = this.register(new NumberConfig<Float>("PlaceRange", "Range to place blocks", Float.valueOf(0.1f), Float.valueOf(4.5f), Float.valueOf(6.0f)));
    private final Config<Float> breakRange = this.register(new NumberConfig<Float>("BreakRange", "Range to break crystals", Float.valueOf(0.1f), Float.valueOf(4.5f), Float.valueOf(6.0f)));
    private final Config<Boolean> rotate = this.register(new BooleanConfig("Rotate", "Silently rotate to placed blocks", true));
    private final Config<Boolean> grim = this.register(new BooleanConfig("Grim", "YawDeceive \u2014 filter dir by player facing & override piston yaw", true, () -> this.rotate.getValue()));
    private final Config<SwapAction> swapAction = this.register(new EnumConfig("SwapAction", "How to swap to required items", (Enum)SwapAction.SCREEN, (Enum[])SwapAction.values()));
    private final Config<Boolean> airPlace = this.register(new BooleanConfig("AirPlace", "Allow placing when not on ground", false));
    private final Config<Boolean> safety = this.register(new BooleanConfig("Safety", "Skip if crystal would kill self", true));
    private final Config<Boolean> blockDestruction = this.register(new BooleanConfig("BlockDestruction", "Account for explosion block destruction", false));
    private final Config<Boolean> selfExtrapolate = this.register(new BooleanConfig("SelfExtrapolate", "Extrapolate self position for self-damage calc", false));
    private final Config<Integer> extrapolationTicks = this.register(new NumberConfig<Integer>("ExtrapolationTicks", "Ticks to extrapolate enemy position", 0, 0, 10));
    private final Config<Boolean> assumeBestArmor = this.register(new BooleanConfig("AssumeBestArmor", "Assume target has Prot 4 netherite", false));
    private class_2338 pistonPos;
    private class_2338 redstonePos;
    private class_2338 crystalPos;
    private class_2338 lastPiston;
    private class_2350 face;
    private boolean usingTorch;
    private class_1657 target;
    private long lastActionMs = 0L;
    private long breakTimerMs = 0L;
    private int preSwapSlot = -1;

    public PistonCrystalModule() {
        super("PistonCrystal", "Places piston + redstone to push a crystal into targets", ModuleCategory.COMBAT, 75);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.resetState();
        this.breakTimerMs = System.currentTimeMillis() + 99999999L;
        SnapRotation.INSTANCE.subscribe();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.resetState();
        SnapRotation.INSTANCE.unsubscribe();
        SnapRotation.reset();
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        class_2350 side;
        if (PistonCrystalModule.mc.field_1724 == null || PistonCrystalModule.mc.field_1687 == null) {
            return;
        }
        if (PistonCrystalModule.mc.field_1724.method_6115()) {
            return;
        }
        long nowMs = System.currentTimeMillis();
        if (nowMs - this.lastActionMs < (long)this.delay.getValue().intValue() * 50L) {
            return;
        }
        int crystalSlot = this.findItem(class_1802.field_8301);
        int pistonSlot = this.findItemClass(class_2665.class);
        int redstoneSlot = this.findRedstone();
        if (crystalSlot == -1 || pistonSlot == -1 || redstoneSlot == -1) {
            this.resetState();
            return;
        }
        this.target = this.pickTarget();
        if (this.target == null) {
            return;
        }
        if (!(this.crystalPos == null || this.redstonePos == null || this.pistonPos == null || BlockUtilPlus.canPlaceCrystal(this.crystalPos) && BlockUtilPlus.canPlace(this.redstonePos) && BlockUtilPlus.canPlace(this.pistonPos))) {
            this.resetState();
        }
        if (this.pistonPos == null && this.crystalPos == null && this.redstonePos == null) {
            this.doPistonCrystal(this.target);
        }
        if (this.lastPiston != null && this.face != null && PistonCrystalModule.mc.field_1687.method_8320(this.lastPiston.method_10093(this.face.method_10153())).method_26204() instanceof class_2671 && PistonCrystalModule.mc.field_1687.method_8320(this.lastPiston).method_26204() instanceof class_2665 && (side = BlockUtilPlus.getClickSide(this.lastPiston)) != null) {
            PistonCrystalModule.mc.field_1761.method_2910(this.lastPiston, side);
            this.resetState();
            return;
        }
        if (this.pistonPos != null && BlockUtilPlus.canPlace(this.pistonPos)) {
            this.placeBlock(pistonSlot, this.pistonPos, this.face);
            this.lastPiston = this.pistonPos;
        }
        if (this.redstonePos != null && BlockUtilPlus.canPlace(this.redstonePos)) {
            if (this.usingTorch) {
                this.placeTorch(redstoneSlot, this.redstonePos);
            } else {
                this.placeBlock(redstoneSlot, this.redstonePos, null);
            }
        }
        if (this.crystalPos != null && BlockUtilPlus.canPlaceCrystal(this.crystalPos)) {
            this.placeCrystal(crystalSlot, this.crystalPos);
            this.lastActionMs = nowMs;
            this.breakTimerMs = nowMs;
            return;
        }
        if (this.breakCrystal.getValue().booleanValue() && nowMs - this.breakTimerMs >= (long)this.delay.getValue().intValue() * 50L) {
            for (int yOff = -1; yOff <= 2; ++yOff) {
                class_2338 check = this.target.method_24515().method_10086(yOff);
                if (!BlockUtilPlus.hasCrystal(check)) continue;
                this.attackCrystalAt(check);
                this.lastActionMs = nowMs;
                this.breakTimerMs = nowMs;
                this.resetState();
                break;
            }
        }
    }

    private void doPistonCrystal(class_1657 tgt) {
        class_2338 base = tgt.method_24515();
        int ticks = this.extrapolationTicks.getValue();
        class_243 vel = tgt.method_18798();
        double ex = tgt.method_23317() + vel.field_1352 * (double)ticks;
        double ey = tgt.method_23318() + vel.field_1351 * (double)ticks;
        double ez = tgt.method_23321() + vel.field_1350 * (double)ticks;
        base = class_2338.method_49637((double)ex, (double)ey, (double)ez);
        for (int h : new int[]{0, 1, 2}) {
            class_2338 standPos = base.method_10086(h);
            class_243 vec = new class_243((double)standPos.method_10263() + 0.5, (double)standPos.method_10264(), (double)standPos.method_10260() + 0.5);
            float dmg = (float)ExplosionUtil.getDamageTo((class_1297)tgt, vec, (boolean)this.blockDestruction.getValue(), ticks, (boolean)this.assumeBestArmor.getValue());
            float selfDmg = (float)ExplosionUtil.getDamageTo((class_1297)PistonCrystalModule.mc.field_1724, vec, (boolean)this.blockDestruction.getValue(), this.selfExtrapolate.getValue() != false ? ticks : 0, (boolean)this.assumeBestArmor.getValue());
            if (dmg <= this.minDamage.getValue().floatValue() || selfDmg > this.maxLocalDamage.getValue().floatValue() || this.safety.getValue().booleanValue() && selfDmg >= PistonCrystalModule.mc.field_1724.method_6032() + PistonCrystalModule.mc.field_1724.method_6067() || !this.trySearch(base, h)) continue;
            return;
        }
    }

    private boolean trySearch(class_2338 base, int height) {
        ArrayList<class_2350> dirs = new ArrayList<class_2350>();
        class_2350 facing = PistonCrystalModule.mc.field_1724.method_5735();
        dirs.add(facing);
        for (class_2350 d2 : class_2350.class_2353.field_11062) {
            if (d2 == facing) continue;
            dirs.add(d2);
        }
        for (class_2350 dir : dirs) {
            class_2338 temp1 = base.method_10093(dir).method_10086(height);
            if (!BlockUtilPlus.canPlaceCrystal(temp1) || !this.inRange(temp1, this.placeRange.getValue().floatValue())) continue;
            class_2338 tempPiston = null;
            class_2338 tempRedstone = null;
            block2: for (class_2350 dir2 : class_2350.class_2353.field_11062) {
                class_2338 temp2;
                class_2338 extCheck;
                if (dir2 == dir.method_10153() || !PistonCrystalModule.mc.field_1687.method_22347(extCheck = (temp2 = temp1.method_10093(dir).method_10093(dir2)).method_10093(dir.method_10153())) && !PistonCrystalModule.mc.field_1687.method_8320(extCheck).method_45474()) continue;
                if (!BlockUtilPlus.canPlace(temp2) && !(PistonCrystalModule.mc.field_1687.method_8320(temp2).method_26204() instanceof class_2665)) {
                    for (class_2350 help : class_2350.values()) {
                        int redSlot;
                        class_2350 side;
                        class_2338 helpPos;
                        if (help == dir.method_10153() || !BlockUtilPlus.isGrimDirection(helpPos = temp2.method_10093(help), help.method_10153()) || !BlockUtilPlus.canPlace(helpPos) || !this.inRange(helpPos, this.placeRange.getValue().floatValue()) || (side = BlockUtilPlus.getPlaceSide(helpPos, d -> true)) == null || (redSlot = this.findRedstone()) == -1) continue;
                        this.doSwap(redSlot);
                        if (this.rotate.getValue().booleanValue()) {
                            this.doRotate(helpPos, side);
                        }
                        BlockUtilPlus.placeBlock(helpPos, side, false);
                        if (this.rotate.getValue().booleanValue()) {
                            this.doSnapBack();
                        }
                        this.restoreSlot(redSlot);
                        return true;
                    }
                    continue;
                }
                if (!this.inRange(temp2, this.placeRange.getValue().floatValue())) continue;
                tempPiston = temp2;
                for (class_2350 dir3 : class_2350.values()) {
                    if (dir3 == dir.method_10153()) continue;
                    class_2338 temp3 = temp2.method_10093(dir3);
                    if (PistonCrystalModule.mc.field_1687.method_8320(temp3).method_26204() instanceof class_2436 || PistonCrystalModule.mc.field_1687.method_8320(temp3).method_26204() instanceof class_2459) {
                        tempRedstone = temp2.method_10093(dir3);
                        break block2;
                    }
                    if (!BlockUtilPlus.canPlace(temp3) || !this.inRange(temp3, this.placeRange.getValue().floatValue())) continue;
                    tempRedstone = temp2.method_10093(dir3);
                    break block2;
                }
                break;
            }
            if (tempPiston == null || tempRedstone == null) continue;
            this.face = dir;
            this.crystalPos = temp1;
            this.pistonPos = tempPiston;
            this.redstonePos = tempRedstone;
            return true;
        }
        return false;
    }

    private void placeBlock(int slot, class_2338 pos, class_2350 pistonDir) {
        if (slot == -1) {
            return;
        }
        class_2350 side = BlockUtilPlus.getPlaceSide(pos, d -> true);
        if (side == null) {
            return;
        }
        this.doSwap(slot);
        if (this.rotate.getValue().booleanValue()) {
            this.doRotate(pos, side);
            if (pistonDir != null && this.grim.getValue().booleanValue()) {
                this.pistonFacingSnap(pistonDir);
            }
        }
        BlockUtilPlus.placeBlock(pos, side, false);
        if (this.rotate.getValue().booleanValue()) {
            this.doSnapBack();
        }
        this.restoreSlot(slot);
    }

    private void placeCrystal(int slot, class_2338 cp) {
        class_2338 base = cp.method_10074();
        class_2350 side = BlockUtilPlus.getClickSide(base);
        if (side == null) {
            side = class_2350.field_11036;
        }
        if (slot == -1) {
            return;
        }
        this.doSwap(slot);
        if (this.rotate.getValue().booleanValue()) {
            this.doRotate(base, side);
        }
        BlockUtilPlus.clickBlock(base, side, false);
        if (this.rotate.getValue().booleanValue()) {
            this.doSnapBack();
        }
        this.restoreSlot(slot);
    }

    private void placeTorch(int slot, class_2338 pos) {
        if (!BlockUtilPlus.canPlace(pos)) {
            return;
        }
        if (slot == -1) {
            return;
        }
        List<class_2350> sides = BlockUtilPlus.getPlaceSides(pos, null);
        if (sides.isEmpty()) {
            return;
        }
        for (class_2350 side : sides) {
            if (PistonCrystalModule.mc.field_1687.method_8320(pos.method_10093(side)).method_26204() instanceof class_2665 || side == class_2350.field_11036) continue;
            this.doSwap(slot);
            if (this.rotate.getValue().booleanValue()) {
                this.doRotate(pos, side);
            }
            BlockUtilPlus.placeBlock(pos, side, false);
            if (this.rotate.getValue().booleanValue()) {
                this.doSnapBack();
            }
            this.restoreSlot(slot);
            return;
        }
    }

    private void attackCrystalAt(class_2338 pos) {
        List crystals = PistonCrystalModule.mc.field_1687.method_8390(class_1511.class, new class_238(pos).method_1014(1.0), e -> e.method_5805());
        if (crystals.isEmpty()) {
            return;
        }
        double brSq = this.breakRange.getValue().floatValue() * this.breakRange.getValue().floatValue();
        class_1511 crystal = crystals.stream().filter(e -> PistonCrystalModule.mc.field_1724.method_5858((class_1297)e) <= brSq).min(Comparator.comparingDouble(e -> PistonCrystalModule.mc.field_1724.method_5858((class_1297)e))).orElse(null);
        if (crystal == null) {
            return;
        }
        if (this.rotate.getValue().booleanValue()) {
            this.applyAnticheatFlags();
            SnapRotation.snapAt(crystal.method_5829());
        }
        Managers.NETWORK.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)crystal, (boolean)PistonCrystalModule.mc.field_1724.method_5715()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        if (this.rotate.getValue().booleanValue()) {
            this.doSnapBack();
        }
    }

    private void applyAnticheatFlags() {
        AnticheatModule ac = AnticheatModule.getInstance();
        SnapRotation.grimFull = ac != null ? ac.isGrimRotation() : true;
        SnapRotation.doSnapBack = ac != null ? ac.isSnapBack() : false;
    }

    private void doRotate(class_2338 pos, class_2350 side) {
        this.applyAnticheatFlags();
        SnapRotation.snapAt(pos.method_46558().method_1031((double)side.method_10148() * 0.5, (double)side.method_10164() * 0.5, (double)side.method_10165() * 0.5));
    }

    private void pistonFacingSnap(class_2350 dir) {
        this.applyAnticheatFlags();
        if (dir == class_2350.field_11034) {
            SnapRotation.snapAt(-90.0f, 5.0f);
        } else if (dir == class_2350.field_11039) {
            SnapRotation.snapAt(90.0f, 5.0f);
        } else if (dir == class_2350.field_11043) {
            SnapRotation.snapAt(180.0f, 5.0f);
        } else {
            SnapRotation.snapAt(0.0f, 5.0f);
        }
    }

    private void doSnapBack() {
        boolean sb;
        AnticheatModule ac = AnticheatModule.getInstance();
        boolean bl = sb = ac != null ? ac.isSnapBack() : false;
        if (sb) {
            SnapRotation.snapBack();
        } else {
            SnapRotation.holdActive = false;
        }
    }

    private void doSwap(int slot) {
        if (slot < 0) {
            return;
        }
        this.preSwapSlot = PistonCrystalModule.mc.field_1724.method_31548().field_7545;
        switch (this.swapAction.getValue().ordinal()) {
            case 0: {
                if (slot < 9) {
                    Managers.INVENTORY.setClientSlot(slot);
                    break;
                }
                PistonCrystalModule.mc.field_1761.method_2906(PistonCrystalModule.mc.field_1724.field_7498.field_7763, slot, this.preSwapSlot + 36, class_1713.field_7791, (class_1657)PistonCrystalModule.mc.field_1724);
                Managers.INVENTORY.setClientSlot(this.preSwapSlot);
                break;
            }
            case 1: {
                if (slot >= 9) break;
                Managers.INVENTORY.setClientSlot(slot);
                break;
            }
        }
    }

    private void restoreSlot(int slot) {
        if (this.preSwapSlot == -1) {
            return;
        }
        if (this.swapAction.getValue() == SwapAction.SCREEN && slot >= 9) {
            PistonCrystalModule.mc.field_1761.method_2906(PistonCrystalModule.mc.field_1724.field_7498.field_7763, slot, this.preSwapSlot + 36, class_1713.field_7791, (class_1657)PistonCrystalModule.mc.field_1724);
        } else if (this.swapAction.getValue() != SwapAction.NONE) {
            Managers.INVENTORY.setClientSlot(this.preSwapSlot);
        }
        this.preSwapSlot = -1;
    }

    private int findItem(class_1792 item) {
        if (this.swapAction.getValue() == SwapAction.NONE) {
            class_1799 h = PistonCrystalModule.mc.field_1724.method_31548().method_5438(PistonCrystalModule.mc.field_1724.method_31548().field_7545);
            return !h.method_7960() && h.method_7909() == item ? PistonCrystalModule.mc.field_1724.method_31548().field_7545 : -1;
        }
        int end = this.swapAction.getValue() == SwapAction.SCREEN ? 36 : 9;
        for (int i = 0; i < end; ++i) {
            class_1799 s = PistonCrystalModule.mc.field_1724.method_31548().method_5438(i);
            if (s.method_7960() || s.method_7909() != item) continue;
            return i;
        }
        return -1;
    }

    private int findItemClass(Class<?> c) {
        if (this.swapAction.getValue() == SwapAction.NONE) {
            class_1747 bi;
            class_1792 class_17922;
            class_1799 h = PistonCrystalModule.mc.field_1724.method_31548().method_5438(PistonCrystalModule.mc.field_1724.method_31548().field_7545);
            if (!h.method_7960() && (class_17922 = h.method_7909()) instanceof class_1747 && c.isInstance((bi = (class_1747)class_17922).method_7711())) {
                return PistonCrystalModule.mc.field_1724.method_31548().field_7545;
            }
            return -1;
        }
        int end = this.swapAction.getValue() == SwapAction.SCREEN ? 36 : 9;
        for (int i = 0; i < end; ++i) {
            class_1747 bi;
            class_1792 class_17923;
            class_1799 s = PistonCrystalModule.mc.field_1724.method_31548().method_5438(i);
            if (s.method_7960() || !((class_17923 = s.method_7909()) instanceof class_1747) || !c.isInstance((bi = (class_1747)class_17923).method_7711())) continue;
            return i;
        }
        return -1;
    }

    private int findRedstone() {
        int slot = this.findItem(class_1802.field_8793);
        if (slot != -1) {
            this.usingTorch = false;
            return slot;
        }
        slot = this.findItem(class_1802.field_8530);
        if (slot != -1) {
            this.usingTorch = true;
            return slot;
        }
        return -1;
    }

    private class_1657 pickTarget() {
        double r = this.targetRange.getValue().floatValue();
        return PistonCrystalModule.mc.field_1687.method_18456().stream().filter(e -> !(e instanceof class_746)).filter(e -> !e.method_7325() && !e.method_29504()).filter(e -> PistonCrystalModule.mc.field_1724.method_5858((class_1297)e) <= r * r).filter(e -> !Managers.SOCIAL.isFriend(e.method_5477().getString())).filter(e -> this.inAirTarget.getValue() != false || e.method_24828()).min(this.getComparator()).orElse(null);
    }

    private Comparator<class_1657> getComparator() {
        return switch (this.sort.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 2 -> Comparator.comparingDouble(e -> e.method_6032() + e.method_6067());
            case 0, 1 -> Comparator.comparingDouble(e -> PistonCrystalModule.mc.field_1724.method_5858((class_1297)e));
        };
    }

    private boolean inRange(class_2338 pos, double r) {
        return PistonCrystalModule.mc.field_1724.method_5649((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5) <= r * r;
    }

    private void resetState() {
        this.pistonPos = null;
        this.redstonePos = null;
        this.crystalPos = null;
        this.lastPiston = null;
        this.face = null;
        this.usingTorch = false;
    }

    public static enum Sort {
        CLOSE_ANGLE,
        LOWEST_DISTANCE,
        LOWEST_HEALTH;

    }

    public static enum SwapAction {
        SCREEN,
        HOTBAR,
        NONE;

    }
}
