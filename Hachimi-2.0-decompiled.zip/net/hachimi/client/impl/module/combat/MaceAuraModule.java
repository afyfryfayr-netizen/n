package net.hachimi.client.impl.module.combat;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.CombatModule;
import net.hachimi.client.init.Managers;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_5134;
import net.minecraft.class_9285;
import net.minecraft.class_9334;

public class MaceAuraModule
extends CombatModule {
    private static MaceAuraModule INSTANCE;
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "Horizontal attack range (blocks)", Float.valueOf(1.0f), Float.valueOf(4.0f), Float.valueOf(8.0f)));
    Config<Float> approachRangeConfig = this.register(new NumberConfig<Float>("ApproachRange", "Horizontal acquisition radius", Float.valueOf(6.0f), Float.valueOf(24.0f), Float.valueOf(50.0f)));
    Config<Float> vertRangeConfig = this.register(new NumberConfig<Float>("VerticalRange", "Max Y-delta above target", Float.valueOf(5.0f), Float.valueOf(20.0f), Float.valueOf(30.0f)));
    Config<Float> minHeightConfig = this.register(new NumberConfig<Float>("MinHeight", "Min Y above target before folding", Float.valueOf(1.0f), Float.valueOf(2.5f), Float.valueOf(15.0f)));
    Config<Float> smashThresholdConfig = this.register(new NumberConfig<Float>("SmashThreshold", "Spoofed fall distance (server min 1.5)", Float.valueOf(1.6f), Float.valueOf(1.7f), Float.valueOf(6.0f)));
    Config<Float> foldDelayConfig = this.register(new NumberConfig<Float>("FoldDelay", "Ticks to wait after fold before striking", Float.valueOf(1.0f), Float.valueOf(2.0f), Float.valueOf(8.0f)));
    Config<Float> attackDelayConfig = this.register(new NumberConfig<Float>("Delay", "ms between attack cycles", Float.valueOf(50.0f), Float.valueOf(250.0f), Float.valueOf(2000.0f)));
    Config<Boolean> autoTargetConfig = this.register(new BooleanConfig("AutoTarget", "Auto-pick nearest player in range", true));
    Config<Boolean> silentSwapConfig = this.register(new BooleanConfig("SilentSwap", "Swap to mace silently for the hit, swap back", true));
    Config<Boolean> attributeSwapConfig = this.register(new BooleanConfig("AttributeSwap", "Pre-attack with sword for extended reach before mace smash", false));
    Config<Boolean> xzSpoofConfig = this.register(new BooleanConfig("XZSpoof", "Fake X/Z to the target so reach gate always passes", true));
    private DipState dipState = DipState.IDLE;
    private int stateTicks = 0;
    private class_1657 dipTarget = null;
    private long lastAttackMs = 0L;

    public MaceAuraModule() {
        super("MaceAura", "Mace smash via two-tick fold\u2192strike spoof", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static MaceAuraModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.lastAttackMs = System.currentTimeMillis();
        this.resetIdle();
    }

    @Override
    public void onDisable() {
        this.resetIdle();
    }

    private void resetIdle() {
        this.dipState = DipState.IDLE;
        this.dipTarget = null;
        this.stateTicks = 0;
    }

    @EventListener
    public void onTick(PlayerTickEvent event) {
        if (MaceAuraModule.mc.field_1724 == null || MaceAuraModule.mc.field_1687 == null || mc.method_1562() == null) {
            return;
        }
        if (!(MaceAuraModule.mc.field_1724.method_6128() || this.dipState != DipState.APPROACH && this.dipState != DipState.FOLD)) {
            this.resetIdle();
            return;
        }
        if (this.dipState == DipState.APPROACH) {
            ++this.stateTicks;
            if (this.dipTarget == null || this.dipTarget.method_31481()) {
                this.resetIdle();
                return;
            }
            double dy = MaceAuraModule.mc.field_1724.method_23318() - this.dipTarget.method_23318();
            if (dy < (double)this.minHeightConfig.getValue().floatValue() || dy > (double)this.vertRangeConfig.getValue().floatValue() || this.stateTicks > 200) {
                this.resetIdle();
                return;
            }
            if (MaceAuraModule.hDist((class_1657)MaceAuraModule.mc.field_1724, this.dipTarget) <= (double)this.rangeConfig.getValue().floatValue()) {
                this.beginFold();
            }
            return;
        }
        if (this.dipState == DipState.FOLD) {
            ++this.stateTicks;
            if (this.dipTarget == null || this.dipTarget.method_31481()) {
                this.resetIdle();
                return;
            }
            if (this.stateTicks >= this.foldDelayConfig.getValue().intValue()) {
                this.dipState = DipState.STRIKE;
                this.stateTicks = 0;
            }
            return;
        }
        if (this.dipState == DipState.STRIKE) {
            if (this.dipTarget != null && !this.dipTarget.method_31481()) {
                this.doStrike(this.dipTarget);
                this.lastAttackMs = System.currentTimeMillis();
            }
            this.resetIdle();
            return;
        }
        if (this.silentSwapConfig.getValue() != false ? this.findMaceInHotbar() == -1 : MaceAuraModule.mc.field_1724.method_6047().method_7909() != class_1802.field_49814) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastAttackMs < this.attackDelayConfig.getValue().longValue()) {
            return;
        }
        class_1657 target = this.findTarget();
        if (target == null) {
            return;
        }
        this.dipTarget = target;
        this.stateTicks = 0;
        if (MaceAuraModule.hDist((class_1657)MaceAuraModule.mc.field_1724, target) <= (double)this.rangeConfig.getValue().floatValue()) {
            this.beginFold();
        } else {
            this.dipState = DipState.APPROACH;
        }
    }

    private void beginFold() {
        this.sendPacket((class_2596<?>)new class_2828.class_2830(MaceAuraModule.mc.field_1724.method_23317(), MaceAuraModule.mc.field_1724.method_23318(), MaceAuraModule.mc.field_1724.method_23321(), MaceAuraModule.mc.field_1724.method_36454(), MaceAuraModule.mc.field_1724.method_36455(), true));
        this.dipState = DipState.FOLD;
        this.stateTicks = 0;
    }

    private void doStrike(class_1657 target) {
        double realX = MaceAuraModule.mc.field_1724.method_23317();
        double realY = MaceAuraModule.mc.field_1724.method_23318();
        double realZ = MaceAuraModule.mc.field_1724.method_23321();
        float yaw = MaceAuraModule.mc.field_1724.method_36454();
        float pitch = MaceAuraModule.mc.field_1724.method_36455();
        double drop = (double)this.smashThresholdConfig.getValue().floatValue() + 0.2;
        double fakeY = realY - drop;
        double fakeX = this.xzSpoofConfig.getValue() != false ? target.method_23317() : realX;
        double fakeZ = this.xzSpoofConfig.getValue() != false ? target.method_23321() : realZ;
        this.sendPacket((class_2596<?>)new class_2828.class_2830(fakeX, fakeY, fakeZ, yaw, pitch, false));
        this.doAttack(target);
        this.sendPacket((class_2596<?>)new class_2848((class_1297)MaceAuraModule.mc.field_1724, class_2848.class_2849.field_12982));
    }

    private void doAttack(class_1657 target) {
        boolean swapped;
        int maceSlot;
        int prev;
        int swordSlot;
        if (this.attributeSwapConfig.getValue().booleanValue() && (swordSlot = this.findSwordInHotbar()) != -1) {
            boolean swap;
            prev = MaceAuraModule.mc.field_1724.method_31548().field_7545;
            boolean bl = swap = swordSlot != prev;
            if (swap) {
                Managers.INVENTORY.setSlot(swordSlot);
            }
            MaceAuraModule.mc.field_1724.method_6104(class_1268.field_5808);
            this.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)target, (boolean)MaceAuraModule.mc.field_1724.method_5715()));
            if (swap) {
                Managers.INVENTORY.setSlot(prev);
            }
        }
        int n = maceSlot = this.silentSwapConfig.getValue() != false ? this.findMaceInHotbar() : -1;
        if (this.silentSwapConfig.getValue().booleanValue() && maceSlot == -1) {
            return;
        }
        prev = MaceAuraModule.mc.field_1724.method_31548().field_7545;
        boolean bl = swapped = maceSlot != -1 && maceSlot != prev;
        if (swapped) {
            Managers.INVENTORY.setSlot(maceSlot);
        }
        MaceAuraModule.mc.field_1724.method_6104(class_1268.field_5808);
        this.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)target, (boolean)MaceAuraModule.mc.field_1724.method_5715()));
        if (swapped) {
            Managers.INVENTORY.setSlot(prev);
        }
    }

    private class_1657 findTarget() {
        double r = this.approachRangeConfig.getValue().floatValue();
        double vr = this.vertRangeConfig.getValue().floatValue();
        if (!this.autoTargetConfig.getValue().booleanValue()) {
            class_1657 p;
            class_1297 class_12972 = MaceAuraModule.mc.field_1692;
            if (class_12972 instanceof class_1657 && (p = (class_1657)class_12972) != MaceAuraModule.mc.field_1724) {
                double dy = MaceAuraModule.mc.field_1724.method_23318() - p.method_23318();
                if (MaceAuraModule.hDist((class_1657)MaceAuraModule.mc.field_1724, p) <= r && dy >= 0.0 && dy <= vr) {
                    return p;
                }
            }
            return null;
        }
        class_1657 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_1657 p : MaceAuraModule.mc.field_1687.method_18456()) {
            double hd;
            double dy;
            if (p == MaceAuraModule.mc.field_1724 || !p.method_5805() || Managers.SOCIAL != null && Managers.SOCIAL.isFriend(p.method_5477().getString()) || (dy = MaceAuraModule.mc.field_1724.method_23318() - p.method_23318()) < 0.0 || dy > vr || (hd = MaceAuraModule.hDist((class_1657)MaceAuraModule.mc.field_1724, p)) > r || !(hd < bestDist)) continue;
            bestDist = hd;
            best = p;
        }
        return best;
    }

    private int findMaceInHotbar() {
        for (int i = 0; i < 9; ++i) {
            if (MaceAuraModule.mc.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_49814) continue;
            return i;
        }
        return -1;
    }

    private int findSwordInHotbar() {
        for (int i = 0; i < 9; ++i) {
            boolean hasDamage;
            class_9285 amc;
            class_1799 s = MaceAuraModule.mc.field_1724.method_31548().method_5438(i);
            if (s.method_7960() || s.method_7909() == class_1802.field_49814 || (amc = (class_9285)s.method_57824(class_9334.field_49636)) == null || !(hasDamage = amc.comp_2393().stream().anyMatch(e -> e.comp_2395().equals((Object)class_5134.field_23721)))) continue;
            return i;
        }
        return -1;
    }

    private static double hDist(class_1657 a, class_1657 b) {
        double dx = a.method_23317() - b.method_23317();
        double dz = a.method_23321() - b.method_23321();
        return Math.sqrt(dx * dx + dz * dz);
    }

    private void sendPacket(class_2596<?> packet) {
        if (mc.method_1562() != null) {
            mc.method_1562().method_52787(packet);
        }
    }

    private static enum DipState {
        IDLE,
        APPROACH,
        FOLD,
        STRIKE;

    }
}
