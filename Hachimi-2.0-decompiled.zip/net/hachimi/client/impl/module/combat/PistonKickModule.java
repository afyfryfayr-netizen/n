package net.hachimi.client.impl.module.combat;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.client.AnticheatModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.player.SnapRotation;
import net.hachimi.client.util.world.BlockUtilPlus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2665;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_3965;

public final class PistonKickModule
extends ToggleModule {
    public static PistonKickModule INSTANCE;
    private final Config<Integer> delay = this.register(new NumberConfig<Integer>("Delay", "Delay between pushes (ticks)", 0, 1, 10));
    private final Config<Boolean> oneTwelve = this.register(new BooleanConfig("1.12", "Place piston and power in the same tick", true));
    private final Config<Float> targetRange = this.register(new NumberConfig<Float>("TargetRange", "Target range", Float.valueOf(1.0f), Float.valueOf(5.0f), Float.valueOf(6.0f)));
    private final Config<Boolean> inAirTarget = this.register(new BooleanConfig("InAirTarget", "Target players in the air", true));
    private final Config<Boolean> rotate = this.register(new BooleanConfig("Rotate", "Silently rotate when placing", true));
    private final Config<Boolean> outOfBlock = this.register(new BooleanConfig("OutOfBlock", "Target players partially outside of blocks", true));
    private final Config<Boolean> breakCrystal = this.register(new BooleanConfig("BreakCrystal", "Break end crystals blocking piston path", false));
    private final Config<Float> placeRange = this.register(new NumberConfig<Float>("PlaceRange", "Block place range", Float.valueOf(1.0f), Float.valueOf(5.0f), Float.valueOf(6.0f)));
    private final Config<Float> breakRange = this.register(new NumberConfig<Float>("BreakRange", "Crystal break range", Float.valueOf(1.0f), Float.valueOf(4.5f), Float.valueOf(6.0f), () -> this.breakCrystal.getValue()));
    private final Config<SwapAction> swapAction = this.register(new EnumConfig("SwapAction", "How to swap to required items", (Enum)SwapAction.SCREEN, (Enum[])SwapAction.values()));
    private final Config<Boolean> airPlace = this.register(new BooleanConfig("AirPlace", "Allow placing blocks in the air", false));
    private final Config<Boolean> consecutive = this.register(new BooleanConfig("Consecutive", "Keep targeting the same player consecutively", true));
    private final Config<Boolean> merge = this.register(new BooleanConfig("Merge", "Burst piston and power packets together", false));
    private int tickCount = 0;
    private class_1657 lastTarget = null;

    public PistonKickModule() {
        super("PistonKick", "Pushes players out of bedrock holes using pistons", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static PistonKickModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.tickCount = 0;
        this.lastTarget = null;
        SnapRotation.INSTANCE.subscribe();
    }

    @Override
    public void onDisable() {
        this.lastTarget = null;
        SnapRotation.INSTANCE.unsubscribe();
        SnapRotation.reset();
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (PistonKickModule.mc.field_1724 == null || PistonKickModule.mc.field_1687 == null) {
            return;
        }
        ++this.tickCount;
        if (this.tickCount < this.delay.getValue()) {
            return;
        }
        this.tickCount = 0;
        int pistonSlot = this.findClass(class_2665.class);
        int powerSlot = this.findPower();
        if (pistonSlot == -1 || powerSlot == -1) {
            return;
        }
        List<class_1657> enemies = this.getEnemies();
        if (enemies.isEmpty()) {
            return;
        }
        if (this.consecutive.getValue().booleanValue() && this.lastTarget != null && enemies.contains(this.lastTarget)) {
            enemies.remove(this.lastTarget);
            enemies.add(0, this.lastTarget);
        }
        for (class_1657 target : enemies) {
            if (!this.inAirTarget.getValue().booleanValue() && !target.method_24828()) continue;
            if (this.breakCrystal.getValue().booleanValue()) {
                this.breakNearbyCrystals(target);
            }
            if (!this.tryKick(target, pistonSlot, powerSlot)) continue;
            this.lastTarget = target;
            return;
        }
    }

    private boolean tryKick(class_1657 target, int pistonSlot, int powerSlot) {
        class_2338 wall;
        class_2338 playerPos;
        float[] offsets;
        for (float ox : offsets = new float[]{-0.25f, 0.0f, 0.25f}) {
            for (float oz : offsets) {
                playerPos = class_2338.method_49637((double)(target.method_23317() + (double)ox), (double)(target.method_23318() + 0.5), (double)(target.method_23321() + (double)oz));
                for (class_2350 dir : class_2350.class_2353.field_11062) {
                    wall = playerPos.method_10093(dir);
                    if (!this.isTargetHere(wall, target) || !PistonKickModule.mc.field_1687.method_39454((class_1297)target, new class_238(wall))) continue;
                    if (this.tryPush(playerPos.method_10093(dir.method_10153()), dir, pistonSlot, powerSlot)) {
                        return true;
                    }
                    if (!this.tryPush(playerPos.method_10093(dir.method_10153()).method_10084(), dir, pistonSlot, powerSlot)) continue;
                    return true;
                }
            }
        }
        if (!PistonKickModule.mc.field_1687.method_39454((class_1297)target, new class_238(class_2338.method_49637((double)target.method_23317(), (double)(target.method_23318() + 2.5), (double)target.method_23321())))) {
            class_2338 entityPos = target.method_24515();
            for (class_2350 dir : class_2350.class_2353.field_11062) {
                class_2338 wall2 = entityPos.method_10093(dir);
                class_238 shifted = target.method_5829().method_989((double)dir.method_10148(), (double)dir.method_10164(), (double)dir.method_10165());
                if (PistonKickModule.mc.field_1687.method_8320(wall2.method_10084()).method_26204() == class_2246.field_10379 || PistonKickModule.mc.field_1687.method_39454((class_1297)target, shifted.method_989(0.0, 1.0, 0.0)) || this.isTargetHere(wall2, target)) continue;
                if (this.tryPush(entityPos.method_10093(dir.method_10153()).method_10084(), dir, pistonSlot, powerSlot)) {
                    return true;
                }
                if (!this.tryPush(entityPos.method_10093(dir.method_10153()), dir, pistonSlot, powerSlot)) continue;
                return true;
            }
        }
        for (float ox : offsets) {
            for (float oz : offsets) {
                playerPos = class_2338.method_49637((double)(target.method_23317() + (double)ox), (double)(target.method_23318() + 0.5), (double)(target.method_23321() + (double)oz));
                for (class_2350 dir : class_2350.class_2353.field_11062) {
                    wall = playerPos.method_10093(dir);
                    if (!this.isTargetHere(wall, target)) continue;
                    if (this.tryPush(playerPos.method_10093(dir.method_10153()).method_10084(), dir, pistonSlot, powerSlot)) {
                        return true;
                    }
                    if (!this.tryPush(playerPos.method_10093(dir.method_10153()), dir, pistonSlot, powerSlot)) continue;
                    return true;
                }
            }
        }
        return false;
    }

    private boolean tryPush(class_2338 pistonPos, class_2350 pushDir, int pistonSlot, int powerSlot) {
        if (!PistonKickModule.mc.field_1687.method_22347(pistonPos.method_10093(pushDir))) {
            return false;
        }
        if (!this.canPlaceAt(pistonPos)) {
            return false;
        }
        class_2350 placeSide = this.getPlaceSide(pistonPos);
        if (placeSide != null) {
            boolean canPower = false;
            for (class_2350 d : class_2350.values()) {
                if (!this.isRedstone(pistonPos.method_10093(d)) && !this.canPlaceAt(pistonPos.method_10093(d))) continue;
                canPower = true;
                break;
            }
            if (!canPower) {
                return false;
            }
            this.doSwap(pistonSlot);
            if (this.rotate.getValue().booleanValue()) {
                this.pistonFacingRotation(pushDir, placeSide);
            }
            this.placeBlockDirect(pistonPos, placeSide);
            this.restoreSlot(pistonSlot);
            if (this.oneTwelve.getValue().booleanValue() || this.merge.getValue().booleanValue() || PistonKickModule.mc.field_1687.method_8320(pistonPos).method_26204() instanceof class_2665) {
                for (class_2350 d : class_2350.values()) {
                    if (!this.isRedstone(pistonPos.method_10093(d))) continue;
                    return true;
                }
                for (class_2350 d : class_2350.values()) {
                    class_2350 pSide;
                    class_2338 powerPos;
                    if (d == class_2350.field_11036 || !this.canPlaceAt(powerPos = pistonPos.method_10093(d)) || !this.inPlaceRange(powerPos) || (pSide = this.getPlaceSide(powerPos)) == null) continue;
                    this.doSwap(powerSlot);
                    if (this.rotate.getValue().booleanValue()) {
                        this.doRotate(powerPos, pSide);
                    }
                    this.placeBlockDirect(powerPos, pSide);
                    this.restoreSlot(powerSlot);
                    return true;
                }
            }
            return true;
        }
        class_2350 powerDir = null;
        for (class_2350 d : class_2350.values()) {
            class_2338 powerPos;
            if (d == class_2350.field_11036 || !this.canPlaceAt(powerPos = pistonPos.method_10093(d)) || !this.inPlaceRange(powerPos) || BlockUtilPlus.getPlaceSide(pistonPos, null) == null) continue;
            powerDir = d;
            break;
        }
        if (powerDir == null) {
            return false;
        }
        class_2338 powerPos = pistonPos.method_10093(powerDir);
        class_2350 pSide = this.getPlaceSide(powerPos);
        if (pSide == null) {
            return false;
        }
        this.doSwap(powerSlot);
        if (this.rotate.getValue().booleanValue()) {
            this.doRotate(powerPos, pSide);
        }
        this.placeBlockDirect(powerPos, pSide);
        this.restoreSlot(powerSlot);
        class_2350 newSide = this.getPlaceSide(pistonPos);
        if (newSide != null) {
            this.doSwap(pistonSlot);
            if (this.rotate.getValue().booleanValue()) {
                this.pistonFacingRotation(pushDir, newSide);
            }
            this.placeBlockDirect(pistonPos, newSide);
            this.restoreSlot(pistonSlot);
        }
        return true;
    }

    private boolean isTargetHere(class_2338 pos, class_1657 target) {
        return new class_238(pos).method_994(target.method_5829());
    }

    private boolean isRedstone(class_2338 pos) {
        class_2248 b = PistonKickModule.mc.field_1687.method_8320(pos).method_26204();
        return b == class_2246.field_10002 || b == class_2246.field_10523;
    }

    private boolean canPlaceAt(class_2338 pos) {
        return PistonKickModule.mc.field_1687.method_8320(pos).method_45474() || PistonKickModule.mc.field_1687.method_22347(pos);
    }

    private boolean inPlaceRange(class_2338 pos) {
        double r = this.placeRange.getValue().floatValue();
        return PistonKickModule.mc.field_1724.method_5649((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5) <= r * r;
    }

    private class_2350 getPlaceSide(class_2338 pos) {
        return this.airPlace.getValue() != false ? BlockUtilPlus.getClickSideStrict(pos) : BlockUtilPlus.getPlaceSide(pos, null);
    }

    private void breakNearbyCrystals(class_1657 target) {
        double r = this.breakRange.getValue().floatValue();
        PistonKickModule.mc.field_1687.method_8390(class_1511.class, target.method_5829().method_1014(r), e -> e.method_5805() && PistonKickModule.mc.field_1724.method_5858((class_1297)e) <= r * r).stream().min(Comparator.comparingDouble(e -> PistonKickModule.mc.field_1724.method_5858((class_1297)e))).ifPresent(crystal -> {
            Managers.NETWORK.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)crystal, (boolean)PistonKickModule.mc.field_1724.method_5715()));
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        });
    }

    private void placeBlockDirect(class_2338 pos, class_2350 side) {
        class_2338 neighbor = pos.method_10093(side);
        class_243 hitVec = new class_243((double)neighbor.method_10263() + 0.5 + (double)side.method_10153().method_10148() * 0.5, (double)neighbor.method_10264() + 0.5 + (double)side.method_10153().method_10164() * 0.5, (double)neighbor.method_10260() + 0.5 + (double)side.method_10153().method_10165() * 0.5);
        class_3965 result = new class_3965(hitVec, side.method_10153(), neighbor, false);
        Managers.NETWORK.sendSequencedPacket(id -> new class_2885(class_1268.field_5808, result, id));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        BlockUtilPlus.placeList.add(pos);
    }

    private void applyAnticheatFlags() {
        AnticheatModule ac = AnticheatModule.getInstance();
        SnapRotation.grimFull = ac != null ? ac.isGrimRotation() : true;
        SnapRotation.doSnapBack = ac != null ? ac.isSnapBack() : false;
    }

    private void doRotate(class_2338 pos, class_2350 side) {
        this.applyAnticheatFlags();
        SnapRotation.snapAt(pos.method_46558().method_1031((double)side.method_10148() * 0.5, (double)side.method_10164() * 0.5, (double)side.method_10165() * 0.5));
    }

    private void pistonFacingRotation(class_2350 pushDir, class_2350 placeSide) {
        this.applyAnticheatFlags();
        float yaw = switch (pushDir) {
            case class_2350.field_11035 -> 0.0f;
            case class_2350.field_11039 -> 90.0f;
            case class_2350.field_11043 -> 180.0f;
            case class_2350.field_11034 -> -90.0f;
            default -> 0.0f;
        };
        SnapRotation.snapAt(yaw, 0.0f);
    }

    private void doSwap(int slot) {
        switch (this.swapAction.getValue().ordinal()) {
            case 0: {
                if (slot < 9) {
                    Managers.INVENTORY.setSlot(slot);
                    break;
                }
                PistonKickModule.mc.field_1761.method_2906(PistonKickModule.mc.field_1724.field_7498.field_7763, slot, PistonKickModule.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)PistonKickModule.mc.field_1724);
                break;
            }
            case 1: {
                if (slot >= 9) break;
                Managers.INVENTORY.setSlot(slot);
                break;
            }
        }
    }

    private void restoreSlot(int slot) {
        if (this.swapAction.getValue() == SwapAction.SCREEN && slot >= 9) {
            PistonKickModule.mc.field_1761.method_2906(PistonKickModule.mc.field_1724.field_7498.field_7763, slot, PistonKickModule.mc.field_1724.method_31548().field_7545, class_1713.field_7791, (class_1657)PistonKickModule.mc.field_1724);
        }
    }

    private int findPower() {
        int slot = this.findBlock(class_2246.field_10002);
        if (slot != -1) {
            return slot;
        }
        return this.findBlock(class_2246.field_10523);
    }

    private int findBlock(class_2248 block) {
        if (this.swapAction.getValue() == SwapAction.NONE) {
            class_1747 bi;
            class_1792 class_17922;
            class_1799 held = PistonKickModule.mc.field_1724.method_6047();
            return !held.method_7960() && (class_17922 = held.method_7909()) instanceof class_1747 && (bi = (class_1747)class_17922).method_7711() == block ? PistonKickModule.mc.field_1724.method_31548().field_7545 : -1;
        }
        int end = this.swapAction.getValue() == SwapAction.SCREEN ? 36 : 9;
        for (int i = 0; i < end; ++i) {
            class_1747 bi;
            class_1792 class_17923;
            class_1799 s = PistonKickModule.mc.field_1724.method_31548().method_5438(i);
            if (s.method_7960() || !((class_17923 = s.method_7909()) instanceof class_1747) || (bi = (class_1747)class_17923).method_7711() != block) continue;
            return i;
        }
        return -1;
    }

    private int findClass(Class<?> clazz) {
        if (this.swapAction.getValue() == SwapAction.NONE) {
            class_1747 bi;
            class_1792 class_17922;
            class_1799 held = PistonKickModule.mc.field_1724.method_6047();
            return !held.method_7960() && (class_17922 = held.method_7909()) instanceof class_1747 && clazz.isInstance((bi = (class_1747)class_17922).method_7711()) ? PistonKickModule.mc.field_1724.method_31548().field_7545 : -1;
        }
        int end = this.swapAction.getValue() == SwapAction.SCREEN ? 36 : 9;
        for (int i = 0; i < end; ++i) {
            class_1747 bi;
            class_1792 class_17923;
            class_1799 s = PistonKickModule.mc.field_1724.method_31548().method_5438(i);
            if (s.method_7960() || !((class_17923 = s.method_7909()) instanceof class_1747) || !clazz.isInstance((bi = (class_1747)class_17923).method_7711())) continue;
            return i;
        }
        return -1;
    }

    private List<class_1657> getEnemies() {
        double r = this.targetRange.getValue().floatValue();
        return PistonKickModule.mc.field_1687.method_18456().stream().filter(p -> p != PistonKickModule.mc.field_1724).filter(p -> !p.method_7325() && !p.method_29504()).filter(p -> !Managers.SOCIAL.isFriend(p.method_5477().getString())).filter(p -> PistonKickModule.mc.field_1724.method_5858((class_1297)p) <= r * r).sorted(Comparator.comparingDouble(p -> PistonKickModule.mc.field_1724.method_5858((class_1297)p))).collect(Collectors.toList());
    }

    public static enum SwapAction {
        SCREEN,
        HOTBAR,
        NONE;

    }
}
