package net.hachimi.client.impl.module.combat;

import com.google.common.collect.Lists;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.ObsidianPlacerModule;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.impl.module.player.AirPlaceModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.position.PositionUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.world.BlastResistantBlocks;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2596;
import net.minecraft.class_2626;
import net.minecraft.class_2680;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_3726;
import net.minecraft.class_8042;

public final class AutoTrapModule
extends ObsidianPlacerModule {
    private static AutoTrapModule INSTANCE;
    Config<Boolean> multitaskConfig = this.register(new BooleanConfig("Multitask", "Allows placing while eating", true));
    Config<Float> placeRangeConfig = this.register(new NumberConfig<Float>("PlaceRange", "The placement range for trap", Float.valueOf(0.0f), Float.valueOf(4.0f), Float.valueOf(6.0f)));
    Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Rotates to block before placing", false));
    Config<Boolean> attackConfig = this.register(new BooleanConfig("Attack", "Attacks crystals in the way of trap ", true));
    Config<Boolean> extendConfig = this.register(new BooleanConfig("Extend", "Extends trap if the player is not in the center of a block", true));
    Config<Boolean> supportConfig = this.register(new BooleanConfig("Support", "Creates a floor for the trap if there is none", false));
    Config<Boolean> headConfig = this.register(new BooleanConfig("Head", "Place a block at targets head", true));
    Config<Boolean> antiStepConfig = this.register(new BooleanConfig("PreventStep", "Prevents target from stepping out of the trap", false));
    Config<Integer> shiftTicksConfig = this.register(new NumberConfig<Integer>("ShiftTicks", "The number of blocks to place per tick", 1, 2, 10));
    Config<Float> shiftDelayConfig = this.register(new NumberConfig<Float>("ShiftDelay", "The delay between each block placement interval", Float.valueOf(0.0f), Float.valueOf(1.0f), Float.valueOf(5.0f)));
    Config<Boolean> autoDisableConfig = this.register(new BooleanConfig("AutoDisable", "Disables after placing the blocks", true));
    Config<Boolean> renderConfig = this.register(new BooleanConfig("Render", "Renders where trap is placing blocks", false));
    Config<Integer> fadeTimeConfig = this.register(new NumberConfig<Integer>("Fade-Time", "Time to fade", Integer.valueOf(0), Integer.valueOf(250), Integer.valueOf(1000), () -> false));
    private List<class_2338> surround = new ArrayList<class_2338>();
    private List<class_2338> placements = new ArrayList<class_2338>();
    private final Map<class_2338, Long> packets = new HashMap<class_2338, Long>();
    private final Map<class_2338, Animation> fadeList = new HashMap<class_2338, Animation>();
    private int blocksPlaced;

    public AutoTrapModule() {
        super("AutoTrap", "Fully traps enemies with blocks", ModuleCategory.COMBAT, 900);
        INSTANCE = this;
    }

    public static AutoTrapModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        this.surround.clear();
        this.placements.clear();
        this.packets.clear();
        this.fadeList.clear();
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        this.blocksPlaced = 0;
        if (!this.multitaskConfig.getValue().booleanValue() && AutoTrapModule.mc.field_1724.method_6115()) {
            this.surround.clear();
            this.placements.clear();
            return;
        }
        ObsidianPlacerModule.BlockSlot blockSlot = this.getResistantBlockItem();
        if (blockSlot == null) {
            return;
        }
        int slot = blockSlot.slot();
        if (slot == -1) {
            this.surround.clear();
            this.placements.clear();
            return;
        }
        class_1657 trapTarget = this.getTrapTarget();
        if (trapTarget == null) {
            this.surround.clear();
            this.placements.clear();
            return;
        }
        class_2338 targetBlockPos = PositionUtil.getRoundedBlockPos(trapTarget.method_23317(), trapTarget.method_23318(), trapTarget.method_23321());
        this.surround = this.getSurround(targetBlockPos, trapTarget);
        if (this.surround.isEmpty()) {
            return;
        }
        if (this.attackConfig.getValue().booleanValue()) {
            this.attackBlockingCrystals(this.surround);
        }
        this.placements = this.getPlacementsFromSurround(this.surround);
        if (this.placements.isEmpty()) {
            if (this.autoDisableConfig.getValue().booleanValue()) {
                this.disable();
            }
            return;
        }
        if (this.supportConfig.getValue().booleanValue()) {
            for (class_2338 block : new ArrayList<class_2338>(this.placements)) {
                class_2350 direction;
                if (block.method_10264() > targetBlockPos.method_10264() || (direction = Managers.INTERACT.getInteractDirectionInternal(block, (Boolean)this.strictDirectionConfig.getValue())) != null) continue;
                this.placements.add(block.method_10074());
            }
        }
        this.placements.sort(Comparator.comparingInt(class_2382::method_10264));
        while (this.blocksPlaced < this.shiftTicksConfig.getValue() && this.blocksPlaced < this.placements.size()) {
            class_2338 targetPos = this.placements.get(this.blocksPlaced);
            ++this.blocksPlaced;
            this.placeBlock(targetPos, slot);
        }
        if (this.rotateConfig.getValue().booleanValue()) {
            Managers.ROTATION.setRotationSilentSync();
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (AutoTrapModule.mc.field_1724 == null || AutoTrapModule.mc.field_1687 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_8042) {
            class_8042 packet = (class_8042)class_25962;
            for (class_2596 packet1 : packet.method_48324()) {
                this.handlePackets(packet1);
            }
        } else {
            this.handlePackets(event.getPacket());
        }
    }

    private void handlePackets(class_2596<?> serverPacket) {
        if (serverPacket instanceof class_2626) {
            class_2626 packet = (class_2626)serverPacket;
            class_2680 blockState = packet.method_11308();
            class_2338 targetPos = packet.method_11309();
            if (this.surround.contains(targetPos)) {
                if (blockState.method_45474() && AutoTrapModule.mc.field_1687.method_8628(DEFAULT_OBSIDIAN_STATE, targetPos, class_3726.method_16194())) {
                    ObsidianPlacerModule.BlockSlot blockSlot = this.getResistantBlockItem();
                    if (blockSlot == null) {
                        return;
                    }
                    int slot = blockSlot.slot();
                    if (slot == -1) {
                        return;
                    }
                    this.placeBlock(targetPos, slot);
                } else if (BlastResistantBlocks.isBlastResistant(blockState)) {
                    this.packets.remove(targetPos);
                }
            }
        }
    }

    private void placeBlock(class_2338 pos, int slot) {
        Managers.INTERACT.placeBlock(pos, slot, (boolean)((Boolean)this.strictDirectionConfig.getValue()), false, true, (state, angles) -> {
            if (this.rotateConfig.getValue().booleanValue() && state) {
                Managers.ROTATION.setRotationSilent(angles[0], angles[1]);
            }
        });
        this.packets.put(pos, System.currentTimeMillis());
    }

    private class_1657 getTrapTarget() {
        ArrayList entities = Lists.newArrayList(AutoTrapModule.mc.field_1687.method_18112());
        return entities.stream().filter(e -> e instanceof class_1657 && e.method_5805() && AutoTrapModule.mc.field_1724 != e && !Managers.SOCIAL.isFriend(e.method_5477())).filter(e -> AutoTrapModule.mc.field_1724.method_5858(e) <= ((NumberConfig)this.placeRangeConfig).getValueSq()).min(Comparator.comparingDouble(e -> AutoTrapModule.mc.field_1724.method_5858(e))).orElse(null);
    }

    public void attackBlockingCrystals(List<class_2338> posList) {
        for (class_2338 pos : posList) {
            class_1297 crystalEntity = AutoTrapModule.mc.field_1687.method_8335(null, new class_238(pos)).stream().filter(e -> e instanceof class_1511).findFirst().orElse(null);
            if (crystalEntity == null) continue;
            Managers.NETWORK.sendPacket((class_2596<?>)class_2824.method_34206((class_1297)crystalEntity, (boolean)AutoTrapModule.mc.field_1724.method_5715()));
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
            return;
        }
    }

    public List<class_2338> getPlacementsFromSurround(List<class_2338> surround) {
        ArrayList<class_2338> placements = new ArrayList<class_2338>();
        for (class_2338 surroundPos : surround) {
            double dist;
            Long placed = this.packets.get(surroundPos);
            if (this.shiftDelayConfig.getValue().floatValue() > 0.0f && placed != null && (float)(System.currentTimeMillis() - placed) < this.shiftDelayConfig.getValue().floatValue() * 50.0f || !AutoTrapModule.mc.field_1687.method_8320(surroundPos).method_45474() || (dist = AutoTrapModule.mc.field_1724.method_5707(surroundPos.method_46558())) > ((NumberConfig)this.placeRangeConfig).getValueSq() || !AutoTrapModule.mc.field_1687.method_8628(DEFAULT_OBSIDIAN_STATE, surroundPos, class_3726.method_16194())) continue;
            placements.add(surroundPos);
        }
        return placements;
    }

    public List<class_2338> getSurround(class_2338 playerPos, class_1657 player) {
        ArrayList<class_2338> surroundBlocks = new ArrayList<class_2338>();
        List<class_2338> playerBlocks = this.getPlayerBlocks(playerPos, player);
        for (class_2338 pos : playerBlocks) {
            for (class_2350 dir : class_2350.values()) {
                class_2338 pos1;
                if (!dir.method_10166().method_10179() || surroundBlocks.contains(pos1 = pos.method_10093(dir)) || playerBlocks.contains(pos1)) continue;
                surroundBlocks.add(pos1);
                surroundBlocks.add(pos1.method_10084());
            }
        }
        if (this.headConfig.getValue().booleanValue()) {
            boolean support = false;
            ArrayList<class_2338> headBlocks = new ArrayList<class_2338>();
            for (class_2338 pos : playerBlocks) {
                class_2338 headPos = pos.method_10079(class_2350.field_11036, 2);
                if (!AutoTrapModule.mc.field_1687.method_8320(headPos).method_45474()) {
                    support = true;
                }
                headBlocks.add(headPos);
                if (!this.antiStepConfig.getValue().booleanValue()) continue;
                class_2338 antiStepPos = pos.method_10079(class_2350.field_11036, 3);
                headBlocks.add(antiStepPos);
            }
            if (!AirPlaceModule.getInstance().isEnabled()) {
                class_2338 supportingPos = null;
                double min = Double.MAX_VALUE;
                for (class_2338 pos : surroundBlocks) {
                    class_2338 pos1 = pos.method_10079(class_2350.field_11036, 2);
                    if (!AutoTrapModule.mc.field_1687.method_8320(pos1).method_45474()) {
                        support = true;
                        break;
                    }
                    double dist = AutoTrapModule.mc.field_1724.method_5707(pos1.method_46558());
                    if (!(dist < min)) continue;
                    supportingPos = pos1;
                    min = dist;
                }
                if (supportingPos != null && !support) {
                    surroundBlocks.add(supportingPos);
                }
            }
            surroundBlocks.addAll(headBlocks);
        }
        return surroundBlocks;
    }

    public List<class_2338> getPlayerBlocks(class_2338 playerPos, class_1657 entity) {
        ArrayList<class_2338> playerBlocks = new ArrayList<class_2338>();
        if (this.extendConfig.getValue().booleanValue()) {
            playerBlocks.addAll(PositionUtil.getAllInBox(entity.method_5829(), playerPos));
        } else {
            playerBlocks.add(playerPos);
        }
        return playerBlocks;
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (this.renderConfig.getValue().booleanValue()) {
            RenderBuffers.preRender();
            for (Map.Entry<class_2338, Animation> set : this.fadeList.entrySet()) {
                set.getValue().setState(false);
                int boxAlpha = (int)(40.0 * set.getValue().getFactor());
                int lineAlpha = (int)(100.0 * set.getValue().getFactor());
                Color boxColor = ColorsModule.getInstance().getColor(boxAlpha);
                Color lineColor = ColorsModule.getInstance().getColor(lineAlpha);
                RenderManager.renderBox(event.getMatrices(), set.getKey(), boxColor.getRGB());
                RenderManager.renderBoundingBox(event.getMatrices(), set.getKey(), 1.5f, lineColor.getRGB());
            }
            RenderBuffers.postRender();
            if (this.placements.isEmpty()) {
                return;
            }
            for (class_2338 pos : this.placements) {
                Animation animation = new Animation(true, this.fadeTimeConfig.getValue().intValue());
                this.fadeList.put(pos, animation);
            }
        }
        this.fadeList.entrySet().removeIf(e -> ((Animation)e.getValue()).getFactor() == 0.0);
    }

    public boolean isPlacing() {
        return !this.placements.isEmpty();
    }
}
