package net.hachimi.client.impl.module.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.ObsidianPlacerModule;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.world.BlastResistantBlocks;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2596;
import net.minecraft.class_2626;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_8042;

public class AutoCrawlTrapModule
extends ObsidianPlacerModule {
    private static AutoCrawlTrapModule INSTANCE;
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("PlaceRange", "The range to trap enemies", Float.valueOf(0.1f), Float.valueOf(4.0f), Float.valueOf(6.0f)));
    Config<Float> enemyRangeConfig = this.register(new NumberConfig<Float>("EnemyRange", "The maximum range of targets", Float.valueOf(0.1f), Float.valueOf(10.0f), Float.valueOf(15.0f)));
    Config<Boolean> downConfig = this.register(new BooleanConfig("PreventDownwards", "Prevents digging downwards", true));
    Config<Boolean> serverHitboxConfig = this.register(new BooleanConfig("HitboxSync", "Places on serverside crawling hitboxes", false));
    Config<Boolean> mineIgnoreConfig = this.register(new BooleanConfig("PreventMine", "Prevents enemies from mining the trap", false));
    Config<Integer> shiftTicksConfig = this.register(new NumberConfig<Integer>("ShiftTicks", "The number of blocks to place per tick", 1, 2, 10));
    Config<Float> shiftDelayConfig = this.register(new NumberConfig<Float>("ShiftDelay", "The delay between each block placement interval", Float.valueOf(0.0f), Float.valueOf(1.0f), Float.valueOf(5.0f)));
    Config<Integer> extrapolateTicksConfig = this.register(new NumberConfig<Integer>("ExtrapolationTicks", "Accounts for motion when calculating enemy positions, not fully accurate.", 0, 0, 10));
    Config<Boolean> renderConfig = this.register(new BooleanConfig("Render", "Renders trap placements", false));
    Config<Integer> fadeTimeConfig = this.register(new NumberConfig<Integer>("Fade-Time", "Time to fade", Integer.valueOf(0), Integer.valueOf(250), Integer.valueOf(1000), () -> false));
    private List<class_2338> surround = new ArrayList<class_2338>();
    private List<class_2338> placements = new ArrayList<class_2338>();
    private final Map<class_2338, Long> packets = new HashMap<class_2338, Long>();
    private final Map<class_2338, Animation> fadeList = new HashMap<class_2338, Animation>();
    private class_1657 target;
    private int blocksPlaced;

    public AutoCrawlTrapModule() {
        super("AutoCrawlTrap", "Automatically places blocks to keep enemies in crawl", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static AutoCrawlTrapModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        this.surround.clear();
        this.placements.clear();
        this.fadeList.clear();
        this.target = null;
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        this.blocksPlaced = 0;
        if (!((Boolean)this.multitaskConfig.getValue()).booleanValue() && this.checkMultitask()) {
            this.surround.clear();
            this.placements.clear();
            return;
        }
        ObsidianPlacerModule.BlockSlot blockSlot = this.getResistantBlockItem();
        if (blockSlot == null) {
            return;
        }
        int slot = blockSlot.slot();
        if (slot == -1) {
            this.surround.clear();
            this.placements.clear();
            return;
        }
        this.target = this.getClosestPlayer(this.enemyRangeConfig.getValue().floatValue());
        if (this.target == null) {
            this.surround.clear();
            this.placements.clear();
            return;
        }
        class_2338 targetPos = EntityUtil.getRoundedBlockPos((class_1297)this.target);
        this.surround = this.getCrawlTrap(this.target, targetPos);
        if (!this.canCrawlTrap(this.target, targetPos) || this.surround.isEmpty()) {
            return;
        }
        this.placements = this.getPlacementsFromTrap(this.surround);
        if (this.placements.isEmpty()) {
            return;
        }
        this.placements.sort(Comparator.comparingInt(class_2382::method_10264));
        while (this.blocksPlaced < this.shiftTicksConfig.getValue() && this.blocksPlaced < this.placements.size()) {
            class_2338 targetPlacePos = this.placements.get(this.blocksPlaced);
            this.placeBlock(targetPlacePos, slot);
        }
        if (((Boolean)this.rotateConfig.getValue()).booleanValue()) {
            Managers.ROTATION.setRotationSilentSync();
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (AutoCrawlTrapModule.mc.field_1724 == null || AutoCrawlTrapModule.mc.field_1687 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_8042) {
            class_8042 packet = (class_8042)class_25962;
            for (class_2596 packet1 : packet.method_48324()) {
                this.handlePackets(packet1);
            }
        } else {
            this.handlePackets(event.getPacket());
        }
    }

    private void handlePackets(class_2596<?> serverPacket) {
        if (serverPacket instanceof class_2626) {
            class_2626 packet = (class_2626)serverPacket;
            class_2680 blockState = packet.method_11308();
            class_2338 targetPos = packet.method_11309();
            if (this.surround.contains(targetPos)) {
                if (blockState.method_45474() && AutoCrawlTrapModule.mc.field_1687.method_8628(DEFAULT_OBSIDIAN_STATE, targetPos, class_3726.method_16194())) {
                    ObsidianPlacerModule.BlockSlot blockSlot = this.getResistantBlockItem();
                    if (blockSlot == null) {
                        return;
                    }
                    int slot = blockSlot.slot();
                    if (slot == -1) {
                        return;
                    }
                    this.placeBlock(targetPos, slot);
                } else if (BlastResistantBlocks.isBlastResistant(blockState)) {
                    this.packets.remove(targetPos);
                }
            }
        }
    }

    private void placeBlock(class_2338 pos, int slot) {
        Managers.INTERACT.placeBlock(pos, slot, (boolean)((Boolean)this.strictDirectionConfig.getValue()), false, true, (state, angles) -> {
            if (((Boolean)this.rotateConfig.getValue()).booleanValue() && state) {
                Managers.ROTATION.setRotationSilent(angles[0], angles[1]);
            }
        });
        this.packets.put(pos, System.currentTimeMillis());
        ++this.blocksPlaced;
    }

    public List<class_2338> getPlacementsFromTrap(List<class_2338> surround) {
        ArrayList<class_2338> placements = new ArrayList<class_2338>();
        for (class_2338 surroundPos : surround) {
            double dist;
            Long placed = this.packets.get(surroundPos);
            if (this.shiftDelayConfig.getValue().floatValue() > 0.0f && placed != null && (float)(System.currentTimeMillis() - placed) < this.shiftDelayConfig.getValue().floatValue() * 50.0f) continue;
            class_238 surroundBox = new class_238(surroundPos);
            List<class_1297> invalid = AutoCrawlTrapModule.mc.field_1687.method_8335(null, surroundBox).stream().filter(e -> this.invalidEntity((class_1297)e)).toList();
            boolean serverCrawling = invalid.stream().allMatch(e -> Managers.HITBOX.isServerCrawling((class_1297)e) && Managers.HITBOX.getCrawlingBoundingBox((class_1297)e).method_994(surroundBox));
            if (!AutoCrawlTrapModule.mc.field_1687.method_8320(surroundPos).method_45474() && (!serverCrawling || !this.serverHitboxConfig.getValue().booleanValue()) && (!Managers.BLOCK.isPassed(surroundPos, 0.7f) || !this.mineIgnoreConfig.getValue().booleanValue()) || (dist = AutoCrawlTrapModule.mc.field_1724.method_5707(surroundPos.method_46558())) > ((NumberConfig)this.rangeConfig).getValueSq() || !AutoCrawlTrapModule.mc.field_1687.method_8628(DEFAULT_OBSIDIAN_STATE, surroundPos, class_3726.method_16194())) continue;
            placements.add(surroundPos);
        }
        return placements;
    }

    public List<class_2338> getCrawlTrap(class_1657 entity, class_2338 playerPos) {
        ArrayList<class_2338> crawlTrap = new ArrayList<class_2338>();
        crawlTrap.add(playerPos.method_10084());
        if (this.downConfig.getValue().booleanValue()) {
            crawlTrap.add(playerPos.method_10074());
        }
        double x = entity.method_23317();
        double y = entity.method_23318();
        double z = entity.method_23321();
        for (int ticks = 0; ticks <= this.extrapolateTicksConfig.getValue(); ++ticks) {
            double ox = (x - entity.field_6014) * (double)ticks;
            double oz = (z - entity.field_5969) * (double)ticks;
            class_2338 blockPos = class_2338.method_49637((double)(x + ox), (double)y, (double)(z + oz));
            if (!crawlTrap.contains(blockPos.method_10084())) {
                crawlTrap.add(blockPos.method_10084());
            }
            if (!this.downConfig.getValue().booleanValue() || crawlTrap.contains(blockPos.method_10074())) continue;
            crawlTrap.add(blockPos.method_10074());
        }
        return crawlTrap;
    }

    public boolean invalidEntity(class_1297 entity) {
        return !(entity instanceof class_1542) && !(entity instanceof class_1303) && !(entity instanceof class_1667);
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (this.renderConfig.getValue().booleanValue()) {
            RenderBuffers.preRender();
            for (Map.Entry<class_2338, Animation> set : this.fadeList.entrySet()) {
                set.getValue().setState(false);
                int boxAlpha = (int)(40.0 * set.getValue().getFactor());
                int lineAlpha = (int)(100.0 * set.getValue().getFactor());
                Color boxColor = ColorsModule.getInstance().getColor(boxAlpha);
                Color lineColor = ColorsModule.getInstance().getColor(lineAlpha);
                RenderManager.renderBox(event.getMatrices(), set.getKey(), boxColor.getRGB());
                RenderManager.renderBoundingBox(event.getMatrices(), set.getKey(), 1.5f, lineColor.getRGB());
            }
            RenderBuffers.postRender();
            if (this.placements.isEmpty()) {
                return;
            }
            for (class_2338 pos : this.placements) {
                Animation animation = new Animation(true, this.fadeTimeConfig.getValue().intValue());
                this.fadeList.put(pos, animation);
            }
        }
        this.fadeList.entrySet().removeIf(e -> ((Animation)e.getValue()).getFactor() == 0.0);
    }

    private boolean canCrawlTrap(class_1657 player, class_2338 playerPos) {
        return player.method_24828() || !AutoCrawlTrapModule.mc.field_1687.method_8320(playerPos.method_10084()).method_45474() || !AutoCrawlTrapModule.mc.field_1687.method_8320(playerPos.method_10086(2)).method_45474();
    }

    public boolean isPlacing() {
        return !this.placements.isEmpty();
    }
}
