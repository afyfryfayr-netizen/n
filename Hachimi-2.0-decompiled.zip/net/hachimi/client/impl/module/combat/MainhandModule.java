package net.hachimi.client.impl.module.combat;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.PlayerUtil;
import net.hachimi.client.util.world.ExplosionUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1829;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2838;
import net.minecraft.class_2868;

public final class MainhandModule
extends ToggleModule {
    private static MainhandModule INSTANCE;
    Config<Boolean> totemConfig = this.register(new BooleanConfig("Totem", "Keeps a totem in TotemSlot and switches when in danger", true));
    Config<Float> healthConfig = this.register(new NumberConfig<Float>("Health", "Health threshold to trigger switch", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(36.0f), () -> this.totemConfig.getValue()));
    Config<Boolean> lethalConfig = this.register(new BooleanConfig("Lethal", "Triggers if an end crystal could kill you", true, () -> this.totemConfig.getValue()));
    Config<Boolean> fallConfig = this.register(new BooleanConfig("Fall", "Triggers if fall damage could kill you", false, () -> this.totemConfig.getValue()));
    Config<Boolean> forceUpdateConfig = this.register(new BooleanConfig("ForceUpdate", "Switch even if already on TotemSlot", false, () -> this.totemConfig.getValue()));
    Config<Boolean> withOffhandConfig = this.register(new BooleanConfig("WithOffhand", "Also switch mainhand when offhand has no totem", false, () -> this.totemConfig.getValue()));
    Config<Boolean> alwaysConfig = this.register(new BooleanConfig("Always", "Always hold totem, not just when unsafe", true, () -> this.totemConfig.getValue()));
    Config<Boolean> switchBackConfig = this.register(new BooleanConfig("SwitchBack", "Switch back to previous slot once safe", false, () -> this.totemConfig.getValue()));
    Config<Boolean> crappleConfig = this.register(new BooleanConfig("Crapple", "Prefers a normal golden apple", false, () -> this.totemConfig.getValue()));
    Config<Boolean> swordGapConfig = this.register(new BooleanConfig("SwordGap", "Switch to gapple while holding sword + right-click", false, () -> this.totemConfig.getValue()));
    Config<Boolean> pickaxeGapConfig = this.register(new BooleanConfig("PickaxeGap", "Switch to gapple while holding pickaxe + right-click", false, () -> this.totemConfig.getValue()));
    Config<Boolean> totemGapConfig = this.register(new BooleanConfig("TotemGap", "Switch to gapple while holding totem + right-click", false, () -> this.totemConfig.getValue()));
    Config<Double> delayConfig = this.register(new NumberConfig<Double>("Delay", "Delay in seconds between switches", Double.valueOf(0.0), Double.valueOf(0.15), Double.valueOf(2.0), () -> this.totemConfig.getValue()));
    Config<Integer> totemSlotConfig = this.register(new NumberConfig<Integer>("TotemSlot", "Hotbar slot (1-9) for the totem", Integer.valueOf(1), Integer.valueOf(5), Integer.valueOf(9), () -> this.totemConfig.getValue()));
    Config<Integer> chorusConfig = this.register(new NumberConfig<Integer>("Chorus", "Emergency chorus fruit hotbar slot (-1=disabled)", Integer.valueOf(-1), Integer.valueOf(-1), Integer.valueOf(8), () -> this.totemConfig.getValue()));
    Config<SwapMode> swapModeConfig = this.register(new EnumConfig("SwapMode", "Method used to move the totem into the hotbar slot", (Enum)SwapMode.ClickSlot, (Enum[])SwapMode.values(), () -> this.totemConfig.getValue()));
    private final Timer timer = new CacheTimer();
    private int previousSlot = -1;
    private boolean switched = false;

    public MainhandModule() {
        super("Mainhand", "Switches to a totem (and emergency gapples/chorus) in your mainhand", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static MainhandModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.previousSlot = -1;
        this.switched = false;
    }

    @Override
    public String getModuleData() {
        return String.valueOf(this.totemSlotConfig.getValue());
    }

    private boolean isUnsafe() {
        return PlayerUtil.getLocalPlayerHealth() < this.healthConfig.getValue().floatValue() || this.lethalConfig.getValue() != false && this.lethalCrystal() || this.fallConfig.getValue() != false && this.lethalFall();
    }

    private boolean lethalCrystal() {
        ArrayList<class_1297> entities = Lists.newArrayList(MainhandModule.mc.field_1687.method_18112());
        for (class_1297 entity : entities) {
            if (!(entity instanceof class_1511) || !entity.method_5805() || !(MainhandModule.mc.field_1724.method_5739(entity) <= 12.0f)) continue;
            class_243 class_2432 = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
            if (!(ExplosionUtil.getDamageTo((class_1297)MainhandModule.mc.field_1724, class_2432, false) >= (double)EntityUtil.getHealth((class_1297)MainhandModule.mc.field_1724))) continue;
            return true;
        }
        return false;
    }

    private boolean lethalFall() {
        return (float)PlayerUtil.computeFallDamage(MainhandModule.mc.field_1724.field_6017, 1.0f) + 0.5f > MainhandModule.mc.field_1724.method_6032();
    }

    @EventListener
    public void onTick(TickEvent event) {
        class_1792 appleType;
        int appleSlot;
        boolean wantsGap;
        int totemInvSlot;
        boolean switchMainHandTotem;
        if (MainhandModule.mc.field_1724 == null || MainhandModule.mc.field_1687 == null || event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (!this.totemConfig.getValue().booleanValue()) {
            return;
        }
        if (!this.timer.passed((long)(this.delayConfig.getValue() * 1000.0))) {
            return;
        }
        if (MainhandModule.mc.field_1724.field_7512 != MainhandModule.mc.field_1724.field_7498) {
            return;
        }
        int totemSlot0 = this.totemSlotConfig.getValue() - 1;
        boolean unsafe = this.isUnsafe();
        boolean bl = switchMainHandTotem = MainhandModule.mc.field_1724.method_6079().method_7909() != class_1802.field_8288 || this.withOffhandConfig.getValue() != false;
        if (MainhandModule.mc.field_1724.method_31548().method_5438(totemSlot0).method_7909() != class_1802.field_8288 && (totemInvSlot = this.findItemInventorySlot(class_1802.field_8288)) != -1) {
            this.swapIntoHotbarSlot(totemInvSlot, totemSlot0);
            Managers.INVENTORY.syncToClient();
            if (switchMainHandTotem && (!this.isSafe() || unsafe) && (totemSlot0 != MainhandModule.mc.field_1724.method_31548().field_7545 || this.forceUpdateConfig.getValue().booleanValue())) {
                this.switchToSlot(totemSlot0);
            }
            this.timer.reset();
            return;
        }
        if (unsafe) {
            if (switchMainHandTotem) {
                if (MainhandModule.mc.field_1724.method_31548().method_5438(totemSlot0).method_7909() == class_1802.field_8288) {
                    if (totemSlot0 != MainhandModule.mc.field_1724.method_31548().field_7545 || this.forceUpdateConfig.getValue().booleanValue()) {
                        this.switchToSlot(totemSlot0);
                        this.timer.reset();
                    }
                    return;
                }
                int hotbarSlot = this.findItemHotbar(class_1802.field_8288);
                if (hotbarSlot != -1) {
                    if (hotbarSlot != MainhandModule.mc.field_1724.method_31548().field_7545 || this.forceUpdateConfig.getValue().booleanValue()) {
                        this.switchToSlot(hotbarSlot);
                        this.timer.reset();
                    }
                    return;
                }
                if (this.chorusConfig.getValue() >= 0 && MainhandModule.mc.field_1724.method_31548().method_5438(this.chorusConfig.getValue().intValue()).method_7909() == class_1802.field_8233) {
                    if (this.chorusConfig.getValue() != MainhandModule.mc.field_1724.method_31548().field_7545) {
                        this.switchToSlot(this.chorusConfig.getValue());
                        this.timer.reset();
                    }
                    return;
                }
            }
        } else if (this.alwaysConfig.getValue().booleanValue() && switchMainHandTotem && MainhandModule.mc.field_1724.method_31548().method_5438(totemSlot0).method_7909() == class_1802.field_8288 && (totemSlot0 != MainhandModule.mc.field_1724.method_31548().field_7545 || this.forceUpdateConfig.getValue().booleanValue())) {
            this.switchToSlot(totemSlot0);
            this.timer.reset();
            return;
        }
        class_1792 mainHand = MainhandModule.mc.field_1724.method_6047().method_7909();
        boolean bl2 = wantsGap = this.swordGapConfig.getValue() != false && mainHand instanceof class_1829 || this.pickaxeGapConfig.getValue() != false && mainHand instanceof class_1810 || this.totemGapConfig.getValue() != false && mainHand == class_1802.field_8288;
        if (wantsGap && MainhandModule.mc.field_1690.field_1904.method_1434() && mainHand != class_1802.field_8463 && mainHand != class_1802.field_8367 && (appleSlot = this.findItemHotbar(appleType = this.getGappleType())) != -1 && appleSlot != MainhandModule.mc.field_1724.method_31548().field_7545) {
            this.switchToSlot(appleSlot);
            this.timer.reset();
            return;
        }
        if (this.switched && this.switchBackConfig.getValue().booleanValue() && this.previousSlot != -1 && !unsafe) {
            this.switchToSlot(this.previousSlot);
            this.previousSlot = -1;
            this.switched = false;
            this.timer.reset();
        }
    }

    private boolean isSafe() {
        return !this.isUnsafe();
    }

    private void switchToSlot(int slot) {
        if (!this.switched) {
            this.previousSlot = MainhandModule.mc.field_1724.method_31548().field_7545;
        }
        Managers.INVENTORY.setClientSlot(slot);
        this.switched = true;
    }

    private void swapIntoHotbarSlot(int totemInvSlot, int hotbarSlot0) {
        int syncId = MainhandModule.mc.field_1724.field_7512.field_7763;
        switch (this.swapModeConfig.getValue().ordinal()) {
            case 0: {
                MainhandModule.mc.field_1761.method_2906(syncId, totemInvSlot, 0, class_1713.field_7790, (class_1657)MainhandModule.mc.field_1724);
                MainhandModule.mc.field_1761.method_2906(syncId, hotbarSlot0 + 36, 0, class_1713.field_7790, (class_1657)MainhandModule.mc.field_1724);
                MainhandModule.mc.field_1761.method_2906(syncId, totemInvSlot, 0, class_1713.field_7790, (class_1657)MainhandModule.mc.field_1724);
                break;
            }
            case 1: {
                MainhandModule.mc.field_1761.method_2906(syncId, totemInvSlot, hotbarSlot0, class_1713.field_7791, (class_1657)MainhandModule.mc.field_1724);
                break;
            }
            case 2: {
                int old = MainhandModule.mc.field_1724.method_31548().field_7545;
                MainhandModule.mc.field_1724.method_31548().field_7545 = hotbarSlot0;
                mc.method_1562().method_52787((class_2596)new class_2868(hotbarSlot0));
                mc.method_1562().method_52787((class_2596)new class_2838(totemInvSlot));
                MainhandModule.mc.field_1724.method_31548().field_7545 = old;
                mc.method_1562().method_52787((class_2596)new class_2868(old));
            }
        }
    }

    private int findItemInventorySlot(class_1792 item) {
        int i;
        for (i = 35; i >= 9; --i) {
            if (MainhandModule.mc.field_1724.method_31548().method_5438(i).method_7909() != item) continue;
            return i;
        }
        for (i = 8; i >= 0; --i) {
            if (MainhandModule.mc.field_1724.method_31548().method_5438(i).method_7909() != item) continue;
            return i + 36;
        }
        return -1;
    }

    private int findItemHotbar(class_1792 item) {
        for (int i = 0; i < 9; ++i) {
            if (MainhandModule.mc.field_1724.method_31548().method_5438(i).method_7909() != item) continue;
            return i;
        }
        return -1;
    }

    private class_1792 getGappleType() {
        if (this.crappleConfig.getValue().booleanValue()) {
            return this.findItemHotbar(class_1802.field_8463) != -1 ? class_1802.field_8463 : class_1802.field_8367;
        }
        return this.findItemHotbar(class_1802.field_8367) != -1 ? class_1802.field_8367 : class_1802.field_8463;
    }

    public static enum SwapMode {
        ClickSlot,
        OffhandSwap,
        Pick;

    }
}
