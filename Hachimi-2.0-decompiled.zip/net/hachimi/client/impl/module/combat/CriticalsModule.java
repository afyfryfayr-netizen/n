package net.hachimi.client.impl.module.combat;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.imixin.IPlayerInteractEntityC2SPacket;
import net.hachimi.client.impl.module.combat.AutoCrawlTrapModule;
import net.hachimi.client.impl.module.combat.AutoCrystalModule;
import net.hachimi.client.impl.module.combat.AutoMineModule;
import net.hachimi.client.impl.module.combat.AutoTrapModule;
import net.hachimi.client.impl.module.combat.AutoWebModule;
import net.hachimi.client.impl.module.combat.AutoXPModule;
import net.hachimi.client.impl.module.combat.SelfTrapModule;
import net.hachimi.client.impl.module.combat.SurroundModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.math.position.PositionUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.network.InteractType;
import net.hachimi.client.util.player.InventoryUtil;
import net.hachimi.client.util.player.MovementUtil;
import net.hachimi.client.util.string.EnumFormatter;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2879;

public class CriticalsModule
extends ToggleModule {
    private static CriticalsModule INSTANCE;
    Config<Boolean> multitaskConfig = this.register(new BooleanConfig("Multitask", "Allows crits when other combat modules are enabled", true));
    Config<CritMode> modeConfig = this.register(new EnumConfig("Mode", "Mode for critical attack modifier", (Enum)CritMode.PACKET, (Enum[])CritMode.values()));
    Config<Boolean> phaseOnlyConfig = this.register(new BooleanConfig("PhasedOnly", "Only attempts criticals when phased", false, () -> this.modeConfig.getValue() == CritMode.GRIM_V3 || this.modeConfig.getValue() == CritMode.GRIM));
    Config<Boolean> wallsOnlyConfig = this.register(new BooleanConfig("WallsOnly", "Only attempts criticals in walls", false, () -> (this.modeConfig.getValue() == CritMode.GRIM_V3 || this.modeConfig.getValue() == CritMode.GRIM) && this.phaseOnlyConfig.getValue() != false));
    Config<Boolean> moveFixConfig = this.register(new BooleanConfig("MoveFix", "Pauses crits when moving", false, () -> this.modeConfig.getValue() == CritMode.GRIM_V3 || this.modeConfig.getValue() == CritMode.GRIM));
    private final Timer attackTimer = new CacheTimer();
    private boolean postUpdateGround;
    private boolean postUpdateSprint;

    public CriticalsModule() {
        super("Criticals", "Modifies attacks to always land critical hits", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    public static CriticalsModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        return EnumFormatter.formatEnum(this.modeConfig.getValue());
    }

    @Override
    public void onDisable() {
        this.postUpdateGround = false;
        this.postUpdateSprint = false;
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Outbound event) {
        IPlayerInteractEntityC2SPacket packet;
        if (CriticalsModule.mc.field_1724 == null || CriticalsModule.mc.field_1687 == null) {
            return;
        }
        if (AutoCrystalModule.getInstance().isAttacking() || AutoCrystalModule.getInstance().isPlacing()) {
            return;
        }
        if (!this.multitaskConfig.getValue().booleanValue() && (SurroundModule.getInstance().isPlacing() || SelfTrapModule.getInstance().isPlacing() || AutoTrapModule.getInstance().isPlacing() || AutoCrawlTrapModule.getInstance().isPlacing() || AutoWebModule.getInstance().isPlacing() || AutoXPModule.getInstance().isEnabled() || AutoMineModule.getInstance().isEnabled())) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof IPlayerInteractEntityC2SPacket && (packet = (IPlayerInteractEntityC2SPacket)class_25962).getType() == InteractType.ATTACK) {
            if (CriticalsModule.mc.field_1724.method_3144() || CriticalsModule.mc.field_1724.method_6128() || CriticalsModule.mc.field_1724.method_5799() || CriticalsModule.mc.field_1724.method_5771() || CriticalsModule.mc.field_1724.method_21754() || CriticalsModule.mc.field_1724.method_6059(class_1294.field_5919) || InventoryUtil.isHolding32k()) {
                return;
            }
            class_1297 e = packet.getEntity();
            if (e == null || !e.method_5805() || !(e instanceof class_1309)) {
                return;
            }
            if (EntityUtil.isVehicle(e)) {
                if (this.modeConfig.getValue() == CritMode.PACKET) {
                    for (int i = 0; i < 5; ++i) {
                        Managers.NETWORK.sendQuietPacket((class_2596<?>)class_2824.method_34206((class_1297)e, (boolean)Managers.POSITION.isSneaking()));
                        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
                    }
                }
                return;
            }
            this.postUpdateSprint = CriticalsModule.mc.field_1724.method_5624();
            if (this.postUpdateSprint) {
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2848((class_1297)CriticalsModule.mc.field_1724, class_2848.class_2849.field_12985));
            }
            this.attackSpoofJump(e);
        }
    }

    public void attackSpoofJump(class_1297 e) {
        double x = Managers.POSITION.getX();
        double y = Managers.POSITION.getY();
        double z = Managers.POSITION.getZ();
        switch (this.modeConfig.getValue().ordinal()) {
            case 2: {
                if (!CriticalsModule.mc.field_1724.method_24828() || CriticalsModule.mc.field_1724.field_3913.field_3904) break;
                double d = 1.0E-7 + 1.0E-7 * (1.0 + (double)RANDOM.nextInt(RANDOM.nextBoolean() ? 34 : 43));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2829(x, y + (double)0.1016f + d * 3.0, z, false));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2829(x, y + (double)0.0202f + d * 2.0, z, false));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2829(x, y + 3.239E-4 + d, z, false));
                CriticalsModule.mc.field_1724.method_7277(e);
                break;
            }
            case 0: {
                if (!CriticalsModule.mc.field_1724.method_24828() || CriticalsModule.mc.field_1724.field_3913.field_3904) break;
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2829(x, y + 0.0625, z, false));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2829(x, y, z, false));
                CriticalsModule.mc.field_1724.method_7277(e);
                break;
            }
            case 1: {
                if (!this.attackTimer.passed(500) || !CriticalsModule.mc.field_1724.method_24828() || CriticalsModule.mc.field_1724.field_3913.field_3904) break;
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2829(x, y + (double)1.1E-7f, z, false));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2829(x, y + (double)1.0E-8f, z, false));
                this.postUpdateGround = true;
                this.attackTimer.reset();
                break;
            }
            case 3: {
                if (this.phaseOnlyConfig.getValue().booleanValue() && (this.wallsOnlyConfig.getValue() != false ? !this.isDoublePhased() : !this.isPhased())) {
                    return;
                }
                if (this.moveFixConfig.getValue().booleanValue() && MovementUtil.isMovingInput()) {
                    return;
                }
                if (!this.attackTimer.passed(250) || !CriticalsModule.mc.field_1724.method_24828() || CriticalsModule.mc.field_1724.method_20448()) break;
                float yaw = Managers.ROTATION.getServerYaw();
                float pitch = Managers.ROTATION.getServerPitch();
                if (Managers.ROTATION.isRotating()) {
                    yaw = Managers.ROTATION.getRotationYaw();
                    pitch = Managers.ROTATION.getRotationPitch();
                }
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2830(x, y + 0.0625, z, yaw, pitch, false));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2830(x, y + 0.0625013579, z, yaw, pitch, false));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2830(x, y + 1.3579E-6, z, yaw, pitch, false));
                this.attackTimer.reset();
                break;
            }
            case 4: {
                if (this.phaseOnlyConfig.getValue().booleanValue() && (this.wallsOnlyConfig.getValue() != false ? !this.isDoublePhased() : !this.isPhased())) {
                    return;
                }
                if (this.moveFixConfig.getValue().booleanValue() && MovementUtil.isMovingInput()) {
                    return;
                }
                if (!CriticalsModule.mc.field_1724.method_24828() || CriticalsModule.mc.field_1724.method_20448()) break;
                float yaw = Managers.ROTATION.getServerYaw();
                float pitch = Managers.ROTATION.getServerPitch();
                if (Managers.ROTATION.isRotating()) {
                    yaw = Managers.ROTATION.getRotationYaw();
                    pitch = Managers.ROTATION.getRotationPitch();
                }
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2830(x, y, z, yaw, pitch, true));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2830(x, y + 0.0625, z, yaw, pitch, false));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2830(x, y + (double)0.04535f, z, yaw, pitch, false));
                break;
            }
            case 5: {
                Managers.MOVEMENT.setMotionY(0.3425);
            }
        }
    }

    @EventListener
    public void onPacketOutboundPost(PacketEvent.OutboundPost event) {
        if (CriticalsModule.mc.field_1724 == null) {
            return;
        }
        if (event.getPacket() instanceof class_2824) {
            if (this.postUpdateGround) {
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2829(CriticalsModule.mc.field_1724.method_23317(), CriticalsModule.mc.field_1724.method_23318(), CriticalsModule.mc.field_1724.method_23321(), false));
                this.postUpdateGround = false;
            }
            if (this.postUpdateSprint) {
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2848((class_1297)CriticalsModule.mc.field_1724, class_2848.class_2849.field_12981));
                this.postUpdateSprint = false;
            }
        }
    }

    public boolean isGrim() {
        return this.modeConfig.getValue() == CritMode.GRIM;
    }

    public boolean isDoublePhased() {
        for (class_2338 pos : PositionUtil.getAllInBox(CriticalsModule.mc.field_1724.method_5829(), CriticalsModule.mc.field_1724.method_24515())) {
            class_2680 state = CriticalsModule.mc.field_1687.method_8320(pos);
            class_2680 state2 = CriticalsModule.mc.field_1687.method_8320(pos.method_10084());
            if (!state.method_51366() || !state2.method_51366()) continue;
            return true;
        }
        return false;
    }

    public boolean isPhased() {
        for (class_2338 pos : PositionUtil.getAllInBox(CriticalsModule.mc.field_1724.method_5829())) {
            if (!CriticalsModule.mc.field_1687.method_8320(pos).method_51366()) continue;
            return true;
        }
        return false;
    }

    public static enum CritMode {
        PACKET,
        PACKET_STRICT,
        VANILLA,
        GRIM,
        GRIM_V3,
        LOW_HOP;

    }
}
