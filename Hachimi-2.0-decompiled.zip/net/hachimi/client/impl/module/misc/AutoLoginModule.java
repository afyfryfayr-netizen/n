package net.hachimi.client.impl.module.misc;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.config.setting.StringConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_2596;
import net.minecraft.class_7439;

public final class AutoLoginModule
extends ToggleModule {
    private static AutoLoginModule INSTANCE;
    private final Config<String> passwordConfig = this.register(new StringConfig("Password", "Your server password", ""));
    private final Config<Boolean> registerConfig = this.register(new BooleanConfig("Register", "Also send /register command", false));
    private final Config<String> registerPasswordConfig = this.register(new StringConfig("RegisterPassword", "Password for /register (leave empty = same as Password)", "", () -> this.registerConfig.getValue()));
    private final Config<Float> delayConfig = this.register(new NumberConfig<Float>("Delay", "Delay in seconds before sending login command", Float.valueOf(0.0f), Float.valueOf(1.5f), Float.valueOf(10.0f)));
    private final Config<Boolean> autoDisableConfig = this.register(new BooleanConfig("AutoDisable", "Disable module after login", true));
    private final Timer delayTimer = new CacheTimer();
    private boolean triggered = false;
    private boolean loggedIn = false;

    public AutoLoginModule() {
        super("AutoLogin", "Automatically logs in on cracked servers", ModuleCategory.MISCELLANEOUS);
        INSTANCE = this;
    }

    public static AutoLoginModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.triggered = false;
        this.loggedIn = false;
        this.delayTimer.reset();
    }

    @Override
    public void onDisable() {
        this.triggered = false;
        this.loggedIn = false;
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (AutoLoginModule.mc.field_1724 == null || AutoLoginModule.mc.field_1687 == null) {
            return;
        }
        if (this.triggered || this.loggedIn) {
            return;
        }
        if (!this.delayTimer.passed((long)(this.delayConfig.getValue().floatValue() * 1000.0f))) {
            return;
        }
        String pass = this.passwordConfig.getValue();
        if (pass.isEmpty()) {
            return;
        }
        if (this.registerConfig.getValue().booleanValue()) {
            String regPass = this.registerPasswordConfig.getValue().isEmpty() ? pass : this.registerPasswordConfig.getValue();
            this.sendCommand("/register " + regPass + " " + regPass);
        }
        this.sendCommand("/login " + pass);
        this.triggered = true;
        if (this.autoDisableConfig.getValue().booleanValue()) {
            this.disable();
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        class_2596<?> class_25962 = event.getPacket();
        if (!(class_25962 instanceof class_7439)) {
            return;
        }
        class_7439 packet = (class_7439)class_25962;
        String msg = packet.comp_763().getString().toLowerCase();
        if (msg.contains("logged in") || msg.contains("successfully") || msg.contains("welcome back")) {
            this.loggedIn = true;
            if (this.autoDisableConfig.getValue().booleanValue()) {
                this.disable();
            }
        }
    }

    private void sendCommand(String cmd) {
        if (mc.method_1562() == null) {
            return;
        }
        if (cmd.startsWith("/")) {
            mc.method_1562().method_45730(cmd.substring(1));
        } else {
            mc.method_1562().method_45729(cmd);
        }
    }
}
