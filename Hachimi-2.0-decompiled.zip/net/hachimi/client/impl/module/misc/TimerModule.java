package net.hachimi.client.impl.module.misc;

import java.text.DecimalFormat;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.render.TickCounterEvent;
import net.hachimi.client.impl.module.movement.SpeedModule;
import net.hachimi.client.init.Managers;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;

public class TimerModule
extends ToggleModule {
    private static TimerModule INSTANCE;
    Config<Float> ticksConfig = this.register(new NumberConfig<Float>("Ticks", "The game tick speed", Float.valueOf(0.1f), Float.valueOf(2.0f), Float.valueOf(50.0f)));
    Config<Boolean> tpsSyncConfig = this.register(new BooleanConfig("TPSSync", "Syncs game tick speed to server tick speed", false));
    private float prevTimer = -1.0f;
    private float timer = 1.0f;

    public TimerModule() {
        super("Timer", "Changes the client tick speed", ModuleCategory.MISCELLANEOUS);
    }

    public static TimerModule getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new TimerModule();
        }
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        DecimalFormat decimal = new DecimalFormat("0.0#");
        return decimal.format(this.timer);
    }

    @Override
    public void toggle() {
        SpeedModule.getInstance().setPrevTimer();
        if (SpeedModule.getInstance().isUsingTimer()) {
            return;
        }
        super.toggle();
    }

    @Override
    public void onDisable() {
        Managers.TICK.setClientTick(1.0f);
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == StageEvent.EventStage.PRE) {
            if (SpeedModule.getInstance().isUsingTimer()) {
                return;
            }
            if (this.tpsSyncConfig.getValue().booleanValue()) {
                this.timer = Math.max(Managers.TICK.getTpsCurrent() / 20.0f, 0.1f);
                return;
            }
            this.timer = this.ticksConfig.getValue().floatValue();
        }
    }

    @EventListener
    public void onTickCounter(TickCounterEvent event) {
        if (this.timer != 1.0f) {
            event.cancel();
            event.setTicks(this.timer);
        }
    }

    public float getTimer() {
        return this.timer;
    }

    public void setTimer(float timer) {
        this.prevTimer = this.timer;
        this.timer = timer;
    }

    public void resetTimer() {
        if (this.prevTimer > 0.0f) {
            this.timer = this.prevTimer;
            this.prevTimer = -1.0f;
        }
    }
}
