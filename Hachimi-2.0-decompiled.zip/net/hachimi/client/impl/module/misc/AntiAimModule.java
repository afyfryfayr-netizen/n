package net.hachimi.client.impl.module.misc;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.RotationModule;
import net.hachimi.eventbus.annotation.EventListener;

public class AntiAimModule
extends RotationModule {
    Config<YawMode> yawModeConfig = this.register(new EnumConfig("Yaw", "The mode for the rotation yaw spin ", (Enum)YawMode.SPIN, (Enum[])YawMode.values()));
    Config<PitchMode> pitchModeConfig = this.register(new EnumConfig("Pitch", "The mode for the rotation pitch spin", (Enum)PitchMode.DOWN, (Enum[])PitchMode.values()));
    Config<Float> yawAddConfig = this.register(new NumberConfig<Float>("YawAdd", "The yaw to add during each rotation", Float.valueOf(-180.0f), Float.valueOf(20.0f), Float.valueOf(180.0f)));
    Config<Float> pitchAddConfig = this.register(new NumberConfig<Float>("CustomPitch", "The pitch to add during each rotation", Float.valueOf(-90.0f), Float.valueOf(20.0f), Float.valueOf(90.0f)));
    Config<Float> spinSpeedConfig = this.register(new NumberConfig<Float>("SpinSpeed", "The yaw speed to rotate", Float.valueOf(1.0f), Float.valueOf(16.0f), Float.valueOf(40.0f)));
    Config<Integer> flipTicksConfig = this.register(new NumberConfig<Integer>("FlipTicks", "The number of ticks to wait between jitter", 2, 2, 20));
    private float yaw;
    private float pitch;
    private float prevYaw;
    private float prevPitch;

    public AntiAimModule() {
        super("AntiAim", "Makes it harder to accurately aim at the player", ModuleCategory.MISCELLANEOUS, 50);
    }

    @Override
    public void onEnable() {
        if (AntiAimModule.mc.field_1724 == null) {
            return;
        }
        this.prevYaw = AntiAimModule.mc.field_1724.method_36454();
        this.prevPitch = AntiAimModule.mc.field_1724.method_36455();
    }

    @EventListener
    public void onPlayerUpdate(PlayerTickEvent event) {
        if (AntiAimModule.mc.field_1690.field_1886.method_1434() || AntiAimModule.mc.field_1690.field_1904.method_1434()) {
            return;
        }
        this.yaw = switch (this.yawModeConfig.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> AntiAimModule.mc.field_1724.method_36454();
            case 1 -> AntiAimModule.mc.field_1724.method_36454() + this.yawAddConfig.getValue().floatValue();
            case 2 -> this.prevYaw;
            case 3 -> {
                float spin = this.yaw + this.spinSpeedConfig.getValue().floatValue();
                if (spin > 360.0f) {
                    yield spin - 360.0f;
                }
                yield spin;
            }
            case 4 -> AntiAimModule.mc.field_1724.method_36454() + (AntiAimModule.mc.field_1724.field_6012 % this.flipTicksConfig.getValue() == 0 ? this.yawAddConfig.getValue().floatValue() : -this.yawAddConfig.getValue().floatValue());
        };
        this.pitch = switch (this.pitchModeConfig.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> AntiAimModule.mc.field_1724.method_36455();
            case 1 -> this.pitchAddConfig.getValue().floatValue();
            case 2 -> this.prevPitch;
            case 3 -> -90.0f;
            case 4 -> 90.0f;
            case 5 -> {
                float jitter = this.pitch + 30.0f;
                if (jitter > 90.0f) {
                    yield -90.0f;
                }
                if (jitter < -90.0f) {
                    yield 90.0f;
                }
                yield jitter;
            }
        };
        this.setRotation(this.yaw, this.pitch);
    }

    public static enum YawMode {
        OFF,
        STATIC,
        ZERO,
        SPIN,
        JITTER;

    }

    public static enum PitchMode {
        OFF,
        STATIC,
        ZERO,
        UP,
        DOWN,
        JITTER;

    }
}
