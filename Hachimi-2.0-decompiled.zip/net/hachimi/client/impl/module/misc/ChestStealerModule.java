package net.hachimi.client.impl.module.misc;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ItemListConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.module.misc.KitModule;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class ChestStealerModule
extends ToggleModule {
    private final Config<Boolean> kitModeConfig = this.register(new BooleanConfig("KitMode", "Refill kit slots: find missing items in chest and place them in their exact slot", true));
    private final Config<List<class_1792>> itemsConfig = this.register(new ItemListConfig("Items", "Items to steal (used when KitMode is off)", class_1802.field_8545));
    private final Config<Float> delayConfig = this.register(new NumberConfig<Float>("Delay", "Delay between each item steal (seconds)", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(2.0f)));
    private final Config<Integer> shiftConfig = this.register(new NumberConfig<Integer>("Shift", "Max slots to process per tick", 1, 27, 54));
    private final Timer stealTimer = new CacheTimer();
    public static final List<TransferAnimation> ANIMATIONS = new CopyOnWriteArrayList<TransferAnimation>();
    private static final long ANIMATION_DURATION_MS = 180L;

    public ChestStealerModule() {
        super("ChestStealer", "Steals items from chests", ModuleCategory.MISCELLANEOUS);
    }

    @Override
    public void onEnable() {
        this.stealTimer.reset();
    }

    @Override
    public void onDisable() {
        ANIMATIONS.clear();
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (ChestStealerModule.mc.field_1724 == null || ChestStealerModule.mc.field_1687 == null) {
            return;
        }
        class_1703 handler = ChestStealerModule.mc.field_1724.field_7512;
        class_1263 containerInv = this.findContainerInventory(handler);
        if (containerInv == null) {
            return;
        }
        if (!this.stealTimer.passed(Float.valueOf(this.delayConfig.getValue().floatValue() * 1000.0f))) {
            return;
        }
        if (this.kitModeConfig.getValue().booleanValue()) {
            this.tickKitMode(handler, containerInv);
        } else {
            this.tickNormalMode(handler, containerInv);
        }
    }

    private class_1263 findContainerInventory(class_1703 handler) {
        for (class_1735 slot : handler.field_7761) {
            class_1263 inv = slot.field_7871;
            if (inv == null || inv instanceof class_1661) continue;
            return inv;
        }
        return null;
    }

    private void tickKitMode(class_1703 handler, class_1263 containerInv) {
        KitModule kit = KitModule.getInstance();
        if (kit == null || !kit.hasKitLoaded()) {
            return;
        }
        Map<Integer, class_1792> kitItems = kit.getKitItems();
        int chestSize = containerInv.method_5439();
        int processed = 0;
        int limit = this.shiftConfig.getValue();
        for (Map.Entry<Integer, class_1792> entry : kitItems.entrySet()) {
            int chestSlot;
            class_1792 current;
            if (processed >= limit) break;
            int invSlot = entry.getKey();
            class_1792 kitItem = entry.getValue();
            if (kitItem == class_1802.field_8162 || (current = ChestStealerModule.mc.field_1724.method_31548().method_5438(invSlot).method_7909()) == kitItem || (chestSlot = this.findInChest(handler, chestSize, kitItem)) == -1) continue;
            int handlerInvSlot = this.invSlotToHandlerSlot(invSlot, chestSize);
            if (current != class_1802.field_8162) {
                int emptyChestSlot = this.findEmptyInChest(handler, chestSize);
                if (emptyChestSlot == -1) continue;
                this.queueAnimation(handler, handlerInvSlot, emptyChestSlot, ChestStealerModule.mc.field_1724.method_31548().method_5438(invSlot).method_7972());
                ChestStealerModule.mc.field_1761.method_2906(handler.field_7763, handlerInvSlot, 0, class_1713.field_7790, (class_1657)ChestStealerModule.mc.field_1724);
                ChestStealerModule.mc.field_1761.method_2906(handler.field_7763, emptyChestSlot, 0, class_1713.field_7790, (class_1657)ChestStealerModule.mc.field_1724);
            }
            class_1799 incoming = handler.method_7611(chestSlot).method_7677().method_7972();
            this.queueAnimation(handler, chestSlot, handlerInvSlot, incoming);
            ChestStealerModule.mc.field_1761.method_2906(handler.field_7763, chestSlot, 0, class_1713.field_7790, (class_1657)ChestStealerModule.mc.field_1724);
            ChestStealerModule.mc.field_1761.method_2906(handler.field_7763, handlerInvSlot, 0, class_1713.field_7790, (class_1657)ChestStealerModule.mc.field_1724);
            this.stealTimer.reset();
            ++processed;
        }
    }

    private void tickNormalMode(class_1703 handler, class_1263 containerInv) {
        int limit = this.shiftConfig.getValue();
        int checked = 0;
        for (int i = 0; i < containerInv.method_5439() && checked < limit; ++i, ++checked) {
            class_1792 item;
            class_1735 slot = handler.method_7611(i);
            if (!slot.method_7681() || (item = slot.method_7677().method_7909()) == class_1802.field_8162 || !((ItemListConfig)this.itemsConfig).contains(item)) continue;
            this.queueAnimationToPlayerInv(handler, slot.field_7874, slot.method_7677().method_7972());
            ChestStealerModule.mc.field_1761.method_2906(handler.field_7763, slot.field_7874, 0, class_1713.field_7794, (class_1657)ChestStealerModule.mc.field_1724);
            this.stealTimer.reset();
        }
    }

    private void queueAnimation(class_1703 handler, int fromId, int toId, class_1799 stack) {
        if (stack.method_7960()) {
            return;
        }
        class_1735 from = handler.method_7611(fromId);
        class_1735 to = handler.method_7611(toId);
        ANIMATIONS.add(new TransferAnimation(stack, from.field_7873, from.field_7872, to.field_7873, to.field_7872, System.currentTimeMillis(), 180L));
    }

    private void queueAnimationToPlayerInv(class_1703 handler, int fromId, class_1799 stack) {
        if (stack.method_7960()) {
            return;
        }
        class_1735 from = handler.method_7611(fromId);
        class_1735 to = this.findFirstPlayerHotbarSlot(handler);
        if (to == null) {
            return;
        }
        ANIMATIONS.add(new TransferAnimation(stack, from.field_7873, from.field_7872, to.field_7873, to.field_7872, System.currentTimeMillis(), 180L));
    }

    private class_1735 findFirstPlayerHotbarSlot(class_1703 handler) {
        for (class_1735 slot : handler.field_7761) {
            if (!(slot.field_7871 instanceof class_1661)) continue;
            return slot;
        }
        return null;
    }

    private int invSlotToHandlerSlot(int invSlot, int chestSize) {
        if (invSlot < 9) {
            return chestSize + 27 + invSlot;
        }
        return chestSize + (invSlot - 9);
    }

    private int findInChest(class_1703 handler, int chestSize, class_1792 item) {
        for (int i = 0; i < chestSize; ++i) {
            class_1735 slot = handler.method_7611(i);
            if (!slot.method_7681() || slot.method_7677().method_7909() != item) continue;
            return i;
        }
        return -1;
    }

    private int findEmptyInChest(class_1703 handler, int chestSize) {
        for (int i = 0; i < chestSize; ++i) {
            if (handler.method_7611(i).method_7681()) continue;
            return i;
        }
        return -1;
    }

    public static final class TransferAnimation {
        public final class_1799 stack;
        public final int fromX;
        public final int fromY;
        public final int toX;
        public final int toY;
        public final long startMs;
        public final long durationMs;

        TransferAnimation(class_1799 stack, int fromX, int fromY, int toX, int toY, long startMs, long durationMs) {
            this.stack = stack;
            this.fromX = fromX;
            this.fromY = fromY;
            this.toX = toX;
            this.toY = toY;
            this.startMs = startMs;
            this.durationMs = durationMs;
        }

        public float progress() {
            return (float)(System.currentTimeMillis() - this.startMs) / (float)this.durationMs;
        }

        public boolean isDone() {
            return this.progress() >= 1.0f;
        }
    }
}
