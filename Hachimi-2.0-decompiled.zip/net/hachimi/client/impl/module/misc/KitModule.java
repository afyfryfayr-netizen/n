package net.hachimi.client.impl.module.misc;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.StringConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class KitModule
extends ToggleModule {
    private static KitModule INSTANCE;
    private final Map<Integer, class_1792> kitInventory = new ConcurrentHashMap<Integer, class_1792>();
    Config<String> nameConfig = this.register(new StringConfig("Name", "The name of the kit to save/load", "default"));
    Config<Boolean> saveConfig = this.register(new BooleanConfig("Save", "Saves your current inventory as the named kit", false){

        @Override
        public void setValue(Boolean in) {
            super.setValue(in);
            if (in.booleanValue()) {
                KitModule.this.saveCurrentInventoryAsKit(KitModule.this.nameConfig.getValue());
                super.setValue(false);
            }
        }
    });
    Config<Boolean> loadConfig = this.register(new BooleanConfig("Load", "Loads the named kit and swaps your inventory to match it", false){

        @Override
        public void setValue(Boolean in) {
            super.setValue(in);
            if (in.booleanValue()) {
                if (KitModule.this.loadKit(KitModule.this.nameConfig.getValue())) {
                    KitModule.this.applyKitToInventory();
                }
                super.setValue(false);
            }
        }
    });

    public KitModule() {
        super("Kit", "Saves and loads inventory kits", ModuleCategory.MISCELLANEOUS);
        INSTANCE = this;
    }

    public static KitModule getInstance() {
        return INSTANCE;
    }

    public String getKitName() {
        return this.nameConfig.getValue();
    }

    public void setKitName(String name) {
        this.nameConfig.setValue(name);
    }

    public boolean isPartOfKit(class_1792 item) {
        if (this.kitInventory.isEmpty()) {
            return true;
        }
        return this.kitInventory.containsValue(item);
    }

    public boolean hasKitLoaded() {
        return !this.kitInventory.isEmpty();
    }

    public Map<Integer, class_1792> getKitItems() {
        return Collections.unmodifiableMap(this.kitInventory);
    }

    public String getActiveKitName() {
        return this.kitInventory.isEmpty() ? null : this.nameConfig.getValue();
    }

    public boolean isOwnShulker(class_2338 pos) {
        return false;
    }

    public void applyKitToInventory() {
        if (KitModule.mc.field_1724 == null || this.kitInventory.isEmpty()) {
            return;
        }
        int syncId = KitModule.mc.field_1724.field_7498.field_7763;
        for (int targetSlot = 0; targetSlot < 36; ++targetSlot) {
            int source;
            class_1799 current;
            class_1792 required = this.kitInventory.getOrDefault(targetSlot, class_1802.field_8162);
            if (required == class_1802.field_8162 || (current = KitModule.mc.field_1724.method_31548().method_5438(targetSlot)).method_7909() == required || (source = this.findItemInInventory(required, targetSlot)) == -1) continue;
            int handlerTarget = this.invIndexToHandlerSlot(targetSlot);
            int handlerSource = this.invIndexToHandlerSlot(source);
            KitModule.mc.field_1761.method_2906(syncId, handlerSource, 0, class_1713.field_7790, (class_1657)KitModule.mc.field_1724);
            KitModule.mc.field_1761.method_2906(syncId, handlerTarget, 0, class_1713.field_7790, (class_1657)KitModule.mc.field_1724);
            KitModule.mc.field_1761.method_2906(syncId, handlerSource, 0, class_1713.field_7790, (class_1657)KitModule.mc.field_1724);
        }
        ChatUtil.clientSendMessage("Kit '" + this.nameConfig.getValue() + "' applied!");
    }

    private int invIndexToHandlerSlot(int invIndex) {
        if (invIndex < 9) {
            return invIndex + 36;
        }
        return invIndex;
    }

    private int findItemInInventory(class_1792 item, int excludeSlot) {
        for (int i = 0; i < 36; ++i) {
            if (i == excludeSlot || KitModule.mc.field_1724.method_31548().method_5438(i).method_7909() != item) continue;
            return i;
        }
        return -1;
    }

    public void saveCurrentInventoryAsKit(String kitName) {
        if (KitModule.mc.field_1724 == null) {
            return;
        }
        this.kitInventory.clear();
        for (int i = 0; i < 36; ++i) {
            this.kitInventory.put(i, KitModule.mc.field_1724.method_31548().method_5438(i).method_7909());
        }
        try {
            Path file = this.getKitFile(kitName);
            JsonObject out = new JsonObject();
            JsonArray items = new JsonArray();
            for (int i = 0; i < 36; ++i) {
                class_1792 item = this.kitInventory.getOrDefault(i, class_1802.field_8162);
                class_2960 id = class_7923.field_41178.method_10221((Object)item);
                items.add(id.toString());
            }
            out.add("items", items);
            Files.writeString(file, (CharSequence)out.toString(), StandardCharsets.UTF_8, new OpenOption[0]);
            ChatUtil.clientSendMessage("Kit '" + kitName + "' saved to " + String.valueOf(file) + "!");
        }
        catch (IOException e) {
            Hachimi.error("Could not save kit '{}'", kitName);
            e.printStackTrace();
            ChatUtil.error("Could not save kit '" + kitName + "'!");
        }
    }

    public boolean loadKit(String kitName) {
        try {
            Path file = this.getKitFile(kitName);
            if (!Files.exists(file, new LinkOption[0])) {
                ChatUtil.error("Kit '" + kitName + "' does not exist!");
                return false;
            }
            String content = Files.readString(file, StandardCharsets.UTF_8);
            JsonObject in = JsonParser.parseString(content).getAsJsonObject();
            if (!in.has("items")) {
                ChatUtil.error("Kit '" + kitName + "' is invalid!");
                return false;
            }
            JsonArray items = in.getAsJsonArray("items");
            this.kitInventory.clear();
            for (int i = 0; i < items.size() && i < 36; ++i) {
                class_2960 id = class_2960.method_12829((String)items.get(i).getAsString());
                class_1792 item = id != null && class_7923.field_41178.method_10250(id) ? (class_1792)class_7923.field_41178.method_10223(id) : class_1802.field_8162;
                this.kitInventory.put(i, item);
            }
            ChatUtil.clientSendMessage("Kit '" + kitName + "' loaded!");
            return true;
        }
        catch (IOException e) {
            Hachimi.error("Could not load kit '{}'", kitName);
            e.printStackTrace();
            ChatUtil.error("Could not load kit '" + kitName + "'!");
            return false;
        }
    }

    public void deleteKit(String kitName) {
        try {
            Path file = this.getKitFile(kitName);
            if (!Files.exists(file, new LinkOption[0])) {
                ChatUtil.error("Kit '" + kitName + "' does not exist!");
                return;
            }
            Files.delete(file);
            ChatUtil.clientSendMessage("Kit '" + kitName + "' deleted!");
        }
        catch (IOException e) {
            Hachimi.error("Could not delete kit '{}'", kitName);
            e.printStackTrace();
            ChatUtil.error("Could not delete kit '" + kitName + "'!");
        }
    }

    private Path getKitFile(String kitName) throws IOException {
        Path kitsDir = KitModule.mc.field_1697.toPath().resolve("hachimi").resolve("Kits");
        if (!Files.exists(kitsDir, new LinkOption[0])) {
            Files.createDirectories(kitsDir, new FileAttribute[0]);
        }
        String safeName = kitName.toLowerCase().replaceAll("[^a-z0-9_-]", "_");
        return kitsDir.resolve(safeName + ".json");
    }
}
