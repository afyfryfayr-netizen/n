package net.hachimi.client.impl.module.misc;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class AutoFrameDupeModule
extends ToggleModule {
    Config<Float> range = this.register(new NumberConfig<Float>("Range", "The maximum distance to interact with item frames", Float.valueOf(1.0f), Float.valueOf(5.0f), Float.valueOf(7.0f)));
    Config<Integer> turns = this.register(new NumberConfig<Integer>("Turns", "How many times to rotate the item in the frame", 1, 5, 10));
    Config<Integer> ticks = this.register(new NumberConfig<Integer>("Ticks", "Delay between interactions in ticks", 1, 5, 10));
    Config<Boolean> switchxd = this.register(new BooleanConfig("Switch", "Automatically switch to shulker boxes when needed", true));
    private int timeoutTicks = 0;

    public AutoFrameDupeModule() {
        super("AutoFrameDupe", "Automatically dupes using frames", ModuleCategory.MISCELLANEOUS);
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (AutoFrameDupeModule.mc.field_1687 == null || AutoFrameDupeModule.mc.field_1724 == null || AutoFrameDupeModule.mc.field_1761 == null) {
            return;
        }
        for (class_1297 entity : AutoFrameDupeModule.mc.field_1687.method_18112()) {
            class_1533 frame;
            if (!(entity instanceof class_1533) || !(AutoFrameDupeModule.mc.field_1724.method_5739((class_1297)(frame = (class_1533)entity)) <= this.range.getValue().floatValue())) continue;
            if (this.timeoutTicks >= this.ticks.getValue()) {
                int shulkerSlot;
                boolean isHolding;
                class_1799 displayedItem = frame.method_6940();
                boolean hasItem = !displayedItem.method_7960();
                boolean bl = isHolding = !AutoFrameDupeModule.mc.field_1724.method_6047().method_7960();
                if (!(!this.switchxd.getValue().booleanValue() || isHolding && this.isShulkerBox(AutoFrameDupeModule.mc.field_1724.method_6047()) || (shulkerSlot = this.findShulkers()) == -1)) {
                    AutoFrameDupeModule.mc.field_1724.method_31548().field_7545 = shulkerSlot;
                    isHolding = true;
                }
                if (!hasItem && isHolding) {
                    AutoFrameDupeModule.mc.field_1761.method_2905((class_1657)AutoFrameDupeModule.mc.field_1724, (class_1297)frame, class_1268.field_5808);
                }
                if (hasItem) {
                    for (int i = 0; i < this.turns.getValue(); ++i) {
                        AutoFrameDupeModule.mc.field_1761.method_2905((class_1657)AutoFrameDupeModule.mc.field_1724, (class_1297)frame, class_1268.field_5808);
                    }
                    AutoFrameDupeModule.mc.field_1761.method_2918((class_1657)AutoFrameDupeModule.mc.field_1724, (class_1297)frame);
                }
                this.timeoutTicks = 0;
                continue;
            }
            ++this.timeoutTicks;
        }
    }

    private boolean isShulkerBox(class_1799 stack) {
        class_1792 item = stack.method_7909();
        return item == class_1802.field_8545 || item == class_1802.field_8722 || item == class_1802.field_8380 || item == class_1802.field_8050 || item == class_1802.field_8829 || item == class_1802.field_8271 || item == class_1802.field_8548 || item == class_1802.field_8520 || item == class_1802.field_8627 || item == class_1802.field_8451 || item == class_1802.field_8213 || item == class_1802.field_8816 || item == class_1802.field_8350 || item == class_1802.field_8584 || item == class_1802.field_8461 || item == class_1802.field_8676 || item == class_1802.field_8268;
    }

    private int findShulkers() {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = AutoFrameDupeModule.mc.field_1724.method_31548().method_5438(i);
            if (!this.isShulkerBox(stack)) continue;
            return i;
        }
        return -1;
    }
}
