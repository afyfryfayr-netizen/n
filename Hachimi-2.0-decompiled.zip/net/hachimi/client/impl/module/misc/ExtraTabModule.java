package net.hachimi.client.impl.module.misc;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.gui.hud.PlayerListColumnsEvent;
import net.hachimi.client.impl.event.gui.hud.PlayerListEvent;
import net.hachimi.client.impl.event.gui.hud.PlayerListIconEvent;
import net.hachimi.client.impl.event.gui.hud.PlayerListNameEvent;
import net.hachimi.client.impl.module.client.SocialsModule;
import net.hachimi.client.init.Managers;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_2561;

public class ExtraTabModule
extends ToggleModule {
    Config<Integer> sizeConfig = this.register(new NumberConfig<Integer>("Size", "The number of players to show", 80, 200, 1000));
    Config<Integer> columnsConfig = this.register(new NumberConfig<Integer>("Columns", "The number columns to show.", 1, 20, 100));
    Config<Boolean> selfConfig = this.register(new BooleanConfig("Self", "Highlights yourself in the tab list.", false));
    Config<Boolean> friendsConfig = this.register(new BooleanConfig("Friends", "Highlights friends in the tab list.", true));

    public ExtraTabModule() {
        super("ExtraTab", "Expands the tab list size to allow for more players", ModuleCategory.MISCELLANEOUS);
    }

    @EventListener
    public void onPlayerListName(PlayerListNameEvent event) {
        String name1;
        String[] names = event.getPlayerName().getString().split(" ");
        if (this.selfConfig.getValue().booleanValue()) {
            for (String s : names) {
                name1 = this.stripControlCodes(s);
                if (!name1.equals(mc.method_53462().getName())) continue;
                event.cancel();
                event.setPlayerName(class_2561.method_30163((String)("\u00a7s" + event.getPlayerName().getString())));
                return;
            }
        }
        if (this.friendsConfig.getValue().booleanValue() && SocialsModule.getInstance().isFriendsEnabled()) {
            for (String s : names) {
                name1 = this.stripControlCodes(s);
                if (!Managers.SOCIAL.isFriend(name1)) continue;
                event.cancel();
                event.setPlayerName(class_2561.method_30163((String)("\u00a7g" + event.getPlayerName().getString())));
                break;
            }
        }
    }

    @EventListener
    public void onPlayerListIcon(PlayerListIconEvent.Width event) {
        String[] names;
        for (String name : names = event.getText().split(" ")) {
            String string = this.stripControlCodes(name);
        }
    }

    @EventListener
    public void onPlayerListIconRender(PlayerListIconEvent.Render event) {
        String[] names;
        for (String name : names = event.getPlayerNameText().getString().split(" ")) {
            String string = this.stripControlCodes(name);
        }
    }

    @EventListener
    public void onPlayerList(PlayerListEvent event) {
        event.cancel();
        event.setSize(this.sizeConfig.getValue());
    }

    @EventListener
    public void onPlayerListColumns(PlayerListColumnsEvent event) {
        event.cancel();
        event.setTabHeight(this.columnsConfig.getValue());
    }

    private String stripControlCodes(String string) {
        StringBuilder builder = new StringBuilder();
        boolean skip = false;
        for (char c : string.toCharArray()) {
            if (c == '\u00a7') {
                skip = true;
                continue;
            }
            if (skip) {
                skip = false;
                continue;
            }
            builder.append(c);
        }
        return builder.toString();
    }
}
