package net.hachimi.client.impl.module.misc;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_2596;
import net.minecraft.class_7438;

public class AntiSpamModule
extends ToggleModule {
    Config<Boolean> unicodeConfig = this.register(new BooleanConfig("Unicode", "Prevents unicode characters from being rendered in chat", false));
    private final Map<UUID, String> messages = new HashMap<UUID, String>();

    public AntiSpamModule() {
        super("AntiSpam", "Prevents players from spamming the game chat", ModuleCategory.MISCELLANEOUS);
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (AntiSpamModule.mc.field_1724 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_7438) {
            String lastMessage;
            class_7438 packet = (class_7438)class_25962;
            if (this.unicodeConfig.getValue().booleanValue()) {
                String msg = packet.comp_1102().comp_1090();
                Pattern pattern = Pattern.compile("[^\\x00-\\x7F\\u0400-\\u04FF]+", 2);
                Matcher matcher = pattern.matcher(msg);
                if (matcher.find()) {
                    event.cancel();
                    return;
                }
            }
            UUID sender = packet.comp_1099();
            String chatMessage = packet.comp_1102().comp_1090();
            if (chatMessage.equalsIgnoreCase(lastMessage = this.messages.get(sender))) {
                event.cancel();
            } else if (lastMessage != null) {
                this.messages.replace(sender, chatMessage);
            } else {
                this.messages.put(sender, chatMessage);
            }
        }
    }
}
