package net.hachimi.client.impl.module.misc;

import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.entity.player.PushEntityEvent;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.util.entity.FakePlayerEntity;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1657;

public class FakePlayerModule
extends ToggleModule {
    private FakePlayerEntity fakePlayer;

    public FakePlayerModule() {
        super("FakePlayer", "Spawns an indestructible client-side player", ModuleCategory.MISCELLANEOUS);
    }

    @Override
    public void onEnable() {
        if (FakePlayerModule.mc.field_1724 != null && FakePlayerModule.mc.field_1687 != null) {
            this.fakePlayer = new FakePlayerEntity((class_1657)FakePlayerModule.mc.field_1724, "FakePlayer");
            this.fakePlayer.spawnPlayer();
        }
    }

    @Override
    public void onDisable() {
        if (this.fakePlayer != null) {
            this.fakePlayer.despawnPlayer();
            this.fakePlayer = null;
        }
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        this.fakePlayer = null;
        this.disable();
    }

    @EventListener
    public void onPushEntity(PushEntityEvent event) {
        if (event.getPushed().equals((Object)FakePlayerModule.mc.field_1724) && event.getPusher().equals((Object)this.fakePlayer)) {
            event.setCanceled(true);
        }
    }
}
