package net.hachimi.client.impl.module.misc;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.network.GameJoinEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.chat.ChatUtil;
import net.hachimi.client.util.math.HexRandom;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;

public class SpammerModule
extends ToggleModule {
    Config<Float> delayConfig = this.register(new NumberConfig<Float>("Delay", "The chat message delay", Float.valueOf(0.0f), Float.valueOf(1.5f), Float.valueOf(10.0f)));
    Config<Boolean> randomConfig = this.register(new BooleanConfig("Random", "Randomizes the spammed messages", false));
    Config<Boolean> antiKickConfig = this.register(new BooleanConfig("AntiKick", "Adds a random suffix to end of messages to prevent kicks", false));
    private final List<String> messages = new ArrayList<String>();
    private int messageIndex;
    private final Timer spamTimer = new CacheTimer();

    public SpammerModule() {
        super("Spammer", "Spams messages in the chat", ModuleCategory.MISCELLANEOUS);
    }

    @Override
    public void onEnable() {
        this.loadFile();
        this.messageIndex = 0;
    }

    @EventListener
    public void onGameJoin(GameJoinEvent event) {
        this.onEnable();
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (this.spamTimer.passed(Float.valueOf(this.delayConfig.getValue().floatValue() * 1000.0f))) {
            this.sendSpamMessage(this.getSpammerMessage());
            this.spamTimer.reset();
        }
    }

    private void loadFile() {
        File spammerDir = Hachimi.CONFIG.getClientDirectory().resolve("spammer.txt").toFile();
        if (!spammerDir.exists()) {
            this.sendModuleError("The spammer.txt file does not exist! Please create one to enable this module");
            this.disable();
            return;
        }
        this.messages.clear();
        try {
            for (String line : Files.readAllLines(Path.of(spammerDir.getAbsolutePath(), new String[0]), StandardCharsets.UTF_8)) {
                String[] messages1;
                for (String message : messages1 = line.split(",")) {
                    this.messages.add(message.trim());
                }
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    private String getSpammerMessage() {
        String defaultMessage = "Hachimi victory!";
        if (this.messages.isEmpty()) {
            return defaultMessage;
        }
        if (this.randomConfig.getValue().booleanValue()) {
            Object message = this.messages.get(RANDOM.nextInt(this.messages.size()));
            if (message != null) {
                if (this.antiKickConfig.getValue().booleanValue()) {
                    message = (String)message + " " + HexRandom.generateRandomHex(2);
                }
                return message;
            }
        } else {
            Object message = this.messages.get(this.messageIndex);
            ++this.messageIndex;
            if (this.messageIndex >= this.messages.size()) {
                this.messageIndex = 0;
            }
            if (message != null) {
                if (this.antiKickConfig.getValue().booleanValue()) {
                    message = (String)message + " " + HexRandom.generateRandomHex(2);
                }
                return message;
            }
        }
        return defaultMessage;
    }

    private void sendSpamMessage(String message) {
        if (message.charAt(0) == '/') {
            message = message.substring(1);
            SpammerModule.mc.field_1724.field_3944.method_45731(message);
            return;
        }
        if (message.startsWith(Managers.COMMAND.getPrefix())) {
            String literal = message.substring(1);
            SpammerModule.mc.field_1705.method_1743().method_1803(message);
            try {
                Managers.COMMAND.getDispatcher().execute(Managers.COMMAND.getDispatcher().parse(literal, (Object)Managers.COMMAND.getSource()));
            }
            catch (Exception exception) {
                // empty catch block
            }
            return;
        }
        if (mc.method_1542()) {
            ChatUtil.clientSendMessageRaw(message);
        } else {
            ChatUtil.serverSendMessage(message);
        }
    }
}
