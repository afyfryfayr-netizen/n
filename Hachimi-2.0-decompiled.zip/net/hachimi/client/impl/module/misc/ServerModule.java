package net.hachimi.client.impl.module.misc;

import java.time.Instant;
import java.util.BitSet;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ConcurrentModule;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.gui.screen.MenuDisconnectEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2668;
import net.minecraft.class_2675;
import net.minecraft.class_2708;
import net.minecraft.class_2720;
import net.minecraft.class_2743;
import net.minecraft.class_2797;
import net.minecraft.class_2856;
import net.minecraft.class_3515;
import net.minecraft.class_7635;

public final class ServerModule
extends ConcurrentModule {
    Config<Boolean> demoConfig = this.register(new BooleanConfig("NoDemo", "Prevents servers from forcing you to a demo screen", true));
    Config<Boolean> resourcePackConfig = this.register(new BooleanConfig("NoResourcePack", "Prevents server from forcing resource pack", false));
    Config<Boolean> antiCrashConfig = this.register(new BooleanConfig("NoServerCrash", "Prevents server packets from crashing the client", false));
    Config<Boolean> illegalDisconnectConfig = this.register(new BooleanConfig("IllegalDisconnect", "Disconnects by getting kicked from server", false));

    public ServerModule() {
        super("Server", "Prevents servers actions on player", ModuleCategory.MISCELLANEOUS);
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        class_2668 packet;
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2668 && (packet = (class_2668)class_25962).method_11491() == class_2668.field_25650 && !mc.method_1530() && this.demoConfig.getValue().booleanValue()) {
            Hachimi.info("Server attempted to use Demo mode features on you!");
            event.cancel();
        }
        if (event.getPacket() instanceof class_2720 && this.resourcePackConfig.getValue().booleanValue()) {
            event.cancel();
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2856(ServerModule.mc.field_1724.method_5667(), class_2856.class_2857.field_13018));
        }
        if (ServerModule.mc.field_1687 == null) {
            return;
        }
        if (this.antiCrashConfig.getValue().booleanValue()) {
            class_2596<?> class_25963 = event.getPacket();
            if (class_25963 instanceof class_2708 && ((packet = (class_2708)class_25963).method_11734() > 3.0E7 || packet.method_11735() > (double)ServerModule.mc.field_1687.method_31600() || packet.method_11738() > 3.0E7 || packet.method_11734() < -3.0E7 || packet.method_11735() < (double)ServerModule.mc.field_1687.method_31607() || packet.method_11738() < -3.0E7)) {
                event.cancel();
            } else {
                class_2664 packet2;
                class_25963 = event.getPacket();
                if (class_25963 instanceof class_2664 && ((packet2 = (class_2664)class_25963).method_11475() > 3.0E7 || packet2.method_11477() > (double)ServerModule.mc.field_1687.method_31600() || packet2.method_11478() > 3.0E7 || packet2.method_11475() < -3.0E7 || packet2.method_11477() < (double)ServerModule.mc.field_1687.method_31607() || packet2.method_11478() < -3.0E7 || packet2.method_11476() > 1000.0f || packet2.method_11479().size() > 1000 || packet2.method_11472() > 1000.0f || packet2.method_11473() > 1000.0f || packet2.method_11474() > 1000.0f || packet2.method_11472() < -1000.0f || packet2.method_11473() < -1000.0f || packet2.method_11474() < -1000.0f)) {
                    event.cancel();
                } else {
                    class_2743 packet3;
                    class_25963 = event.getPacket();
                    if (class_25963 instanceof class_2743 && ((packet3 = (class_2743)class_25963).method_11815() > 1000.0 || packet3.method_11816() > 1000.0 || packet3.method_11819() > 1000.0 || packet3.method_11815() < -1000.0 || packet3.method_11816() < -1000.0 || packet3.method_11819() < -1000.0)) {
                        event.cancel();
                    } else {
                        class_2675 packet4;
                        class_25963 = event.getPacket();
                        if (class_25963 instanceof class_2675 && (packet4 = (class_2675)class_25963).method_11545() > 500) {
                            event.cancel();
                        }
                    }
                }
            }
        }
    }

    @EventListener
    public void onMenuDisconnect(MenuDisconnectEvent event) {
        if (this.illegalDisconnectConfig.getValue().booleanValue()) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2797("\u00a7", Instant.now(), class_3515.class_7426.method_43531(), null, new class_7635.class_7636(1, new BitSet(2))));
        }
    }
}
