package net.hachimi.client.impl.module.misc;

import java.util.List;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.ItemListConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.config.setting.StringConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1657;
import net.minecraft.class_1706;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_471;
import net.minecraft.class_9334;

public final class AutoAnvilRenameModule
extends ToggleModule {
    Config<Selection> autoRenameSelectionConfig = this.register(new EnumConfig("Selection", "The selection of items to rename", (Enum)Selection.ALL, (Enum[])Selection.values()));
    Config<List<class_1792>> autoRenameWhitelistConfig = this.register(new ItemListConfig("Whitelist", "The items to rename.", class_1802.field_8545, class_1802.field_8722, class_1802.field_8451, class_1802.field_8627, class_1802.field_8268, class_1802.field_8584, class_1802.field_8676, class_1802.field_8380, class_1802.field_8271, class_1802.field_8548, class_1802.field_8461, class_1802.field_8213, class_1802.field_8829, class_1802.field_8350, class_1802.field_8816, class_1802.field_8520));
    Config<List<class_1792>> autoRenameBlacklistConfig = this.register(new ItemListConfig("Blacklist", "The items to not rename.", class_1802.field_8287));
    Config<String> autoRenameTextConfig = this.register(new StringConfig("Text", "The text to rename the items to.", "HachimiClient.net"));
    Config<Integer> autoRenameDelayConfig = this.register(new NumberConfig<Integer>("Delay", "The delay between renaming items.", 0, 10, 20));
    Config<Boolean> debugConfig = this.register(new BooleanConfig("Debug", "Prints debug information to chat.", false, () -> false));
    private final CacheTimer delayTimer = new CacheTimer();

    public AutoAnvilRenameModule() {
        super("AutoAnvilRename", "Automatically renames items in anvils.", ModuleCategory.MISCELLANEOUS);
    }

    @EventListener
    public void onTick(TickEvent event) {
        class_437 class_4372;
        if (AutoAnvilRenameModule.mc.field_1724 == null || AutoAnvilRenameModule.mc.field_1687 == null || AutoAnvilRenameModule.mc.field_1761 == null || !((class_4372 = AutoAnvilRenameModule.mc.field_1755) instanceof class_471)) {
            return;
        }
        class_471 anvilScreen = (class_471)class_4372;
        if (!this.delayTimer.passed(this.autoRenameDelayConfig.getValue())) {
            return;
        }
        if (AutoAnvilRenameModule.mc.field_1724.field_7520 <= 0 && !AutoAnvilRenameModule.mc.field_1724.method_7337()) {
            if (this.debugConfig.getValue().booleanValue()) {
                this.sendModuleMessage("Not enough experience levels!");
            }
            return;
        }
        class_1706 screenHandler = (class_1706)anvilScreen.method_17577();
        if (!screenHandler.method_7611(1).method_7677().method_7960()) {
            this.moveToEmptySlot(screenHandler, 1);
            return;
        }
        if (!screenHandler.method_7611(0).method_7677().method_7960()) {
            this.moveToEmptySlot(screenHandler, 0);
            return;
        }
        if (!screenHandler.method_7611(2).method_7677().method_7960()) {
            this.moveToEmptySlot(screenHandler, 2);
            return;
        }
        for (int i = 3; i < 39; ++i) {
            class_1799 itemStack = screenHandler.method_7611(i).method_7677();
            if (itemStack.method_7960() || this.equalsName(itemStack, this.autoRenameTextConfig.getName()) || this.autoRenameSelectionConfig.getValue() == Selection.BLACKLIST && this.autoRenameBlacklistConfig.getValue().contains(itemStack.method_7909()) || this.autoRenameSelectionConfig.getValue() == Selection.WHITELIST && !this.autoRenameWhitelistConfig.getValue().contains(itemStack.method_7909())) continue;
            String name = !this.autoRenameTextConfig.getValue().trim().isEmpty() ? this.autoRenameTextConfig.getValue() : "";
            AutoAnvilRenameModule.mc.field_1761.method_2906(screenHandler.field_7763, i, 0, class_1713.field_7790, (class_1657)AutoAnvilRenameModule.mc.field_1724);
            AutoAnvilRenameModule.mc.field_1761.method_2906(screenHandler.field_7763, screenHandler.method_7611((int)0).field_7874, 0, class_1713.field_7790, (class_1657)AutoAnvilRenameModule.mc.field_1724);
            ((class_471)AutoAnvilRenameModule.mc.field_1755).field_2821.method_1852(name);
            if (this.debugConfig.getValue().booleanValue()) {
                this.sendModuleMessage("Successfully renamed item in slot: " + i + ".");
            }
            AutoAnvilRenameModule.mc.field_1761.method_2906(screenHandler.field_7763, screenHandler.method_7611((int)2).field_7874, 0, class_1713.field_7790, (class_1657)AutoAnvilRenameModule.mc.field_1724);
            AutoAnvilRenameModule.mc.field_1761.method_2906(screenHandler.field_7763, i, 0, class_1713.field_7790, (class_1657)AutoAnvilRenameModule.mc.field_1724);
            break;
        }
        this.delayTimer.reset();
    }

    private void moveToEmptySlot(class_1706 screenHandler, int slot) {
        if (AutoAnvilRenameModule.mc.field_1761 == null) {
            return;
        }
        for (int i = 3; i < 39; ++i) {
            class_1799 itemStack = screenHandler.method_7611(i).method_7677();
            if (!itemStack.method_7960()) continue;
            AutoAnvilRenameModule.mc.field_1761.method_2906(screenHandler.field_7763, screenHandler.method_7611((int)slot).field_7874, 0, class_1713.field_7790, (class_1657)AutoAnvilRenameModule.mc.field_1724);
            AutoAnvilRenameModule.mc.field_1761.method_2906(screenHandler.field_7763, i, 0, class_1713.field_7790, (class_1657)AutoAnvilRenameModule.mc.field_1724);
            return;
        }
        AutoAnvilRenameModule.mc.field_1761.method_2906(screenHandler.field_7763, screenHandler.method_7611((int)slot).field_7874, 0, class_1713.field_7795, (class_1657)AutoAnvilRenameModule.mc.field_1724);
    }

    private boolean equalsName(class_1799 itemStack, String itemName) {
        if (itemName.trim().isEmpty()) {
            return itemStack.method_57824(class_9334.field_49631) == null;
        }
        return itemStack.method_7964().getString().equals(itemName);
    }

    private static enum Selection {
        ALL,
        WHITELIST,
        BLACKLIST;

    }
}
