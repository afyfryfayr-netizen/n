package net.hachimi.client.impl.module;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.module.BlockPlacerModule;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public class ObsidianPlacerModule
extends BlockPlacerModule {
    protected static final class_2680 DEFAULT_OBSIDIAN_STATE = class_2246.field_10540.method_9564();
    private static final List<class_2248> RESISTANT_BLOCKS = new LinkedList<class_2248>(){
        {
            this.add(class_2246.field_10540);
            this.add(class_2246.field_22423);
            this.add(class_2246.field_10443);
        }
    };

    public ObsidianPlacerModule(String name, String desc, ModuleCategory category) {
        super(name, desc, category);
    }

    public ObsidianPlacerModule(String name, String desc, ModuleCategory category, int rotationPriority) {
        super(name, desc, category, rotationPriority);
    }

    protected BlockSlot getResistantBlockItem() {
        HashSet<BlockSlot> blockSlots = new HashSet<BlockSlot>();
        for (class_2248 type : RESISTANT_BLOCKS) {
            int slot = this.getBlockItemSlot(type);
            if (slot == -1) continue;
            blockSlots.add(new BlockSlot(type, slot));
        }
        BlockSlot slot = blockSlots.stream().filter(b -> b.block() == class_2246.field_10540).findFirst().orElse(null);
        if (slot != null) {
            return slot;
        }
        BlockSlot slot1 = blockSlots.stream().filter(b -> b.block() == class_2246.field_22423).findFirst().orElse(null);
        if (slot1 != null) {
            return slot1;
        }
        BlockSlot slot2 = blockSlots.stream().filter(b -> b.block() == class_2246.field_10443).findFirst().orElse(null);
        if (slot2 != null) {
            return slot2;
        }
        return null;
    }

    public record BlockSlot(class_2248 block, int slot) {
        @Override
        public boolean equals(Object obj) {
            BlockSlot b;
            return obj instanceof BlockSlot && (b = (BlockSlot)obj).block() == this.block;
        }
    }
}
