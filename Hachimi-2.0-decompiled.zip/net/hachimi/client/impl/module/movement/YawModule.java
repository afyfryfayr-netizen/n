package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.entity.LookDirectionEvent;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1501;
import net.minecraft.class_3532;

public class YawModule
extends ToggleModule {
    Config<Boolean> lockConfig = this.register(new BooleanConfig("Lock", "Locks the yaw in cardinal direction", false));

    public YawModule() {
        super("Yaw", "Locks player yaw to a cardinal axis", ModuleCategory.MOVEMENT);
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == StageEvent.EventStage.PRE) {
            float yaw = (float)Math.round(YawModule.mc.field_1724.method_36454() / 45.0f) * 45.0f;
            class_1297 vehicle = YawModule.mc.field_1724.method_5854();
            if (vehicle != null) {
                vehicle.method_36456(yaw);
                if (vehicle instanceof class_1501) {
                    class_1501 llama = (class_1501)vehicle;
                    llama.method_5847(yaw);
                }
                return;
            }
            YawModule.mc.field_1724.method_36456(yaw);
            YawModule.mc.field_1724.method_5847(yaw);
        }
    }

    @EventListener
    public void onLookDirection(LookDirectionEvent event) {
        if (this.lockConfig.getValue().booleanValue()) {
            event.cancel();
            float f = (float)event.getCursorDeltaY() * 0.15f;
            YawModule.mc.field_1724.method_36457(class_3532.method_15363((float)(YawModule.mc.field_1724.method_36455() + f), (float)-90.0f, (float)90.0f));
        }
    }
}
