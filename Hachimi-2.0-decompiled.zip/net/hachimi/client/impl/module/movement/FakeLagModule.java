package net.hachimi.client.impl.module.movement;

import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.FakePlayerEntity;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;

public class FakeLagModule
extends ToggleModule {
    Config<LagMode> modeConfig = this.register(new EnumConfig("Mode", "The mode for caching packets", (Enum)LagMode.BLINK, (Enum[])LagMode.values()));
    Config<Boolean> pulseConfig = this.register(new BooleanConfig("Pulse", "Releases packets at intervals", false));
    Config<Float> factorConfig = this.register(new NumberConfig<Float>("Factor", "The factor for packet intervals", Float.valueOf(0.0f), Float.valueOf(1.0f), Float.valueOf(10.0f), () -> this.pulseConfig.getValue()));
    Config<Boolean> renderConfig = this.register(new BooleanConfig("Render", "Renders the serverside player position", true));
    private FakePlayerEntity serverModel;
    private boolean blinking;
    private final Queue<class_2596<?>> packets = new LinkedBlockingQueue();

    public FakeLagModule() {
        super("FakeLag", "Withholds packets from the server, creating clientside lag", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEnable() {
        if (FakeLagModule.mc.field_1724 != null && this.renderConfig.getValue().booleanValue()) {
            this.serverModel = new FakePlayerEntity((class_1657)FakeLagModule.mc.field_1724);
            this.serverModel.spawnPlayer();
            this.serverModel.method_5826(FakeLagModule.mc.field_1724.method_5667());
        }
    }

    @Override
    public void onDisable() {
        if (FakeLagModule.mc.field_1724 == null) {
            return;
        }
        if (!this.packets.isEmpty()) {
            for (class_2596 class_25962 : this.packets) {
                Managers.NETWORK.sendPacket(class_25962);
            }
            this.packets.clear();
        }
        if (this.serverModel != null) {
            this.serverModel.method_5826(UUID.fromString("8667ba71-b85a-4004-af54-457a9734eed7"));
            this.serverModel.despawnPlayer();
        }
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == StageEvent.EventStage.PRE && this.pulseConfig.getValue().booleanValue() && (float)this.packets.size() > this.factorConfig.getValue().floatValue() * 10.0f) {
            this.blinking = true;
            if (!this.packets.isEmpty()) {
                for (class_2596 class_25962 : this.packets) {
                    Managers.NETWORK.sendPacket(class_25962);
                }
            }
            this.packets.clear();
            if (this.serverModel != null) {
                this.serverModel.method_5719((class_1297)FakeLagModule.mc.field_1724);
                this.serverModel.method_5847(FakeLagModule.mc.field_1724.field_6241);
            }
            this.blinking = false;
        }
    }

    @EventListener
    public void onDisconnectEvent(DisconnectEvent event) {
        this.disable();
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Outbound event) {
        if (FakeLagModule.mc.field_1724 == null || FakeLagModule.mc.field_1724.method_3144() || this.blinking) {
            return;
        }
        if (event.getPacket() instanceof class_2846 || event.getPacket() instanceof class_2828 || event.getPacket() instanceof class_2848 || event.getPacket() instanceof class_2879 || event.getPacket() instanceof class_2824 || event.getPacket() instanceof class_2885 || event.getPacket() instanceof class_2886) {
            event.cancel();
            this.packets.add(event.getPacket());
        }
    }

    public static enum LagMode {
        BLINK;

    }
}
