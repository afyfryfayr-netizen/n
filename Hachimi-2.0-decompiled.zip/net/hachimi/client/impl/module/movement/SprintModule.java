package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.entity.JumpRotationEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.event.network.SprintCancelEvent;
import net.hachimi.client.impl.module.RotationModule;
import net.hachimi.client.impl.module.client.AnticheatModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.player.MovementUtil;
import net.hachimi.client.util.player.PlayerUtil;
import net.hachimi.client.util.string.EnumFormatter;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1294;
import net.minecraft.class_3532;

public class SprintModule
extends RotationModule {
    private static SprintModule INSTANCE;
    Config<SprintMode> modeConfig = this.register(new EnumConfig("Mode", "Sprinting mode. Rage allows for multi-directional sprinting.", (Enum)SprintMode.LEGIT, (Enum[])SprintMode.values()));
    Config<Boolean> jumpFixConfig = this.register(new BooleanConfig("JumpFix", "Fixes jumping slowdown in Rage sprint", true, () -> this.modeConfig.getValue() == SprintMode.RAGE || this.modeConfig.getValue() == SprintMode.RAGE_STRICT));

    public SprintModule() {
        super("Sprint", "Automatically sprints", ModuleCategory.MOVEMENT, 110);
        INSTANCE = this;
    }

    public static SprintModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        return EnumFormatter.formatEnum(this.modeConfig.getValue());
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (this.canSprint()) {
            float sprintYaw = this.getSprintYaw(SprintModule.mc.field_1724.method_36454());
            if (this.checkSprintAngle(sprintYaw)) {
                return;
            }
            switch (this.modeConfig.getValue().ordinal()) {
                case 0: {
                    if (!SprintModule.mc.field_1724.field_3913.method_20622() || SprintModule.mc.field_1724.field_5976 && !SprintModule.mc.field_1724.field_34927) break;
                    SprintModule.mc.field_1724.method_5728(true);
                    break;
                }
                case 1: 
                case 2: 
                case 3: {
                    SprintModule.mc.field_1724.method_5728(true);
                }
            }
        }
    }

    @EventListener
    public void onSprintCancel(SprintCancelEvent event) {
        if (this.canSprint() && (this.modeConfig.getValue() == SprintMode.RAGE || this.modeConfig.getValue() == SprintMode.RAGE_STRICT)) {
            float sprintYaw = this.getSprintYaw(SprintModule.mc.field_1724.method_36454());
            if (this.checkSprintAngle(sprintYaw)) {
                return;
            }
            event.cancel();
        }
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (this.canSprint() && this.modeConfig.getValue() == SprintMode.RAGE_STRICT) {
            this.setRotation(this.getSprintYaw(SprintModule.mc.field_1724.method_36454()), SprintModule.mc.field_1724.method_36455());
        }
    }

    @EventListener
    public void onJumpYaw(JumpRotationEvent event) {
        if (this.jumpFixConfig.getValue().booleanValue() && (this.modeConfig.getValue() == SprintMode.RAGE || this.modeConfig.getValue() == SprintMode.RAGE_STRICT)) {
            float yaw = event.getYaw();
            float forward = Math.signum(SprintModule.mc.field_1724.field_3913.field_3905);
            float strafe = 90.0f * Math.signum(SprintModule.mc.field_1724.field_3913.field_3907);
            if (forward != 0.0f) {
                strafe *= forward * 0.5f;
            }
            yaw -= strafe;
            if (forward < 0.0f) {
                yaw -= 180.0f;
            }
            event.cancel();
            event.setYaw(yaw);
        }
    }

    private boolean canSprint() {
        if (AnticheatModule.getInstance().getWebJumpFix() && PlayerUtil.inWeb(1.0)) {
            return false;
        }
        return MovementUtil.isInputtingMovement() && !SprintModule.mc.field_1724.method_5715() && !SprintModule.mc.field_1724.method_3144() && !SprintModule.mc.field_1724.method_6128() && !SprintModule.mc.field_1724.method_5799() && !SprintModule.mc.field_1724.method_5771() && !SprintModule.mc.field_1724.method_21754() && !SprintModule.mc.field_1724.method_6059(class_1294.field_5919) && (float)SprintModule.mc.field_1724.method_7344().method_7586() > 6.0f;
    }

    private boolean checkSprintAngle(float sprintYaw) {
        if (this.modeConfig.getValue() == SprintMode.RAGE_STRICT) {
            return class_3532.method_15356((float)sprintYaw, (float)Managers.ROTATION.getServerYaw()) > 0.0f;
        }
        if (this.modeConfig.getValue() == SprintMode.GRIM) {
            return class_3532.method_15356((float)SprintModule.mc.field_1724.method_36454(), (float)Managers.ROTATION.getServerYaw()) > 0.0f;
        }
        return false;
    }

    public float getSprintYaw(float yaw) {
        boolean forward = SprintModule.mc.field_1690.field_1894.method_1434();
        boolean backward = SprintModule.mc.field_1690.field_1881.method_1434();
        boolean left = SprintModule.mc.field_1690.field_1913.method_1434();
        boolean right = SprintModule.mc.field_1690.field_1849.method_1434();
        if (forward && !backward) {
            if (left && !right) {
                yaw -= 45.0f;
            } else if (right && !left) {
                yaw += 45.0f;
            }
        } else if (backward && !forward) {
            yaw += 180.0f;
            if (left && !right) {
                yaw += 45.0f;
            } else if (right && !left) {
                yaw -= 45.0f;
            }
        } else if (left && !right) {
            yaw -= 90.0f;
        } else if (right && !left) {
            yaw += 90.0f;
        }
        return class_3532.method_15393((float)yaw);
    }

    public static enum SprintMode {
        LEGIT,
        RAGE,
        RAGE_STRICT,
        GRIM;

    }
}
