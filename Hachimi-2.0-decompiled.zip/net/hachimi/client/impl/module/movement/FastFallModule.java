package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.entity.player.PlayerMoveEvent;
import net.hachimi.client.impl.event.network.TickMovementEvent;
import net.hachimi.client.impl.module.exploit.PacketFlyModule;
import net.hachimi.client.impl.module.movement.FlightModule;
import net.hachimi.client.impl.module.movement.LongJumpModule;
import net.hachimi.client.impl.module.movement.SpeedModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_238;

public class FastFallModule
extends ToggleModule {
    Config<Float> heightConfig = this.register(new NumberConfig<Float>("Height", "The maximum fall height", Float.valueOf(1.0f), Float.valueOf(3.0f), Float.valueOf(10.0f)));
    Config<FallMode> fallModeConfig = this.register(new EnumConfig("Mode", "The mode for falling down blocks", (Enum)FallMode.STEP, (Enum[])FallMode.values()));
    Config<Boolean> accelerateConfig = this.register(new BooleanConfig("Accelerate", "Accels the fall speed", false, () -> this.fallModeConfig.getValue() == FallMode.STEP));
    Config<Integer> shiftTicksConfig = this.register(new NumberConfig<Integer>("ShiftTicks", "Number of ticks to shift ahead", Integer.valueOf(1), Integer.valueOf(3), Integer.valueOf(5), () -> this.fallModeConfig.getValue() == FallMode.SHIFT));
    private boolean prevOnGround;
    private boolean cancelFallMovement;
    private int fallTicks;
    private final Timer fallTimer = new CacheTimer();

    public FastFallModule() {
        super("FastFall", "Falls down blocks faster", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onDisable() {
        this.cancelFallMovement = false;
        this.fallTicks = 0;
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == StageEvent.EventStage.PRE) {
            this.prevOnGround = FastFallModule.mc.field_1724.method_24828();
            if (this.fallModeConfig.getValue() == FallMode.STEP) {
                if (FastFallModule.mc.field_1724.method_3144() || FastFallModule.mc.field_1724.method_6128() || FastFallModule.mc.field_1724.method_21754() || FastFallModule.mc.field_1724.method_5771() || FastFallModule.mc.field_1724.method_5799() || FastFallModule.mc.field_1724.field_3913.field_3904 || FastFallModule.mc.field_1724.field_3913.field_3903 || !Managers.ANTICHEAT.hasPassed(1000L)) {
                    return;
                }
                if (SpeedModule.getInstance().isEnabled() || LongJumpModule.getInstance().isEnabled() || FlightModule.getInstance().isEnabled() || PacketFlyModule.getInstance().isEnabled()) {
                    return;
                }
                double fallHeight = this.traceDown();
                if (fallHeight > 0.01 && fallHeight <= (double)this.heightConfig.getValue().floatValue() && FastFallModule.mc.field_1724.method_24828()) {
                    Managers.MOVEMENT.setMotionXZ(FastFallModule.mc.field_1724.method_18798().field_1352 * 0.05, FastFallModule.mc.field_1724.method_18798().field_1350 * 0.05);
                    Managers.MOVEMENT.setMotionY(this.accelerateConfig.getValue() != false ? FastFallModule.mc.field_1724.method_18798().field_1351 - (double)0.62f : -3.0);
                }
            }
        }
    }

    @EventListener
    public void onTickMovement(TickMovementEvent event) {
        if (this.fallModeConfig.getValue() == FallMode.SHIFT) {
            if (FastFallModule.mc.field_1724.method_3144() || FastFallModule.mc.field_1724.method_6128() || FastFallModule.mc.field_1724.method_21754() || FastFallModule.mc.field_1724.method_5771() || FastFallModule.mc.field_1724.method_5799() || FastFallModule.mc.field_1724.field_3913.field_3904 || FastFallModule.mc.field_1724.field_3913.field_3903 || !Managers.ANTICHEAT.hasPassed(1000L)) {
                return;
            }
            if (!Managers.ANTICHEAT.hasPassed(1000L) || !this.fallTimer.passed(1000) || SpeedModule.getInstance().isEnabled() || LongJumpModule.getInstance().isEnabled() || FlightModule.getInstance().isEnabled() || PacketFlyModule.getInstance().isEnabled()) {
                return;
            }
            double fallHeight = this.traceDown();
            if (fallHeight > 0.01 && fallHeight <= (double)this.heightConfig.getValue().floatValue() + 0.01) {
                if (FastFallModule.mc.field_1724.method_24828()) {
                    Managers.MOVEMENT.setMotionXZ(FastFallModule.mc.field_1724.method_18798().field_1352 * 0.05, FastFallModule.mc.field_1724.method_18798().field_1350 * 0.05);
                }
                if (FastFallModule.mc.field_1724.method_18798().field_1351 < 0.0 && this.prevOnGround && !FastFallModule.mc.field_1724.method_24828()) {
                    this.fallTimer.reset();
                    event.cancel();
                    event.setIterations(this.shiftTicksConfig.getValue());
                    this.cancelFallMovement = true;
                    this.fallTicks = 0;
                }
            }
        }
    }

    @EventListener
    public void onPlayerMove(PlayerMoveEvent event) {
        if (FlightModule.getInstance().isEnabled() || PacketFlyModule.getInstance().isEnabled()) {
            return;
        }
        if (this.cancelFallMovement && this.fallModeConfig.getValue() == FallMode.SHIFT) {
            event.setX(0.0);
            event.setZ(0.0);
            Managers.MOVEMENT.setMotionXZ(0.0, 0.0);
            ++this.fallTicks;
            if (this.fallTicks > this.shiftTicksConfig.getValue()) {
                this.cancelFallMovement = false;
                this.fallTicks = 0;
            }
        }
    }

    private double traceDown() {
        class_238 bb = FastFallModule.mc.field_1724.method_5829();
        for (double i = 0.0; i < (double)this.heightConfig.getValue().floatValue() + 0.5; i += 0.01) {
            if (FastFallModule.mc.field_1687.method_8587((class_1297)FastFallModule.mc.field_1724, bb.method_989(0.0, -i, 0.0))) continue;
            return i;
        }
        return -1.0;
    }

    public static enum FallMode {
        STEP,
        SHIFT;

    }
}
