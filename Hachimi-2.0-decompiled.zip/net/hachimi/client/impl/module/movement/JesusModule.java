package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.entity.player.PlayerJumpEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.network.PlayerUpdateEvent;
import net.hachimi.client.impl.event.world.BlockCollisionEvent;
import net.hachimi.client.impl.module.exploit.PacketFlyModule;
import net.hachimi.client.impl.module.movement.FlightModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.mixin.accessor.AccessorKeyBinding;
import net.hachimi.client.mixin.accessor.AccessorPlayerMoveC2SPacket;
import net.hachimi.client.util.string.EnumFormatter;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2404;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_304;
import net.minecraft.class_3532;
import net.minecraft.class_3612;
import net.minecraft.class_3675;

public class JesusModule
extends ToggleModule {
    Config<JesusMode> modeConfig = this.register(new EnumConfig("Mode", "The mode for walking on water", (Enum)JesusMode.SOLID, (Enum[])JesusMode.values()));
    Config<Boolean> strictConfig = this.register(new BooleanConfig("Strict", "NCP Updated bypass for floating offsets", false, () -> this.modeConfig.getValue() == JesusMode.SOLID));
    private int floatTimer = 1000;
    private boolean fluidState;
    private double floatOffset;

    public JesusModule() {
        super("Jesus", "Allow player to walk on water", ModuleCategory.MOVEMENT);
    }

    @Override
    public String getModuleData() {
        return EnumFormatter.formatEnum(this.modeConfig.getValue());
    }

    @Override
    public void onDisable() {
        this.floatOffset = 0.0;
        this.floatTimer = 1000;
        class_304.method_1416((class_3675.class_306)((AccessorKeyBinding)JesusModule.mc.field_1690.field_1903).getBoundKey(), (boolean)false);
    }

    @EventListener
    public void onBlockCollision(BlockCollisionEvent event) {
        class_2680 state = event.getState();
        if (FlightModule.getInstance().isEnabled() || PacketFlyModule.getInstance().isEnabled() || JesusModule.mc.field_1724.method_7325() || JesusModule.mc.field_1724.method_5809() || state.method_26227().method_15769()) {
            return;
        }
        if (this.modeConfig.getValue() != JesusMode.DOLPHIN && state.method_26227().method_15771() && (state.method_26204() == class_2246.field_10382 || state.method_26227().method_15772() == class_3612.field_15910 || state.method_26204() == class_2246.field_10164)) {
            event.cancel();
            event.setVoxelShape(class_259.method_1078((class_238)new class_238(0.0, 0.0, 0.0, 1.0, 0.99, 1.0)));
            if (JesusModule.mc.field_1724.method_5854() != null) {
                event.setVoxelShape(class_259.method_1078((class_238)new class_238(0.0, 0.0, 0.0, 1.0, (double)0.95f, 1.0)));
            } else if (this.modeConfig.getValue() == JesusMode.TRAMPOLINE) {
                event.setVoxelShape(class_259.method_1078((class_238)new class_238(0.0, 0.0, 0.0, 1.0, 0.96, 1.0)));
            }
        }
    }

    @EventListener
    public void onPlayerJump(PlayerJumpEvent event) {
        if (!this.isInFluid() && this.isOnFluid()) {
            event.cancel();
        }
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == StageEvent.EventStage.PRE) {
            if (FlightModule.getInstance().isEnabled() || PacketFlyModule.getInstance().isEnabled()) {
                return;
            }
            if (this.modeConfig.getValue() == JesusMode.SOLID) {
                if (this.isInFluid() || JesusModule.mc.field_1724.field_6017 > 3.0f || JesusModule.mc.field_1724.method_5715()) {
                    // empty if block
                }
                if (!JesusModule.mc.field_1690.field_1832.method_1434() && !JesusModule.mc.field_1690.field_1903.method_1434()) {
                    if (this.isInFluid()) {
                        this.floatTimer = 0;
                        Managers.MOVEMENT.setMotionY(0.11);
                        return;
                    }
                    if (this.floatTimer == 0) {
                        Managers.MOVEMENT.setMotionY(0.3);
                    } else if (this.floatTimer == 1) {
                        Managers.MOVEMENT.setMotionY(0.0);
                    }
                    ++this.floatTimer;
                }
            } else if (this.modeConfig.getValue() == JesusMode.DOLPHIN && this.isInFluid() && !JesusModule.mc.field_1690.field_1832.method_1434() && !JesusModule.mc.field_1690.field_1903.method_1434()) {
                class_304.method_1416((class_3675.class_306)((AccessorKeyBinding)JesusModule.mc.field_1690.field_1903).getBoundKey(), (boolean)true);
            }
        }
    }

    @EventListener
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (FlightModule.getInstance().isEnabled() || PacketFlyModule.getInstance().isEnabled()) {
            return;
        }
        if (event.getStage() == StageEvent.EventStage.PRE && this.modeConfig.getValue() == JesusMode.TRAMPOLINE) {
            boolean inFluid;
            boolean bl = inFluid = this.getFluidBlockInBB(JesusModule.mc.field_1724.method_5829()) != null;
            if (inFluid && !JesusModule.mc.field_1724.method_5715()) {
                JesusModule.mc.field_1724.method_24830(false);
            }
            class_2248 block = JesusModule.mc.field_1687.method_8320(new class_2338((int)Math.floor(JesusModule.mc.field_1724.method_23317()), (int)Math.floor(JesusModule.mc.field_1724.method_23318()), (int)Math.floor(JesusModule.mc.field_1724.method_23321()))).method_26204();
            if (this.fluidState && !JesusModule.mc.field_1724.method_31549().field_7479 && !JesusModule.mc.field_1724.method_5799()) {
                if (JesusModule.mc.field_1724.method_18798().field_1351 < -0.3 || JesusModule.mc.field_1724.method_24828() || JesusModule.mc.field_1724.method_21754()) {
                    this.fluidState = false;
                    return;
                }
                Managers.MOVEMENT.setMotionY(JesusModule.mc.field_1724.method_18798().field_1351 / (double)0.98f + 0.08);
                Managers.MOVEMENT.setMotionY(JesusModule.mc.field_1724.method_18798().field_1351 - 0.03120000000005);
            }
            if (this.isInFluid()) {
                Managers.MOVEMENT.setMotionY(0.1);
                this.fluidState = false;
                return;
            }
            if (!this.isInFluid() && block instanceof class_2404 && JesusModule.mc.field_1724.method_18798().field_1351 < 0.2) {
                Managers.MOVEMENT.setMotionY(this.strictConfig.getValue() != false ? 0.184 : 0.5);
                this.fluidState = true;
            }
        }
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Outbound event) {
        class_2828 packet;
        if (event.isClientPacket() || JesusModule.mc.field_1724 == null || mc.method_1562() == null || JesusModule.mc.field_1724.field_6012 <= 20 || FlightModule.getInstance().isEnabled() || PacketFlyModule.getInstance().isEnabled()) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2828 && (packet = (class_2828)class_25962).method_36171() && this.modeConfig.getValue() == JesusMode.SOLID && !this.isInFluid() && this.isOnFluid() && JesusModule.mc.field_1724.field_6017 <= 3.0f) {
            double y = packet.method_12268(JesusModule.mc.field_1724.method_23318());
            if (!this.strictConfig.getValue().booleanValue()) {
                this.floatOffset = JesusModule.mc.field_1724.field_6012 % 2 == 0 ? 0.0 : 0.05;
            }
            ((AccessorPlayerMoveC2SPacket)packet).hookSetY(y - this.floatOffset);
            if (this.strictConfig.getValue().booleanValue()) {
                this.floatOffset += 0.12;
                if (this.floatOffset > 0.4) {
                    this.floatOffset = 0.2;
                }
            }
        }
    }

    public boolean isInFluid() {
        return JesusModule.mc.field_1724.method_5799() || JesusModule.mc.field_1724.method_5771();
    }

    public class_2680 getFluidBlockInBB(class_238 box) {
        return this.getFluidBlockInBB(class_3532.method_15357((double)(box.field_1322 - 0.2)));
    }

    public class_2680 getFluidBlockInBB(int minY) {
        for (int i = class_3532.method_15357((double)JesusModule.mc.field_1724.method_5829().field_1323); i < class_3532.method_15384((double)JesusModule.mc.field_1724.method_5829().field_1320); ++i) {
            for (int j = class_3532.method_15357((double)JesusModule.mc.field_1724.method_5829().field_1321); j < class_3532.method_15384((double)JesusModule.mc.field_1724.method_5829().field_1324); ++j) {
                class_2680 state = JesusModule.mc.field_1687.method_8320(new class_2338(i, minY, j));
                if (!(state.method_26204() instanceof class_2404) || !state.method_26227().method_15771()) continue;
                return state;
            }
        }
        return null;
    }

    public boolean isOnFluid() {
        if (JesusModule.mc.field_1724.field_6017 >= 3.0f) {
            return false;
        }
        class_238 bb = JesusModule.mc.field_1724.method_5854() != null ? JesusModule.mc.field_1724.method_5854().method_5829().method_35580(0.0, 0.0, 0.0).method_989(0.0, (double)-0.05f, 0.0) : JesusModule.mc.field_1724.method_5829().method_35580(0.0, 0.0, 0.0).method_989(0.0, (double)-0.05f, 0.0);
        boolean onLiquid = false;
        int y = (int)bb.field_1322;
        for (int x = class_3532.method_15357((double)bb.field_1323); x < class_3532.method_15357((double)(bb.field_1320 + 1.0)); ++x) {
            for (int z = class_3532.method_15357((double)bb.field_1321); z < class_3532.method_15357((double)(bb.field_1324 + 1.0)); ++z) {
                class_2680 block = JesusModule.mc.field_1687.method_8320(new class_2338(x, y, z));
                if (block.method_26204() == class_2246.field_10124) continue;
                if (block.method_26204() instanceof class_2404 && block.method_26227().method_15771()) {
                    return false;
                }
                onLiquid = true;
            }
        }
        return onLiquid;
    }

    public static enum JesusMode {
        SOLID,
        DOLPHIN,
        TRAMPOLINE;

    }
}
