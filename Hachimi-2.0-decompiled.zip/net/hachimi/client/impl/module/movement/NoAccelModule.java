package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.entity.player.PlayerMoveEvent;
import net.hachimi.client.impl.module.movement.FlightModule;
import net.hachimi.client.impl.module.movement.SpeedModule;
import net.hachimi.client.util.player.MovementUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1294;
import net.minecraft.class_241;

public class NoAccelModule
extends ToggleModule {
    Config<Boolean> airConfig = this.register(new BooleanConfig("Air", "Removes acceleration while in the air", true));
    Config<Boolean> downwardsConfig = this.register(new BooleanConfig("Downwards", "Removes acceleration while descending", true));

    public NoAccelModule() {
        super("NoAccel", "Removes sprint acceleration", ModuleCategory.MOVEMENT);
    }

    @EventListener
    public void onPlayerMove(PlayerMoveEvent event) {
        double amplifier;
        if (SpeedModule.getInstance().isEnabled() || FlightModule.getInstance().isEnabled()) {
            return;
        }
        if (!NoAccelModule.mc.field_1724.method_24828() && this.airConfig.getValue() == false || NoAccelModule.mc.field_1724.method_18798().field_1351 < 0.0 && this.downwardsConfig.getValue() == false || !MovementUtil.isInputtingMovement()) {
            return;
        }
        double speedEffect = 1.0;
        double slowEffect = 1.0;
        if (NoAccelModule.mc.field_1724.method_6059(class_1294.field_5904)) {
            amplifier = NoAccelModule.mc.field_1724.method_6112(class_1294.field_5904).method_5578();
            speedEffect = 1.0 + 0.2 * (amplifier + 1.0);
        }
        if (NoAccelModule.mc.field_1724.method_6059(class_1294.field_5909)) {
            amplifier = NoAccelModule.mc.field_1724.method_6112(class_1294.field_5909).method_5578();
            slowEffect = 1.0 + 0.2 * (amplifier + 1.0);
        }
        double base = (double)0.2873f * speedEffect / slowEffect;
        class_241 motion = SpeedModule.getInstance().handleVanillaMotion((float)base);
        event.cancel();
        event.setX(motion.field_1343);
        event.setZ(motion.field_1342);
    }
}
