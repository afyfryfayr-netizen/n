package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.config.ConfigUpdateEvent;
import net.hachimi.client.impl.event.entity.player.PlayerMoveEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.module.exploit.DisablerModule;
import net.hachimi.client.impl.module.misc.TimerModule;
import net.hachimi.client.impl.module.movement.FlightModule;
import net.hachimi.client.impl.module.movement.LongJumpModule;
import net.hachimi.client.impl.module.player.FreecamModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.FakePlayerEntity;
import net.hachimi.client.util.math.MathUtil;
import net.hachimi.client.util.player.MovementUtil;
import net.hachimi.client.util.string.EnumFormatter;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1531;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_3532;

public class SpeedModule
extends ToggleModule {
    private static SpeedModule INSTANCE;
    Config<Speed> speedModeConfig = this.register(new EnumConfig("Mode", "Speed mode", (Enum)Speed.STRAFE, (Enum[])Speed.values()));
    Config<Float> collisionDistanceConfig = this.register(new NumberConfig<Float>("CollisionDistance", "The distance to apply collision speed", Float.valueOf(0.5f), Float.valueOf(1.5f), Float.valueOf(2.0f), () -> this.speedModeConfig.getValue() == Speed.GRIM_COLLIDE));
    Config<Float> speedConfig = this.register(new NumberConfig<Float>("Speed", "The speed for alternative modes", Float.valueOf(0.1f), Float.valueOf(4.0f), Float.valueOf(50.0f), () -> this.speedModeConfig.getValue() == Speed.VANILLA));
    Config<Boolean> timerConfig = this.register(new BooleanConfig("UseTimer", "Uses timer to increase acceleration", false, () -> this.isStrafe()));
    Config<Boolean> fastConfig = this.register(new BooleanConfig("Fast", "Fast timer speed", false, () -> this.speedModeConfig.getValue() == Speed.STRAFE_STRICT && this.timerConfig.getValue() != false));
    Config<Boolean> strafeBoostConfig = this.register(new BooleanConfig("StrafeBoost", "Uses explosion velocity to boost Strafe", false, () -> this.isStrafe()));
    Config<Integer> boostTicksConfig = this.register(new NumberConfig<Integer>("BoostTicks", "The number of ticks to boost strafe", Integer.valueOf(10), Integer.valueOf(20), Integer.valueOf(40), () -> this.isStrafe() && this.strafeBoostConfig.getValue() != false));
    Config<Boolean> speedWaterConfig = this.register(new BooleanConfig("SpeedInWater", "Applies speed even in water and lava", false));
    private int strafe = 4;
    private boolean accel;
    private int strictTicks;
    private int strictFastTicks;
    private int boostTicks;
    private double speed;
    private double boostSpeed;
    private double distance;
    private boolean prevTimer;
    private static final float FRICTION = 159.077f;

    public SpeedModule() {
        super("Speed", "Move faster", ModuleCategory.MOVEMENT);
        INSTANCE = this;
    }

    public static SpeedModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        if (this.speedModeConfig.getValue() == Speed.GRIM_COLLIDE) {
            return "Grim";
        }
        return EnumFormatter.formatEnum(this.speedModeConfig.getValue());
    }

    @Override
    public void onEnable() {
        this.prevTimer = TimerModule.getInstance().isEnabled();
        if (this.timerConfig.getValue().booleanValue() && !this.prevTimer && this.isStrafe()) {
            TimerModule.getInstance().enable();
        }
    }

    @Override
    public void onDisable() {
        this.resetStrafe();
        if (TimerModule.getInstance().isEnabled()) {
            TimerModule.getInstance().resetTimer();
            if (!this.prevTimer) {
                TimerModule.getInstance().disable();
            }
        }
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == StageEvent.EventStage.PRE) {
            ++this.boostTicks;
            if (this.boostTicks > this.boostTicksConfig.getValue()) {
                this.boostSpeed = 0.0;
            }
            double dx = SpeedModule.mc.field_1724.method_23317() - SpeedModule.mc.field_1724.field_6014;
            double dz = SpeedModule.mc.field_1724.method_23321() - SpeedModule.mc.field_1724.field_5969;
            this.distance = Math.sqrt(dx * dx + dz * dz);
            if (this.speedModeConfig.getValue() == Speed.GRIM_COLLIDE && MovementUtil.isInputtingMovement()) {
                int collisions = 0;
                for (class_1297 entity : SpeedModule.mc.field_1687.method_18112()) {
                    if (!this.checkIsCollidingEntity(entity) || !(class_3532.method_15355((float)((float)SpeedModule.mc.field_1724.method_5858(entity))) <= this.collisionDistanceConfig.getValue().floatValue())) continue;
                    ++collisions;
                }
                if (collisions > 0) {
                    class_243 velocity = SpeedModule.mc.field_1724.method_18798();
                    double factor = 0.08 * (double)collisions;
                    class_241 strafe = this.handleStrafeMotion((float)factor);
                    SpeedModule.mc.field_1724.method_18800(velocity.field_1352 + (double)strafe.field_1343, velocity.field_1351, velocity.field_1350 + (double)strafe.field_1342);
                }
            }
        }
    }

    @EventListener
    public void onPlayerMove(PlayerMoveEvent event) {
        if (SpeedModule.mc.field_1724 != null && SpeedModule.mc.field_1687 != null && event.getType() == class_1313.field_6308) {
            double amplifier;
            if (!MovementUtil.isInputtingMovement() || FlightModule.getInstance().isEnabled() || LongJumpModule.getInstance().isEnabled() || DisablerModule.getInstance().grimFireworkCheck() || FreecamModule.getInstance().isEnabled() && !FreecamModule.getInstance().control || SpeedModule.mc.field_1724.method_31549().field_7479 || SpeedModule.mc.field_1724.method_3144() || SpeedModule.mc.field_1724.method_6128() || SpeedModule.mc.field_1724.method_21754() || SpeedModule.mc.field_1724.field_6017 > 2.0f || (SpeedModule.mc.field_1724.method_5771() || SpeedModule.mc.field_1724.method_5799()) && !this.speedWaterConfig.getValue().booleanValue()) {
                this.resetStrafe();
                TimerModule.getInstance().setTimer(1.0f);
                return;
            }
            event.cancel();
            double speedEffect = 1.0;
            double slowEffect = 1.0;
            if (SpeedModule.mc.field_1724.method_6059(class_1294.field_5904)) {
                amplifier = SpeedModule.mc.field_1724.method_6112(class_1294.field_5904).method_5578();
                speedEffect = 1.0 + 0.2 * (amplifier + 1.0);
            }
            if (SpeedModule.mc.field_1724.method_6059(class_1294.field_5909)) {
                amplifier = SpeedModule.mc.field_1724.method_6112(class_1294.field_5909).method_5578();
                slowEffect = 1.0 + 0.2 * (amplifier + 1.0);
            }
            double base = (double)0.2873f * speedEffect / slowEffect;
            float jumpEffect = 0.0f;
            if (SpeedModule.mc.field_1724.method_6059(class_1294.field_5913)) {
                jumpEffect += (float)(SpeedModule.mc.field_1724.method_6112(class_1294.field_5913).method_5578() + 1) * 0.1f;
            }
            if (this.speedModeConfig.getValue() == Speed.STRAFE || this.speedModeConfig.getValue() == Speed.STRAFE_B_HOP) {
                if (!Managers.ANTICHEAT.hasPassed(100L)) {
                    return;
                }
                if (this.timerConfig.getValue().booleanValue()) {
                    TimerModule.getInstance().setTimer(1.0888f);
                }
                if (this.strafe == 1) {
                    this.speed = (double)1.35f * base - (double)0.01f;
                } else if (this.strafe == 2) {
                    if (SpeedModule.mc.field_1724.field_3913.field_3904 || !SpeedModule.mc.field_1724.method_24828()) {
                        return;
                    }
                    float jump = (this.speedModeConfig.getValue() == Speed.STRAFE_B_HOP ? 0.4f : 0.39999995f) + jumpEffect;
                    event.setY(jump);
                    Managers.MOVEMENT.setMotionY(jump);
                    this.speed *= this.speedModeConfig.getValue() == Speed.STRAFE_B_HOP ? 1.535 : (this.accel ? 1.6835 : 1.395);
                } else if (this.strafe == 3) {
                    double moveSpeed = 0.66 * (this.distance - base);
                    this.speed = this.distance - moveSpeed;
                    this.accel = !this.accel;
                } else {
                    if ((!SpeedModule.mc.field_1687.method_8587((class_1297)SpeedModule.mc.field_1724, SpeedModule.mc.field_1724.method_5829().method_989(0.0, SpeedModule.mc.field_1724.method_18798().method_10214(), 0.0)) || SpeedModule.mc.field_1724.field_5992) && this.strafe > 0) {
                        this.strafe = MovementUtil.isInputtingMovement() ? 1 : 0;
                    }
                    this.speed = this.distance - this.distance / (double)159.077f;
                }
                this.speed = Math.max(this.speed, base);
                if (this.strafeBoostConfig.getValue().booleanValue()) {
                    this.speed += this.boostSpeed;
                }
                class_241 motion = this.handleStrafeMotion((float)this.speed);
                event.setX(motion.field_1343);
                event.setZ(motion.field_1342);
                ++this.strafe;
            } else if (this.speedModeConfig.getValue() == Speed.STRAFE_STRICT) {
                if (!Managers.ANTICHEAT.hasPassed(100L)) {
                    return;
                }
                if (this.timerConfig.getValue().booleanValue()) {
                    if (this.fastConfig.getValue().booleanValue()) {
                        ++this.strictFastTicks;
                        if (this.strictFastTicks > 10) {
                            this.strictFastTicks = 0;
                        }
                        float res = 1.0f + (float)this.strictFastTicks / 100.0f;
                        TimerModule.getInstance().setTimer(Math.max(1.0f, res));
                    } else {
                        TimerModule.getInstance().setTimer(1.0888f);
                    }
                }
                if (this.strafe == 1) {
                    this.speed = (double)1.35f * base - (double)0.01f;
                } else if (this.strafe == 2) {
                    if (SpeedModule.mc.field_1724.field_3913.field_3904 || !SpeedModule.mc.field_1724.method_24828()) {
                        return;
                    }
                    float jump = 0.39999995f + jumpEffect;
                    event.setY(jump);
                    Managers.MOVEMENT.setMotionY(jump);
                    this.speed *= 2.149;
                } else if (this.strafe == 3) {
                    double moveSpeed = 0.66 * (this.distance - base);
                    this.speed = this.distance - moveSpeed;
                } else {
                    if ((!SpeedModule.mc.field_1687.method_8587((class_1297)SpeedModule.mc.field_1724, SpeedModule.mc.field_1724.method_5829().method_989(0.0, SpeedModule.mc.field_1724.method_18798().method_10214(), 0.0)) || SpeedModule.mc.field_1724.field_5992) && this.strafe > 0) {
                        this.strafe = MovementUtil.isInputtingMovement() ? 1 : 0;
                    }
                    this.speed = this.distance - this.distance / (double)159.077f;
                }
                ++this.strictTicks;
                this.speed = Math.max(this.speed, base);
                if (this.timerConfig.getValue().booleanValue()) {
                    TimerModule.getInstance().setTimer(1.0888f);
                }
                double baseMax = 0.465 * speedEffect / slowEffect;
                double baseMin = 0.44 * speedEffect / slowEffect;
                this.speed = Math.min(this.speed, this.strictTicks > 25 ? baseMax : baseMin);
                if (this.strafeBoostConfig.getValue().booleanValue()) {
                    this.speed += this.boostSpeed;
                }
                if (this.strictTicks > 50) {
                    this.strictTicks = 0;
                }
                class_241 motion = this.handleStrafeMotion((float)this.speed);
                event.setX(motion.field_1343);
                event.setZ(motion.field_1342);
                ++this.strafe;
            } else if (this.speedModeConfig.getValue() == Speed.LOW_HOP) {
                if (!Managers.ANTICHEAT.hasPassed(100L)) {
                    return;
                }
                if (this.timerConfig.getValue().booleanValue()) {
                    TimerModule.getInstance().setTimer(1.0888f);
                }
                if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.4, 3)) {
                    Managers.MOVEMENT.setMotionY(0.31 + (double)jumpEffect);
                    event.setY(0.31 + (double)jumpEffect);
                } else if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.71, 3)) {
                    Managers.MOVEMENT.setMotionY(0.04 + (double)jumpEffect);
                    event.setY(0.04 + (double)jumpEffect);
                } else if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.75, 3)) {
                    Managers.MOVEMENT.setMotionY(-0.2 - (double)jumpEffect);
                    event.setY(-0.2 - (double)jumpEffect);
                } else if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.55, 3)) {
                    Managers.MOVEMENT.setMotionY(-0.14 + (double)jumpEffect);
                    event.setY(-0.14 + (double)jumpEffect);
                } else if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.41, 3)) {
                    Managers.MOVEMENT.setMotionY(-0.2 + (double)jumpEffect);
                    event.setY(-0.2 + (double)jumpEffect);
                }
                if (this.strafe == 1) {
                    this.speed = (double)1.35f * base - (double)0.01f;
                } else if (this.strafe == 2) {
                    double jump = (this.isBoxColliding() ? 0.2 : 0.3999) + (double)jumpEffect;
                    Managers.MOVEMENT.setMotionY(jump);
                    event.setY(jump);
                    this.speed *= this.accel ? 1.5685 : 1.3445;
                } else if (this.strafe == 3) {
                    double moveSpeed = 0.66 * (this.distance - base);
                    this.speed = this.distance - moveSpeed;
                    this.accel = !this.accel;
                } else {
                    if (SpeedModule.mc.field_1724.method_24828() && this.strafe > 0) {
                        this.strafe = MovementUtil.isInputtingMovement() ? 1 : 0;
                    }
                    this.speed = this.distance - this.distance / (double)159.077f;
                }
                this.speed = Math.max(this.speed, base);
                class_241 motion = this.handleVanillaMotion((float)this.speed);
                event.setX(motion.field_1343);
                event.setZ(motion.field_1342);
                ++this.strafe;
            } else if (this.speedModeConfig.getValue() == Speed.GAY_HOP) {
                if (!Managers.ANTICHEAT.hasPassed(100L)) {
                    this.strafe = 1;
                    return;
                }
                if (this.strafe == 1 && SpeedModule.mc.field_1724.field_5992 && MovementUtil.isInputtingMovement()) {
                    this.speed = 1.25 * base - (double)0.01f;
                } else if (this.strafe == 2 && SpeedModule.mc.field_1724.field_5992 && MovementUtil.isInputtingMovement()) {
                    float jump = (this.isBoxColliding() ? 0.2f : 0.4f) + jumpEffect;
                    event.setY(jump);
                    Managers.MOVEMENT.setMotionY(jump);
                    this.speed *= 2.149;
                } else if (this.strafe == 3) {
                    double moveSpeed = 0.66 * (this.distance - base);
                    this.speed = this.distance - moveSpeed;
                } else {
                    if (SpeedModule.mc.field_1724.method_24828() && this.strafe > 0) {
                        this.strafe = 1.35 * base - 0.01 > this.speed ? 0 : (MovementUtil.isInputtingMovement() ? 1 : 0);
                    }
                    this.speed = this.distance - this.distance / (double)159.077f;
                }
                this.speed = Math.max(this.speed, base);
                if (this.strafe > 0) {
                    class_241 motion = this.handleStrafeMotion((float)this.speed);
                    event.setX(motion.field_1343);
                    event.setZ(motion.field_1342);
                }
                ++this.strafe;
            } else if (this.speedModeConfig.getValue() == Speed.V_HOP) {
                if (!Managers.ANTICHEAT.hasPassed(100L)) {
                    this.strafe = 1;
                    return;
                }
                if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.4, 3)) {
                    Managers.MOVEMENT.setMotionY(0.31 + (double)jumpEffect);
                    event.setY(0.31 + (double)jumpEffect);
                } else if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.71, 3)) {
                    Managers.MOVEMENT.setMotionY(0.04 + (double)jumpEffect);
                    event.setY(0.04 + (double)jumpEffect);
                } else if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.75, 3)) {
                    Managers.MOVEMENT.setMotionY(-0.2 - (double)jumpEffect);
                    event.setY(-0.2 - (double)jumpEffect);
                }
                if (!SpeedModule.mc.field_1687.method_8587(null, SpeedModule.mc.field_1724.method_5829().method_989(0.0, -0.56, 0.0)) && MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.55, 3)) {
                    Managers.MOVEMENT.setMotionY(-0.14 + (double)jumpEffect);
                    event.setY(-0.14 + (double)jumpEffect);
                }
                if (this.strafe != 1 || !SpeedModule.mc.field_1724.field_5992 || SpeedModule.mc.field_1724.field_6250 == 0.0f && SpeedModule.mc.field_1724.field_6212 == 0.0f) {
                    if (this.strafe != 2 || !SpeedModule.mc.field_1724.field_5992 || SpeedModule.mc.field_1724.field_6250 == 0.0f && SpeedModule.mc.field_1724.field_6212 == 0.0f) {
                        if (this.strafe == 3) {
                            double moveSpeed = 0.66 * (this.distance - base);
                            this.speed = this.distance - moveSpeed;
                        } else {
                            if (SpeedModule.mc.field_1724.method_24828() && this.strafe > 0) {
                                this.strafe = 1.35 * base - 0.01 > this.speed ? 0 : (MovementUtil.isInputtingMovement() ? 1 : 0);
                            }
                            this.speed = this.distance - this.distance / (double)159.077f;
                        }
                    } else {
                        double jump = (this.isBoxColliding() ? 0.2 : 0.4) + (double)jumpEffect;
                        Managers.MOVEMENT.setMotionY(jump);
                        event.setY(jump);
                        this.speed *= 2.149;
                    }
                } else {
                    this.speed = 2.0 * base - 0.01;
                }
                if (this.strafe > 8) {
                    this.speed = base;
                }
                this.speed = Math.max(this.speed, base);
                class_241 motion = this.handleStrafeMotion((float)this.speed);
                event.setX(motion.field_1343);
                event.setZ(motion.field_1342);
                ++this.strafe;
            } else if (this.speedModeConfig.getValue() == Speed.B_HOP) {
                if (!Managers.ANTICHEAT.hasPassed(100L)) {
                    this.strafe = 4;
                    return;
                }
                if (MathUtil.round(SpeedModule.mc.field_1724.method_23318() - (double)((int)SpeedModule.mc.field_1724.method_23318()), 3) == MathUtil.round(0.138, 3)) {
                    Managers.MOVEMENT.setMotionY(SpeedModule.mc.field_1724.method_18798().field_1351 - (0.08 + (double)jumpEffect));
                    event.setY(event.getY() - (0.0931 + (double)jumpEffect));
                    Managers.POSITION.setPositionY(SpeedModule.mc.field_1724.method_23318() - (0.0931 + (double)jumpEffect));
                }
                if (this.strafe != 2 || SpeedModule.mc.field_1724.field_6250 == 0.0f && SpeedModule.mc.field_1724.field_6212 == 0.0f) {
                    if (this.strafe == 3) {
                        double moveSpeed = 0.66 * (this.distance - base);
                        this.speed = this.distance - moveSpeed;
                    } else {
                        if (SpeedModule.mc.field_1724.method_24828()) {
                            this.strafe = 1;
                        }
                        this.speed = this.distance - this.distance / (double)159.077f;
                    }
                } else {
                    double jump = (this.isBoxColliding() ? 0.2 : 0.4) + (double)jumpEffect;
                    Managers.MOVEMENT.setMotionY(jump);
                    event.setY(jump);
                    this.speed *= 2.149;
                }
                this.speed = Math.max(this.speed, base);
                class_241 motion = this.handleStrafeMotion((float)this.speed);
                event.setX(motion.field_1343);
                event.setZ(motion.field_1342);
                ++this.strafe;
            } else if (this.speedModeConfig.getValue() == Speed.VANILLA) {
                class_241 motion = this.handleStrafeMotion(this.speedConfig.getValue().floatValue() / 10.0f);
                event.setX(motion.field_1343);
                event.setZ(motion.field_1342);
            }
        }
    }

    public class_241 handleStrafeMotion(float speed) {
        float forward = SpeedModule.mc.field_1724.field_3913.field_3905;
        float strafe = SpeedModule.mc.field_1724.field_3913.field_3907;
        float yaw = SpeedModule.mc.field_1724.field_5982 + (SpeedModule.mc.field_1724.method_36454() - SpeedModule.mc.field_1724.field_5982) * mc.method_60646().method_60637(true);
        if (forward == 0.0f && strafe == 0.0f) {
            return class_241.field_1340;
        }
        if (forward != 0.0f) {
            if (strafe >= 1.0f) {
                yaw += forward > 0.0f ? -45.0f : 45.0f;
                strafe = 0.0f;
            } else if (strafe <= -1.0f) {
                yaw += forward > 0.0f ? 45.0f : -45.0f;
                strafe = 0.0f;
            }
            if (forward > 0.0f) {
                forward = 1.0f;
            } else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }
        float rx = (float)Math.cos(Math.toRadians(yaw));
        float rz = (float)(-Math.sin(Math.toRadians(yaw)));
        return new class_241(forward * speed * rz + strafe * speed * rx, forward * speed * rx - strafe * speed * rz);
    }

    public class_241 handleVanillaMotion(float speed) {
        float forward = SpeedModule.mc.field_1724.field_3913.field_3905;
        float strafe = SpeedModule.mc.field_1724.field_3913.field_3907;
        if (forward == 0.0f && strafe == 0.0f) {
            return class_241.field_1340;
        }
        if (forward != 0.0f && strafe != 0.0f) {
            forward *= (float)Math.sin(0.7853981633974483);
            strafe *= (float)Math.cos(0.7853981633974483);
        }
        return new class_241((float)((double)(forward * speed) * -Math.sin(Math.toRadians(SpeedModule.mc.field_1724.method_36454())) + (double)(strafe * speed) * Math.cos(Math.toRadians(SpeedModule.mc.field_1724.method_36454()))), (float)((double)(forward * speed) * Math.cos(Math.toRadians(SpeedModule.mc.field_1724.method_36454())) - (double)(strafe * speed) * -Math.sin(Math.toRadians(SpeedModule.mc.field_1724.method_36454()))));
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (SpeedModule.mc.field_1724 == null || SpeedModule.mc.field_1687 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2664) {
            class_2664 packet = (class_2664)class_25962;
            double x = packet.method_11472();
            double d = packet.method_11474();
        } else {
            class_2743 packet;
            class_2596<?> x = event.getPacket();
            if (x instanceof class_2743 && (packet = (class_2743)x).method_11818() == SpeedModule.mc.field_1724.method_5628()) {
                double x2 = packet.method_11815();
                double d = packet.method_11819();
            } else if (event.getPacket() instanceof class_2708) {
                this.resetStrafe();
            }
        }
    }

    @EventListener
    public void onConfigUpdate(ConfigUpdateEvent event) {
        if (event.getConfig() == this.timerConfig && event.getStage() == StageEvent.EventStage.POST && this.isStrafe()) {
            if (this.timerConfig.getValue().booleanValue()) {
                this.prevTimer = TimerModule.getInstance().isEnabled();
                if (!this.prevTimer) {
                    TimerModule.getInstance().enable();
                }
            } else if (TimerModule.getInstance().isEnabled()) {
                TimerModule.getInstance().resetTimer();
                if (!this.prevTimer) {
                    TimerModule.getInstance().disable();
                }
            }
        }
    }

    public boolean isBoxColliding() {
        return !SpeedModule.mc.field_1687.method_8587((class_1297)SpeedModule.mc.field_1724, SpeedModule.mc.field_1724.method_5829().method_989(0.0, 0.21, 0.0));
    }

    public boolean checkIsCollidingEntity(class_1297 entity) {
        return entity != null && entity != SpeedModule.mc.field_1724 && entity instanceof class_1309 && !(entity instanceof FakePlayerEntity) && !(entity instanceof class_1531);
    }

    public void setPrevTimer() {
        this.prevTimer = !this.prevTimer;
    }

    public boolean isUsingTimer() {
        return this.isEnabled() && this.timerConfig.getValue() != false;
    }

    public void resetStrafe() {
        this.strafe = 4;
        this.strictTicks = 0;
        this.strictFastTicks = 0;
        this.speed = 0.0;
        this.distance = 0.0;
        this.accel = false;
    }

    public boolean isStrafe() {
        return this.speedModeConfig.getValue() != Speed.GRIM_COLLIDE && this.speedModeConfig.getValue() != Speed.VANILLA;
    }

    private static enum Speed {
        STRAFE,
        STRAFE_STRICT,
        STRAFE_B_HOP,
        LOW_HOP,
        GAY_HOP,
        V_HOP,
        B_HOP,
        VANILLA,
        GRIM_COLLIDE;

    }
}
