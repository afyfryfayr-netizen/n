package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.mixin.accessor.AccessorFireworkRocketEntity;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public final class FireworkBoostModule
extends ToggleModule {
    Config<Double> speedConfig = this.register(new NumberConfig<Double>("Speed", "The initial speed of the rocket.", 1.0, 1.5, 10.0));
    Config<Boolean> accelerateConfig = this.register(new BooleanConfig("Accelerate", "Whether or not to accelerate the rocket.", false));
    Config<Double> accelSpeedConfig = this.register(new NumberConfig<Double>("AccelSpeed", "The speed to accelerate the rocket at.", Double.valueOf(0.1), Double.valueOf(0.5), Double.valueOf(5.0), () -> this.accelerateConfig.getValue()));
    Config<Double> maxSpeedConfig = this.register(new NumberConfig<Double>("MaxSpeed", "The initial speed of the rocket.", Double.valueOf(1.0), Double.valueOf(3.0), Double.valueOf(10.0), () -> this.accelerateConfig.getValue()));
    private int tickCounter;
    private double speed;

    public FireworkBoostModule() {
        super("FireworkBoost", "Allows you to change the acceleration of your firework.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onDisable() {
        this.speed = 0.0;
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE || FireworkBoostModule.mc.field_1724.method_5771()) {
            return;
        }
        if (this.isBoostedByRocket() && FireworkBoostModule.mc.field_1724.method_6128()) {
            class_243 vec3d = FireworkBoostModule.mc.field_1724.method_5720();
            class_243 vec3d2 = FireworkBoostModule.mc.field_1724.method_18798();
            if (this.accelerateConfig.getValue().booleanValue()) {
                this.speed += this.accelSpeedConfig.getValue() * (double)this.tickCounter;
                if (this.speed < this.maxSpeedConfig.getValue()) {
                    ++this.tickCounter;
                } else {
                    this.speed = class_3532.method_15350((double)this.speed, (double)0.0, (double)this.maxSpeedConfig.getValue());
                }
            } else {
                this.speed = this.speedConfig.getValue();
            }
            FireworkBoostModule.mc.field_1724.method_18799(vec3d2.method_1031(vec3d.field_1352 * 0.1 + (vec3d.field_1352 * this.speed - vec3d2.field_1352) * 0.5, vec3d.field_1351 * 0.1 + (vec3d.field_1351 * this.speed - vec3d2.field_1351) * 0.5, vec3d.field_1350 * 0.1 + (vec3d.field_1350 * this.speed - vec3d2.field_1350) * 0.5));
        } else {
            this.speed = 0.0;
        }
    }

    private boolean isBoostedByRocket() {
        for (class_1297 entity : FireworkBoostModule.mc.field_1687.method_18112()) {
            class_1671 rocket;
            if (!(entity instanceof class_1671) || !((AccessorFireworkRocketEntity)(rocket = (class_1671)entity)).hookWasShotByEntity() || ((AccessorFireworkRocketEntity)rocket).hookGetShooter() != FireworkBoostModule.mc.field_1724) continue;
            return true;
        }
        return false;
    }
}
