package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.entity.player.TravelEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.RotationModule;
import net.hachimi.client.impl.module.movement.ElytraFlyModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.RotationUtil;
import net.hachimi.client.util.world.BlockUtilPlus;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1770;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_3532;

public class FollowerModule
extends RotationModule {
    private static FollowerModule INSTANCE;
    private static final long RETURN_TIME_MS = 300L;
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "Range to search for a target to follow", Float.valueOf(0.0f), Float.valueOf(60.0f), Float.valueOf(128.0f)));
    Config<SortPriority> sortPriorityConfig = this.register(new EnumConfig("SortPriority", "How to pick the best target among candidates in range", (Enum)SortPriority.ClosestAngle, (Enum[])SortPriority.values()));
    Config<Boolean> friendConfig = this.register(new BooleanConfig("Friend", "Allows following players on the friend list", false));
    Config<Boolean> onlyFlyingConfig = this.register(new BooleanConfig("OnlyFlying", "Only follow while ElytraFly is enabled and an elytra is equipped", true));
    private class_1297 target;
    private float yaw;
    private float pitch;
    private boolean canFollow = false;
    private final Timer returnTimer = new CacheTimer();

    public FollowerModule() {
        super("Follower", "Automatically flies towards and dive-attacks the nearest enemy using ElytraFly", ModuleCategory.MOVEMENT);
        INSTANCE = this;
    }

    public static FollowerModule getInstance() {
        return INSTANCE;
    }

    public boolean canFollow() {
        return this.canFollow;
    }

    @Override
    public String getModuleData() {
        return this.target != null ? this.target.method_5477().getString() : null;
    }

    @Override
    public void onEnable() {
        this.returnTimer.setElapsedTime(9999999);
    }

    @EventListener
    public void onTravel(TravelEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (ElytraFlyModule.getInstance() == null || !ElytraFlyModule.getInstance().getFallFlying() || !this.canFollow) {
            return;
        }
        class_243 v = FollowerModule.mc.field_1724.method_18798();
        double speed = v.method_1033();
        if (speed < 0.01) {
            return;
        }
        double radYaw = Math.toRadians(this.yaw);
        double radPitch = Math.toRadians(this.pitch);
        double x = -Math.sin(radYaw) * Math.cos(radPitch) * speed;
        double y = -Math.sin(radPitch) * speed;
        double z = Math.cos(radYaw) * Math.cos(radPitch) * speed;
        FollowerModule.mc.field_1724.method_18800(x, y, z);
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (FollowerModule.mc.field_1724 == null || FollowerModule.mc.field_1687 == null) {
            return;
        }
        if (this.onlyFlyingConfig.getValue().booleanValue() && !this.elytraFlyActiveAndEquipped()) {
            this.canFollow = false;
            return;
        }
        this.target = this.findTarget();
        if (this.target == null) {
            this.canFollow = false;
            return;
        }
        if (this.wantToMove()) {
            this.canFollow = false;
            return;
        }
        this.canFollow = true;
        double myY = FollowerModule.mc.field_1724.method_23318();
        double targetY = this.target.method_23318();
        boolean shouldReturn = false;
        if (!this.returnTimer.passed(300L)) {
            shouldReturn = true;
        }
        if (myY <= targetY) {
            this.returnTimer.reset();
            shouldReturn = true;
        }
        if (FollowerModule.mc.field_1724.method_24828()) {
            FollowerModule.mc.field_1724.method_6043();
            shouldReturn = true;
            this.returnTimer.reset();
        }
        float[] rot = RotationUtil.getRotationsTo(FollowerModule.mc.field_1724.method_33571(), this.getAttackVec(this.target));
        this.pitch = shouldReturn ? -90.0f : rot[1];
        this.yaw = rot[0];
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2830(FollowerModule.mc.field_1724.method_23317(), FollowerModule.mc.field_1724.method_23318(), FollowerModule.mc.field_1724.method_23321(), this.yaw, this.pitch, FollowerModule.mc.field_1724.method_24828()));
    }

    private boolean elytraFlyActiveAndEquipped() {
        ElytraFlyModule ef = ElytraFlyModule.getInstance();
        if (ef == null || !ef.isEnabled()) {
            return false;
        }
        return FollowerModule.mc.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833 && class_1770.method_7804((class_1799)FollowerModule.mc.field_1724.method_6118(class_1304.field_6174));
    }

    private class_243 getAttackVec(class_1297 entity) {
        return BlockUtilPlus.getClosestPointToBox(FollowerModule.mc.field_1724.method_33571(), entity.method_5829());
    }

    private boolean wantToMove() {
        return FollowerModule.mc.field_1690.field_1894.method_1434() || FollowerModule.mc.field_1690.field_1881.method_1434() || FollowerModule.mc.field_1690.field_1913.method_1434() || FollowerModule.mc.field_1690.field_1849.method_1434();
    }

    private class_1297 findTarget() {
        double range = this.rangeConfig.getValue().floatValue();
        class_1297 best = null;
        block5: for (class_1297 entity : FollowerModule.mc.field_1687.method_18456()) {
            if (entity == FollowerModule.mc.field_1724 || !entity.method_5805() || !this.friendConfig.getValue().booleanValue() && Managers.SOCIAL.isFriend(entity.method_5477()) || (double)FollowerModule.mc.field_1724.method_5739(entity) > range) continue;
            if (best == null) {
                best = entity;
                continue;
            }
            double dist = FollowerModule.mc.field_1724.method_5739(entity);
            double bestDist = FollowerModule.mc.field_1724.method_5739(best);
            switch (this.sortPriorityConfig.getValue().ordinal()) {
                case 0: {
                    float bestAngle;
                    float[] rots = RotationUtil.getRotationsTo(FollowerModule.mc.field_1724.method_19538(), entity.method_19538());
                    float[] bestRots = RotationUtil.getRotationsTo(FollowerModule.mc.field_1724.method_19538(), best.method_19538());
                    float angle = Math.abs(class_3532.method_15393((float)(FollowerModule.mc.field_1724.method_36454() - rots[0])));
                    if (!(angle < (bestAngle = Math.abs(class_3532.method_15393((float)(FollowerModule.mc.field_1724.method_36454() - bestRots[0])))))) continue block5;
                    best = entity;
                    break;
                }
                case 1: {
                    if (!(dist < bestDist)) break;
                    best = entity;
                    break;
                }
                case 2: {
                    float hp = EntityUtil.getHealth(entity);
                    float bestHp = EntityUtil.getHealth(best);
                    if (!(hp < bestHp) && (hp != bestHp || !(dist < bestDist))) break;
                    best = entity;
                }
            }
        }
        return best;
    }

    public static enum SortPriority {
        ClosestAngle,
        LowestDistance,
        LowestHealth;

    }
}
