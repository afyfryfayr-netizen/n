package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.exploit.DisablerModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.mixin.accessor.AccessorPlayerMoveC2SPacket;
import net.hachimi.client.util.player.MovementUtil;
import net.hachimi.client.util.string.EnumFormatter;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_4970;

public class FlightModule
extends ToggleModule {
    private static FlightModule INSTANCE;
    Config<FlightMode> modeConfig = this.register(new EnumConfig("Mode", "The mode for vanilla flight", (Enum)FlightMode.NORMAL, (Enum[])FlightMode.values()));
    Config<Float> speedConfig = this.register(new NumberConfig<Float>("Speed", "The horizontal flight speed", Float.valueOf(0.1f), Float.valueOf(2.5f), Float.valueOf(10.0f)));
    Config<Float> vspeedConfig = this.register(new NumberConfig<Float>("VerticalSpeed", "The vertical flight speed", Float.valueOf(0.1f), Float.valueOf(1.0f), Float.valueOf(5.0f)));
    Config<AntiKick> antiKickConfig = this.register(new EnumConfig("AntiKick", "Prevents vanilla flight detection", (Enum)AntiKick.NORMAL, (Enum[])AntiKick.values()));
    Config<Boolean> accelerateConfig = this.register(new BooleanConfig("Accelerate", "Accelerate as you fly", false));
    Config<Float> accelerateSpeedConfig = this.register(new NumberConfig<Float>("AccelerateSpeed", "Speed to accelerate as", Float.valueOf(0.01f), Float.valueOf(0.2f), Float.valueOf(1.0f), () -> this.accelerateConfig.getValue()));
    Config<Float> maxSpeedConfig = this.register(new NumberConfig<Float>("MaxSpeed", "Max speed to acceleratee to", Float.valueOf(1.0f), Float.valueOf(5.0f), Float.valueOf(10.0f), () -> this.accelerateConfig.getValue()));
    private double speed;
    private double lastY;
    private boolean floating;
    private int floatingTicks;
    private boolean modifyY;

    public FlightModule() {
        super("Flight", "Allows the player to fly in survival", ModuleCategory.MOVEMENT);
        INSTANCE = this;
    }

    public static FlightModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        return EnumFormatter.formatEnum(this.modeConfig.getValue());
    }

    @Override
    public void onEnable() {
        if (this.modeConfig.getValue() == FlightMode.VANILLA) {
            this.enableVanillaFly();
        }
        this.speed = 0.0;
    }

    @Override
    public void onDisable() {
        if (this.modeConfig.getValue() == FlightMode.VANILLA) {
            this.disableVanillaFly();
        }
        this.modifyY = false;
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (this.accelerateConfig.getValue().booleanValue()) {
            if (!MovementUtil.isInputtingMovement() || FlightModule.mc.field_1724.field_5976) {
                this.speed = 0.0;
            }
            this.speed += (double)this.accelerateSpeedConfig.getValue().floatValue();
            if (this.speed > (double)this.maxSpeedConfig.getValue().floatValue()) {
                this.speed = this.maxSpeedConfig.getValue().floatValue();
            }
        } else {
            this.speed = this.speedConfig.getValue().floatValue();
        }
        if (DisablerModule.getInstance().grimFireworkCheck()) {
            if (this.modeConfig.getValue() == FlightMode.VANILLA) {
                this.disableVanillaFly();
            }
            return;
        }
        if (this.modeConfig.getValue().equals((Object)FlightMode.VANILLA)) {
            this.enableVanillaFly();
            FlightModule.mc.field_1724.method_31549().method_7248((float)(this.speed * (double)0.05f));
        } else {
            this.disableVanillaFly();
        }
        boolean stopVerticalMovement = false;
        if (this.floating) {
            ++this.floatingTicks;
            if (this.floatingTicks >= 20) {
                if (this.antiKickConfig.getValue() == AntiKick.PACKET) {
                    this.modifyY = true;
                } else if (this.antiKickConfig.getValue() == AntiKick.NORMAL) {
                    FlightModule.mc.field_1724.method_5814(FlightModule.mc.field_1724.method_23317(), FlightModule.mc.field_1724.method_23318() - 0.0313, FlightModule.mc.field_1724.method_23321());
                    if (this.modeConfig.getValue() == FlightMode.VANILLA) {
                        this.disableVanillaFly();
                        Managers.MOVEMENT.setMotionY(0.0);
                        stopVerticalMovement = true;
                    }
                }
                this.floatingTicks = 0;
                this.floating = false;
            }
        }
        if (this.modeConfig.getValue() == FlightMode.NORMAL) {
            Managers.MOVEMENT.setMotionY(0.0);
            if (FlightModule.mc.field_1690.field_1903.method_1434() && !stopVerticalMovement) {
                Managers.MOVEMENT.setMotionY(this.vspeedConfig.getValue().floatValue());
            } else if (FlightModule.mc.field_1690.field_1832.method_1434()) {
                Managers.MOVEMENT.setMotionY(-this.vspeedConfig.getValue().floatValue());
            }
            this.speed = Math.max(this.speed, (double)0.2873f);
            float forward = FlightModule.mc.field_1724.field_3913.field_3905;
            float strafe = FlightModule.mc.field_1724.field_3913.field_3907;
            float yaw = FlightModule.mc.field_1724.method_36454();
            if (forward == 0.0f && strafe == 0.0f) {
                Managers.MOVEMENT.setMotionXZ(0.0, 0.0);
                return;
            }
            double rx = Math.cos(Math.toRadians(yaw + 90.0f));
            double rz = Math.sin(Math.toRadians(yaw + 90.0f));
            Managers.MOVEMENT.setMotionXZ((double)forward * this.speed * rx + (double)strafe * this.speed * rz, (double)forward * this.speed * rz - (double)strafe * this.speed * rx);
        }
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Outbound event) {
        if (FlightModule.mc.field_1724 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2828) {
            class_2828 packet = (class_2828)class_25962;
            if (this.antiKickConfig.getValue() != AntiKick.OFF) {
                double packetY = packet.method_12268(Double.NaN);
                if (!Double.isNaN(packetY)) {
                    if (this.modifyY) {
                        ((AccessorPlayerMoveC2SPacket)packet).hookSetY(this.lastY - 0.04);
                        this.modifyY = false;
                        return;
                    }
                    this.floating = this.floatingCheck(packet);
                    this.lastY = packetY;
                    return;
                }
                if (this.modifyY) {
                    class_2828.class_2830 packet1 = packet.method_36172() ? new class_2828.class_2830(FlightModule.mc.field_1724.method_23317(), FlightModule.mc.field_1724.method_23318() - 0.04, FlightModule.mc.field_1724.method_23321(), FlightModule.mc.field_1724.method_36454(), FlightModule.mc.field_1724.method_36455(), packet.method_12273()) : new class_2828.class_2829(FlightModule.mc.field_1724.method_23317(), FlightModule.mc.field_1724.method_23318() - 0.04, FlightModule.mc.field_1724.method_23321(), packet.method_12273());
                    event.cancel();
                    Managers.NETWORK.sendQuietPacket((class_2596<?>)packet1);
                    this.modifyY = false;
                }
            }
        }
    }

    private boolean floatingCheck(class_2828 packet) {
        double e = class_3532.method_15350((double)packet.method_12268(FlightModule.mc.field_1724.method_23318()), (double)-2.0E7, (double)2.0E7);
        double s = e - this.lastY;
        return s >= -0.03125 && !FlightModule.mc.field_1724.field_36331 && this.isEntityOnAir((class_1297)FlightModule.mc.field_1724);
    }

    private boolean isEntityOnAir(class_1297 entity) {
        return entity.method_37908().method_29546(entity.method_5829().method_1014(0.0625).method_1012(0.0, -0.55, 0.0)).allMatch(class_4970.class_4971::method_26215);
    }

    private void enableVanillaFly() {
        FlightModule.mc.field_1724.method_31549().field_7478 = true;
        FlightModule.mc.field_1724.method_31549().field_7479 = true;
    }

    private void disableVanillaFly() {
        if (!FlightModule.mc.field_1724.method_7337()) {
            FlightModule.mc.field_1724.method_31549().field_7478 = false;
        }
        FlightModule.mc.field_1724.method_31549().field_7479 = false;
        FlightModule.mc.field_1724.method_31549().method_7248(0.05f);
    }

    public static enum FlightMode {
        NORMAL,
        VANILLA;

    }

    public static enum AntiKick {
        NORMAL,
        PACKET,
        OFF;

    }
}
