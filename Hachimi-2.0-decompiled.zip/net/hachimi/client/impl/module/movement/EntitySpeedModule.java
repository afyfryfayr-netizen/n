package net.hachimi.client.impl.module.movement;

import java.text.DecimalFormat;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2752;
import net.minecraft.class_2824;

public class EntitySpeedModule
extends ToggleModule {
    Config<Float> speedConfig = this.register(new NumberConfig<Float>("Speed", "The speed of the entity while moving", Float.valueOf(0.1f), Float.valueOf(0.5f), Float.valueOf(4.0f)));
    Config<Boolean> antiStuckConfig = this.register(new BooleanConfig("AntiStuck", "Prevents entities from getting stuck when moving up", false));
    Config<Boolean> strictConfig = this.register(new BooleanConfig("Strict", "The NCP-Updated bypass for speeding up entity movement", false));
    private final Timer entityJumpTimer = new CacheTimer();

    public EntitySpeedModule() {
        super("EntitySpeed", "Increases riding entity speeds", ModuleCategory.MOVEMENT);
    }

    @Override
    public String getModuleData() {
        DecimalFormat decimal = new DecimalFormat("0.0");
        return decimal.format(this.speedConfig.getValue());
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (EntitySpeedModule.mc.field_1724.method_3144() && EntitySpeedModule.mc.field_1724.method_49694() != null) {
            double d = Math.cos(Math.toRadians(EntitySpeedModule.mc.field_1724.method_36454() + 90.0f));
            double d2 = Math.sin(Math.toRadians(EntitySpeedModule.mc.field_1724.method_36454() + 90.0f));
            class_2338 pos1 = class_2338.method_49637((double)(EntitySpeedModule.mc.field_1724.method_23317() + 2.0 * d), (double)(EntitySpeedModule.mc.field_1724.method_23318() - 1.0), (double)(EntitySpeedModule.mc.field_1724.method_23321() + 2.0 * d2));
            class_2338 pos2 = class_2338.method_49637((double)(EntitySpeedModule.mc.field_1724.method_23317() + 2.0 * d), (double)(EntitySpeedModule.mc.field_1724.method_23318() - 2.0), (double)(EntitySpeedModule.mc.field_1724.method_23321() + 2.0 * d2));
            if (this.antiStuckConfig.getValue().booleanValue() && !EntitySpeedModule.mc.field_1724.method_49694().method_24828() && !EntitySpeedModule.mc.field_1687.method_8320(pos1).method_51366() && !EntitySpeedModule.mc.field_1687.method_8320(pos2).method_51366()) {
                this.entityJumpTimer.reset();
                return;
            }
            class_2338 pos3 = class_2338.method_49637((double)(EntitySpeedModule.mc.field_1724.method_23317() + 2.0 * d), (double)EntitySpeedModule.mc.field_1724.method_23318(), (double)(EntitySpeedModule.mc.field_1724.method_23321() + 2.0 * d2));
            if (this.antiStuckConfig.getValue().booleanValue() && EntitySpeedModule.mc.field_1687.method_8320(pos3).method_51366()) {
                this.entityJumpTimer.reset();
                return;
            }
            class_2338 pos4 = class_2338.method_49637((double)(EntitySpeedModule.mc.field_1724.method_23317() + d), (double)(EntitySpeedModule.mc.field_1724.method_23318() + 1.0), (double)(EntitySpeedModule.mc.field_1724.method_23321() + d2));
            if (this.antiStuckConfig.getValue().booleanValue() && EntitySpeedModule.mc.field_1687.method_8320(pos4).method_51366()) {
                this.entityJumpTimer.reset();
                return;
            }
            if (EntitySpeedModule.mc.field_1724.field_3913.field_3904) {
                this.entityJumpTimer.reset();
            }
            if (this.entityJumpTimer.passed(10000) || !this.antiStuckConfig.getValue().booleanValue()) {
                if (!EntitySpeedModule.mc.field_1724.method_49694().method_5799() || EntitySpeedModule.mc.field_1724.field_3913.field_3904 || !this.entityJumpTimer.passed(1000)) {
                    if (EntitySpeedModule.mc.field_1724.method_49694().method_24828()) {
                        EntitySpeedModule.mc.field_1724.method_49694().method_18800(EntitySpeedModule.mc.field_1724.method_18798().field_1352, 0.4, EntitySpeedModule.mc.field_1724.method_18798().field_1350);
                    }
                    EntitySpeedModule.mc.field_1724.method_49694().method_18800(EntitySpeedModule.mc.field_1724.method_18798().field_1352, -0.4, EntitySpeedModule.mc.field_1724.method_18798().field_1350);
                }
                if (this.strictConfig.getValue().booleanValue()) {
                    Managers.NETWORK.sendPacket((class_2596<?>)class_2824.method_34207((class_1297)EntitySpeedModule.mc.field_1724.method_49694(), (boolean)false, (class_1268)class_1268.field_5808));
                }
                this.handleEntityMotion(this.speedConfig.getValue().floatValue(), d, d2);
                this.entityJumpTimer.reset();
            }
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (EntitySpeedModule.mc.field_1724 == null || !EntitySpeedModule.mc.field_1724.method_3144() || EntitySpeedModule.mc.field_1690.field_1832.method_1434() || EntitySpeedModule.mc.field_1724.method_49694() == null) {
            return;
        }
        if (this.strictConfig.getValue().booleanValue()) {
            if (event.getPacket() instanceof class_2752) {
                event.cancel();
            } else if (event.getPacket() instanceof class_2708) {
                event.cancel();
            }
        }
    }

    private void handleEntityMotion(float entitySpeed, double d, double d2) {
        class_243 motion = EntitySpeedModule.mc.field_1724.method_49694().method_18798();
        float forward = EntitySpeedModule.mc.field_1724.field_3913.field_3905;
        float strafe = EntitySpeedModule.mc.field_1724.field_3913.field_3907;
        if (forward == 0.0f && strafe == 0.0f) {
            EntitySpeedModule.mc.field_1724.method_49694().method_18800(0.0, motion.field_1351, 0.0);
            return;
        }
        EntitySpeedModule.mc.field_1724.method_49694().method_18800((double)(forward * entitySpeed) * d + (double)(strafe * entitySpeed) * d2, motion.field_1351, (double)(forward * entitySpeed) * d2 - (double)(strafe * entitySpeed) * d);
    }
}
