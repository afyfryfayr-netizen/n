package net.hachimi.client.impl.module.movement;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.entity.ElytraUpdateEvent;
import net.hachimi.client.impl.event.entity.player.TravelEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.module.RotationModule;
import net.hachimi.client.impl.module.movement.FollowerModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.TickTimer;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1671;
import net.minecraft.class_1713;
import net.minecraft.class_1770;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2815;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2886;
import net.minecraft.class_408;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_490;

public class ElytraFlyModule
extends RotationModule {
    private static ElytraFlyModule INSTANCE;
    Config<Mode> modeConfig = this.register(new EnumConfig("Mode", "Vanilla: LeavesHack-style rotate/travel logic. Control: directly set velocity like free-fly", (Enum)Mode.Vanilla, (Enum[])Mode.values()));
    Config<Float> controlSpeedConfig = this.register(new NumberConfig<Float>("ControlSpeed", "Horizontal fly speed while in Control mode", Float.valueOf(0.1f), Float.valueOf(1.0f), Float.valueOf(10.0f), () -> this.modeConfig.getValue() == Mode.Control));
    Config<Float> controlUpFactorConfig = this.register(new NumberConfig<Float>("ControlUpFactor", "Vertical speed while holding jump in Control mode", Float.valueOf(0.0f), Float.valueOf(1.0f), Float.valueOf(10.0f), () -> this.modeConfig.getValue() == Mode.Control));
    Config<Float> controlDownFactorConfig = this.register(new NumberConfig<Float>("ControlDownFactor", "Vertical speed while holding sneak in Control mode", Float.valueOf(0.0f), Float.valueOf(1.0f), Float.valueOf(10.0f), () -> this.modeConfig.getValue() == Mode.Control));
    Config<Boolean> controlSpeedLimitConfig = this.register(new BooleanConfig("ControlSpeedLimit", "Cap horizontal speed in Control mode", true, () -> this.modeConfig.getValue() == Mode.Control));
    Config<Float> controlMaxSpeedConfig = this.register(new NumberConfig<Float>("ControlMaxSpeed", "Max horizontal speed in Control mode", Float.valueOf(0.1f), Float.valueOf(2.5f), Float.valueOf(10.0f), () -> this.modeConfig.getValue() == Mode.Control && this.controlSpeedLimitConfig.getValue() != false));
    Config<Boolean> controlNoDragConfig = this.register(new BooleanConfig("ControlNoDrag", "Ignore vanilla air drag while in Control mode", false, () -> this.modeConfig.getValue() == Mode.Control));
    Config<Boolean> noMoveConfig = this.register(new BooleanConfig("NoMove", "Only move while a movement key is held", true));
    Config<Boolean> noAnimationConfig = this.register(new BooleanConfig("NoAnimation", "Stand still pose while flying", true));
    Config<Boolean> sneakingFixConfig = this.register(new BooleanConfig("SneakingFix", "Automatically press/release shift when the module is disabled", true));
    Config<Boolean> swapAlternativeConfig = this.register(new BooleanConfig("SwapAlternative", "Also search the full inventory (not just the hotbar) for fireworks", true));
    Config<Boolean> freezeConfig = this.register(new BooleanConfig("Freeze", "Freeze position when not moving", false));
    Config<FreezeMode> freezeModeConfig = this.register(new EnumConfig("FreezeMode", "How Freeze releases itself: never (Static), after N ticks (Tick), or after N ms (Timer)", (Enum)FreezeMode.Static, (Enum[])FreezeMode.values(), this.freezeConfig::getValue));
    Config<Float> freezeDurationConfig = this.register(new NumberConfig<Float>("FreezeDuration", "Duration before Freeze releases itself (ticks for Tick mode, milliseconds for Timer mode)", Float.valueOf(1.0f), Float.valueOf(20.0f), Float.valueOf(20000.0f), () -> this.freezeConfig.getValue() != false && this.freezeModeConfig.getValue() != FreezeMode.Static));
    Config<Boolean> noRotationConfig = this.register(new BooleanConfig("NoRotation", "Prevents sending rotation packets to server", false));
    Config<Boolean> packetConfig = this.register(new BooleanConfig("Packet", "Sends anti-kick movement packets", false));
    Config<Boolean> grimV3Config = this.register(new BooleanConfig("GrimV3", "Continuously swaps armor/elytra to avoid durability-based flags on GrimAC", true));
    Config<Float> grimDelayConfig = this.register(new NumberConfig<Float>("GrimDelay", "Tick delay between each GrimV3 swap cycle", Float.valueOf(0.0f), Float.valueOf(3.0f), Float.valueOf(100.0f), () -> this.grimV3Config.getValue()));
    Config<Boolean> autoJumpConfig = this.register(new BooleanConfig("AutoJump", "Auto jump to start elytra", false));
    Config<Boolean> autoFlyConfig = this.register(new BooleanConfig("AutoFly", "Automatically starts fall-flying when wearing an elytra while falling", true));
    Config<Boolean> fireworksConfig = this.register(new BooleanConfig("Fireworks", "Automatically fires a firework when nothing is currently boosting", true));
    Config<Float> delayConfig = this.register(new NumberConfig<Float>("Delay", "Minimum delay (seconds) between each automatic firework shot", Float.valueOf(0.0f), Float.valueOf(0.8f), Float.valueOf(5.0f), () -> this.fireworksConfig.getValue()));
    Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Sends a rotation packet every tick following movement direction (requires Rotations > MovementFix enabled to keep actual movement in sync)", true));
    Config<Boolean> rotateHoldConfig = this.register(new BooleanConfig("RotateHold", "Holds rotation even when not moving", false, () -> this.rotateConfig.getValue()));
    Config<Boolean> motionStopConfig = this.register(new BooleanConfig("MotionStop", "Stops all motion while rotating and not actively moving", false, () -> this.rotateConfig.getValue()));
    private static final double FALL_SPEED = 0.02;
    private boolean isUsingFirework = false;
    private boolean isFallFlying = false;
    private int packetDelayInt = 0;
    private final CacheTimer fireworkTimer = new CacheTimer();
    private final CacheTimer swapTimer = new CacheTimer();
    private final CacheTimer freezeTimer = new CacheTimer();
    private final TickTimer freezeTickTimer = new TickTimer();
    private boolean wasMovingLastTick = true;

    public ElytraFlyModule() {
        super("ElytraFly", "Elytra fly using fireworks (ported from LeavesHack)", ModuleCategory.MOVEMENT);
        INSTANCE = this;
    }

    public static ElytraFlyModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.fireworkTimer.setElapsedTime(-255L);
        this.swapTimer.setElapsedTime(-255L);
        this.packetDelayInt = 0;
        this.freezeTimer.reset();
        this.freezeTickTimer.reset();
        this.wasMovingLastTick = true;
    }

    @Override
    public void onDisable() {
        if (ElytraFlyModule.mc.field_1724 == null) {
            return;
        }
        if (this.sneakingFixConfig.getValue().booleanValue()) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2848((class_1297)ElytraFlyModule.mc.field_1724, class_2848.class_2849.field_12979));
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2848((class_1297)ElytraFlyModule.mc.field_1724, class_2848.class_2849.field_12984));
        }
    }

    @EventListener
    public void onElytraUpdate(ElytraUpdateEvent event) {
        if (this.noAnimationConfig.getValue().booleanValue()) {
            event.cancel();
        }
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        boolean standingStillIntentionally;
        boolean wearingElytra;
        boolean followerSteering;
        if (ElytraFlyModule.mc.field_1724 == null || ElytraFlyModule.mc.field_1687 == null) {
            return;
        }
        if (ElytraFlyModule.mc.field_1755 != null && ElytraFlyModule.mc.field_1755 instanceof class_465 && !(ElytraFlyModule.mc.field_1755 instanceof class_490) && !(ElytraFlyModule.mc.field_1755 instanceof class_481)) {
            return;
        }
        ++this.packetDelayInt;
        float yaw = this.getSprintYaw(ElytraFlyModule.mc.field_1724.method_36454());
        float pitch = this.getPitch(ElytraFlyModule.mc.field_1724.method_36455());
        boolean bl = followerSteering = FollowerModule.getInstance() != null && FollowerModule.getInstance().canFollow();
        if (this.rotateConfig.getValue().booleanValue() && !this.noRotationConfig.getValue().booleanValue() && !followerSteering && (this.wantToMove() || this.rotateHoldConfig.getValue().booleanValue())) {
            ElytraFlyModule.mc.field_1724.method_36456(yaw);
            ElytraFlyModule.mc.field_1724.method_36457(pitch);
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2828.class_2830(ElytraFlyModule.mc.field_1724.method_23317(), ElytraFlyModule.mc.field_1724.method_23318(), ElytraFlyModule.mc.field_1724.method_23321(), yaw, pitch, ElytraFlyModule.mc.field_1724.method_24828()));
        }
        boolean hasFirework = false;
        for (class_1297 entity : ElytraFlyModule.mc.field_1687.method_18112()) {
            class_1671 firework;
            if (!(entity instanceof class_1671) || (firework = (class_1671)entity).method_24921() != ElytraFlyModule.mc.field_1724) continue;
            hasFirework = true;
            break;
        }
        this.isUsingFirework = hasFirework;
        int elytraSlot = this.findItemInventorySlot(class_1802.field_8833);
        boolean bl2 = wearingElytra = ElytraFlyModule.mc.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833 && class_1770.method_7804((class_1799)ElytraFlyModule.mc.field_1724.method_6118(class_1304.field_6174));
        if (this.autoFlyConfig.getValue().booleanValue() && wearingElytra && !this.isFallFlying && !ElytraFlyModule.mc.field_1724.method_24828()) {
            this.sendPacket((class_2596<?>)new class_2848((class_1297)ElytraFlyModule.mc.field_1724, class_2848.class_2849.field_12982));
            ElytraFlyModule.mc.field_1724.method_23669();
        }
        if (this.autoJumpConfig.getValue().booleanValue() && ElytraFlyModule.mc.field_1724.method_24828() && !ElytraFlyModule.mc.field_1724.method_6128() && ElytraFlyModule.mc.field_1724.method_6118(class_1304.field_6174).method_7909() instanceof class_1770) {
            ElytraFlyModule.mc.field_1724.method_6043();
            this.sendPacket((class_2596<?>)new class_2848((class_1297)ElytraFlyModule.mc.field_1724, class_2848.class_2849.field_12982));
            ElytraFlyModule.mc.field_1724.method_23669();
        }
        if (this.grimV3Config.getValue().booleanValue()) {
            if (elytraSlot != -1 && (float)this.packetDelayInt > this.grimDelayConfig.getValue().floatValue()) {
                int syncId = ElytraFlyModule.mc.field_1724.field_7512.field_7763;
                ElytraFlyModule.mc.field_1761.method_2906(syncId, elytraSlot, 0, class_1713.field_7790, (class_1657)ElytraFlyModule.mc.field_1724);
                ElytraFlyModule.mc.field_1761.method_2906(syncId, 6, 0, class_1713.field_7790, (class_1657)ElytraFlyModule.mc.field_1724);
                ElytraFlyModule.mc.field_1761.method_2906(syncId, elytraSlot, 0, class_1713.field_7790, (class_1657)ElytraFlyModule.mc.field_1724);
                if (!ElytraFlyModule.mc.field_1724.method_24828()) {
                    this.sendPacket((class_2596<?>)new class_2848((class_1297)ElytraFlyModule.mc.field_1724, class_2848.class_2849.field_12982));
                    ElytraFlyModule.mc.field_1724.method_23669();
                }
                ElytraFlyModule.mc.field_1761.method_2906(syncId, elytraSlot, 0, class_1713.field_7790, (class_1657)ElytraFlyModule.mc.field_1724);
                ElytraFlyModule.mc.field_1761.method_2906(syncId, 6, 0, class_1713.field_7790, (class_1657)ElytraFlyModule.mc.field_1724);
                ElytraFlyModule.mc.field_1761.method_2906(syncId, elytraSlot, 0, class_1713.field_7790, (class_1657)ElytraFlyModule.mc.field_1724);
                this.packetDelayInt = 0;
            }
        } else if (wearingElytra && this.isFallFlying && !ElytraFlyModule.mc.field_1724.method_24828() && this.swapTimer.passed(800)) {
            int syncId = ElytraFlyModule.mc.field_1724.field_7512.field_7763;
            ElytraFlyModule.mc.field_1761.method_2906(syncId, 6, 0, class_1713.field_7790, (class_1657)ElytraFlyModule.mc.field_1724);
            ElytraFlyModule.mc.field_1761.method_2906(syncId, 6, 0, class_1713.field_7790, (class_1657)ElytraFlyModule.mc.field_1724);
            this.sendPacket((class_2596<?>)new class_2848((class_1297)ElytraFlyModule.mc.field_1724, class_2848.class_2849.field_12982));
            ElytraFlyModule.mc.field_1724.method_23669();
            this.swapTimer.reset();
        }
        boolean bl3 = standingStillIntentionally = (this.noMoveConfig.getValue() != false || this.freezeConfig.getValue() != false) && !this.wantToMove();
        if (this.fireworksConfig.getValue().booleanValue() && wearingElytra && this.isFallFlying && !hasFirework && !standingStillIntentionally) {
            this.fireFirework();
        }
    }

    @EventListener
    public void onTravel(TravelEvent event) {
        if (!this.isFallFlying) {
            return;
        }
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (this.modeConfig.getValue() == Mode.Control) {
            this.applyControlVelocity();
            return;
        }
        if (FollowerModule.getInstance() != null && FollowerModule.getInstance().canFollow()) {
            return;
        }
        if (!this.noMoveConfig.getValue().booleanValue() && !this.freezeConfig.getValue().booleanValue()) {
            return;
        }
        if (ElytraFlyModule.mc.field_1755 instanceof class_408) {
            this.setVelocityY(0.02);
            return;
        }
        if (!this.wantToMove()) {
            boolean freezeExpired;
            this.setVelocityX(0.0);
            this.setVelocityZ(0.0);
            boolean bl = freezeExpired = this.freezeConfig.getValue() != false && this.freezeModeConfig.getValue() != FreezeMode.Static && this.isFreezeDurationElapsed();
            if (this.freezeConfig.getValue().booleanValue() && !freezeExpired) {
                this.setVelocityY(0.0);
            } else {
                this.setVelocityY(0.02);
            }
            this.wasMovingLastTick = false;
        } else {
            if (!this.wasMovingLastTick) {
                this.freezeTimer.reset();
                this.freezeTickTimer.reset();
            }
            this.wasMovingLastTick = true;
        }
    }

    private void applyControlVelocity() {
        if (ElytraFlyModule.mc.field_1690.field_1832.method_1434() && ElytraFlyModule.mc.field_1724.field_3913.field_3904) {
            this.setVelocityY(0.0);
        } else if (ElytraFlyModule.mc.field_1690.field_1832.method_1434()) {
            this.setVelocityY(-this.controlDownFactorConfig.getValue().floatValue());
        } else if (ElytraFlyModule.mc.field_1724.field_3913.field_3904) {
            this.setVelocityY(-this.controlUpFactorConfig.getValue().floatValue());
        } else {
            this.setVelocityY(3.0E-11 * (double)this.controlDownFactorConfig.getValue().floatValue());
        }
        double yaw = Math.toRadians(ElytraFlyModule.mc.field_1724.method_36454());
        double dirX = -Math.sin(yaw);
        double dirZ = Math.cos(yaw);
        double speed = this.controlSpeedConfig.getValue().floatValue();
        double vx = 0.0;
        double vz = 0.0;
        if (ElytraFlyModule.mc.field_1690.field_1894.method_1434()) {
            vx += dirX * speed;
            vz += dirZ * speed;
        }
        if (ElytraFlyModule.mc.field_1690.field_1881.method_1434()) {
            vx -= dirX * speed;
            vz -= dirZ * speed;
        }
        if (ElytraFlyModule.mc.field_1690.field_1913.method_1434()) {
            vx += dirZ * speed;
            vz -= dirX * speed;
        }
        if (ElytraFlyModule.mc.field_1690.field_1849.method_1434()) {
            vx -= dirZ * speed;
            vz += dirX * speed;
        }
        if (this.controlSpeedLimitConfig.getValue().booleanValue()) {
            double max = this.controlMaxSpeedConfig.getValue().floatValue();
            double horiz = Math.sqrt(vx * vx + vz * vz);
            if (horiz > max && horiz > 0.0) {
                vx = vx / horiz * max;
                vz = vz / horiz * max;
            }
        }
        if (this.controlNoDragConfig.getValue().booleanValue()) {
            this.setVelocityX(-vx);
            this.setVelocityZ(-vz);
        } else {
            class_243 v = ElytraFlyModule.mc.field_1724.method_18798();
            ElytraFlyModule.mc.field_1724.method_18800(v.field_1352 * 0.6 + vx, v.field_1351, v.field_1350 * 0.6 + vz);
        }
    }

    private boolean isFreezeDurationElapsed() {
        return switch (this.freezeModeConfig.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 1 -> this.freezeTickTimer.passed(this.freezeDurationConfig.getValue());
            case 2 -> this.freezeTimer.passed(this.freezeDurationConfig.getValue());
            case 0 -> false;
        };
    }

    private void setVelocityX(double x) {
        class_243 v = ElytraFlyModule.mc.field_1724.method_18798();
        ElytraFlyModule.mc.field_1724.method_18800(x, v.field_1351, v.field_1350);
    }

    private void setVelocityY(double y) {
        class_243 v = ElytraFlyModule.mc.field_1724.method_18798();
        ElytraFlyModule.mc.field_1724.method_18800(v.field_1352, -y, v.field_1350);
    }

    private void setVelocityZ(double z) {
        class_243 v = ElytraFlyModule.mc.field_1724.method_18798();
        ElytraFlyModule.mc.field_1724.method_18800(v.field_1352, v.field_1351, z);
    }

    public void setFallFlying(boolean value) {
        this.isFallFlying = value;
    }

    public boolean getFallFlying() {
        return this.isFallFlying;
    }

    public void fireFirework() {
        int firework;
        if (!this.fireworkTimer.passed((long)(this.delayConfig.getValue().floatValue() * 1000.0f))) {
            return;
        }
        if (ElytraFlyModule.mc.field_1724.method_6047().method_7909() == class_1802.field_8639) {
            Managers.NETWORK.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, ElytraFlyModule.mc.field_1724.method_36454(), ElytraFlyModule.mc.field_1724.method_36455()));
            this.fireworkTimer.reset();
        } else if (ElytraFlyModule.mc.field_1724.method_6079().method_7909() == class_1802.field_8639) {
            Managers.NETWORK.sendSequencedPacket(id -> new class_2886(class_1268.field_5810, id, ElytraFlyModule.mc.field_1724.method_36454(), ElytraFlyModule.mc.field_1724.method_36455()));
            this.fireworkTimer.reset();
        } else if (this.swapAlternativeConfig.getValue().booleanValue() && (firework = this.findItemInventorySlot(class_1802.field_8639)) != -1) {
            this.inventorySwap(firework, ElytraFlyModule.mc.field_1724.method_31548().field_7545);
            Managers.NETWORK.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, ElytraFlyModule.mc.field_1724.method_36454(), ElytraFlyModule.mc.field_1724.method_36455()));
            this.inventorySwap(firework, ElytraFlyModule.mc.field_1724.method_31548().field_7545);
            this.sendPacket((class_2596<?>)new class_2815(ElytraFlyModule.mc.field_1724.field_7512.field_7763));
            this.fireworkTimer.reset();
        } else {
            firework = this.findItemHotbar(class_1802.field_8639);
            if (firework != -1) {
                int old = ElytraFlyModule.mc.field_1724.method_31548().field_7545;
                this.switchToSlot(firework);
                Managers.NETWORK.sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, ElytraFlyModule.mc.field_1724.method_36454(), ElytraFlyModule.mc.field_1724.method_36455()));
                this.switchToSlot(old);
                this.fireworkTimer.reset();
            }
        }
    }

    private int findItemInventorySlot(class_1792 item) {
        for (int i = 0; i < 36; ++i) {
            class_1799 stack = ElytraFlyModule.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() || stack.method_7909() != item) continue;
            return i < 9 ? i + 36 : i;
        }
        return -1;
    }

    private int findItemHotbar(class_1792 item) {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = ElytraFlyModule.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() || stack.method_7909() != item) continue;
            return i;
        }
        return -1;
    }

    private void inventorySwap(int slotA, int hotbarSlot) {
        int syncId = ElytraFlyModule.mc.field_1724.field_7512.field_7763;
        ElytraFlyModule.mc.field_1761.method_2906(syncId, slotA, hotbarSlot, class_1713.field_7791, (class_1657)ElytraFlyModule.mc.field_1724);
    }

    private void switchToSlot(int hotbarSlot) {
        Managers.INVENTORY.setSlot(hotbarSlot);
    }

    private void sendPacket(class_2596<?> packet) {
        if (mc.method_1562() != null) {
            mc.method_1562().method_52787(packet);
        }
    }

    private boolean wantToMove() {
        return ElytraFlyModule.mc.field_1690.field_1894.method_1434() || ElytraFlyModule.mc.field_1690.field_1881.method_1434() || ElytraFlyModule.mc.field_1690.field_1913.method_1434() || ElytraFlyModule.mc.field_1690.field_1849.method_1434() || ElytraFlyModule.mc.field_1690.field_1903.method_1434() || ElytraFlyModule.mc.field_1690.field_1832.method_1434();
    }

    public boolean isMoving() {
        if (ElytraFlyModule.mc.field_1724 == null || ElytraFlyModule.mc.field_1724.field_3913 == null) {
            return false;
        }
        return (double)ElytraFlyModule.mc.field_1724.field_3913.field_3905 != 0.0 || (double)ElytraFlyModule.mc.field_1724.field_3913.field_3907 != 0.0;
    }

    public float getSprintYaw(float yaw) {
        if (ElytraFlyModule.mc.field_1690.field_1894.method_1434() && !ElytraFlyModule.mc.field_1690.field_1881.method_1434()) {
            if (ElytraFlyModule.mc.field_1690.field_1913.method_1434() && !ElytraFlyModule.mc.field_1690.field_1849.method_1434()) {
                yaw -= 45.0f;
            } else if (ElytraFlyModule.mc.field_1690.field_1849.method_1434() && !ElytraFlyModule.mc.field_1690.field_1913.method_1434()) {
                yaw += 45.0f;
            }
        } else if (ElytraFlyModule.mc.field_1690.field_1881.method_1434() && !ElytraFlyModule.mc.field_1690.field_1894.method_1434()) {
            yaw += 180.0f;
            if (ElytraFlyModule.mc.field_1690.field_1913.method_1434() && !ElytraFlyModule.mc.field_1690.field_1849.method_1434()) {
                yaw += 45.0f;
            } else if (ElytraFlyModule.mc.field_1690.field_1849.method_1434() && !ElytraFlyModule.mc.field_1690.field_1913.method_1434()) {
                yaw -= 45.0f;
            }
        } else if (ElytraFlyModule.mc.field_1690.field_1913.method_1434() && !ElytraFlyModule.mc.field_1690.field_1849.method_1434()) {
            yaw -= 90.0f;
        } else if (ElytraFlyModule.mc.field_1690.field_1849.method_1434() && !ElytraFlyModule.mc.field_1690.field_1913.method_1434()) {
            yaw += 90.0f;
        }
        return yaw;
    }

    private float getPitch(float pitch) {
        if (!(ElytraFlyModule.mc.field_1755 instanceof class_408)) {
            if (ElytraFlyModule.mc.field_1690.field_1832.method_1434() && ElytraFlyModule.mc.field_1690.field_1903.method_1434()) {
                pitch = -3.0f;
            } else if (ElytraFlyModule.mc.field_1690.field_1903.method_1434()) {
                pitch = this.isMoving() ? -45.0f : -90.0f;
            } else if (ElytraFlyModule.mc.field_1690.field_1832.method_1434()) {
                float f = pitch = this.isMoving() ? 45.0f : 90.0f;
            }
            if (this.isMoving() && !ElytraFlyModule.mc.field_1690.field_1832.method_1434() && !ElytraFlyModule.mc.field_1690.field_1903.method_1434()) {
                pitch = -1.9f;
            }
        }
        return pitch;
    }

    public boolean isPhased() {
        return ElytraFlyModule.mc.field_1687.method_39454((class_1297)ElytraFlyModule.mc.field_1724, ElytraFlyModule.mc.field_1724.method_5829());
    }

    public static enum Mode {
        Vanilla,
        Control;

    }

    public static enum FreezeMode {
        Static,
        Tick,
        Timer;

    }
}
