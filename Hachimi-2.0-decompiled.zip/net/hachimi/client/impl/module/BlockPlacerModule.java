package net.hachimi.client.impl.module;

import java.util.function.Predicate;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.module.CombatModule;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;

public class BlockPlacerModule
extends CombatModule {
    protected Config<Boolean> strictDirectionConfig = this.register(new BooleanConfig("StrictDirection", "Places on visible sides only", false));
    protected Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Rotates to block before placing", false));
    protected Config<Boolean> stopMotionConfig = this.register(new BooleanConfig("StopMotion", "Stops movement before placing", false));

    public BlockPlacerModule(String name, String desc, ModuleCategory category) {
        super(name, desc, category);
        this.register(this.strictDirectionConfig, this.rotateConfig, this.stopMotionConfig);
    }

    public BlockPlacerModule(String name, String desc, ModuleCategory category, int rotationPriority) {
        super(name, desc, category, rotationPriority);
        this.register(this.strictDirectionConfig, this.rotateConfig, this.stopMotionConfig);
    }

    protected int getSlot(Predicate<class_1799> filter) {
        for (int i = 0; i < 9; ++i) {
            class_1799 itemStack = BlockPlacerModule.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960() || !filter.test(itemStack)) continue;
            return i;
        }
        return -1;
    }

    protected int getBlockItemSlot(class_2248 block) {
        for (int i = 0; i < 9; ++i) {
            class_1747 blockItem;
            class_1799 stack = BlockPlacerModule.mc.field_1724.method_31548().method_5438(i);
            class_1792 class_17922 = stack.method_7909();
            if (!(class_17922 instanceof class_1747) || (blockItem = (class_1747)class_17922).method_7711() != block) continue;
            return i;
        }
        return -1;
    }

    public record BlockSlot(class_2248 block, int slot) {
        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof BlockSlot)) {
                return false;
            }
            BlockSlot other = (BlockSlot)obj;
            return other.block() == this.block;
        }
    }
}
