package net.hachimi.client.impl.module.client;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ConcurrentModule;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.event.config.ConfigUpdateEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.mixin.accessor.AccessorPlayerMoveC2SPacket;
import net.hachimi.client.util.math.position.DirectionUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.world.BlastResistantBlocks;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2645;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AnticheatModule
extends ConcurrentModule {
    private static AnticheatModule INSTANCE;
    Config<Anticheats> modeConfig = this.register(new EnumConfig("Mode", "Applies anticheat optimizations", (Enum)Anticheats.GRIM, (Enum[])Anticheats.values()));
    Config<PlacementMode> placementConfig = this.register(new EnumConfig("Placement", "Placement packet mode sent to server", (Enum)PlacementMode.Grim, (Enum[])PlacementMode.values()));
    Config<SwingMode> entitySwingConfig = this.register(new EnumConfig("EntitySwing", "Swing mode when attacking entities", (Enum)SwingMode.Normal, (Enum[])SwingMode.values()));
    Config<SwingMode> placeSwingConfig = this.register(new EnumConfig("PlaceSwing", "Swing mode when placing blocks", (Enum)SwingMode.None, (Enum[])SwingMode.values()));
    Config<Float> breakDelayConfig = this.register(new NumberConfig<Float>("BreakDelay", "Delay in ticks between block breaks", Float.valueOf(0.0f), Float.valueOf(1.0f), Float.valueOf(10.0f)));
    Config<AttackMode> attackConfig = this.register(new EnumConfig("Attack", "How to send attack packets to the server", (Enum)AttackMode.Normal, (Enum[])AttackMode.values()));
    Config<PlacePacketMode> placeConfig = this.register(new EnumConfig("Place", "How to send place packets to the server", (Enum)PlacePacketMode.Packet, (Enum[])PlacePacketMode.values()));
    Config<Boolean> multiPlaceConfig = this.register(new BooleanConfig("MultiPlace", "Allows placing multiple blocks per tick", false));
    Config<Boolean> multiPointConfig = this.register(new BooleanConfig("MultiPoint", "Sends multiple hit vectors when placing to bypass raytrace", false));
    Config<Boolean> closestDirectionConfig = this.register(new BooleanConfig("ClosestDirection", "Uses closest valid direction when placing blocks", false));
    Config<Boolean> grimAirplaceConfig = this.register(new BooleanConfig("GrimAirplace", "Bypasses Grim airplace check using offhand swap trick", false));
    Config<Boolean> sneakingSpoofConfig = this.register(new BooleanConfig("SneakingSpoof", "Spoofs sneaking state when placing to bypass block interaction checks", false));
    Config<Boolean> pickConfig = this.register(new BooleanConfig("Pick", "Cancels PickFromInventory packets to prevent Grim flags", false));
    Config<Float> damageConfig = this.register(new NumberConfig<Float>("Damage", "Damage multiplier sent to server for Grim consistency", Float.valueOf(0.0f), Float.valueOf(0.7f), Float.valueOf(1.0f)));
    Config<Float> entityPlaceConfig = this.register(new NumberConfig<Float>("PlaceThreshold", "Max ticks to place on entities", Float.valueOf(0.0f), Float.valueOf(2.0f), Float.valueOf(25.0f), () -> this.modeConfig.getValue() != Anticheats.VANILLA));
    Config<Boolean> noScreenCloseConfig = this.register(new BooleanConfig("NoScreenClose", "Prevents the server from closing your inventory screen", false, () -> this.modeConfig.getValue() == Anticheats.GRIM));
    Config<Boolean> raytraceSpoofConfig = this.register(new BooleanConfig("RaytraceFix", "Allows you to spoof your raytrace", false, () -> this.modeConfig.getValue() == Anticheats.N_C_P));
    public Config<Boolean> grimRotationConfig = this.register(new BooleanConfig("GrimRotation", "Sends Full movement packet when rotating to bypass GrimAC rotation check", true, () -> this.modeConfig.getValue() == Anticheats.GRIM));
    public Config<Boolean> snapBackConfig = this.register(new BooleanConfig("SnapBack", "Sends a snap-back rotation packet after placing/attacking to restore real look direction", false, () -> this.modeConfig.getValue() == Anticheats.GRIM));
    private final Timer raytraceTimer = new CacheTimer();
    private float pitch = Float.NaN;

    public AnticheatModule() {
        super("Anticheat", "Settings for anticheat configs", ModuleCategory.CLIENT);
        INSTANCE = this;
    }

    public static AnticheatModule getInstance() {
        return INSTANCE;
    }

    @EventListener(priority=10000)
    public void onPacketOutbound(PacketEvent.Outbound event) {
        class_2828 packet;
        class_2596<?> class_25962;
        if (AnticheatModule.mc.field_1724 == null || AnticheatModule.mc.field_1687 == null) {
            return;
        }
        if (this.isNCP() && this.raytraceSpoofConfig.getValue().booleanValue() && (class_25962 = event.getPacket()) instanceof class_2885) {
            packet = (class_2885)class_25962;
            if (this.raytraceTimer.passed(250)) {
                class_3965 packetResult = packet.method_12543();
                class_2338 pos = packetResult.method_17777();
                class_3965 result = AnticheatModule.mc.field_1687.method_17742(new class_3959(AnticheatModule.mc.field_1724.method_33571(), DirectionUtil.getDirectionOffsetPos(pos, packetResult.method_17780()), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)AnticheatModule.mc.field_1724));
                if (AnticheatModule.mc.field_1687.method_18026(AnticheatModule.mc.field_1724.method_5829().method_1012(0.0, 0.15, 0.0)) && result != null && result.method_17783() == class_239.class_240.field_1332 && !result.method_17777().equals((Object)pos)) {
                    this.pitch = -75.0f;
                    this.raytraceTimer.reset();
                }
            }
        }
        if ((class_25962 = event.getPacket()) instanceof class_2828 && (packet = (class_2828)class_25962).method_36172() && !Float.isNaN(this.pitch)) {
            ((AccessorPlayerMoveC2SPacket)packet).hookSetPitch(this.pitch);
            this.pitch = Float.NaN;
        }
        if (this.isGrim() && (class_25962 = event.getPacket()) instanceof class_2846 && ((packet = (class_2846)class_25962).method_12363() == class_2846.class_2847.field_12968 || packet.method_12363() == class_2846.class_2847.field_12973 || packet.method_12363() == class_2846.class_2847.field_12971)) {
            if (BlastResistantBlocks.isUnbreakable(packet.method_12362())) {
                event.cancel();
                return;
            }
            if (packet.method_12363() == class_2846.class_2847.field_12968) {
                Managers.NETWORK.sendQuietPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, packet.method_12362(), class_2350.field_11036));
                Managers.NETWORK.sendQuietPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12968, packet.method_12362(), class_2350.field_11036));
                Managers.NETWORK.sendQuietPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, packet.method_12362(), class_2350.field_11036));
                event.cancel();
            }
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        class_2645 packet;
        class_2596<?> class_25962;
        if (AnticheatModule.mc.field_1724 == null || AnticheatModule.mc.field_1687 == null) {
            return;
        }
        if (this.isGrim() && this.noScreenCloseConfig.getValue().booleanValue() && (class_25962 = event.getPacket()) instanceof class_2645 && (packet = (class_2645)class_25962).method_36148() == 0) {
            event.cancel();
        }
    }

    @EventListener
    public void onConfigUpdate(ConfigUpdateEvent event) {
        if (event.getStage() == StageEvent.EventStage.POST && event.getConfig() == this.raytraceSpoofConfig && !this.raytraceSpoofConfig.getValue().booleanValue()) {
            this.pitch = Float.NaN;
        }
    }

    public boolean isGrim() {
        return this.modeConfig.getValue() == Anticheats.GRIM;
    }

    public boolean isNCP() {
        return this.modeConfig.getValue() == Anticheats.N_C_P;
    }

    public boolean getMiningFix() {
        return this.isGrim();
    }

    public boolean getWebJumpFix() {
        return false;
    }

    public int getEntityPlaceThreshold() {
        return this.modeConfig.getValue() == Anticheats.VANILLA ? 0 : Math.round(this.entityPlaceConfig.getValue().floatValue() * 10.0f);
    }

    public PlacementMode getPlacementMode() {
        return this.placementConfig.getValue();
    }

    public SwingMode getEntitySwing() {
        return this.entitySwingConfig.getValue();
    }

    public SwingMode getPlaceSwing() {
        return this.placeSwingConfig.getValue();
    }

    public float getBreakDelayMs() {
        return this.breakDelayConfig.getValue().floatValue() * 50.0f;
    }

    public AttackMode getAttackMode() {
        return this.attackConfig.getValue();
    }

    public PlacePacketMode getPlacePacketMode() {
        return this.placeConfig.getValue();
    }

    public boolean isMultiPlace() {
        return this.multiPlaceConfig.getValue();
    }

    public boolean isMultiPoint() {
        return this.multiPointConfig.getValue();
    }

    public boolean isClosestDirection() {
        return this.closestDirectionConfig.getValue();
    }

    public boolean isGrimAirplace() {
        return this.grimAirplaceConfig.getValue();
    }

    public boolean isSneakingSpoof() {
        return this.sneakingSpoofConfig.getValue();
    }

    public boolean isPick() {
        return this.pickConfig.getValue();
    }

    public float getDamageMultiplier() {
        return this.damageConfig.getValue().floatValue();
    }

    public boolean isGrimRotation() {
        return this.grimRotationConfig.getValue();
    }

    public boolean isSnapBack() {
        return this.snapBackConfig.getValue();
    }

    private static enum Anticheats {
        GRIM,
        N_C_P,
        VANILLA;

    }

    public static enum PlacementMode {
        Grim,
        NCP,
        Normal;

    }

    public static enum SwingMode {
        Normal,
        None,
        Packet;

    }

    public static enum AttackMode {
        Normal,
        Packet;

    }

    public static enum PlacePacketMode {
        Normal,
        Packet;

    }
}
