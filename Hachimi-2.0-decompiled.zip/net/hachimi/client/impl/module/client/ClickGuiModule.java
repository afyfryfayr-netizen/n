package net.hachimi.client.impl.module.client;

import net.hachimi.client.Hachimi;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.config.ConfigUpdateEvent;
import net.hachimi.client.impl.gui.click.ClickGuiScreen;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.render.animation.Easing;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_437;

public class ClickGuiModule
extends ToggleModule {
    private static ClickGuiModule INSTANCE;
    Config<Boolean> blurConfig = this.register(new BooleanConfig("Blur", "Adds a blur background to the panels", false));
    Config<Float> scaleConfig = this.register(new NumberConfig<Float>("Scale", "The gui scale", Float.valueOf(0.5f), Float.valueOf(1.0f), Float.valueOf(3.0f)));
    Config<Integer> scrollSpeedConfig = this.register(new NumberConfig<Integer>("ScrollSpeed", "The speed of GUI scrolling", 5, 30, 100));
    Config<Boolean> soundsConfig = this.register(new BooleanConfig("Sounds", "Click sounds", true));
    Config<Boolean> descriptionsConfig = this.register(new BooleanConfig("Descriptions", "Shows feature descriptions", true));
    public static ClickGuiScreen CLICK_GUI_SCREEN;
    public static float CLICK_GUI_SCALE;
    private final Animation openCloseAnimation = new Animation(false, 400.0f, Easing.BACK_OUT);
    private final Animation transparencyAnimation = new Animation(false, 300.0f, Easing.CUBIC_IN_OUT);

    public ClickGuiModule() {
        super("ClickGui", "Opens the clickgui screen", ModuleCategory.CLIENT, 344);
        INSTANCE = this;
    }

    public static ClickGuiModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        if (ClickGuiModule.mc.field_1724 == null || ClickGuiModule.mc.field_1687 == null) {
            this.toggle();
            return;
        }
        if (CLICK_GUI_SCREEN == null) {
            CLICK_GUI_SCALE = this.scaleConfig.getValue().floatValue();
            CLICK_GUI_SCREEN = new ClickGuiScreen(this);
            Hachimi.CONFIG.loadClickGui();
        }
        if (CLICK_GUI_SCALE != this.scaleConfig.getValue().floatValue()) {
            CLICK_GUI_SCALE = this.scaleConfig.getValue().floatValue();
            CLICK_GUI_SCREEN = new ClickGuiScreen(this);
        }
        this.openCloseAnimation.setState(true);
        this.transparencyAnimation.setState(true);
        this.openCloseAnimation.reset();
        this.transparencyAnimation.reset();
        mc.method_1507((class_437)CLICK_GUI_SCREEN);
    }

    @Override
    public void onDisable() {
        if (ClickGuiModule.mc.field_1724 == null || ClickGuiModule.mc.field_1687 == null) {
            this.toggle();
            return;
        }
        if (CLICK_GUI_SCREEN != null) {
            Hachimi.CONFIG.saveClickGui();
        }
        ClickGuiModule.mc.field_1724.method_3137();
        this.openCloseAnimation.setState(false);
        this.transparencyAnimation.setState(false);
    }

    @EventListener
    public void onConfigUpdate(ConfigUpdateEvent event) {
        if (event.getStage() == StageEvent.EventStage.POST && event.getConfig() == this.scaleConfig && ClickGuiModule.mc.field_1687 == null) {
            CLICK_GUI_SCALE = this.scaleConfig.getValue().floatValue();
        }
    }

    public int getColor() {
        return ColorsModule.getInstance().getColor((int)(100.0 * this.openCloseAnimation.getFactor())).getRGB();
    }

    public int getColor(int a) {
        return ColorsModule.getInstance().getColor((int)((double)a * this.openCloseAnimation.getFactor())).getRGB();
    }

    public int getColor(float alpha) {
        return ColorsModule.getInstance().getColor((int)((double)(100.0f * alpha) * this.openCloseAnimation.getFactor())).getRGB();
    }

    public int getColor(int a, float alpha) {
        return ColorsModule.getInstance().getColor((int)((double)((float)a * alpha) * this.openCloseAnimation.getFactor())).getRGB();
    }

    public int fixTransparency(int color) {
        float alpha = this.getAlpha();
        if (alpha == 1.0f) {
            return color;
        }
        float colorAlpha = color >> 24 & 0xFF;
        alpha = Math.max(0.0f, Math.min(1.0f, alpha));
        int colorAlphaInt = Math.max(10, (int)(colorAlpha * alpha));
        return colorAlphaInt << 24 | color & 0xFFFFFF;
    }

    public boolean getBlur() {
        return this.blurConfig.getValue();
    }

    public boolean getSounds() {
        return this.soundsConfig.getValue();
    }

    public boolean getDescriptions() {
        return this.descriptionsConfig.getValue();
    }

    public float getAlpha() {
        return (float)this.transparencyAnimation.getFactor();
    }

    public float getScaleFactor() {
        return (float)this.openCloseAnimation.getFactor();
    }

    public int getScrollSpeed() {
        return this.scrollSpeedConfig.getValue();
    }

    static {
        CLICK_GUI_SCALE = 1.0f;
    }
}
