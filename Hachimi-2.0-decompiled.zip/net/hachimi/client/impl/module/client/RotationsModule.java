package net.hachimi.client.impl.module.client;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ConcurrentModule;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.module.exploit.DisablerModule;

public class RotationsModule
extends ConcurrentModule {
    private static RotationsModule INSTANCE;
    Config<Float> preserveTicksConfig = this.register(new NumberConfig<Float>("PreserveTicks", "Time to preserve rotations after reaching the target rotations", Float.valueOf(0.0f), Float.valueOf(10.0f), Float.valueOf(20.0f)));
    Config<Boolean> movementFixConfig = this.register(new BooleanConfig("MovementFix", "Fixes movement on Grim when rotating", false));
    Config<Boolean> mouseSensFixConfig = this.register(new BooleanConfig("MouseSensFix", "Fixes movement on Grim when applying mouse sensitivity", false));
    private float prevYaw;

    public RotationsModule() {
        super("Rotations", "Manages client rotations", ModuleCategory.CLIENT);
        INSTANCE = this;
    }

    public static RotationsModule getInstance() {
        return INSTANCE;
    }

    public boolean getMovementFix() {
        return this.movementFixConfig.getValue() != false && (!DisablerModule.getInstance().isEnabled() || !DisablerModule.getInstance().isYawOverflow());
    }

    public boolean getMouseSensFix() {
        return this.mouseSensFixConfig.getValue();
    }

    public float getPreserveTicks() {
        return this.preserveTicksConfig.getValue().floatValue();
    }
}
