package net.hachimi.client.impl.module.client;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.config.ConfigUpdateEvent;
import net.hachimi.client.init.Fonts;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;

public class FontModule
extends ToggleModule {
    private static FontModule INSTANCE;
    Config<Boolean> antiAliasConfig = this.register(new BooleanConfig("AntiAlias", "Applies antialiasing to font", true));
    Config<Boolean> fractionalMetrics = this.register(new BooleanConfig("FractionalMetrics", "Applies fractional metrics to font", false));
    Config<Integer> sizeConfig = this.register(new NumberConfig<Integer>("Size", "The font size", 5, 9, 12));
    Config<Float> vanillaShadowConfig = this.register(new NumberConfig<Float>("VanillaShadow", "The vanilla shadow offset", Float.valueOf(0.1f), Float.valueOf(1.0f), Float.valueOf(1.5f)));

    public FontModule() {
        super("Font", "Changes the client text to custom font rendering", ModuleCategory.CLIENT);
        INSTANCE = this;
    }

    public static FontModule getInstance() {
        return INSTANCE;
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == StageEvent.EventStage.PRE && Fonts.FONT_SIZE != (float)this.sizeConfig.getValue().intValue()) {
            Fonts.setSize(this.sizeConfig.getValue().intValue());
        }
    }

    @EventListener
    public void onConfigUpdate(ConfigUpdateEvent event) {
        if (!Fonts.isInitialized()) {
            return;
        }
        if (event.getStage() == StageEvent.EventStage.POST && (event.getConfig() == this.antiAliasConfig || event.getConfig() == this.fractionalMetrics)) {
            Fonts.closeFonts();
        }
    }

    public boolean getAntiAlias() {
        return this.antiAliasConfig.getValue();
    }

    public boolean getFractionalMetrics() {
        return this.fractionalMetrics.getValue();
    }

    public float getVanillaShadow() {
        return this.vanillaShadowConfig.getValue().floatValue();
    }
}
