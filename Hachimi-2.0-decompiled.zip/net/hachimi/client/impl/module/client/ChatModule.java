package net.hachimi.client.impl.module.client;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.gui.chat.ChatMessageEvent;
import net.hachimi.client.impl.event.gui.hud.RenderOverlayEvent;
import net.hachimi.client.impl.event.keyboard.KeyboardInputEvent;
import net.hachimi.client.impl.event.network.GameJoinEvent;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.impl.module.client.HUDModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.chat.ChatUtil;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.render.animation.Easing;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_408;

public class ChatModule
extends ToggleModule {
    private static ChatModule INSTANCE;
    private boolean ircChat;
    private boolean notified;
    private final Timer timer = new CacheTimer();
    public Config<Boolean> dmsOnly = this.register(new BooleanConfig("DMOnly", "Only receive private messages from IRC", false));
    private final Animation ircAnimation = new Animation(false, 200.0f, Easing.LINEAR);

    public ChatModule() {
        super("Chat", "Manages the client chat", ModuleCategory.CLIENT);
        INSTANCE = this;
    }

    public static ChatModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        System.out.println("Baritone has been removed");
        if (ChatModule.mc.field_1724 == null || this.notified || this.dmsOnly.getValue().booleanValue()) {
            return;
        }
        ChatUtil.clientSendMessageRaw("\u00a7s[Chat]\u00a77 Press ALT in chat to enter IRC!", 107);
        this.notified = true;
    }

    @EventListener
    public void onGameJoin(GameJoinEvent event) {
        if (this.dmsOnly.getValue().booleanValue()) {
            return;
        }
        if (this.notified) {
            return;
        }
        ChatUtil.clientSendMessageRaw("\u00a7s[Chat]\u00a77 Press ALT in chat to enter IRC!", 107);
        this.notified = true;
    }

    @EventListener
    public void onKey(KeyboardInputEvent event) {
        if (this.dmsOnly.getValue().booleanValue()) {
            return;
        }
        if (!this.timer.passed(250)) {
            return;
        }
        if (event.getAction() != 2 && (event.getKeycode() == 342 || event.getKeycode() == 346) && ChatModule.mc.field_1755 instanceof class_408) {
            this.ircChat = !this.ircChat;
            this.ircAnimation.setState(this.ircChat);
            this.timer.reset();
        }
    }

    @EventListener(priority=-2147483648)
    public void onChatMessage(ChatMessageEvent.Client event) {
        if (this.dmsOnly.getValue().booleanValue()) {
            return;
        }
        if (this.ircChat) {
            String text = event.getMessage().trim();
            if (text.isEmpty() || text.isBlank() || text.startsWith(Managers.COMMAND.getPrefix()) || text.startsWith("/")) {
                return;
            }
            event.cancel();
            ChatModule.mc.field_1705.method_1743().method_1803(text);
        }
    }

    @EventListener
    public void onRenderOverlay(RenderOverlayEvent.Hotbar event) {
        if (this.dmsOnly.getValue().booleanValue()) {
            return;
        }
        if (ChatModule.mc.field_1755 instanceof class_408 && this.ircAnimation.getFactor() > 0.01) {
            float height = mc.method_22683().method_4502();
            float width = mc.method_22683().method_4486();
            float anim = HUDModule.getInstance().isEnabled() ? HUDModule.getInstance().getChatAnimation() : 1.0f;
            RenderManager.borderedRect(event.getContext().method_51448(), 2.0, (int)height, width - 4.0f, -16.0f * anim, ColorsModule.getInstance().getRGB((int)(255.0 * this.ircAnimation.getFactor())), 1.0);
        }
    }

    public boolean isDmsOnly() {
        return this.dmsOnly.getValue();
    }
}
