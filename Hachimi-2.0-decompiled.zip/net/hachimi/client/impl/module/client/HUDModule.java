package net.hachimi.client.impl.module.client;

import java.awt.Color;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.stream.Stream;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.ConfigContainer;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.ScreenOpenEvent;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.entity.EntityDeathEvent;
import net.hachimi.client.impl.event.entity.StatusEffectEvent;
import net.hachimi.client.impl.event.gui.hud.RenderOverlayEvent;
import net.hachimi.client.impl.event.gui.screen.RenderOpenChatEvent;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.impl.module.exploit.FastLatencyModule;
import net.hachimi.client.impl.module.misc.TimerModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.StreamUtils;
import net.hachimi.client.util.math.PerSecondCounter;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.InventoryUtil;
import net.hachimi.client.util.render.ColorUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.render.animation.Easing;
import net.hachimi.client.util.string.EnumFormatter;
import net.hachimi.client.util.world.BlockUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1041;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3544;
import net.minecraft.class_408;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public class HUDModule
extends ToggleModule {
    private static HUDModule INSTANCE;
    Config<Boolean> watermarkConfig = this.register(new BooleanConfig("Watermark", "Displays client name and version watermark", true));
    Config<Boolean> logoConfig = this.register(new BooleanConfig("Logo", "Displays the Hachimi logo in the top left corner", false));
    Config<Float> logoScaleConfig = this.register(new NumberConfig<Float>("Logo-Scale", "The scale of the logo image", Float.valueOf(0.1f), Float.valueOf(1.6f), Float.valueOf(2.0f), () -> this.logoConfig.getValue()));
    Config<Integer> logoOpacityConfig = this.register(new NumberConfig<Integer>("Logo-Opacity", "The opacity of the logo image", Integer.valueOf(0), Integer.valueOf(255), Integer.valueOf(255), () -> this.logoConfig.getValue()));
    Config<Boolean> serverStatusConfig = this.register(new BooleanConfig("ServerStatus", "Displays warning for server connection status", true));
    Config<Boolean> userInfo = this.register(new BooleanConfig("UserInfo", "Displays your user information", true));
    Config<Boolean> directionConfig = this.register(new BooleanConfig("Direction", "Displays facing direction", true));
    Config<Boolean> rotationConfig = this.register(new BooleanConfig("Rotation", "Displays player yaw and pitch", false, () -> this.directionConfig.getValue()));
    Config<Boolean> armorConfig = this.register(new BooleanConfig("Armor", "Displays player equipped armor and durability", true));
    Config<Boolean> armorDurabilityConfig = this.register(new BooleanConfig("ArmorDurability", "Displays player equipped armor durability", false, () -> this.armorConfig.getValue()));
    Config<Boolean> totemsConfig = this.register(new BooleanConfig("Totems", "Displays player totems", false));
    Config<VanillaHud> potionHudConfig = this.register(new EnumConfig("PotionHud", "Renders the Minecraft potion Hud", (Enum)VanillaHud.HIDE, (Enum[])VanillaHud.values()));
    Config<VanillaHud> itemNameConfig = this.register(new EnumConfig("ItemName", "Renders the Minecraft item name display", (Enum)VanillaHud.HIDE, (Enum[])VanillaHud.values()));
    Config<Boolean> potionEffectsConfig = this.register(new BooleanConfig("PotionEffects", "Displays active potion effects", true));
    Config<PotionColors> potionColorsConfig = this.register(new EnumConfig("PotionColors", "Displays active potion colors", (Enum)PotionColors.NORMAL, (Enum[])PotionColors.values(), () -> this.potionEffectsConfig.getValue()));
    Config<Boolean> potionTimerConfig = this.register(new BooleanConfig("PotionTimer", "Shows remaining seconds of effects + potion count (Alien-style)", true));
    Config<Boolean> potionTimerResLvlConfig = this.register(new BooleanConfig("ResistanceLevelCheck", "Only show Resistance timer if level II+", true, () -> this.potionTimerConfig.getValue()));
    Config<Integer> potionTimerYOffsetConfig = this.register(new NumberConfig<Integer>("PotionTimerY", "Y offset from center (positive = up)", Integer.valueOf(-200), Integer.valueOf(40), Integer.valueOf(200), () -> this.potionTimerConfig.getValue()));
    Config<Boolean> durabilityConfig = this.register(new BooleanConfig("Durability", "Displays the current held items durability", false));
    Config<Boolean> coordsConfig = this.register(new BooleanConfig("Coords", "Displays world coordinates", true));
    Config<Boolean> netherCoordsConfig = this.register(new BooleanConfig("NetherCoords", "Displays nether coordinates", true, () -> this.coordsConfig.getValue()));
    Config<Boolean> serverBrandConfig = this.register(new BooleanConfig("ServerBrand", "Displays the current server brand", false));
    Config<Boolean> chestsConfig = this.register(new BooleanConfig("Chests", "Displays the amount of chests in your render distance", false));
    Config<SpeedHud> speedConfig = this.register(new EnumConfig("Speed", "Displays the current movement speed of the player", (Enum)SpeedHud.K_M_H, (Enum[])SpeedHud.values()));
    Config<Boolean> pingConfig = this.register(new BooleanConfig("Ping", "Display server response time in ms", true));
    Config<Boolean> tpsConfig = this.register(new BooleanConfig("TPS", "Displays server ticks per second", true));
    Config<Boolean> packetsConfig = this.register(new BooleanConfig("Packets", "Displays outbound packets per second", false));
    Config<Boolean> fpsConfig = this.register(new BooleanConfig("FPS", "Displays game FPS", true));
    Config<Boolean> arraylistConfig = this.register(new BooleanConfig("Arraylist", "Displays a list of all active modules", true));
    Config<Integer> animTimeConfig = this.register(new NumberConfig<Integer>("Arraylist-Time", "Timer for the animation", Integer.valueOf(0), Integer.valueOf(1000), Integer.valueOf(2000), () -> false));
    Config<Ordering> orderingConfig = this.register(new EnumConfig("Ordering", "The ordering of the arraylist", (Enum)Ordering.LENGTH, (Enum[])Ordering.values(), () -> this.arraylistConfig.getValue()));
    Config<Rendering> renderingConfig = this.register(new EnumConfig("Rendering", "The rendering mode of the HUD", (Enum)Rendering.UP, (Enum[])Rendering.values()));
    Config<RainbowMode> rainbowModeConfig = this.register(new EnumConfig("Rainbow", "The rendering mode for rainbow", (Enum)RainbowMode.OFF, (Enum[])RainbowMode.values()));
    Config<Color> gradientColorConfig = this.register(new ColorConfig("GradientColor", "The color of the rainbow gradient", Color.WHITE, false, false, () -> this.rainbowModeConfig.getValue() == RainbowMode.GRADIENT));
    Config<Float> rainbowSpeedConfig = this.register(new NumberConfig<Float>("Rainbow-Speed", "The speed for the rainbow color cycling", Float.valueOf(0.1f), Float.valueOf(50.0f), Float.valueOf(100.0f), () -> this.rainbowModeConfig.getValue() != RainbowMode.OFF));
    Config<Integer> rainbowSaturationConfig = this.register(new NumberConfig<Integer>("Rainbow-Saturation", "The saturation of rainbow colors", Integer.valueOf(0), Integer.valueOf(35), Integer.valueOf(100), () -> this.rainbowModeConfig.getValue() != RainbowMode.OFF && this.rainbowModeConfig.getValue() != RainbowMode.GRADIENT));
    Config<Integer> rainbowBrightnessConfig = this.register(new NumberConfig<Integer>("Rainbow-Brightness", "The brightness of rainbow colors", Integer.valueOf(0), Integer.valueOf(100), Integer.valueOf(100), () -> this.rainbowModeConfig.getValue() != RainbowMode.OFF && this.rainbowModeConfig.getValue() != RainbowMode.GRADIENT));
    Config<Float> rainbowDifferenceConfig = this.register(new NumberConfig<Float>("Rainbow-Difference", "The difference offset for rainbow colors", Float.valueOf(0.1f), Float.valueOf(40.0f), Float.valueOf(100.0f), () -> this.rainbowModeConfig.getValue() != RainbowMode.OFF));
    private static final class_2960 LOGO_TEXTURE;
    private static final int LOGO_WIDTH = 1057;
    private static final int LOGO_HEIGHT = 384;
    private final DecimalFormat decimal = new DecimalFormat("0.0");
    private final DecimalFormat decimal2 = new DecimalFormat("0.0#");
    private long rainbowOffset;
    private float topLeft;
    private float topRight;
    private float bottomLeft;
    private float bottomRight;
    private boolean renderingUp;
    private final Animation chatOpenAnimation = new Animation(false, 200.0f, Easing.LINEAR);
    private final PerSecondCounter fpsCounter = new PerSecondCounter();
    private final Map<String, HudRenderModule> hudRenderModules = new HashMap<String, HudRenderModule>();
    private final Map<PotionData, Animation> hudRenderPotions = new ConcurrentSkipListMap<PotionData, Animation>();
    private final Timer serverStatus = new CacheTimer();
    private final Animation statusAnimation = new Animation(false, 300.0f, Easing.LINEAR);

    public HUDModule() {
        super("HUD", "Displays the HUD (heads up display) screen.", ModuleCategory.CLIENT);
        INSTANCE = this;
    }

    public static HUDModule getInstance() {
        return INSTANCE;
    }

    private void arrayListRenderModule(RenderOverlayEvent.Post event, ToggleModule toggleModule, long drawnCount) {
        if (toggleModule.getAnimation().getFactor() <= (double)0.01f || toggleModule.isHidden()) {
            return;
        }
        HudRenderModule hudRender = this.hudRenderModules.get(toggleModule.getId());
        if (hudRender != null) {
            hudRender.draw(event.getContext(), drawnCount);
        }
    }

    @EventListener
    public void onDeath(EntityDeathEvent event) {
        if (event.getEntity() == HUDModule.mc.field_1724) {
            this.hudRenderPotions.clear();
        }
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        this.hudRenderPotions.clear();
    }

    @EventListener
    public void onRenderOpenChat(RenderOpenChatEvent event) {
        event.cancel();
        event.setAnimation((float)this.chatOpenAnimation.getFactor());
    }

    @EventListener
    public void onRenderOverlayPost(RenderOverlayEvent.Post event) {
        if (this.hudRenderModules.isEmpty()) {
            for (Module module : Managers.MODULE.getModules()) {
                if (!(module instanceof ToggleModule)) continue;
                ToggleModule toggleModule = (ToggleModule)module;
                this.hudRenderModules.put(module.getId(), new HudRenderModule(toggleModule));
            }
        }
        int updates = class_3532.method_15340((int)Math.round(240.0f / (float)mc.method_47599()), (int)1, (int)10);
        for (int i = 0; i < updates; ++i) {
            for (HudRenderModule hudRenderModule : this.hudRenderModules.values()) {
                hudRenderModule.updateAnimation();
            }
        }
        this.fpsCounter.updateCounter();
        if (HUDModule.mc.field_1724 != null && HUDModule.mc.field_1687 != null) {
            for (Map.Entry<PotionData, Animation> entry : this.hudRenderPotions.entrySet()) {
                PotionData effectInstance = entry.getKey();
                Animation animation = entry.getValue();
                effectInstance.update();
                if (HUDModule.mc.field_1724.method_6112(effectInstance.getType()) != null || !(animation.getFactor() < (double)0.01f)) continue;
                this.hudRenderPotions.remove(effectInstance);
            }
            if (HUDModule.mc.field_1690.field_1842) {
                return;
            }
            class_1041 res = mc.method_22683();
            if (this.serverStatusConfig.getValue().booleanValue()) {
                this.statusAnimation.setState(this.serverStatus.passed(1000));
                String warning = String.format("\u00a7fServer not responding \u00a77(\u00a7r%s.s\u00a77)", this.decimal.format((double)this.serverStatus.getElapsedTime() / 1000.0));
                int width = RenderManager.textWidth(warning);
                Color color = ColorUtil.interpolateColor(class_3532.method_15363((float)(((float)this.serverStatus.getElapsedTime() - 1000.0f) / 5000.0f), (float)0.0f, (float)1.0f), Color.RED, Color.GREEN);
                int alpha = (int)(255.0 * this.statusAnimation.getFactor());
                RenderManager.renderText(event.getContext(), warning, (float)res.method_4486() / 2.0f - (float)width / 2.0f, 4.0f, ColorUtil.fixTransparency(color.getRGB(), alpha));
            }
            this.rainbowOffset = 0L;
            this.topRight = this.topLeft = 2.0f;
            this.bottomRight = this.bottomLeft = (float)res.method_4502() - 11.0f;
            this.renderingUp = this.renderingConfig.getValue() == Rendering.UP;
            this.bottomLeft -= (float)(14.0 * this.chatOpenAnimation.getFactor());
            this.bottomRight -= (float)(14.0 * this.chatOpenAnimation.getFactor());
            if (this.potionHudConfig.getValue() == VanillaHud.MOVE && !HUDModule.mc.field_1724.method_6026().isEmpty()) {
                this.topRight += 27.0f;
            }
            List<Module> modules = Managers.MODULE.getModules();
            long drawnCount = modules.stream().filter(ToggleModule.class::isInstance).map(ToggleModule.class::cast).filter(m -> !m.isHidden()).count();
            if (this.logoConfig.getValue().booleanValue()) {
                float scale = this.logoScaleConfig.getValue().floatValue();
                float width = 1057.0f * scale;
                float height = 384.0f * scale;
                float alpha = (float)this.logoOpacityConfig.getValue().intValue() / 255.0f;
                int logoColor = this.getHudColor(drawnCount - this.rainbowOffset);
                float logoRed = (float)(logoColor >> 16 & 0xFF) / 255.0f;
                float logoGreen = (float)(logoColor >> 8 & 0xFF) / 255.0f;
                float logoBlue = (float)(logoColor & 0xFF) / 255.0f;
                RenderManager.rectTextured(event.getContext().method_51448(), LOGO_TEXTURE, 2.0f, 2.0f + width, this.topLeft, this.topLeft + height, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, logoRed, logoGreen, logoBlue, alpha);
                this.topLeft += height + 2.0f;
            }
            if (this.watermarkConfig.getValue().booleanValue()) {
                RenderManager.renderText(event.getContext(), String.format("%s %s", "Hachimi", "2.0"), 2.0f, this.topLeft, this.getHudColor(drawnCount - this.rainbowOffset));
                this.topLeft += (float)RenderManager.textHeight();
            }
            if (this.userInfo.getValue().booleanValue()) {
                RenderManager.renderText(event.getContext(), String.format("UID %s", "1"), 2.0f, this.topLeft, this.getHudColor(drawnCount - this.rainbowOffset));
                this.topLeft += (float)RenderManager.textHeight();
            }
            if (this.arraylistConfig.getValue().booleanValue()) {
                Stream<ToggleModule> moduleStream = modules.stream().filter(ToggleModule.class::isInstance).map(ToggleModule.class::cast);
                moduleStream = switch (this.orderingConfig.getValue().ordinal()) {
                    default -> throw new MatchException(null, null);
                    case 1 -> StreamUtils.sortCached(moduleStream, ConfigContainer::getName);
                    case 0 -> StreamUtils.sortCached(moduleStream, m -> -RenderManager.textWidth(this.getFormattedModule((Module)m)));
                };
                moduleStream.forEach(t -> this.arrayListRenderModule(event, (ToggleModule)t, drawnCount));
            }
            if (this.coordsConfig.getValue().booleanValue()) {
                double x = HUDModule.mc.field_1724.method_23317();
                double y = HUDModule.mc.field_1724.method_23318();
                double z = HUDModule.mc.field_1724.method_23321();
                boolean nether = HUDModule.mc.field_1687.method_27983() == class_1937.field_25180;
                RenderManager.renderText(event.getContext(), String.format("XYZ \u00a7f%s, %s, %s " + (this.netherCoordsConfig.getValue() != false ? "\u00a77[\u00a7f%s, %s\u00a77]" : ""), this.decimal.format(x), this.decimal.format(y), this.decimal.format(z), nether ? this.decimal.format(x * 8.0) : this.decimal.format(x / 8.0), nether ? this.decimal.format(z * 8.0) : this.decimal.format(z / 8.0)), 2.0f, this.bottomLeft, this.getHudColor(this.rainbowOffset));
                this.bottomLeft -= (float)RenderManager.textHeight();
            }
            if (this.directionConfig.getValue().booleanValue()) {
                class_2350 direction = HUDModule.mc.field_1724.method_5735();
                String dir = EnumFormatter.formatDirection(direction);
                String axis = EnumFormatter.formatAxis(direction.method_10166());
                boolean pos = direction.method_10171() == class_2350.class_2352.field_11056;
                String rotationText = String.format(", %s", (int)class_3532.method_15393((float)Managers.ROTATION.getServerYaw()));
                RenderManager.renderText(event.getContext(), String.format("%s \u00a77[\u00a7f%s%s%s\u00a77]", dir, axis, pos ? "+" : "-", this.rotationConfig.getValue() != false ? rotationText : ""), 2.0f, this.bottomLeft, this.getHudColor(this.rainbowOffset));
            }
            if (this.potionEffectsConfig.getValue().booleanValue()) {
                for (Map.Entry<PotionData, Animation> e1 : this.hudRenderPotions.entrySet()) {
                    String duration;
                    boolean amplifier;
                    PotionData e = e1.getKey();
                    Animation animation = e1.getValue();
                    class_1291 effect = (class_1291)e.getType().comp_349();
                    if (effect == class_1294.field_5925) continue;
                    boolean infinite = e.getDuration() == -1;
                    boolean bl = amplifier = e.getAmplifier() + 1 > 1 && !infinite;
                    if (infinite) {
                        duration = "Inf";
                    } else {
                        int i = class_3532.method_15375((float)e.getDuration());
                        duration = class_3544.method_15439((int)i, (float)HUDModule.mc.field_1687.method_54719().method_54748());
                    }
                    String text = String.format("%s %s\u00a7f%s", effect.method_5560().getString(), amplifier ? e.getAmplifier() + 1 + " " : "", duration);
                    int width = RenderManager.textWidth(text);
                    float x = ((float)width + 1.0f) * (float)animation.getFactor();
                    int potionColor = switch (this.potionColorsConfig.getValue().ordinal()) {
                        default -> throw new MatchException(null, null);
                        case 0 -> ColorUtil.withAlpha(effect.method_5556(), (int)(255.0 * animation.getFactor()));
                        case 1 -> ColorUtil.withAlpha(this.getLiquidColor(e.getType().method_55840(), effect), (int)(255.0 * animation.getFactor()));
                        case 2 -> ColorUtil.withAlpha(this.getHudColor(this.rainbowOffset), (int)(255.0 * animation.getFactor()));
                    };
                    RenderManager.renderText(event.getContext(), text, (float)res.method_4486() - x, this.renderingUp ? this.bottomRight : this.topRight, ColorUtil.fixTransparency(potionColor, (float)animation.getFactor()));
                    if (this.renderingUp) {
                        this.bottomRight -= (float)RenderManager.textHeight();
                    } else {
                        this.topRight += (float)RenderManager.textHeight();
                    }
                    ++this.rainbowOffset;
                }
            }
            if (this.serverBrandConfig.getValue().booleanValue()) {
                String brand = HUDModule.mc.field_1724.field_3944.method_52790();
                int width = RenderManager.textWidth(brand);
                RenderManager.renderText(event.getContext(), brand, (float)(res.method_4486() - width) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, this.getHudColor(this.rainbowOffset));
                if (this.renderingUp) {
                    this.bottomRight -= (float)RenderManager.textHeight();
                } else {
                    this.topRight += (float)RenderManager.textHeight();
                }
                ++this.rainbowOffset;
            }
            if (this.potionTimerConfig.getValue().booleanValue()) {
                StringBuilder sb = new StringBuilder();
                int resCount = 0;
                block14: for (int i = 0; i < 36; ++i) {
                    class_1799 stack = HUDModule.mc.field_1724.method_31548().method_5438(i);
                    if (stack.method_7909() != class_1802.field_8436) continue;
                    class_1844 contents = (class_1844)stack.method_57825(class_9334.field_49651, (Object)class_1844.field_49274);
                    for (class_1293 fx : contents.method_57397()) {
                        if (!fx.method_5579().equals((Object)class_1294.field_5907)) continue;
                        ++resCount;
                        continue block14;
                    }
                }
                if (resCount > 0) {
                    sb.append("\u00a7e").append(resCount);
                }
                if (HUDModule.mc.field_1724.method_6059(class_1294.field_5907)) {
                    boolean levelOk;
                    class_1293 fx = HUDModule.mc.field_1724.method_6112(class_1294.field_5907);
                    boolean bl = levelOk = this.potionTimerResLvlConfig.getValue() == false || fx.method_5578() > 0;
                    if (levelOk) {
                        if (!sb.isEmpty()) {
                            sb.append(" ");
                        }
                        sb.append("\u00a79").append(fx.method_5584() / 20 + 1);
                    }
                }
                if (HUDModule.mc.field_1724.method_6059(class_1294.field_5910)) {
                    if (!sb.isEmpty()) {
                        sb.append(" ");
                    }
                    sb.append("\u00a74").append(HUDModule.mc.field_1724.method_6112(class_1294.field_5910).method_5584() / 20 + 1);
                }
                if (HUDModule.mc.field_1724.method_6059(class_1294.field_5904)) {
                    if (!sb.isEmpty()) {
                        sb.append(" ");
                    }
                    sb.append("\u00a7b").append(HUDModule.mc.field_1724.method_6112(class_1294.field_5904).method_5584() / 20 + 1);
                }
                if (!sb.isEmpty()) {
                    String txt = sb.toString();
                    int sw = res.method_4486();
                    int sh = res.method_4502();
                    int tx = sw / 2 - HUDModule.mc.field_1772.method_1727(txt) / 2;
                    int n = sh / 2;
                    Objects.requireNonNull(HUDModule.mc.field_1772);
                    int ty = n + 9 - this.potionTimerYOffsetConfig.getValue();
                    event.getContext().method_25303(HUDModule.mc.field_1772, txt, tx, ty, -1);
                }
            }
            if (this.speedConfig.getValue() != SpeedHud.OFF) {
                double speed;
                float timer;
                double x = HUDModule.mc.field_1724.method_23317() - HUDModule.mc.field_1724.field_6014;
                double z = HUDModule.mc.field_1724.method_23321() - HUDModule.mc.field_1724.field_5969;
                float f = timer = TimerModule.getInstance().isEnabled() ? TimerModule.getInstance().getTimer() : 1.0f;
                if (this.speedConfig.getValue() == SpeedHud.K_M_H) {
                    dist = Math.sqrt(x * x + z * z) / 1000.0;
                    double div = 1.388888888888889E-5;
                    speed = dist / div * (double)timer;
                } else {
                    dist = Math.sqrt((x *= 20.0) * x + (z *= 20.0) * z);
                    speed = Math.abs(dist) * (double)timer;
                }
                String text = String.format("Speed \u00a7f%s%s", this.decimal2.format(speed), this.speedConfig.getValue() == SpeedHud.K_M_H ? "km/h" : "b/s");
                int width = RenderManager.textWidth(text);
                RenderManager.renderText(event.getContext(), text, (float)(res.method_4486() - width) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, this.getHudColor(this.rainbowOffset));
                if (this.renderingUp) {
                    this.bottomRight -= (float)RenderManager.textHeight();
                } else {
                    this.topRight += (float)RenderManager.textHeight();
                }
                ++this.rainbowOffset;
            }
            if (this.durabilityConfig.getValue().booleanValue() && HUDModule.mc.field_1724.method_6047().method_7963()) {
                int n = HUDModule.mc.field_1724.method_6047().method_7936();
                int n2 = HUDModule.mc.field_1724.method_6047().method_7919();
                String text1 = "Durability ";
                String text2 = String.valueOf(n - n2);
                int width = RenderManager.textWidth(text1);
                int width2 = RenderManager.textWidth(text2);
                Color color = ColorUtil.hslToColor((float)(n - n2) / (float)n * 120.0f, 100.0f, 50.0f, 1.0f);
                RenderManager.renderText(event.getContext(), text1, (float)(res.method_4486() - width - width2) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, this.getHudColor(this.rainbowOffset));
                RenderManager.renderText(event.getContext(), text2, (float)(res.method_4486() - width2) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, color.getRGB());
                if (this.renderingUp) {
                    this.bottomRight -= (float)RenderManager.textHeight();
                } else {
                    this.topRight += (float)RenderManager.textHeight();
                }
                ++this.rainbowOffset;
            }
            if (this.pingConfig.getValue().booleanValue() && !mc.method_1542()) {
                int latency = FastLatencyModule.getInstance().isEnabled() ? (int)FastLatencyModule.getInstance().getLatency() : Managers.NETWORK.getClientLatency();
                String text = String.format("Ping \u00a7f%dms", latency);
                int width = RenderManager.textWidth(text);
                RenderManager.renderText(event.getContext(), text, (float)(res.method_4486() - width) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, this.getHudColor(this.rainbowOffset));
                if (this.renderingUp) {
                    this.bottomRight -= (float)RenderManager.textHeight();
                } else {
                    this.topRight += (float)RenderManager.textHeight();
                }
                ++this.rainbowOffset;
            }
            if (this.packetsConfig.getValue().booleanValue()) {
                String text = String.format("Packets \u00a7f%s<-%s", Managers.NETWORK.getOutgoingPPS(), Managers.NETWORK.getIncomingPPS());
                int width = RenderManager.textWidth(text);
                RenderManager.renderText(event.getContext(), text, (float)(res.method_4486() - width) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, this.getHudColor(this.rainbowOffset));
                if (this.renderingUp) {
                    this.bottomRight -= (float)RenderManager.textHeight();
                } else {
                    this.topRight += (float)RenderManager.textHeight();
                }
                ++this.rainbowOffset;
            }
            if (this.tpsConfig.getValue().booleanValue()) {
                float curr = Managers.TICK.getTpsCurrent();
                float avg = Managers.TICK.getTpsAverage();
                String text = String.format("TPS \u00a7f%s \u00a77[\u00a7f%s\u00a77]", this.decimal2.format(curr) + (Managers.TICK.isTicksFilled() ? "" : "*"), this.decimal2.format(avg));
                int width = RenderManager.textWidth(text);
                RenderManager.renderText(event.getContext(), text, (float)(res.method_4486() - width) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, this.getHudColor(this.rainbowOffset));
                if (this.renderingUp) {
                    this.bottomRight -= (float)RenderManager.textHeight();
                } else {
                    this.topRight += (float)RenderManager.textHeight();
                }
                ++this.rainbowOffset;
            }
            if (this.chestsConfig.getValue().booleanValue()) {
                int singleChests = 0;
                int doubleChests = 0;
                for (class_2586 blockEntity : BlockUtil.blockEntities()) {
                    class_2680 state;
                    if (!(blockEntity instanceof class_2595) || !(state = blockEntity.method_11010()).method_28498((class_2769)class_2281.field_10770)) continue;
                    class_2745 chestType = (class_2745)state.method_11654((class_2769)class_2281.field_10770);
                    if (chestType == class_2745.field_12569) {
                        ++singleChests;
                        continue;
                    }
                    ++doubleChests;
                }
                String text = String.format("Chests \u00a7f%d", singleChests + doubleChests / 2);
                int width = RenderManager.textWidth(text);
                RenderManager.renderText(event.getContext(), text, (float)(res.method_4486() - width) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, this.getHudColor(this.rainbowOffset));
                if (this.renderingUp) {
                    this.bottomRight -= (float)RenderManager.textHeight();
                } else {
                    this.topRight += (float)RenderManager.textHeight();
                }
                ++this.rainbowOffset;
            }
            if (this.fpsConfig.getValue().booleanValue()) {
                String text = String.format("FPS \u00a7f%d", this.fpsCounter.getPerSecond());
                int width = RenderManager.textWidth(text);
                RenderManager.renderText(event.getContext(), text, (float)(res.method_4486() - width) - 1.0f, this.renderingUp ? this.bottomRight : this.topRight, this.getHudColor(this.rainbowOffset));
                ++this.rainbowOffset;
            }
            if (this.armorConfig.getValue().booleanValue()) {
                class_1297 riding = HUDModule.mc.field_1724.method_5854();
                int x = res.method_4486() / 2 + 15;
                int y = res.method_4502();
                int n1 = HUDModule.mc.field_1724.method_5748();
                int n2 = Math.min(HUDModule.mc.field_1724.method_5669(), n1);
                if (HUDModule.mc.field_1724.method_5777(class_3486.field_15517) || n2 < n1) {
                    y -= 65;
                } else if (riding instanceof class_1309) {
                    class_1309 entity = (class_1309)riding;
                    y -= 45 + (int)Math.ceil((entity.method_6063() - 1.0f) / 20.0f) * 10;
                } else {
                    y = HUDModule.mc.field_1724.method_7337() ? (y -= 45) : (y -= 55);
                }
                for (int i = 3; i >= 0; --i) {
                    class_1799 armor = (class_1799)HUDModule.mc.field_1724.method_31548().field_7548.get(i);
                    int f = armor.method_7936();
                    int f2 = armor.method_7919();
                    event.getContext().method_51427(armor, x, y);
                    event.getContext().method_51431(HUDModule.mc.field_1772, armor, x, y);
                    if (this.armorDurabilityConfig.getValue().booleanValue() && !armor.method_7960()) {
                        event.getContext().method_51448().method_22905(0.65f, 0.65f, 1.0f);
                        RenderManager.renderText(event.getContext(), Math.round((float)(f - f2) / (float)f * 100.0f) + "%", ((float)x + 2.0f) * 1.5384616f, ((float)y - 5.0f) * 1.5384616f, ColorUtil.hslToColor((float)(f - f2) / (float)f * 120.0f, 100.0f, 50.0f, 1.0f).getRGB());
                        event.getContext().method_51448().method_22905(1.5384616f, 1.5384616f, 1.0f);
                    }
                    x += 18;
                }
            }
            if (this.totemsConfig.getValue().booleanValue() && !HUDModule.mc.field_1724.method_7337() && !HUDModule.mc.field_1724.method_7325()) {
                int x = res.method_4486() / 2 - 8;
                int y = res.method_4502() - 55;
                event.getContext().method_51427(new class_1799((class_1935)class_1802.field_8288), x, y - 1);
                String totems = String.valueOf(InventoryUtil.count(class_1802.field_8288));
                event.getContext().method_51448().method_22905(0.75f, 0.75f, 1.0f);
                event.getContext().method_51448().method_46416(0.0f, 0.0f, 200.0f);
                RenderManager.renderText(event.getContext(), totems, (float)(x + 19 - RenderManager.textWidth(totems)) * 1.333333f, (float)(y + 9) * 1.333333f, -1);
                event.getContext().method_51448().method_22905(1.333333f, 1.333333f, 1.0f);
            }
        }
    }

    @EventListener
    public void onStatusEffectAdd(StatusEffectEvent.Add event) {
        class_1293 instance = event.getStatusEffect();
        PotionData data = new PotionData((class_6880<class_1291>)instance.method_5579(), instance.method_5578(), instance.method_5584());
        if (this.hudRenderPotions.keySet().removeIf(d -> data.getType() == d.getType())) {
            this.hudRenderPotions.put(data, new Animation(true, 250.0f, Easing.SINE_IN_OUT));
        } else {
            Animation anim = new Animation(false, 250.0f, Easing.SINE_IN_OUT);
            anim.setState(true);
            this.hudRenderPotions.put(data, anim);
        }
    }

    @EventListener
    public void onStatusEffectRemove(StatusEffectEvent.Remove event) {
        for (PotionData data : this.hudRenderPotions.keySet()) {
            if (!data.getType().equals(event.getType())) continue;
            this.hudRenderPotions.get(data).setState(false);
            break;
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        this.serverStatus.reset();
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (HUDModule.mc.field_1687 == null || mc.method_1493()) {
            this.serverStatus.reset();
        }
    }

    @EventListener
    public void onChatOpen(ScreenOpenEvent event) {
        if (event.getScreen() == null && this.chatOpenAnimation.getState()) {
            this.chatOpenAnimation.setState(false);
        } else if (event.getScreen() instanceof class_408) {
            this.chatOpenAnimation.setState(true);
        }
    }

    @EventListener
    public void onRenderOverlayStatusEffect(RenderOverlayEvent.StatusEffect event) {
        if (this.potionHudConfig.getValue() == VanillaHud.HIDE) {
            event.cancel();
        }
    }

    @EventListener
    public void onRenderOverlayItemName(RenderOverlayEvent.ItemName event) {
        if (this.itemNameConfig.getValue() != VanillaHud.KEEP) {
            event.cancel();
        }
        if (this.itemNameConfig.getValue() == VanillaHud.MOVE) {
            boolean armor;
            class_1041 window = mc.method_22683();
            int x = window.method_4486() / 2 - 90;
            int y = window.method_4502() - 49;
            boolean bl = armor = !HUDModule.mc.field_1724.method_31548().field_7548.isEmpty();
            if (HUDModule.mc.field_1724.method_6067() > 0.0f) {
                y -= 9;
            }
            if (armor) {
                y -= 9;
            }
            event.setX(x);
            event.setY(y);
        }
    }

    private int getHudColor(long rainbowOffset) {
        return switch (this.rainbowModeConfig.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> ColorsModule.getInstance().getRGB();
            case 3 -> this.rainbow(1L);
            case 2 -> this.rainbow(rainbowOffset);
            case 1 -> {
                float speed = Math.max(100.0f - this.rainbowSpeedConfig.getValue().floatValue(), 0.1f);
                float difference = Math.max(100.0f - this.rainbowDifferenceConfig.getValue().floatValue(), 0.1f);
                double roundY = Math.sin(Math.toRadians((double)((float)rainbowOffset * difference) + (double)System.currentTimeMillis() / (double)speed));
                roundY = Math.abs(roundY);
                yield ColorUtil.interpolateColor((float)class_3532.method_15350((double)roundY, (double)0.0, (double)1.0), ColorsModule.getInstance().getColor(), this.gradientColorConfig.getValue()).getRGB();
            }
        };
    }

    private String getFormattedModule(Module module) {
        return module.getName() + this.getFormattedModuleData(module.getModuleData());
    }

    private String getFormattedModuleData(String metadata) {
        if (metadata == null || metadata.equals("ARRAYLIST_INFO")) {
            return "";
        }
        return " \u00a77[\u00a7f" + metadata + "\u00a77]";
    }

    public int getLiquidColor(String name, class_1291 effect) {
        return switch (name.replace("minecraft:", "")) {
            case "speed" -> 8171462;
            case "slowness" -> 5926017;
            case "haste" -> 14270531;
            case "mining_fatigue" -> 4866583;
            case "strength" -> 9643043;
            case "instant_health" -> 16262179;
            case "instant_damage" -> 4393481;
            case "jump_boost" -> 2293580;
            case "nausea" -> 5578058;
            case "regeneration" -> 13458603;
            case "resistance" -> 10044730;
            case "fire_resistance" -> 14981690;
            case "water_breathing" -> 3035801;
            case "invisibility" -> 8356754;
            case "blindness" -> 2039587;
            case "night_vision" -> 0x1F1FA1;
            case "hunger" -> 5797459;
            case "weakness" -> 0x484D48;
            case "poison" -> 5149489;
            case "wither" -> 3484199;
            case "health_boost" -> 16284963;
            case "absorption" -> 0x2552A5;
            case "saturation" -> 16262179;
            case "glowing" -> 9740385;
            case "levitation" -> 0xCEFFFF;
            case "luck" -> 0x339900;
            case "unluck" -> 12624973;
            default -> effect.method_5556();
        };
    }

    private int rainbow(long offset) {
        float hue = (float)(((double)System.currentTimeMillis() * (double)(this.rainbowSpeedConfig.getValue().floatValue() / 10.0f) + (double)(offset * 500L)) % (double)(30000.0f / (this.rainbowDifferenceConfig.getValue().floatValue() / 100.0f)) / (double)(30000.0f / (this.rainbowDifferenceConfig.getValue().floatValue() / 20.0f)));
        return Color.HSBtoRGB(hue, (float)this.rainbowSaturationConfig.getValue().intValue() / 100.0f, (float)this.rainbowBrightnessConfig.getValue().intValue() / 100.0f);
    }

    public int alpha(long offset) {
        float[] hsb = new float[3];
        Color color = ColorsModule.getInstance().getColor();
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), hsb);
        float b = (float)(((double)System.currentTimeMillis() * (double)(this.rainbowSpeedConfig.getValue().floatValue() / 10.0f) + (double)(offset * 500L)) % (double)(30000.0f / (this.rainbowDifferenceConfig.getValue().floatValue() / 100.0f)) / (double)(30000.0f / (this.rainbowDifferenceConfig.getValue().floatValue() / 20.0f)));
        float brightness = hsb[2] * Math.abs(b % 1.0f - 0.55f) + 0.4f;
        return Color.HSBtoRGB(hsb[0], hsb[1], brightness);
    }

    public float getChatAnimation() {
        return (float)this.chatOpenAnimation.getFactor();
    }

    static {
        LOGO_TEXTURE = class_2960.method_60655((String)"hachimiclient", (String)"textures/white.png");
    }

    public static enum VanillaHud {
        MOVE,
        HIDE,
        KEEP;

    }

    public static enum PotionColors {
        NORMAL,
        OLD,
        OFF;

    }

    public static enum SpeedHud {
        K_M_H,
        B_P_S,
        OFF;

    }

    public static enum Ordering {
        LENGTH,
        ALPHABETICAL;

    }

    public static enum Rendering {
        UP,
        DOWN;

    }

    public static enum RainbowMode {
        OFF,
        GRADIENT,
        GRADIENT_HUE,
        STATIC_HUE;

    }

    public class HudRenderModule {
        private final ToggleModule module;
        private double x;
        private long startTime;
        private double endpoint;
        private int prevTextWidth;
        private boolean wasDrawing;

        public HudRenderModule(ToggleModule module) {
            this.module = module;
        }

        public void updateAnimation() {
            boolean drawing;
            String text = HUDModule.this.getFormattedModule(this.module);
            int textWidth = RenderManager.textWidth(text);
            boolean bl = drawing = this.module.isEnabled() && !this.module.isHidden();
            if (drawing != this.wasDrawing || this.prevTextWidth != textWidth) {
                this.startTime = System.currentTimeMillis();
                this.endpoint = drawing ? (double)((float)(-textWidth) - 2.0f) : 2.0;
                this.wasDrawing = drawing;
                this.prevTextWidth = textWidth;
            }
            double animationProgress = Math.min((double)((float)(System.currentTimeMillis() - this.startTime) / (float)HUDModule.this.animTimeConfig.getValue().intValue()), 1.0);
            double factor = Easing.BOUNCE_IN_OUT.ease(animationProgress);
            this.x = this.x * (1.0 - factor) + this.endpoint * factor;
        }

        public void draw(class_332 context, long drawnCount) {
            int color = ColorUtil.fixTransparency(HUDModule.this.getHudColor(drawnCount - HUDModule.this.rainbowOffset), (float)this.module.getAnimation().getFactor());
            RenderManager.renderText(context, HUDModule.this.getFormattedModule(this.module), (float)Globals.mc.method_22683().method_4486() + (float)this.x, HUDModule.this.renderingUp ? HUDModule.this.topRight : HUDModule.this.bottomRight, color);
            if (HUDModule.this.renderingUp) {
                HUDModule.this.topRight += (float)RenderManager.textHeight();
            } else {
                HUDModule.this.bottomRight -= (float)RenderManager.textHeight();
            }
            ++HUDModule.this.rainbowOffset;
        }
    }

    public static class PotionData
    implements Comparable<PotionData> {
        private final class_6880<class_1291> type;
        private final int amplifier;
        private int duration;

        public PotionData(class_6880<class_1291> type, int amplifier, int duration) {
            this.type = type;
            this.amplifier = amplifier;
            this.duration = duration;
        }

        public void update() {
            class_1293 instance = Globals.mc.field_1724.method_6112(this.type);
            if (instance != null) {
                this.duration = instance.method_5584();
            }
        }

        public String getPotionName() {
            return ((class_1291)this.getType().comp_349()).method_5560().getString();
        }

        public class_6880<class_1291> getType() {
            return this.type;
        }

        public int getAmplifier() {
            return this.amplifier;
        }

        public int getDuration() {
            return this.duration;
        }

        @Override
        public int compareTo(PotionData other) {
            return other.getPotionName().compareTo(this.getPotionName());
        }
    }
}
