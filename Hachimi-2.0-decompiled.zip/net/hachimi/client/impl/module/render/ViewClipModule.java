package net.hachimi.client.impl.module.render;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.render.CameraClipEvent;
import net.hachimi.eventbus.annotation.EventListener;

public class ViewClipModule
extends ToggleModule {
    Config<Float> distanceConfig = this.register(new NumberConfig<Float>("Distance", "The third-person camera clip distance", Float.valueOf(1.0f), Float.valueOf(3.5f), Float.valueOf(20.0f)));

    public ViewClipModule() {
        super("ViewClip", "Clips your third-person camera through blocks", ModuleCategory.RENDER);
    }

    @EventListener
    public void onCameraClip(CameraClipEvent event) {
        event.cancel();
        event.setDistance(this.distanceConfig.getValue().floatValue());
    }
}
