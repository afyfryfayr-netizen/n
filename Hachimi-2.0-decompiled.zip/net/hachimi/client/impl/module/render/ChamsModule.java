package net.hachimi.client.impl.module.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.api.render.chams.ChamsModelRenderer;
import net.hachimi.client.api.render.model.StaticBipedEntityModel;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.event.render.entity.RenderCrystalEvent;
import net.hachimi.client.impl.event.render.entity.RenderEntityEvent;
import net.hachimi.client.impl.event.render.entity.RenderThroughWallsEvent;
import net.hachimi.client.impl.event.render.item.RenderArmEvent;
import net.hachimi.client.impl.module.player.FreecamModule;
import net.hachimi.client.impl.module.render.NoRenderModule;
import net.hachimi.client.impl.module.render.ShadersModule;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.entity.FakePlayerEntity;
import net.hachimi.client.util.render.ColorUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1477;
import net.minecraft.class_1493;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_3532;
import net.minecraft.class_3887;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_922;

public class ChamsModule
extends ToggleModule {
    private static ChamsModule INSTANCE;
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "The chams render range", Float.valueOf(10.0f), Float.valueOf(50.0f), Float.valueOf(200.0f)));
    Config<ChamsMode> modeConfig = this.register(new EnumConfig("Mode", "The rendering mode for the chams", (Enum)ChamsMode.FILL, (Enum[])ChamsMode.values()));
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "The line width of the render", Float.valueOf(1.0f), Float.valueOf(1.5f), Float.valueOf(5.0f), () -> this.modeConfig.getValue() != ChamsMode.FILL));
    Config<Boolean> wallsConfig = this.register(new BooleanConfig("ThroughWalls", "Renders chams through walls", true, () -> this.modeConfig.getValue() != ChamsMode.NORMAL));
    Config<Boolean> textureConfig = this.register(new BooleanConfig("Texture", "Renders the entity model texture", false, () -> this.wallsConfig.getValue() != false && this.modeConfig.getValue() != ChamsMode.NORMAL));
    Config<Boolean> playersConfig = this.register(new BooleanConfig("Players", "Render chams on other players", true));
    Config<Boolean> selfConfig = this.register(new BooleanConfig("Self", "Render chams on the player", true));
    Config<Boolean> handsConfig = this.register(new BooleanConfig("Hands", "Render chams on first-person hands", true));
    Config<Boolean> monstersConfig = this.register(new BooleanConfig("Monsters", "Render chams on monsters", true));
    Config<Boolean> animalsConfig = this.register(new BooleanConfig("Animals", "Render chams on animals", true));
    Config<Boolean> crystalsConfig = this.register(new BooleanConfig("Crystals", "Render chams on crystals", true));
    Config<Boolean> popsConfig = this.register(new BooleanConfig("Pops", "Render chams on totem pops", false));
    Config<Integer> fadeTimeConfig = this.register(new NumberConfig<Integer>("Fade-Time", "Timer for the fade", Integer.valueOf(0), Integer.valueOf(1000), Integer.valueOf(3000), () -> false));
    Config<Color> colorConfig = this.register(new ColorConfig("Color", "The color of the chams", new Color(255, 0, 0, 60)));
    private final Map<PopChamEntity, Animation> fadeList = new ConcurrentHashMap<PopChamEntity, Animation>();

    public ChamsModule() {
        super("Chams", "Renders entity models through walls", ModuleCategory.RENDER);
        INSTANCE = this;
    }

    public static ChamsModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        this.fadeList.clear();
    }

    @EventListener
    public void onRenderThroughWalls(RenderThroughWallsEvent event) {
        if (this.modeConfig.getValue() == ChamsMode.NORMAL && this.checkChams(event.getEntity())) {
            event.cancel();
        }
    }

    @EventListener(priority=0x7FFFFFFF)
    public void onRenderWorld(RenderWorldEvent event) {
        RenderBuffers.preRender();
        RenderSystem.disableDepthTest();
        for (Map.Entry<PopChamEntity, Animation> set : new HashSet<Map.Entry<PopChamEntity, Animation>>(this.fadeList.entrySet())) {
            set.getValue().setState(false);
            Color color = this.colorConfig.getValue();
            int boxAlpha = (int)((double)color.getAlpha() * set.getValue().getFactor());
            int lineAlpha = (int)(145.0 * set.getValue().getFactor());
            int boxColor = ColorUtil.withAlpha(color.getRGB(), boxAlpha);
            int lineColor = ColorUtil.withAlpha(color.getRGB(), lineAlpha);
            ChamsModelRenderer.renderStaticPlayerModel(event.getMatrices(), (class_742)set.getKey(), set.getKey().getModel(), event.getTickDelta(), boxColor, lineColor, this.widthConfig.getValue().floatValue(), this.modeConfig.getValue() != ChamsMode.FILL, true, false);
        }
        this.fadeList.entrySet().removeIf(e -> ((Animation)e.getValue()).getFactor() == 0.0);
        RenderBuffers.postRender();
        if (this.modeConfig.getValue() == ChamsMode.NORMAL) {
            return;
        }
        if (ShadersModule.getInstance().isEnabled() && !ShadersModule.getInstance().textureConfig.getValue().booleanValue()) {
            return;
        }
        RenderBuffers.preRender();
        if (!this.wallsConfig.getValue().booleanValue()) {
            RenderSystem.enableDepthTest();
        }
        for (class_1297 entity : ChamsModule.mc.field_1687.method_18112()) {
            class_1309 livingEntity;
            if (NoRenderModule.getInstance().isEnabled() && NoRenderModule.getInstance().shouldSkipEntity(entity)) continue;
            double x = Math.abs(ChamsModule.mc.field_1773.method_19418().method_19326().field_1352 - entity.method_23317());
            double z = Math.abs(ChamsModule.mc.field_1773.method_19418().method_19326().field_1350 - entity.method_23321());
            double d = ((Integer)ChamsModule.mc.field_1690.method_42503().method_41753() + 1) * 16;
            class_243 start = FreecamModule.getInstance().isEnabled() ? FreecamModule.getInstance().getCameraPosition() : ChamsModule.mc.field_1724.method_19538();
            if (start.method_1025(entity.method_19538()) > ((NumberConfig)this.rangeConfig).getValueSq() || x > d || z > d || !RenderManager.isFrustumVisible(entity.method_5829()) || (!(entity instanceof class_1309) || !this.checkChams(livingEntity = (class_1309)entity)) && (!(entity instanceof class_1511) || !this.crystalsConfig.getValue().booleanValue())) continue;
            if (!this.wallsConfig.getValue().booleanValue()) {
                RenderSystem.depthMask((boolean)false);
            }
            this.renderEntityChams(event.getMatrices(), entity, event.getTickDelta());
        }
        RenderBuffers.postRender();
        if (!this.wallsConfig.getValue().booleanValue()) {
            RenderSystem.depthMask((boolean)true);
        }
    }

    @EventListener
    public void onRenderGame(RenderWorldEvent.Hand event) {
        if (this.modeConfig.getValue() == ChamsMode.NORMAL) {
            return;
        }
        if (ShadersModule.getInstance().isEnabled() && !ShadersModule.getInstance().textureConfig.getValue().booleanValue()) {
            return;
        }
        RenderBuffers.preRender();
        if (this.handsConfig.getValue().booleanValue()) {
            int color1 = this.colorConfig.getValue().getRGB();
            int lineColor1 = ColorUtil.withAlpha(color1, 145);
            ChamsModelRenderer.renderHand(event.getMatrices(), event.getTickDelta(), lineColor1, color1, this.widthConfig.getValue().floatValue(), this.modeConfig.getValue() != ChamsMode.FILL, this.modeConfig.getValue() != ChamsMode.WIREFRAME, false);
        }
        RenderBuffers.postRender();
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        class_2663 packet;
        if (ChamsModule.mc.field_1687 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2663 && (packet = (class_2663)class_25962).method_11470() == 35 && this.popsConfig.getValue().booleanValue()) {
            class_1297 entity = packet.method_11469((class_1937)ChamsModule.mc.field_1687);
            if (entity == ChamsModule.mc.field_1724 || !(entity instanceof class_1657)) {
                return;
            }
            class_1657 player = (class_1657)entity;
            Animation animation = new Animation(true, this.fadeTimeConfig.getValue().intValue());
            this.fadeList.put(new PopChamEntity(player, mc.method_60646().method_60637(true)), animation);
        }
    }

    @EventListener
    public void onRenderCrystal(RenderCrystalEvent event) {
        if (this.modeConfig.getValue() == ChamsMode.NORMAL) {
            return;
        }
        if (ChamsModule.mc.field_1724 != null && (!this.textureConfig.getValue().booleanValue() || !this.wallsConfig.getValue().booleanValue()) && this.crystalsConfig.getValue().booleanValue() && ChamsModule.mc.field_1724.method_5858((class_1297)event.endCrystalEntity) <= ((NumberConfig)this.rangeConfig).getValueSq()) {
            event.cancel();
        }
    }

    @EventListener
    public void onRenderEntity(RenderEntityEvent event) {
        float n;
        class_2350 direction;
        class_1297 class_12972;
        if (this.modeConfig.getValue() == ChamsMode.NORMAL) {
            return;
        }
        if (ChamsModule.mc.field_1724 == null || this.textureConfig.getValue().booleanValue() && this.wallsConfig.getValue().booleanValue() || !this.checkChams(event.entity) || ChamsModule.mc.field_1724.method_5858((class_1297)event.entity) > ((NumberConfig)this.rangeConfig).getValueSq()) {
            return;
        }
        event.cancel();
        event.matrixStack.method_22903();
        event.model.field_3447 = event.entity.method_6055(event.g);
        event.model.field_3449 = event.entity.method_5765();
        event.model.field_3448 = event.entity.method_6109();
        float h = class_3532.method_17821((float)event.g, (float)event.entity.field_6220, (float)event.entity.field_6283);
        float j = class_3532.method_17821((float)event.g, (float)event.entity.field_6259, (float)event.entity.field_6241);
        float k = j - h;
        if (event.entity.method_5765() && (class_12972 = event.entity.method_5854()) instanceof class_1309) {
            class_1309 livingEntity2 = (class_1309)class_12972;
            h = class_3532.method_17821((float)event.g, (float)livingEntity2.field_6220, (float)livingEntity2.field_6283);
            k = j - h;
            float l = class_3532.method_15393((float)k);
            if (l < -85.0f) {
                l = -85.0f;
            }
            if (l >= 85.0f) {
                l = 85.0f;
            }
            h = j - l;
            if (l * l > 2500.0f) {
                h += l * 0.2f;
            }
            k = j - h;
        }
        float m = class_3532.method_16439((float)event.g, (float)event.entity.field_6004, (float)event.entity.method_36455());
        if (class_922.method_38563((class_1309)event.entity)) {
            m *= -1.0f;
            k *= -1.0f;
        }
        if (event.entity.method_41328(class_4050.field_18078) && (direction = event.entity.method_18401()) != null) {
            n = event.entity.method_18381(class_4050.field_18076) - 0.1f;
            event.matrixStack.method_46416((float)(-direction.method_10148()) * n, 0.0f, (float)(-direction.method_10165()) * n);
        }
        float l = this.getAnimationProgress(event.entity, event.g);
        if (event.entity instanceof class_1657) {
            ChamsModelRenderer.setupPlayerTransforms((class_742)event.entity, event.matrixStack, l, h, event.g);
        } else {
            ChamsModelRenderer.setupTransforms(event.entity, event.matrixStack, l, h, event.g);
        }
        event.matrixStack.method_22905(-1.0f, -1.0f, 1.0f);
        event.matrixStack.method_22905(0.9375f, 0.9375f, 0.9375f);
        event.matrixStack.method_46416(0.0f, -1.501f, 0.0f);
        n = 0.0f;
        float o = 0.0f;
        if (!event.entity.method_5765() && event.entity.method_5805()) {
            n = event.entity.field_42108.method_48570(event.g);
            o = event.entity.field_42108.method_48572(event.g);
            if (event.entity.method_6109()) {
                o *= 3.0f;
            }
            if (n > 1.0f) {
                n = 1.0f;
            }
        }
        event.model.method_2816((class_1297)event.entity, o, n, event.g);
        event.model.method_2819((class_1297)event.entity, o, n, l, k, m);
        if (!event.entity.method_7325()) {
            for (class_3887 featureRenderer : event.features) {
                featureRenderer.method_4199(event.matrixStack, event.vertexConsumerProvider, event.i, (class_1297)event.entity, o, n, event.g, l, k, m);
            }
        }
        event.matrixStack.method_22909();
    }

    @EventListener
    public void onRenderArm(RenderArmEvent event) {
        if (this.modeConfig.getValue() == ChamsMode.NORMAL) {
            return;
        }
        if (this.handsConfig.getValue().booleanValue() && !this.textureConfig.getValue().booleanValue()) {
            event.cancel();
        }
    }

    public void renderEntityChams(class_4587 matrixStack, class_1297 entity, float tickDelta) {
        int color1 = this.colorConfig.getValue().getRGB();
        int lineColor1 = ColorUtil.withAlpha(color1, 145);
        this.renderEntityChams(matrixStack, entity, tickDelta, color1, lineColor1);
    }

    public void renderEntityChams(class_4587 matrixStack, class_1297 entity, float tickDelta, int color, int lineColor) {
        ChamsModelRenderer.render(matrixStack, entity, tickDelta, color, lineColor, this.widthConfig.getValue().floatValue(), this.modeConfig.getValue() != ChamsMode.FILL, this.modeConfig.getValue() != ChamsMode.WIREFRAME, false);
    }

    private float getAnimationProgress(class_1309 entity, float f) {
        float f2;
        if (entity instanceof class_1477) {
            return class_3532.method_16439((float)f, (float)((class_1477)entity).field_6900, (float)((class_1477)entity).field_6904);
        }
        if (entity instanceof class_1493) {
            class_1493 wolf = (class_1493)entity;
            f2 = wolf.method_6714();
        } else {
            f2 = (float)entity.field_6012 + f;
        }
        return f2;
    }

    public boolean checkChams(class_1309 entity) {
        if (entity instanceof class_1657) {
            if (entity == ChamsModule.mc.field_1724) {
                return this.selfConfig.getValue() != false && (!ChamsModule.mc.field_1690.method_31044().method_31034() || FreecamModule.getInstance().isEnabled());
            }
            return this.playersConfig.getValue();
        }
        return EntityUtil.isMonster((class_1297)entity) && this.monstersConfig.getValue() != false || (EntityUtil.isNeutral((class_1297)entity) || EntityUtil.isPassive((class_1297)entity)) && this.animalsConfig.getValue() != false;
    }

    public static enum ChamsMode {
        NORMAL,
        FILL,
        WIREFRAME,
        WIRE_FILL;

    }

    public static class PopChamEntity
    extends FakePlayerEntity {
        private final StaticBipedEntityModel<class_742> model;

        public PopChamEntity(class_1657 player, float tickDelta) {
            super(player);
            this.model = new StaticBipedEntityModel<class_742>((class_742)player, false, tickDelta);
            this.field_6243 = player.field_6243;
            this.field_6264 = player.field_6243;
            this.method_18380(player.method_18376());
        }

        public StaticBipedEntityModel<class_742> getModel() {
            return this.model;
        }
    }
}
