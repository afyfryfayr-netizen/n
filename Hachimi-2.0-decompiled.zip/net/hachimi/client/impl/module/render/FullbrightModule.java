package net.hachimi.client.impl.module.render;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.config.ConfigUpdateEvent;
import net.hachimi.client.impl.event.network.GameJoinEvent;
import net.hachimi.client.impl.event.render.LightmapGammaEvent;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public class FullbrightModule
extends ToggleModule {
    Config<Brightness> brightnessConfig = this.register(new EnumConfig("Mode", "Mode for world brightness", (Enum)Brightness.GAMMA, (Enum[])Brightness.values()));

    public FullbrightModule() {
        super("Fullbright", "Brightens the world", ModuleCategory.RENDER);
    }

    @Override
    public void onEnable() {
        if (FullbrightModule.mc.field_1724 != null && FullbrightModule.mc.field_1687 != null && this.brightnessConfig.getValue() == Brightness.POTION) {
            FullbrightModule.mc.field_1724.method_6092(new class_1293(class_1294.field_5925, -1, 0));
        }
    }

    @Override
    public void onDisable() {
        if (FullbrightModule.mc.field_1724 != null && FullbrightModule.mc.field_1687 != null && this.brightnessConfig.getValue() == Brightness.POTION) {
            FullbrightModule.mc.field_1724.method_6016(class_1294.field_5925);
        }
    }

    @EventListener
    public void onGameJoin(GameJoinEvent event) {
        this.onDisable();
        this.onEnable();
    }

    @EventListener
    public void onLightmapGamma(LightmapGammaEvent event) {
        if (this.brightnessConfig.getValue() == Brightness.GAMMA) {
            event.cancel();
            event.setGamma(-1);
        }
    }

    @EventListener
    public void onConfigUpdate(ConfigUpdateEvent event) {
        if (FullbrightModule.mc.field_1724 != null && this.brightnessConfig == event.getConfig() && event.getStage() == StageEvent.EventStage.POST && this.brightnessConfig.getValue() != Brightness.POTION) {
            FullbrightModule.mc.field_1724.method_6016(class_1294.field_5925);
        }
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (this.brightnessConfig.getValue() == Brightness.POTION && !FullbrightModule.mc.field_1724.method_6059(class_1294.field_5925)) {
            FullbrightModule.mc.field_1724.method_6092(new class_1293(class_1294.field_5925, -1, 0));
        }
    }

    public static enum Brightness {
        GAMMA,
        POTION;

    }
}
