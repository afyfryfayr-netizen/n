package net.hachimi.client.impl.module.render;

import java.awt.Color;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.particle.BlockBreakParticleEvent;
import net.hachimi.client.impl.event.particle.EmitParticleEvent;
import net.hachimi.client.impl.event.particle.ParticleEvent;
import net.hachimi.client.impl.event.particle.TotemParticleEvent;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_2398;
import net.minecraft.class_3532;

public class ParticlesModule
extends ToggleModule {
    Config<TotemParticle> totemConfig = this.register(new EnumConfig("Totem", "Modify totem particle rendering", (Enum)TotemParticle.OFF, (Enum[])TotemParticle.values()));
    Config<Color> totemColorConfig = this.register(new ColorConfig("TotemColor", "Color of the totem particles", new Color(25, 120, 0), false, false, () -> this.totemConfig.getValue() == TotemParticle.COLOR));
    Config<Integer> totemParticlesConfig = this.register(new NumberConfig<Integer>("TotemParticles", "Max totem particles", Integer.valueOf(3), Integer.valueOf(16), Integer.valueOf(16), () -> this.totemConfig.getValue() != TotemParticle.REMOVE));
    Config<Integer> totemParticleTicksConfig = this.register(new NumberConfig<Integer>("TotemParticleTicks", "Max totem particle ticks", Integer.valueOf(5), Integer.valueOf(30), Integer.valueOf(30), () -> this.totemConfig.getValue() != TotemParticle.REMOVE));
    Config<Boolean> explosionsConfig = this.register(new BooleanConfig("Explosions", "Prevents explosion particles from rendering", true));
    Config<Boolean> fireworkConfig = this.register(new BooleanConfig("Firework", "Prevents rendering of firework particles", false));
    Config<Boolean> potionConfig = this.register(new BooleanConfig("Effects", "Prevents rendering of potion effect particles", true));
    Config<Boolean> itemsConfig = this.register(new BooleanConfig("Items", "Prevents rendering of eating particles", false));
    Config<Boolean> bottleConfig = this.register(new BooleanConfig("BottleSplash", "Prevents rendering of bottle splash particles", true));
    Config<Boolean> portalConfig = this.register(new BooleanConfig("Portal", "Prevents rendering of portal particles", true));
    Config<Boolean> blockConfig = this.register(new BooleanConfig("Block", "Prevents block particles from rendering", false));
    Config<Boolean> blockBreakConfig = this.register(new BooleanConfig("BlockBreak", "Prevents block break particles from rendering", false));
    Config<Boolean> campfiresConfig = this.register(new BooleanConfig("Campfires", "Prevents campfire particles from rendering", false));
    Config<Boolean> obsidianTearConfig = this.register(new BooleanConfig("CryingObsidian", "Prevents obsidian tear particles from rendering", false));

    public ParticlesModule() {
        super("Particles", "Change the rendering of particles", ModuleCategory.RENDER);
    }

    @EventListener
    public void onParticle(ParticleEvent event) {
        if (this.potionConfig.getValue() != false && event.getParticleType() == class_2398.field_11226 || this.explosionsConfig.getValue() != false && (event.getParticleType() == class_2398.field_11236 || event.getParticleType() == class_2398.field_11221) || this.fireworkConfig.getValue() != false && event.getParticleType() == class_2398.field_11248 || this.itemsConfig.getValue() != false && event.getParticleType() == class_2398.field_11218 || this.bottleConfig.getValue() != false && (event.getParticleType() == class_2398.field_11245 || event.getParticleType() == class_2398.field_11213) || this.portalConfig.getValue() != false && event.getParticleType() == class_2398.field_11214 || this.blockConfig.getValue() != false && event.getParticleType() == class_2398.field_11217 || this.campfiresConfig.getValue() != false && event.getParticleType() == class_2398.field_17430 || this.obsidianTearConfig.getValue().booleanValue() && (event.getParticleType() == class_2398.field_22447 || event.getParticleType() == class_2398.field_22446 || event.getParticleType() == class_2398.field_22448)) {
            event.cancel();
        }
    }

    @EventListener
    public void onParticleEmitter(ParticleEvent.Emitter event) {
        if (this.totemConfig.getValue() == TotemParticle.REMOVE && event.getParticleType() == class_2398.field_11220) {
            event.cancel();
        }
    }

    @EventListener
    public void onEmitParticle(EmitParticleEvent event) {
        if (this.totemConfig.getValue() != TotemParticle.REMOVE && event.getParticleType() == class_2398.field_11220) {
            event.cancel();
            event.setParticleCount(this.totemParticlesConfig.getValue());
            event.setParticleTime(this.totemParticleTicksConfig.getValue());
        }
    }

    @EventListener
    public void onTotemParticle(TotemParticleEvent event) {
        if (this.totemConfig.getValue() == TotemParticle.COLOR) {
            event.cancel();
            Color color = this.totemColorConfig.getValue();
            float r = (float)color.getRed() / 255.0f;
            float g = (float)color.getGreen() / 255.0f;
            float b = (float)color.getBlue() / 255.0f;
            if (RANDOM.nextInt(4) == 0) {
                float r2 = (float)color.getRed() * 0.7f / 255.0f;
                float g2 = (float)color.getGreen() * 0.7f / 255.0f;
                float b2 = (float)color.getBlue() * 0.7f / 255.0f;
                event.setColor(new Color(class_3532.method_15363((float)r2, (float)0.0f, (float)1.0f), class_3532.method_15363((float)g2, (float)0.0f, (float)1.0f), class_3532.method_15363((float)b2, (float)0.0f, (float)1.0f)));
            } else {
                event.setColor(new Color(class_3532.method_15363((float)(r + RANDOM.nextFloat() * 0.1f), (float)0.0f, (float)1.0f), class_3532.method_15363((float)(g + RANDOM.nextFloat() * 0.1f), (float)0.0f, (float)1.0f), class_3532.method_15363((float)(b + RANDOM.nextFloat() * 0.1f), (float)0.0f, (float)1.0f)));
            }
        }
    }

    @EventListener
    public void onBlockBreakParticle(BlockBreakParticleEvent event) {
        if (this.blockBreakConfig.getValue().booleanValue()) {
            event.cancel();
        }
    }

    private static enum TotemParticle {
        OFF,
        REMOVE,
        COLOR;

    }
}
