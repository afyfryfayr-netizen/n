package net.hachimi.client.impl.module.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.Interpolation;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.impl.module.client.SocialsModule;
import net.hachimi.client.init.Managers;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1007;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_922;
import org.joml.Quaternionf;

public class SkeletonModule
extends ToggleModule {
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "The line width of the skeleton", Float.valueOf(1.0f), Float.valueOf(1.0f), Float.valueOf(5.0f)));

    public SkeletonModule() {
        super("Skeleton", "Renders a skeleton to show player limbs", ModuleCategory.RENDER);
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent.Game event) {
        class_4587 matrixStack = event.getMatrices();
        float g = event.getTickDelta();
        RenderBuffers.preRender();
        for (class_1297 entity : SkeletonModule.mc.field_1687.method_18112()) {
            if (entity == null || !entity.method_5805() || !(entity instanceof class_1657)) continue;
            class_1657 playerEntity = (class_1657)entity;
            if (SkeletonModule.mc.field_1690.method_31044().method_31034() && playerEntity == SkeletonModule.mc.field_1724) continue;
            class_243 skeletonPos = Interpolation.getInterpolatedPosition(entity, g);
            class_1007 livingEntityRenderer = (class_1007)((class_922)mc.method_1561().method_3953((class_1297)playerEntity));
            class_591 playerEntityModel = (class_591)livingEntityRenderer.method_4038();
            boolean rotating = Managers.ROTATION.isRotating();
            float h = class_3532.method_17821((float)g, (float)(rotating ? Managers.ROTATION.getRotationYaw() : playerEntity.field_6220), (float)(rotating ? Managers.ROTATION.getRotationYaw() : playerEntity.field_6283));
            float j = class_3532.method_17821((float)g, (float)(rotating ? Managers.ROTATION.getRotationYaw() : playerEntity.field_6259), (float)(rotating ? Managers.ROTATION.getRotationYaw() : playerEntity.field_6241));
            float q = playerEntity.field_42108.method_48569() - playerEntity.field_42108.method_48566() * (1.0f - g);
            float p = playerEntity.field_42108.method_48570(g);
            float o = (float)playerEntity.field_6012 + g;
            float k = j - h;
            float m = rotating ? Managers.ROTATION.getRotationPitch() : playerEntity.method_5695(g);
            playerEntityModel.method_17086((class_1309)playerEntity, q, p, g);
            playerEntityModel.method_17087((class_1309)playerEntity, q, p, o, k, m);
            boolean swimming = playerEntity.method_20232();
            boolean sneaking = playerEntity.method_5715();
            boolean flying = playerEntity.method_6128();
            class_630 head = playerEntityModel.field_3398;
            class_630 leftArm = playerEntityModel.field_27433;
            class_630 rightArm = playerEntityModel.field_3401;
            class_630 leftLeg = playerEntityModel.field_3397;
            class_630 rightLeg = playerEntityModel.field_3392;
            matrixStack.method_22903();
            matrixStack.method_22904(skeletonPos.field_1352, skeletonPos.field_1351, skeletonPos.field_1350);
            if (swimming) {
                matrixStack.method_46416(0.0f, 0.35f, 0.0f);
            }
            matrixStack.method_22907(new Quaternionf().setAngleAxis((double)(h + 180.0f) * Math.PI / 180.0, 0.0, -1.0, 0.0));
            if (swimming || flying) {
                matrixStack.method_22907(new Quaternionf().setAngleAxis((double)(90.0f + m) * Math.PI / 180.0, -1.0, 0.0, 0.0));
            }
            if (swimming) {
                matrixStack.method_46416(0.0f, -0.95f, 0.0f);
            }
            RenderBuffers.LINES.begin(matrixStack);
            RenderSystem.lineWidth((float)this.widthConfig.getValue().floatValue());
            Color skeletonColor = ColorsModule.getInstance().getColor();
            if (Managers.SOCIAL.isFriend(playerEntity.method_5477())) {
                skeletonColor = SocialsModule.getInstance().getFriendColor();
            }
            RenderBuffers.LINES.color(skeletonColor.getRGB());
            RenderBuffers.LINES.vertexLine(0.0, sneaking ? (double)0.6f : (double)0.7f, sneaking ? (double)0.23f : 0.0, 0.0, sneaking ? (double)1.05f : (double)1.4f, 0.0);
            RenderBuffers.LINES.vertexLine(-0.37f, sneaking ? (double)1.05f : (double)1.35f, 0.0, 0.37f, sneaking ? (double)1.05f : (double)1.35f, 0.0);
            RenderBuffers.LINES.vertexLine(-0.15f, sneaking ? (double)0.6f : (double)0.7f, sneaking ? (double)0.23f : 0.0, 0.15f, sneaking ? (double)0.6f : (double)0.7f, sneaking ? (double)0.23f : 0.0);
            RenderBuffers.LINES.end();
            matrixStack.method_22903();
            matrixStack.method_46416(0.0f, sneaking ? 1.05f : 1.4f, 0.0f);
            this.rotateSkeleton(matrixStack, head);
            RenderBuffers.LINES.updateMatrices(matrixStack);
            RenderBuffers.LINES.vertexLine(0.0, 0.0, 0.0, 0.0, 0.25, 0.0);
            matrixStack.method_22909();
            matrixStack.method_22903();
            matrixStack.method_46416(0.15f, sneaking ? 0.6f : 0.7f, sneaking ? 0.23f : 0.0f);
            this.rotateSkeleton(matrixStack, rightLeg);
            RenderBuffers.LINES.updateMatrices(matrixStack);
            RenderBuffers.LINES.vertexLine(0.0, 0.0, 0.0, 0.0, -0.6f, 0.0);
            matrixStack.method_22909();
            matrixStack.method_22903();
            matrixStack.method_46416(-0.15f, sneaking ? 0.6f : 0.7f, sneaking ? 0.23f : 0.0f);
            this.rotateSkeleton(matrixStack, leftLeg);
            RenderBuffers.LINES.updateMatrices(matrixStack);
            RenderBuffers.LINES.vertexLine(0.0, 0.0, 0.0, 0.0, -0.6f, 0.0);
            matrixStack.method_22909();
            matrixStack.method_22903();
            matrixStack.method_46416(0.37f, sneaking ? 1.05f : 1.35f, 0.0f);
            this.rotateSkeleton(matrixStack, rightArm);
            RenderBuffers.LINES.updateMatrices(matrixStack);
            RenderBuffers.LINES.vertexLine(0.0, 0.0, 0.0, 0.0, -0.55f, 0.0);
            matrixStack.method_22909();
            matrixStack.method_22903();
            matrixStack.method_46416(-0.37f, sneaking ? 1.05f : 1.35f, 0.0f);
            this.rotateSkeleton(matrixStack, leftArm);
            RenderBuffers.LINES.updateMatrices(matrixStack);
            RenderBuffers.LINES.vertexLine(0.0, 0.0, 0.0, 0.0, -0.55f, 0.0);
            matrixStack.method_22909();
            matrixStack.method_22909();
        }
        RenderBuffers.postRender();
        RenderBuffers.LINES.end();
    }

    private void rotateSkeleton(class_4587 matrix, class_630 modelPart) {
        if (modelPart.field_3674 != 0.0f) {
            matrix.method_22907(class_7833.field_40718.rotation(modelPart.field_3674));
        }
        if (modelPart.field_3675 != 0.0f) {
            matrix.method_22907(class_7833.field_40715.rotation(modelPart.field_3675));
        }
        if (modelPart.field_3654 != 0.0f) {
            matrix.method_22907(class_7833.field_40713.rotation(modelPart.field_3654));
        }
    }
}
