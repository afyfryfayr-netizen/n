package net.hachimi.client.impl.module.render;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.camera.CameraPositionEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_5498;

public class MotionCameraModule
extends ToggleModule {
    Config<Boolean> noFirstPersonConfig = this.register(new BooleanConfig("NoFirstPerson", "Disables the effect in first person view", true));
    Config<Float> speedConfig = this.register(new NumberConfig<Float>("Speed", "How fast the camera follows the player (0 = no lag, 1 = instant)", Float.valueOf(0.0f), Float.valueOf(0.3f), Float.valueOf(1.0f)));
    Config<Float> firstPersonSpeedConfig = this.register(new NumberConfig<Float>("FirstPersonSpeed", "Speed when in first person", Float.valueOf(0.0f), Float.valueOf(0.6f), Float.valueOf(1.0f), () -> this.noFirstPersonConfig.getValue() == false));
    private double fakeX;
    private double fakeY;
    private double fakeZ;
    private double prevFakeX;
    private double prevFakeY;
    private double prevFakeZ;
    private boolean initialized = false;

    public MotionCameraModule() {
        super("MotionCamera", "Camera smoothly lags behind player movement", ModuleCategory.RENDER);
    }

    @Override
    public void onEnable() {
        if (MotionCameraModule.mc.field_1724 == null) {
            return;
        }
        this.fakeX = MotionCameraModule.mc.field_1724.method_23317();
        this.fakeY = MotionCameraModule.mc.field_1724.method_23318() + (double)MotionCameraModule.mc.field_1724.method_18381(MotionCameraModule.mc.field_1724.method_18376());
        this.fakeZ = MotionCameraModule.mc.field_1724.method_23321();
        this.prevFakeX = this.fakeX;
        this.prevFakeY = this.fakeY;
        this.prevFakeZ = this.fakeZ;
        this.initialized = true;
    }

    @Override
    public void onDisable() {
        this.initialized = false;
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (MotionCameraModule.mc.field_1724 == null) {
            return;
        }
        this.prevFakeX = this.fakeX;
        this.prevFakeY = this.fakeY;
        this.prevFakeZ = this.fakeZ;
        boolean isFirstPerson = MotionCameraModule.mc.field_1690.method_31044() == class_5498.field_26664;
        float speed = (isFirstPerson && this.noFirstPersonConfig.getValue() == false ? this.firstPersonSpeedConfig.getValue() : this.speedConfig.getValue()).floatValue();
        double targetX = MotionCameraModule.mc.field_1724.method_23317();
        double targetY = MotionCameraModule.mc.field_1724.method_23318() + (double)MotionCameraModule.mc.field_1724.method_18381(MotionCameraModule.mc.field_1724.method_18376());
        double targetZ = MotionCameraModule.mc.field_1724.method_23321();
        this.fakeX = this.animate(this.fakeX, targetX, speed);
        this.fakeY = this.animate(this.fakeY, targetY, speed);
        this.fakeZ = this.animate(this.fakeZ, targetZ, speed);
    }

    @EventListener
    public void onCameraPosition(CameraPositionEvent event) {
        if (!this.initialized) {
            return;
        }
        if (this.noFirstPersonConfig.getValue().booleanValue() && MotionCameraModule.mc.field_1690.method_31044() == class_5498.field_26664) {
            return;
        }
        float delta = event.getTickDelta();
        event.setX(this.lerp(this.prevFakeX, this.fakeX, delta));
        event.setY(this.lerp(this.prevFakeY, this.fakeY, delta));
        event.setZ(this.lerp(this.prevFakeZ, this.fakeZ, delta));
    }

    private double animate(double current, double target, double speed) {
        if (speed >= 1.0) {
            return target;
        }
        if (speed <= 0.0) {
            return current;
        }
        double diff = target - current;
        if (Math.abs(diff) <= 0.001) {
            return target;
        }
        return current + diff * speed;
    }

    private double lerp(double a, double b, float t) {
        return a + (b - a) * (double)t;
    }
}
