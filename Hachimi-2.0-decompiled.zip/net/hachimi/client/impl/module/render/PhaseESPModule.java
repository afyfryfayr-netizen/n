package net.hachimi.client.impl.module.render;

import java.awt.Color;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.util.world.BlastResistantBlocks;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class PhaseESPModule
extends ToggleModule {
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "The line width of the render", Float.valueOf(1.0f), Float.valueOf(1.0f), Float.valueOf(5.0f)));
    Config<Boolean> diagonalConfig = this.register(new BooleanConfig("Diagonal", "Renders safe diagonal phase blocks", true));
    Config<Boolean> safeConfig = this.register(new BooleanConfig("Safe", "Highlights safe phase blocks", false));
    Config<Color> unsafeConfig = this.register(new ColorConfig("UnsafeColor", "The color for rendering unsafe phase blocks", new Color(255, 0, 0), false, false));
    Config<Color> obsidianConfig = this.register(new ColorConfig("ObsidianColor", "The color for rendering obsidian phase blocks", new Color(255, 255, 0), false, false, () -> this.safeConfig.getValue()));
    Config<Color> bedrockConfig = this.register(new ColorConfig("BedrockColor", "The color for rendering bedrock phase blocks", new Color(0, 255, 0), false, false, () -> this.safeConfig.getValue()));

    public PhaseESPModule() {
        super("PhaseESP", "Displays safe phase blocks", ModuleCategory.RENDER);
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (PhaseESPModule.mc.field_1724 == null || PhaseESPModule.mc.field_1687 == null || !PhaseESPModule.mc.field_1724.method_24828()) {
            return;
        }
        RenderBuffers.preRender();
        class_2338 playerPos = PhaseESPModule.mc.field_1724.method_24515();
        class_243 pos = PhaseESPModule.mc.field_1724.method_19538();
        double dx = pos.method_10216() - (double)playerPos.method_10263();
        double dz = pos.method_10215() - (double)playerPos.method_10260();
        for (class_2350 direction : class_2350.values()) {
            Color color;
            class_2338 blockPos;
            if (!direction.method_10166().method_10179() || PhaseESPModule.mc.field_1687.method_8320(blockPos = playerPos.method_10093(direction)).method_45474() || (color = this.getPhaseColor(blockPos)) == null) continue;
            double x = blockPos.method_10263();
            double y = blockPos.method_10264();
            double z = blockPos.method_10260();
            if (direction == class_2350.field_11034 && dx >= 0.65) {
                RenderManager.renderLine(event.getMatrices(), x, y, z, x, y, z + 1.0, this.widthConfig.getValue().floatValue(), color.getRGB());
                continue;
            }
            if (direction == class_2350.field_11039 && dx <= 0.35) {
                RenderManager.renderLine(event.getMatrices(), x + 1.0, y, z, x + 1.0, y, z + 1.0, this.widthConfig.getValue().floatValue(), color.getRGB());
                continue;
            }
            if (direction == class_2350.field_11035 && dz >= 0.65) {
                RenderManager.renderLine(event.getMatrices(), x, y, z, x + 1.0, y, z, this.widthConfig.getValue().floatValue(), color.getRGB());
                continue;
            }
            if (direction != class_2350.field_11043 || !(dz <= 0.35)) continue;
            RenderManager.renderLine(event.getMatrices(), x, y, z + 1.0, x + 1.0, y, z + 1.0, this.widthConfig.getValue().floatValue(), color.getRGB());
        }
        if (this.diagonalConfig.getValue().booleanValue()) {
            Color color4;
            Color color3;
            Color color2;
            double x = playerPos.method_10263();
            double y = playerPos.method_10264();
            double z = playerPos.method_10260();
            class_2338 currentPos = playerPos.method_10093(class_2350.field_11039).method_10093(class_2350.field_11043);
            Color color1 = this.getPhaseColor(currentPos);
            if (color1 != null && dx <= 0.35 && dz <= 0.35) {
                RenderManager.renderLine(event.getMatrices(), x, y, z, x, y + 1.0, z, this.widthConfig.getValue().floatValue(), color1.getRGB());
            }
            if ((color2 = this.getPhaseColor(currentPos = playerPos.method_10093(class_2350.field_11039).method_10093(class_2350.field_11035))) != null && dx <= 0.35 && dz >= 0.65) {
                RenderManager.renderLine(event.getMatrices(), x, y, z + 1.0, x, y + 1.0, z + 1.0, this.widthConfig.getValue().floatValue(), color2.getRGB());
            }
            if ((color3 = this.getPhaseColor(currentPos = playerPos.method_10093(class_2350.field_11034).method_10093(class_2350.field_11043))) != null && dx >= 0.65 && dz <= 0.35) {
                RenderManager.renderLine(event.getMatrices(), x + 1.0, y, z, x + 1.0, y + 1.0, z, this.widthConfig.getValue().floatValue(), color3.getRGB());
            }
            if ((color4 = this.getPhaseColor(currentPos = playerPos.method_10093(class_2350.field_11034).method_10093(class_2350.field_11035))) != null && dx >= 0.65 && dz >= 0.65) {
                RenderManager.renderLine(event.getMatrices(), x + 1.0, y, z + 1.0, x + 1.0, y + 1.0, z + 1.0, this.widthConfig.getValue().floatValue(), color4.getRGB());
            }
        }
        RenderBuffers.postRender();
    }

    private Color getPhaseColor(class_2338 blockPos) {
        class_2680 state1 = PhaseESPModule.mc.field_1687.method_8320(blockPos);
        if (state1.method_26215()) {
            return null;
        }
        class_2680 state = PhaseESPModule.mc.field_1687.method_8320(blockPos.method_10074());
        Color color = null;
        if (state.method_45474()) {
            color = this.unsafeConfig.getValue();
        } else if (this.safeConfig.getValue().booleanValue()) {
            color = BlastResistantBlocks.isUnbreakable(state.method_26204()) ? this.bedrockConfig.getValue() : this.obsidianConfig.getValue();
        }
        return color;
    }
}
