package net.hachimi.client.impl.module.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.Interpolation;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1667;
import net.minecraft.class_1680;
import net.minecraft.class_1681;
import net.minecraft.class_1683;
import net.minecraft.class_1684;
import net.minecraft.class_1685;
import net.minecraft.class_1686;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1803;
import net.minecraft.class_1823;
import net.minecraft.class_1828;
import net.minecraft.class_1835;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_8251;
import org.joml.Matrix4f;

public class TrajectoriesModule
extends ToggleModule {
    public TrajectoriesModule() {
        super("Trajectories", "Renders the trajectory path of projectiles", ModuleCategory.RENDER);
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        class_1799 mainhand = TrajectoriesModule.mc.field_1724.method_6047();
        class_1792 throwItem = mainhand.method_7909();
        class_4587 matrixStack = new class_4587();
        double d = ((Integer)TrajectoriesModule.mc.field_1690.method_41808().method_41753()).intValue();
        matrixStack.method_34425(TrajectoriesModule.mc.field_1773.method_22973(d));
        Matrix4f prevProjectionMatrix = RenderSystem.getProjectionMatrix();
        RenderSystem.setProjectionMatrix((Matrix4f)matrixStack.method_23760().method_23761(), (class_8251)class_8251.field_43360);
        RenderBuffers.preRender();
        if ((throwItem instanceof class_1753 || throwItem instanceof class_1764 || throwItem instanceof class_1835) && TrajectoriesModule.mc.field_1724.method_6048() > 0 || this.isThrowableItem(throwItem)) {
            float yaw = TrajectoriesModule.mc.field_1724.method_36454();
            double x = Interpolation.interpolateDouble(TrajectoriesModule.mc.field_1724.field_6014, TrajectoriesModule.mc.field_1724.method_23317(), mc.method_60646().method_60637(true));
            double y = Interpolation.interpolateDouble(TrajectoriesModule.mc.field_1724.field_6036, TrajectoriesModule.mc.field_1724.method_23318(), mc.method_60646().method_60637(true));
            double z = Interpolation.interpolateDouble(TrajectoriesModule.mc.field_1724.field_5969, TrajectoriesModule.mc.field_1724.method_23321(), mc.method_60646().method_60637(true));
            y = y + (double)TrajectoriesModule.mc.field_1724.method_18381(TrajectoriesModule.mc.field_1724.method_18376()) - 0.1000000014901161;
            if (throwItem == TrajectoriesModule.mc.field_1724.method_6047().method_7909()) {
                x -= (double)(class_3532.method_15362((float)(yaw / 180.0f * (float)Math.PI)) * 0.16f);
                z -= (double)(class_3532.method_15374((float)(yaw / 180.0f * (float)Math.PI)) * 0.16f);
            } else {
                x += (double)(class_3532.method_15362((float)(yaw / 180.0f * (float)Math.PI)) * 0.16f);
                z += (double)(class_3532.method_15374((float)(yaw / 180.0f * (float)Math.PI)) * 0.16f);
            }
            float n = throwItem instanceof class_1753 ? 1.0f : 0.4f;
            double motionX = -class_3532.method_15374((float)(yaw / 180.0f * (float)Math.PI)) * class_3532.method_15362((float)(TrajectoriesModule.mc.field_1724.method_36455() / 180.0f * (float)Math.PI)) * n;
            double motionY = -class_3532.method_15374((float)((TrajectoriesModule.mc.field_1724.method_36455() + (float)(throwItem instanceof class_1828 || throwItem instanceof class_1803 || throwItem instanceof class_1779 ? -20 : 0)) / 180.0f * (float)Math.PI)) * n;
            double motionZ = class_3532.method_15362((float)(yaw / 180.0f * (float)Math.PI)) * class_3532.method_15362((float)(TrajectoriesModule.mc.field_1724.method_36455() / 180.0f * (float)Math.PI)) * n;
            float power = (float)TrajectoriesModule.mc.field_1724.method_6048() / 20.0f;
            power = (power * power + power * 2.0f) / 3.0f;
            if (power > 1.0f) {
                power = 1.0f;
            }
            float dist = class_3532.method_15355((float)((float)(motionX * motionX + motionY * motionY + motionZ * motionZ)));
            motionX /= (double)dist;
            motionY /= (double)dist;
            motionZ /= (double)dist;
            float pow = (throwItem instanceof class_1753 ? power * 2.0f : (throwItem instanceof class_1764 ? 2.2f : 1.0f)) * this.getProjectilePower(throwItem);
            motionX *= (double)pow;
            motionY *= (double)pow;
            motionZ *= (double)pow;
            if (!TrajectoriesModule.mc.field_1724.method_24828()) {
                motionY += TrajectoriesModule.mc.field_1724.method_18798().method_10214();
            }
            float size = throwItem instanceof class_1753 || throwItem instanceof class_1764 ? 0.3f : 0.25f;
            boolean hasLanded = false;
            while (!hasLanded) {
                boolean landing = false;
                class_243 lastPos = new class_243(x, y, z);
                class_2338 blockPos = class_2338.method_49637((double)(x += motionX), (double)(y += motionY), (double)(z += motionZ));
                if (TrajectoriesModule.mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_10382) {
                    motionX *= 0.8;
                    motionY *= 0.8;
                    motionZ *= 0.8;
                } else {
                    motionX *= 0.99;
                    motionY *= 0.99;
                    motionZ *= 0.99;
                }
                motionY = throwItem instanceof class_1753 ? (motionY -= (double)0.05f) : (TrajectoriesModule.mc.field_1724.method_6047().method_7909() instanceof class_1764 ? (motionY -= (double)0.05f) : (motionY -= (double)0.03f));
                class_238 projectileBox = new class_238(x - (double)size, y - (double)size, z - (double)size, x + (double)size, y + (double)size, z + (double)size);
                for (class_1297 entity : TrajectoriesModule.mc.field_1687.method_8335(null, projectileBox)) {
                    if (entity == TrajectoriesModule.mc.field_1724 || this.isThrowableEntity(entity)) continue;
                    RenderManager.renderBox(event.getMatrices(), Interpolation.getInterpolatedEntityBox(entity), ColorsModule.getInstance().getRGB(40));
                    RenderManager.renderBoundingBox(event.getMatrices(), Interpolation.getInterpolatedEntityBox(entity), 1.5f, ColorsModule.getInstance().getRGB(145));
                    landing = true;
                }
                class_243 pos = new class_243(x, y, z);
                class_3965 result = TrajectoriesModule.mc.field_1687.method_17742(new class_3959(lastPos, pos, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)TrajectoriesModule.mc.field_1724));
                if (result != null && result.method_17783() == class_239.class_240.field_1332) {
                    landing = true;
                    class_2350 side = result.method_17780();
                    if (side == class_2350.field_11043 || side == class_2350.field_11035) {
                        RenderManager.renderSide(event.getMatrices(), x - (double)0.6f, y - (double)0.6f, z, x + (double)0.6f, y + (double)0.6f, z, side, ColorsModule.getInstance().getRGB(80));
                    } else if (side == class_2350.field_11039 || side == class_2350.field_11034) {
                        RenderManager.renderSide(event.getMatrices(), x, y - (double)0.6f, z - (double)0.6f, x, y + (double)0.6f, z + (double)0.6f, side, ColorsModule.getInstance().getRGB(80));
                    } else {
                        RenderManager.renderSide(event.getMatrices(), x - (double)0.6f, y, z - (double)0.6f, x + (double)0.6f, y, z + (double)0.6f, side, ColorsModule.getInstance().getRGB(80));
                    }
                }
                if (y < (double)TrajectoriesModule.mc.field_1687.method_31607()) break;
                if (motionX == 0.0 && motionY == 0.0 && motionZ == 0.0) continue;
                RenderManager.renderLine(event.getMatrices(), lastPos, pos, 1.5f, ColorsModule.getInstance().getRGB());
                if (!landing) continue;
                hasLanded = true;
            }
        }
        RenderBuffers.postRender();
        RenderSystem.setProjectionMatrix((Matrix4f)prevProjectionMatrix, (class_8251)class_8251.field_43360);
    }

    private float getProjectilePower(class_1792 item) {
        if (item instanceof class_1828 || item instanceof class_1803) {
            return 0.4f;
        }
        if (item instanceof class_1779) {
            return 0.5f;
        }
        if (item instanceof class_1835) {
            return 2.0f;
        }
        return 1.5f;
    }

    private boolean isThrowableItem(class_1792 item) {
        return item instanceof class_1776 || item instanceof class_1779 || item instanceof class_1823 || item instanceof class_1771 || item instanceof class_1828 || item instanceof class_1803;
    }

    private boolean isThrowableEntity(class_1297 entity) {
        return entity instanceof class_1683 || entity instanceof class_1684 || entity instanceof class_1303 || entity instanceof class_1686 || entity instanceof class_1667 || entity instanceof class_1685 || entity instanceof class_1680 || entity instanceof class_1681;
    }
}
