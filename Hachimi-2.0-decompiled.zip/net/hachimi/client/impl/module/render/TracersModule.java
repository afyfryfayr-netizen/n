package net.hachimi.client.impl.module.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.Interpolation;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.client.SocialsModule;
import net.hachimi.client.impl.module.player.FreecamModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.mixin.accessor.AccessorCamera;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_8251;
import org.joml.Matrix4f;

public class TracersModule
extends ToggleModule {
    Config<RenderMode> modeConfig = this.register(new EnumConfig("Mode", "Render tracers to entities not visible on the screen", (Enum)RenderMode.NORMAL, (Enum[])RenderMode.values()));
    Config<Target> targetConfig = this.register(new EnumConfig("Target", "The body part of the entity to target", (Enum)Target.FEET, (Enum[])Target.values()));
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "The line width of the tracer", Float.valueOf(1.0f), Float.valueOf(1.0f), Float.valueOf(5.0f)));
    Config<Boolean> playersConfig = this.register(new BooleanConfig("Players", "Render tracers to player", true));
    Config<Color> playersColorConfig = this.register(new ColorConfig("PlayersColor", "The render color for players", new Color(200, 60, 60), false, () -> this.playersConfig.getValue()));
    Config<Boolean> friendsConfig = this.register(new BooleanConfig("Friends", "Render tracers to players that are friended", false, () -> this.playersConfig.getValue()));
    Config<Boolean> invisiblesConfig = this.register(new BooleanConfig("Invisibles", "Render tracers to invisible entities", false));
    Config<Color> invisiblesColorConfig = this.register(new ColorConfig("InvisiblesColor", "The render color for invisibles", new Color(200, 100, 0), false, () -> this.invisiblesConfig.getValue()));
    Config<Boolean> monstersConfig = this.register(new BooleanConfig("Monsters", "Render tracers to monsters", false));
    Config<Color> monstersColorConfig = this.register(new ColorConfig("MonstersColor", "The render color for monsters", new Color(200, 60, 60), false, () -> this.monstersConfig.getValue()));
    Config<Boolean> animalsConfig = this.register(new BooleanConfig("Animals", "Render tracers to animals", false));
    Config<Color> animalsColorConfig = this.register(new ColorConfig("AnimalsColor", "The render color for animals", new Color(0, 200, 0), false, () -> this.animalsConfig.getValue()));
    Config<Boolean> vehiclesConfig = this.register(new BooleanConfig("Vehicles", "Render tracers to vehicles", false));
    Config<Color> vehiclesColorConfig = this.register(new ColorConfig("VehiclesColor", "The render color for vehicles", new Color(200, 100, 0), false, () -> this.vehiclesConfig.getValue()));
    Config<Boolean> itemsConfig = this.register(new BooleanConfig("Items", "Render tracers to items", false));
    Config<Color> itemsColorConfig = this.register(new ColorConfig("ItemsColor", "The render color for items", new Color(255, 255, 255), false, () -> this.itemsConfig.getValue()));

    public TracersModule() {
        super("Tracers", "Draws a tracer to all entities in render distance", ModuleCategory.RENDER);
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        class_1657 playerEntity;
        block11: {
            block10: {
                class_1297 class_12972;
                if (TracersModule.mc.field_1724 == null || mc.method_1560() == null || !((class_12972 = mc.method_1560()) instanceof class_1657)) break block10;
                playerEntity = (class_1657)class_12972;
                if (!TracersModule.mc.field_1690.field_1842) break block11;
            }
            return;
        }
        class_4587 matrixStack = new class_4587();
        double d = ((Integer)TracersModule.mc.field_1690.method_41808().method_41753()).intValue();
        matrixStack.method_34425(TracersModule.mc.field_1773.method_22973(d));
        Matrix4f prevProjectionMatrix = RenderSystem.getProjectionMatrix();
        RenderSystem.setProjectionMatrix((Matrix4f)matrixStack.method_23760().method_23761(), (class_8251)class_8251.field_43360);
        RenderBuffers.preRender();
        class_243 playerPos = Interpolation.getRenderPosition((class_1297)playerEntity, event.getTickDelta());
        class_4184 camera = TracersModule.mc.field_1773.method_19418();
        double eyeHeight = class_3532.method_16439((float)event.getTickDelta(), (float)((AccessorCamera)camera).getLastCameraY(), (float)((AccessorCamera)camera).getCameraY());
        double x1 = playerEntity.method_23317() - playerPos.method_10216();
        double y1 = playerEntity.method_23318() - playerPos.method_10214() + eyeHeight;
        double z1 = playerEntity.method_23321() - playerPos.method_10215();
        float pitch = playerEntity.method_36455();
        float yaw = playerEntity.method_36454();
        if (FreecamModule.getInstance().isEnabled()) {
            class_243 pos1 = FreecamModule.getInstance().getCameraPosition();
            class_243 pos2 = Interpolation.getRenderPosition(pos1, FreecamModule.getInstance().getLastCameraPosition(), event.getTickDelta());
            float[] rotations = FreecamModule.getInstance().getCameraRotations();
            x1 = pos1.field_1352 - pos2.field_1352;
            y1 = pos1.field_1351 - pos2.field_1351;
            z1 = pos1.field_1350 - pos2.field_1350;
            yaw = rotations[0];
            pitch = rotations[1];
        }
        class_243 pos = new class_243(0.0, 0.0, 1.0).method_1037(-((float)Math.toRadians(pitch))).method_1024(-((float)Math.toRadians(yaw))).method_1019(new class_243(x1, y1, z1));
        for (class_1297 entity : TracersModule.mc.field_1687.method_18112()) {
            Color color;
            boolean shouldDraw;
            switch (this.modeConfig.getValue().ordinal()) {
                default: {
                    throw new MatchException(null, null);
                }
                case 2: {
                    boolean bl = true;
                    break;
                }
                case 0: {
                    boolean bl = RenderManager.isFrustumVisible(entity.method_5829());
                    break;
                }
                case 1: {
                    boolean bl = shouldDraw = !RenderManager.isFrustumVisible(entity.method_5829());
                }
            }
            if (entity == null || !entity.method_5805() || entity == TracersModule.mc.field_1724 || !shouldDraw || entity instanceof class_1657 && Managers.SOCIAL.isFriend(entity.method_5476()) && !this.friendsConfig.getValue().booleanValue() || (color = this.getTracerColor(entity)) == null) continue;
            class_243 entityPos = Interpolation.getRenderPosition(entity, event.getTickDelta());
            double x2 = entity.method_23317() - entityPos.method_10216();
            double y2 = entity.method_23318() - entityPos.method_10214();
            double z2 = entity.method_23321() - entityPos.method_10215();
            RenderManager.renderLine(event.getMatrices(), pos, new class_243(x2, y2, z2).method_1031(0.0, this.getTargetY(entity), 0.0), this.widthConfig.getValue().floatValue(), color.getRGB());
        }
        RenderBuffers.postRender();
        RenderSystem.setProjectionMatrix((Matrix4f)prevProjectionMatrix, (class_8251)class_8251.field_43360);
    }

    private Color getTracerColor(class_1297 entity) {
        if (entity.method_5767() && this.invisiblesConfig.getValue().booleanValue()) {
            return this.invisiblesColorConfig.getValue();
        }
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (this.playersConfig.getValue().booleanValue()) {
                if (Managers.SOCIAL.isFriend(player.method_5477())) {
                    return SocialsModule.getInstance().getFriendColor();
                }
                return this.playersColorConfig.getValue();
            }
        }
        if (EntityUtil.isMonster(entity) && this.monstersConfig.getValue().booleanValue()) {
            return this.monstersColorConfig.getValue();
        }
        if ((EntityUtil.isPassive(entity) || EntityUtil.isNeutral(entity)) && this.animalsConfig.getValue().booleanValue()) {
            return this.animalsColorConfig.getValue();
        }
        if (EntityUtil.isVehicle(entity) && this.vehiclesConfig.getValue().booleanValue()) {
            return this.vehiclesColorConfig.getValue();
        }
        if (entity instanceof class_1542 && this.itemsConfig.getValue().booleanValue()) {
            return this.itemsColorConfig.getValue();
        }
        return null;
    }

    private double getTargetY(class_1297 entity) {
        return switch (this.targetConfig.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> 0.0;
            case 1 -> (double)entity.method_17682() / 2.0;
            case 2 -> entity.method_18381(entity.method_18376());
        };
    }

    public static enum RenderMode {
        ON_SCREEN,
        OFF_SCREEN,
        NORMAL;

    }

    public static enum Target {
        FEET,
        TORSO,
        HEAD;

    }
}
