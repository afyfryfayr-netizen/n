package net.hachimi.client.impl.module.render;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.BoxRender;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.render.RenderBlockOutlineEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4587;

public class BlockHighlightModule
extends ToggleModule {
    Config<BoxRender> boxModeConfig = this.register(new EnumConfig("BoxMode", "Box rendering mode", (Enum)BoxRender.OUTLINE, (Enum[])BoxRender.values()));
    Config<Boolean> entitiesConfig = this.register(new BooleanConfig("Debug-Entities", "Highlights entity bounding boxes for debug purposes", false));
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "The line width of the highlight", Float.valueOf(1.0f), Float.valueOf(1.0f), Float.valueOf(5.0f)));
    Config<Boolean> fadeConfig = this.register(new BooleanConfig("Fade", "Fades the block highlight", false));
    Config<Integer> fadeTimeConfig = this.register(new NumberConfig<Integer>("Fade-Time", "Timer for the fade", Integer.valueOf(0), Integer.valueOf(200), Integer.valueOf(1000), () -> false));
    private double distance;
    private final Map<class_238, Animation> fadeList = new HashMap<class_238, Animation>();

    public BlockHighlightModule() {
        super("BlockHighlight", "Highlights the block the player is facing", ModuleCategory.RENDER);
    }

    @Override
    public String getModuleData() {
        class_3965 result;
        if (BlockHighlightModule.mc.field_1687 == null) {
            return super.getModuleData();
        }
        class_239 class_2392 = BlockHighlightModule.mc.field_1765;
        if (class_2392 instanceof class_3965 && BlockHighlightModule.mc.field_1687.method_8320((result = (class_3965)class_2392).method_17777()).method_26215()) {
            return super.getModuleData();
        }
        DecimalFormat decimal = new DecimalFormat("0.0");
        return decimal.format(this.distance);
    }

    @Override
    public void onDisable() {
        this.fadeList.clear();
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (BlockHighlightModule.mc.field_1687 == null) {
            return;
        }
        if (!this.fadeConfig.getValue().booleanValue() && !this.fadeList.isEmpty()) {
            this.fadeList.clear();
        }
        class_238 render = null;
        class_239 result = BlockHighlightModule.mc.field_1765;
        if (result != null) {
            class_243 pos = Managers.POSITION.getEyePos();
            if (this.entitiesConfig.getValue().booleanValue() && result.method_17783() == class_239.class_240.field_1331) {
                class_1297 entity = ((class_3966)result).method_17782();
                render = entity.method_5829();
                this.distance = pos.method_1022(entity.method_19538());
                if (this.fadeConfig.getValue().booleanValue()) {
                    this.fadeList.put(render, new Animation(true, this.fadeTimeConfig.getValue().intValue()));
                }
            } else if (result.method_17783() == class_239.class_240.field_1332) {
                class_2338 hpos = ((class_3965)result).method_17777();
                class_2680 state = BlockHighlightModule.mc.field_1687.method_8320(hpos);
                class_265 outlineShape = state.method_26218((class_1922)BlockHighlightModule.mc.field_1687, hpos);
                if (outlineShape.method_1110()) {
                    return;
                }
                class_238 render1 = outlineShape.method_1107();
                render = new class_238((double)hpos.method_10263() + render1.field_1323, (double)hpos.method_10264() + render1.field_1322, (double)hpos.method_10260() + render1.field_1321, (double)hpos.method_10263() + render1.field_1320, (double)hpos.method_10264() + render1.field_1325, (double)hpos.method_10260() + render1.field_1324);
                this.distance = pos.method_1022(hpos.method_46558());
                if (this.fadeConfig.getValue().booleanValue()) {
                    this.fadeList.put(render, new Animation(true, this.fadeTimeConfig.getValue().intValue()));
                }
            }
        }
        RenderBuffers.preRender();
        if (this.fadeConfig.getValue().booleanValue()) {
            for (Map.Entry<class_238, Animation> set : this.fadeList.entrySet()) {
                class_238 box = set.getKey();
                set.getValue().setState(false);
                if (set.getValue().getFactor() < (double)0.01f) continue;
                int boxAlpha = (int)(40.0 * set.getValue().getFactor());
                int lineAlpha = (int)(145.0 * set.getValue().getFactor());
                this.renderBb(event.getMatrices(), box, ColorsModule.getInstance().getRGB(boxAlpha), ColorsModule.getInstance().getRGB(lineAlpha));
            }
        } else if (render != null) {
            this.renderBb(event.getMatrices(), render, ColorsModule.getInstance().getRGB(40), ColorsModule.getInstance().getRGB(145));
        }
        RenderBuffers.postRender();
    }

    private void renderBb(class_4587 matrixStack, class_238 render, int color, int lineColor) {
        switch (this.boxModeConfig.getValue()) {
            case FILL: {
                RenderManager.renderBox(matrixStack, render, color);
                RenderManager.renderBoundingBox(matrixStack, render, this.widthConfig.getValue().floatValue(), lineColor);
                break;
            }
            case OUTLINE: {
                RenderManager.renderBoundingBox(matrixStack, render, this.widthConfig.getValue().floatValue(), lineColor);
            }
        }
    }

    @EventListener
    public void onRenderBlockOutline(RenderBlockOutlineEvent event) {
        event.cancel();
    }
}
