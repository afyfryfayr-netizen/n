package net.hachimi.client.impl.module.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.Interpolation;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.event.world.RemoveEntityEvent;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1683;
import net.minecraft.class_1684;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class BreadcrumbsModule
extends ToggleModule {
    private final Map<Integer, List<TimedPosition>> positions = new ConcurrentHashMap<Integer, List<TimedPosition>>();
    Config<Boolean> infiniteConfig = this.register(new BooleanConfig("Infinite", "Renders breadcrumbs for all positions since toggle", true));
    Config<Float> maxTimeConfig = this.register(new NumberConfig<Float>("MaxPosition", "The maximum time for a given position", Float.valueOf(1.0f), Float.valueOf(2.0f), Float.valueOf(20.0f)));
    Config<Integer> fadeTimeConfig = this.register(new NumberConfig<Integer>("Fade-Time", "Timer for the fade", Integer.valueOf(0), Integer.valueOf(1000), Integer.valueOf(5000), () -> false));
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "The line width of the path", Float.valueOf(1.0f), Float.valueOf(1.0f), Float.valueOf(5.0f)));
    Config<Boolean> selfConfig = this.register(new BooleanConfig("Self", "Renders breadcrumbs on player", true));
    Config<Boolean> playersConfig = this.register(new BooleanConfig("Players", "Renders breadcrumbs on other players", false));
    Config<Boolean> pearlsConfig = this.register(new BooleanConfig("Pearls", "Renders breadcrumbs on thrown pearls", false));
    Config<Boolean> arrowsConfig = this.register(new BooleanConfig("Arrows", "Renders breadcrumbs on arrows", false));
    Config<Boolean> xpBottlesConfig = this.register(new BooleanConfig("XPBottles", "Renders breadcrumbs on thrown experience bottles", false));

    public BreadcrumbsModule() {
        super("Breadcrumbs", "Renders a line connecting all previous positions", ModuleCategory.RENDER);
    }

    @Override
    public void onDisable() {
        this.positions.clear();
    }

    @EventListener
    public void onPlayerUpdate(PlayerTickEvent event) {
        for (class_1297 class_12972 : BreadcrumbsModule.mc.field_1687.method_18112()) {
            if (!this.checkEntity(class_12972)) continue;
            class_243 pos = Interpolation.getInterpolatedPosition(class_12972, mc.method_60646().method_60637(true));
            if (this.positions.containsKey(class_12972.method_5628())) {
                this.positions.get(class_12972.method_5628()).add(new TimedPosition(pos, System.currentTimeMillis()));
                continue;
            }
            CopyOnWriteArrayList<TimedPosition> timedPositions = new CopyOnWriteArrayList<TimedPosition>();
            timedPositions.add(new TimedPosition(pos, System.currentTimeMillis()));
            this.positions.put(class_12972.method_5628(), timedPositions);
        }
        if (!this.infiniteConfig.getValue().booleanValue()) {
            for (Map.Entry entry : this.positions.entrySet()) {
                for (TimedPosition timedPosition : (List)entry.getValue()) {
                    if (!((float)(System.currentTimeMillis() - timedPosition.time()) > this.maxTimeConfig.getValue().floatValue() * 1000.0f)) continue;
                    this.positions.get(entry.getKey()).remove(timedPosition);
                }
            }
        }
    }

    @EventListener
    public void onEntityDeath(RemoveEntityEvent event) {
        if (this.infiniteConfig.getValue().booleanValue()) {
            this.positions.remove(event.getEntity().method_5628());
        }
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        event.getMatrices().method_22903();
        RenderBuffers.preRender();
        RenderSystem.lineWidth((float)this.widthConfig.getValue().floatValue());
        RenderBuffers.LINES.begin(event.getMatrices());
        for (Map.Entry<Integer, List<TimedPosition>> entry : this.positions.entrySet()) {
            List<TimedPosition> timedPositions = entry.getValue();
            for (int i = 0; i < timedPositions.size(); ++i) {
                TimedPosition timedPosition = timedPositions.get(i);
                if (!this.infiniteConfig.getValue().booleanValue()) {
                    float fade = 1.0f - class_3532.method_15363((float)((float)(System.currentTimeMillis() - timedPosition.time()) / (float)this.fadeTimeConfig.getValue().intValue()), (float)0.0f, (float)1.0f);
                    RenderBuffers.LINES.color(ColorsModule.getInstance().getRGB((int)(fade * 255.0f)));
                } else {
                    RenderBuffers.LINES.color(ColorsModule.getInstance().getRGB());
                }
                if (i <= 1) continue;
                class_243 vec3d = timedPositions.get(i - 1).pos();
                class_243 vec3d2 = timedPosition.pos();
                RenderBuffers.LINES.vertexLine(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350, vec3d2.field_1352, vec3d2.field_1351, vec3d2.field_1350);
            }
        }
        RenderBuffers.LINES.end();
        RenderBuffers.postRender();
        event.getMatrices().method_22909();
    }

    public boolean checkEntity(class_1297 entity) {
        if (entity instanceof class_1657) {
            return this.playersConfig.getValue() != false || entity == BreadcrumbsModule.mc.field_1724 && this.selfConfig.getValue() != false;
        }
        return entity instanceof class_1684 && this.pearlsConfig.getValue() != false || entity instanceof class_1667 && this.arrowsConfig.getValue() != false || entity instanceof class_1683 && this.xpBottlesConfig.getValue() != false;
    }

    private record TimedPosition(class_243 pos, long time) {
    }
}
