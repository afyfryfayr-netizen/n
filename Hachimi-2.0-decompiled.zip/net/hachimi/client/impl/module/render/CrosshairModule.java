package net.hachimi.client.impl.module.render;

import java.awt.Color;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.gui.hud.RenderCrosshairEvent;
import net.hachimi.client.util.player.MovementUtil;
import net.hachimi.client.util.render.ColorUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.render.animation.Easing;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1934;
import net.minecraft.class_332;

public class CrosshairModule
extends ToggleModule {
    Config<Float> lengthConfig = this.register(new NumberConfig<Float>("Length", "The crosshair length", Float.valueOf(0.0f), Float.valueOf(1.0f), Float.valueOf(2.5f)));
    Config<Float> thicknessConfig = this.register(new NumberConfig<Float>("Thickness", "The crosshair thickness", Float.valueOf(0.1f), Float.valueOf(0.5f), Float.valueOf(2.0f)));
    Config<Integer> gapConfig = this.register(new NumberConfig<Integer>("Gap", "The gap between the lines", 1, 2, 5));
    Config<Boolean> dynamicConfig = this.register(new BooleanConfig("Dynamic", "Indicates when the player is moving", false));
    Config<Boolean> outlineConfig = this.register(new BooleanConfig("Outline", "Outlines the crosshair", true));
    Config<Float> outlineThicknessConfig = this.register(new NumberConfig<Float>("OutlineThickness", "The width of the outline", Float.valueOf(0.1f), Float.valueOf(0.3f), Float.valueOf(0.5f), () -> this.outlineConfig.getValue()));
    Config<Float> opacityConfig = this.register(new NumberConfig<Float>("Opacity", "The crosshair opacity", Float.valueOf(0.1f), Float.valueOf(1.0f), Float.valueOf(1.0f)));
    Config<Color> colorConfig = this.register(new ColorConfig("Color", "The crosshair color", Color.WHITE));
    private final Animation gapAnimation = new Animation(false, 100.0f, Easing.LINEAR);

    public CrosshairModule() {
        super("Crosshair", "Custom crosshairs", ModuleCategory.RENDER);
    }

    @EventListener
    public void onRenderCrosshair(RenderCrosshairEvent event) {
        event.cancel();
        if (!CrosshairModule.mc.field_1690.method_31044().method_31034() || CrosshairModule.mc.field_1761.method_2920() == class_1934.field_9219) {
            return;
        }
        class_332 context = event.getContext();
        float x = (float)context.method_51421() / 2.0f - 0.5f;
        float y = (float)context.method_51443() / 2.0f - 0.5f;
        float halfLength = this.lengthConfig.getValue().floatValue() * 10.0f / 2.0f;
        float o1 = this.outlineThicknessConfig.getValue().floatValue();
        float o2 = o1 * 2.0f;
        float o3 = o1 * 3.0f;
        boolean moving = MovementUtil.isMovingInput() || CrosshairModule.mc.field_1724.method_5715() || CrosshairModule.mc.field_1724.method_6101() || !CrosshairModule.mc.field_1724.method_24828();
        double gap = this.gapConfig.getValue().intValue();
        if (this.dynamicConfig.getValue().booleanValue()) {
            this.gapAnimation.setState(moving);
            gap += 2.0 * this.gapAnimation.getFactor();
        }
        if (this.outlineConfig.getValue().booleanValue()) {
            RenderManager.rect(context.method_51448(), (double)(x - halfLength) - gap - (double)o2, y - this.thicknessConfig.getValue().floatValue() - o1, halfLength + o3, this.thicknessConfig.getValue().floatValue() * 2.0f + o2, ColorUtil.withAlpha(Color.BLACK.getRGB(), this.opacityConfig.getValue().floatValue()));
            RenderManager.rect(context.method_51448(), (double)x + gap - (double)o2, y - this.thicknessConfig.getValue().floatValue() - o1, halfLength + o3, this.thicknessConfig.getValue().floatValue() * 2.0f + o2, ColorUtil.withAlpha(Color.BLACK.getRGB(), this.opacityConfig.getValue().floatValue()));
        }
        RenderManager.rect(context.method_51448(), (double)(x - halfLength) - gap, y - this.thicknessConfig.getValue().floatValue(), halfLength, this.thicknessConfig.getValue().floatValue() * 2.0f, ColorUtil.withAlpha(this.colorConfig.getValue().getRGB(), this.opacityConfig.getValue().floatValue()));
        RenderManager.rect(context.method_51448(), (double)x + gap, y - this.thicknessConfig.getValue().floatValue(), halfLength, this.thicknessConfig.getValue().floatValue() * 2.0f, ColorUtil.withAlpha(this.colorConfig.getValue().getRGB(), this.opacityConfig.getValue().floatValue()));
        if (this.outlineConfig.getValue().booleanValue()) {
            RenderManager.rect(context.method_51448(), x - this.thicknessConfig.getValue().floatValue() - o1, (double)(y - halfLength) - gap - (double)o1, this.thicknessConfig.getValue().floatValue() * 2.0f + o2, halfLength + o3, ColorUtil.withAlpha(Color.BLACK.getRGB(), this.opacityConfig.getValue().floatValue()));
            RenderManager.rect(context.method_51448(), x - this.thicknessConfig.getValue().floatValue() - o1, (double)y + gap - (double)o1, this.thicknessConfig.getValue().floatValue() * 2.0f + o2, halfLength + o3, ColorUtil.withAlpha(Color.BLACK.getRGB(), this.opacityConfig.getValue().floatValue()));
        }
        RenderManager.rect(context.method_51448(), x - this.thicknessConfig.getValue().floatValue(), (double)(y - halfLength) - gap, this.thicknessConfig.getValue().floatValue() * 2.0f, halfLength, ColorUtil.withAlpha(this.colorConfig.getValue().getRGB(), this.opacityConfig.getValue().floatValue()));
        RenderManager.rect(context.method_51448(), x - this.thicknessConfig.getValue().floatValue(), (double)y + gap, this.thicknessConfig.getValue().floatValue() * 2.0f, halfLength, ColorUtil.withAlpha(this.colorConfig.getValue().getRGB(), this.opacityConfig.getValue().floatValue()));
    }
}
