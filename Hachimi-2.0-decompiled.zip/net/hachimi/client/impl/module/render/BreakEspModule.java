package net.hachimi.client.impl.module.render;

import java.awt.Color;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.manager.world.BreakManager;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.render.ColorUtilPlus;
import net.hachimi.client.util.render.Render3DUtilPlus;
import net.hachimi.client.util.render.animation.EasingPlus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_4587;

public final class BreakEspModule
extends ToggleModule {
    private final Config<Boolean> progress = this.register(new BooleanConfig("Progress", "Show break progress", true));
    private final Config<Color> box = this.register(new ColorConfig("Box", "Box outline color", new Color(198, 176, 12, 255), true, true));
    private final Config<Color> fill = this.register(new ColorConfig("Fill", "Box fill color", new Color(198, 176, 12, 78), true, true));
    private final Config<Color> boxFriend = this.register(new ColorConfig("FriendBox", "Friend outline color", new Color(30, 45, 169, 255), true, true));
    private final Config<Color> fillFriend = this.register(new ColorConfig("FriendFill", "Friend fill color", new Color(30, 45, 169, 78), true, true));
    private final Config<EasingPlus> ease = this.register(new EnumConfig("Ease", "Box animation easing", (Enum)EasingPlus.CubicInOut, (Enum[])EasingPlus.values()));
    private final Config<ColorMode> colorMode = this.register(new EnumConfig("ColorMode", "Box color mode", (Enum)ColorMode.Static, (Enum[])ColorMode.values()));
    private final Config<Float> rainbowSpeed = this.register(new NumberConfig<Float>("RainbowSpeed", "Rainbow speed (ms/cycle)", Float.valueOf(500.0f), Float.valueOf(3000.0f), Float.valueOf(10000.0f), () -> this.colorMode.getValue() == ColorMode.Rainbow));
    private final Config<Boolean> second = this.register(new BooleanConfig("Second", "Show double-mine blocks", true));
    private final Config<Color> secondBox = this.register(new ColorConfig("SecondBox", "Double outline color", new Color(255, 255, 255, 255), true, true, () -> this.second.getValue()));
    private final Config<Color> secondFill = this.register(new ColorConfig("SecondFill", "Double fill color", new Color(255, 255, 255, 100), true, true, () -> this.second.getValue()));
    private final Color startColor = new Color(255, 6, 6);
    private final Color endColor = new Color(0, 255, 12);
    private final Color doubleColor = new Color(255, 179, 96);
    private final DecimalFormat df = new DecimalFormat("0.0");

    public BreakEspModule() {
        super("BreakESP", "Highlight blocks being mined by other players", ModuleCategory.RENDER);
    }

    private Color getBoxColor(class_1657 player, int index, int total) {
        if (this.isFriend(player)) {
            return this.boxFriend.getValue();
        }
        return switch (this.colorMode.getValue().ordinal()) {
            case 1 -> ColorUtilPlus.rainbowColor((double)index / (double)Math.max(total, 1), this.rainbowSpeed.getValue().floatValue(), 0.9f, 1.0f, this.box.getValue().getAlpha());
            case 2 -> ColorUtilPlus.pulseColor(this.box.getValue(), index, total, 0.001);
            default -> this.box.getValue();
        };
    }

    private Color getFillColor(class_1657 player, int index, int total) {
        if (this.isFriend(player)) {
            return this.fillFriend.getValue();
        }
        Color b = this.getBoxColor(player, index, total);
        return this.colorMode.getValue() == ColorMode.Static ? this.fill.getValue() : ColorUtilPlus.injectAlpha(b, this.fill.getValue().getAlpha());
    }

    private boolean isFriend(class_1657 player) {
        return Managers.SOCIAL != null && Managers.SOCIAL.isFriend(player.method_5477().getString());
    }

    private boolean fillEnabled(Config<Color> cfg) {
        return cfg.getValue().getAlpha() > 0;
    }

    private boolean boxEnabled(Config<Color> cfg) {
        return cfg.getValue().getAlpha() > 0;
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (BreakEspModule.mc.field_1724 == null || BreakEspModule.mc.field_1687 == null) {
            return;
        }
        BreakManager bm = Managers.BREAK;
        if (bm == null) {
            return;
        }
        class_4587 matrixStack = event.getMatrices();
        int idx = 0;
        int total = bm.breakMap.size();
        for (BreakManager.BreakData breakData : bm.breakMap.values()) {
            if (breakData == null || breakData.getEntity() == null) {
                ++idx;
                continue;
            }
            class_1657 player = (class_1657)breakData.getEntity();
            double size = 0.5 * (1.0 - breakData.fade.ease(this.ease.getValue()));
            class_238 cbox = new class_238(breakData.pos).method_1002(size, size, size).method_1002(-size, -size, -size);
            if (this.fillEnabled(this.fill)) {
                Render3DUtilPlus.drawFill(matrixStack, cbox, this.getFillColor(player, idx, total));
            }
            if (this.boxEnabled(this.box)) {
                Render3DUtilPlus.drawBox(matrixStack, cbox, this.getBoxColor(player, idx, total));
            }
            Render3DUtilPlus.drawText3D(player.method_5477().getString(), breakData.pos.method_46558().method_1031(0.0, this.progress.getValue() != false ? 0.15 : 0.0, 0.0), -1);
            if (this.progress.getValue().booleanValue()) {
                String label;
                double ratio = (double)breakData.timer.getMs() / breakData.breakTime;
                String string = breakData.failed ? "\u00a74Failed" : (label = breakData.complete ? "Broke" : this.df.format(Math.min(1.0, ratio) * 100.0));
                Color labelColor = breakData.complete ? (BreakEspModule.mc.field_1687.method_22347(breakData.pos) ? this.endColor : this.startColor) : ColorUtilPlus.fadeColor(this.startColor, this.endColor, ratio);
                Render3DUtilPlus.drawText3D(class_2561.method_30163((String)label), breakData.pos.method_46558().method_1031(0.0, -0.15, 0.0), 0.0, 0.0, 1.0, labelColor);
            }
            ++idx;
        }
        if (this.second.getValue().booleanValue()) {
            Iterator<BreakManager.BreakData> iterator = ((ConcurrentHashMap.KeySetView)bm.doubleMap.keySet()).iterator();
            while (iterator.hasNext()) {
                int i = (Integer)((Object)iterator.next());
                BreakManager.BreakData breakData = bm.doubleMap.get(i);
                if (breakData == null || breakData.getEntity() == null || BreakEspModule.mc.field_1687.method_22347(breakData.pos)) {
                    bm.doubleMap.remove(i);
                    continue;
                }
                BreakManager.BreakData singleBreakData = bm.breakMap.get(i);
                if (singleBreakData != null && singleBreakData.pos.equals((Object)breakData.pos)) continue;
                double size = 0.5 * (1.0 - breakData.fade.ease(this.ease.getValue()));
                class_238 cbox = new class_238(breakData.pos).method_1002(size, size, size).method_1002(-size, -size, -size);
                if (this.fillEnabled(this.secondFill)) {
                    Render3DUtilPlus.drawFill(matrixStack, cbox, this.secondFill.getValue());
                }
                if (this.boxEnabled(this.secondBox)) {
                    Render3DUtilPlus.drawBox(matrixStack, cbox, this.secondBox.getValue());
                }
                Render3DUtilPlus.drawText3D(breakData.getEntity().method_5477().getString(), breakData.pos.method_46558().method_1031(0.0, 0.15, 0.0), -1);
                Render3DUtilPlus.drawText3D("Double", breakData.pos.method_46558().method_1031(0.0, -0.15, 0.0), this.doubleColor.getRGB());
            }
        }
    }

    public static enum ColorMode {
        Static,
        Rainbow,
        Pulse;

    }
}
