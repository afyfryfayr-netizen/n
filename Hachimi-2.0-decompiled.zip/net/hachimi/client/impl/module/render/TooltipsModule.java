package net.hachimi.client.impl.module.render;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.gui.RenderTooltipEvent;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.util.world.ItemUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1799;
import net.minecraft.class_1806;
import net.minecraft.class_1937;
import net.minecraft.class_22;
import net.minecraft.class_2371;
import net.minecraft.class_4597;
import net.minecraft.class_9209;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

public class TooltipsModule
extends ToggleModule {
    Config<Boolean> shulkersConfig = this.register(new BooleanConfig("Shulkers", "Renders all the contents of shulkers in tooltips", true));
    Config<Boolean> mapsConfig = this.register(new BooleanConfig("Maps", "Renders a preview of maps in tooltips", false));

    public TooltipsModule() {
        super("Tooltips", "Renders detailed tooltips showing items", ModuleCategory.RENDER);
    }

    @EventListener
    public void onRenderTooltip(RenderTooltipEvent event) {
        class_1799 stack = event.getStack();
        if (stack.method_7960()) {
            return;
        }
        if (this.shulkersConfig.getValue().booleanValue() && ItemUtil.isShulker(stack.method_7909())) {
            class_9288 container = (class_9288)stack.method_57824(class_9334.field_49622);
            if (container == null || container.method_59712().findAny().isEmpty()) {
                return;
            }
            event.cancel();
            event.context.method_51448().method_22903();
            event.context.method_51448().method_46416(0.0f, 0.0f, 600.0f);
            class_2371 shulkerInventory = class_2371.method_10213((int)27, (Object)class_1799.field_8037);
            container.method_57489().filter(itemStack -> !itemStack.method_7960()).forEach(itemStack -> {
                for (int i = 0; i < shulkerInventory.size(); ++i) {
                    if (!((class_1799)shulkerInventory.get(i)).method_7960()) continue;
                    shulkerInventory.set(i, (Object)itemStack.method_7972());
                    break;
                }
            });
            RenderManager.rect(event.context.method_51448(), (double)event.getX() + 8.0, (double)event.getY() - 21.0, 150.0, 13.0, ColorsModule.getInstance().getRGB(170));
            RenderManager.enableScissor((double)event.getX() + 8.0, (double)event.getY() - 21.0, (double)event.getX() + 158.0, (double)event.getY() - 8.0);
            RenderManager.renderText(event.getContext(), stack.method_7964().getString(), (float)event.getX() + 11.0f, (float)event.getY() - 18.0f, -1);
            RenderManager.disableScissor();
            RenderManager.rect(event.context.method_51448(), (double)event.getX() + 8.0, (double)event.getY() - 8.0, 150.0, 55.0, 0x77000000);
            for (int i = 0; i < shulkerInventory.size(); ++i) {
                class_1799 itemStack2 = (class_1799)shulkerInventory.get(i);
                if (itemStack2.method_7960()) continue;
                int x = event.getX() + i % 9 * 16 + 9;
                int y = event.getY() + i / 9 * 16 - 5;
                event.context.method_51427(itemStack2, x, y);
                event.context.method_51431(TooltipsModule.mc.field_1772, itemStack2, x, y);
            }
            event.context.method_51448().method_22909();
        } else if (this.mapsConfig.getValue().booleanValue() && stack.method_7909() instanceof class_1806) {
            event.cancel();
            event.context.method_51448().method_22903();
            event.context.method_51448().method_46416(0.0f, 0.0f, 600.0f);
            RenderManager.rect(event.context.method_51448(), (double)event.getX() + 8.0, (double)event.getY() - 21.0, 128.0, 13.0, ColorsModule.getInstance().getRGB(170));
            RenderManager.enableScissor((double)event.getX() + 8.0, (double)event.getY() - 21.0, (double)event.getX() + 132.0, (double)event.getY() - 8.0);
            RenderManager.renderText(event.getContext(), stack.method_7964().getString(), (float)event.getX() + 11.0f, (float)event.getY() - 18.0f, -1);
            RenderManager.disableScissor();
            event.getContext().method_51448().method_46416((float)event.getX() + 8.0f, (float)event.getY() - 8.0f, 0.0f);
            class_9209 mapIdComponent = (class_9209)stack.method_57824(class_9334.field_49646);
            class_22 mapState = class_1806.method_7997((class_9209)mapIdComponent, (class_1937)TooltipsModule.mc.field_1687);
            if (mapState != null) {
                TooltipsModule.mc.field_1773.method_3194().method_1773(event.getContext().method_51448(), (class_4597)event.getContext().method_51450(), mapIdComponent, mapState, true, 1);
            }
            event.context.method_51448().method_22909();
        }
    }
}
