package net.hachimi.client.impl.module.render;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.biome.BiomeEffectsEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.util.string.EnumFormatter;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2596;
import net.minecraft.class_2668;
import net.minecraft.class_4761;

public class NoWeatherModule
extends ToggleModule {
    Config<Weather> weatherConfig = this.register(new EnumConfig("Weather", "The world weather", (Enum)Weather.CLEAR, (Enum[])Weather.values()));
    private Weather weather;

    public NoWeatherModule() {
        super("NoWeather", "Prevents weather rendering", ModuleCategory.RENDER);
    }

    @Override
    public String getModuleData() {
        return EnumFormatter.formatEnum(this.weatherConfig.getValue());
    }

    @Override
    public void onEnable() {
        if (NoWeatherModule.mc.field_1687 != null) {
            this.weather = NoWeatherModule.mc.field_1687.method_8546() ? Weather.THUNDER : (NoWeatherModule.mc.field_1687.method_8419() ? Weather.RAIN : Weather.CLEAR);
            this.setWeather(this.weatherConfig.getValue());
        }
    }

    @Override
    public void onDisable() {
        if (NoWeatherModule.mc.field_1687 != null && this.weather != null) {
            this.setWeather(this.weather);
        }
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == StageEvent.EventStage.POST) {
            this.setWeather(this.weatherConfig.getValue());
        }
    }

    @EventListener
    public void onBiomeEffects(BiomeEffectsEvent event) {
        if (this.weatherConfig.getValue() == Weather.ASH) {
            event.cancel();
            event.setParticleConfig(new class_4761((class_2394)class_2398.field_23956, 0.118093334f));
        }
    }

    private void setWeather(Weather weather) {
        switch (weather.ordinal()) {
            case 0: 
            case 3: {
                NoWeatherModule.mc.field_1687.method_28104().method_157(false);
                NoWeatherModule.mc.field_1687.method_8519(0.0f);
                NoWeatherModule.mc.field_1687.method_8496(0.0f);
                break;
            }
            case 1: {
                NoWeatherModule.mc.field_1687.method_28104().method_157(true);
                NoWeatherModule.mc.field_1687.method_8519(1.0f);
                NoWeatherModule.mc.field_1687.method_8496(0.0f);
                break;
            }
            case 2: {
                NoWeatherModule.mc.field_1687.method_28104().method_157(true);
                NoWeatherModule.mc.field_1687.method_8519(2.0f);
                NoWeatherModule.mc.field_1687.method_8496(1.0f);
            }
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        class_2668 packet;
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2668 && ((packet = (class_2668)class_25962).method_11491() == class_2668.field_25646 || packet.method_11491() == class_2668.field_25647 || packet.method_11491() == class_2668.field_25652 || packet.method_11491() == class_2668.field_25653)) {
            event.cancel();
        }
    }

    public static enum Weather {
        CLEAR,
        RAIN,
        THUNDER,
        ASH;

    }
}
