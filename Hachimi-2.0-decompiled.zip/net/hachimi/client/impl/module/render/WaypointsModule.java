package net.hachimi.client.impl.module.render;

import com.google.common.collect.Maps;
import java.text.DecimalFormat;
import java.util.Map;
import java.util.UUID;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.api.waypoint.Waypoint;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.entity.EntityDeathEvent;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.event.world.LoadWorldEvent;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.world.DimensionUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2703;
import net.minecraft.class_4048;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_7828;
import net.minecraft.class_8042;

public class WaypointsModule
extends ToggleModule {
    private static WaypointsModule INSTANCE;
    Config<Boolean> logoutsConfig = this.register(new BooleanConfig("LogoutPoints", "Marks the position of player logouts", false));
    Config<Boolean> deathsConfig = this.register(new BooleanConfig("DeathPoints", "Marks the position of player deaths", false));
    Config<Boolean> coordsConfig = this.register(new BooleanConfig("Coords", "Shows the coordinates of the waypoint", true));
    Config<Boolean> distanceConfig = this.register(new BooleanConfig("Distance", "Shows the distance to the waypoint", true));
    DecimalFormat format = new DecimalFormat("0.0");
    private final Map<UUID, class_1657> loginPlayers = Maps.newConcurrentMap();
    private final Map<UUID, class_1657> logoutPlayers = Maps.newConcurrentMap();

    public WaypointsModule() {
        super("Waypoints", "Renders a waypoint at marked locations", ModuleCategory.RENDER);
        INSTANCE = this;
    }

    public static WaypointsModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        Managers.WAYPOINT.clear();
        this.loginPlayers.clear();
        this.logoutPlayers.clear();
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        this.onDisable();
    }

    @EventListener
    public void onLoadWorld(LoadWorldEvent event) {
        this.onDisable();
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (WaypointsModule.mc.field_1724 == null || !this.logoutsConfig.getValue().booleanValue()) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_8042) {
            class_8042 packet = (class_8042)class_25962;
            for (class_2596 packet1 : packet.method_48324()) {
                this.handlePlayerListPackets(packet1);
            }
        } else {
            this.handlePlayerListPackets(event.getPacket());
        }
    }

    public void handlePlayerListPackets(class_2596<?> packet1) {
        class_2703 packet;
        if (packet1 instanceof class_2703 && (packet = (class_2703)packet1).method_46327().contains(class_2703.class_5893.field_29136)) {
            for (class_2703.class_2705 player : packet.method_46330()) {
                for (UUID uuid : this.logoutPlayers.keySet()) {
                    if (!uuid.equals(player.comp_1107().getId())) continue;
                    this.logoutPlayers.remove(uuid);
                }
            }
            this.loginPlayers.clear();
        } else if (packet1 instanceof class_7828) {
            class_7828 packet2 = (class_7828)packet1;
            for (UUID uuid2 : packet2.comp_1105()) {
                for (UUID uuid : this.loginPlayers.keySet()) {
                    if (!uuid.equals(uuid2)) continue;
                    class_1657 player = this.loginPlayers.get(uuid);
                    if (this.logoutPlayers.containsKey(uuid)) continue;
                    this.logoutPlayers.put(uuid, player);
                }
            }
            this.loginPlayers.clear();
        }
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.POST) {
            return;
        }
        for (class_1657 player : WaypointsModule.mc.field_1687.method_18456()) {
            if (player == null || player.equals((Object)WaypointsModule.mc.field_1724)) continue;
            this.loginPlayers.put(player.method_7334().getId(), player);
        }
    }

    @EventListener
    public void onRemoveEntity(EntityDeathEvent event) {
        if (event.getEntity() instanceof class_746 && this.deathsConfig.getValue().booleanValue()) {
            String serverIp = mc.method_1542() ? "Singleplayer" : Managers.NETWORK.getServerIp();
            Managers.WAYPOINT.removeContains("Last Death");
            Managers.WAYPOINT.register(new Waypoint("Last Death", serverIp, DimensionUtil.getDimension(), WaypointsModule.mc.field_1724.method_23317(), WaypointsModule.mc.field_1724.method_23318(), WaypointsModule.mc.field_1724.method_23321()));
        }
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (WaypointsModule.mc.field_1724 == null || WaypointsModule.mc.field_1687 == null) {
            return;
        }
        RenderBuffers.preRender();
        for (Waypoint waypoint : Managers.WAYPOINT.getWaypoints()) {
            if (!waypoint.getIp().equalsIgnoreCase(mc.method_1542() ? "Singleplayer" : Managers.NETWORK.getServerIp()) || DimensionUtil.getDimension() != waypoint.getDimension()) continue;
            this.renderWaypointBox(event.getMatrices(), waypoint.getPos(), waypoint.getName());
        }
        if (this.logoutsConfig.getValue().booleanValue()) {
            for (UUID uuid : this.logoutPlayers.keySet()) {
                class_1657 data = this.logoutPlayers.get(uuid);
                if (data == null) continue;
                this.renderWaypointBox(event.getMatrices(), data.method_19538(), data.method_5477().getString() + "'s Logout", data.method_20448());
            }
        }
        RenderBuffers.postRender();
    }

    private void renderWaypointBox(class_4587 matrixStack, class_243 pos, String tag) {
        this.renderWaypointBox(matrixStack, pos, tag, false);
    }

    private void renderWaypointBox(class_4587 matrixStack, class_243 pos, String tag, boolean crawlHitbox) {
        class_238 waypointBox = crawlHitbox ? class_4048.method_18384((float)0.6f, (float)0.6f).method_55685(0.4f).method_30757(pos) : class_4048.method_18385((float)0.6f, (float)2.2f).method_30757(pos);
        double center = (waypointBox.field_1320 - waypointBox.field_1323) / 2.0;
        RenderManager.renderBoundingBox(matrixStack, waypointBox, 1.5f, ColorsModule.getInstance().getRGB(255));
        int dist = (int)Math.sqrt(WaypointsModule.mc.field_1724.method_5707(pos));
        String waypointTag = "\u00a77" + tag + (this.coordsConfig.getValue() != false ? String.format(" XYZ %s %s %s", this.format.format(pos.method_10216()), this.format.format(pos.method_10214()), this.format.format(pos.method_10215())) : "") + (this.distanceConfig.getValue() != false ? String.format(" %sm", dist) : "");
        RenderManager.renderSign(waypointTag, waypointBox.field_1323 + center, waypointBox.field_1325 + 0.4, waypointBox.field_1321 + center, -1);
    }
}
