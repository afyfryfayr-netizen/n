package net.hachimi.client.impl.module.render;

import java.awt.Color;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.Interpolation;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.EntityOutlineEvent;
import net.hachimi.client.impl.event.entity.decoration.TeamColorEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.client.SocialsModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.entity.EntityUtil;
import net.hachimi.client.util.render.ColorUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_238;

public class ESPModule
extends ToggleModule {
    private static ESPModule INSTANCE;
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "The ESP render range", Float.valueOf(10.0f), Float.valueOf(50.0f), Float.valueOf(200.0f)));
    Config<ESPMode> modeConfig = this.register(new EnumConfig("Mode", "ESP rendering mode", (Enum)ESPMode.BOX, (Enum[])ESPMode.values()));
    Config<Boolean> fillConfig = this.register(new BooleanConfig("Fill", "Fills the box render", false, () -> this.modeConfig.getValue() == ESPMode.BOX));
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "ESP rendering line width", Float.valueOf(0.1f), Float.valueOf(2.0f), Float.valueOf(5.0f), () -> this.modeConfig.getValue() == ESPMode.BOX));
    Config<Boolean> playersConfig = this.register(new BooleanConfig("Players", "Render players through walls", true));
    Config<Boolean> selfConfig = this.register(new BooleanConfig("Self", "Render self through walls", true));
    Config<Color> playersColorConfig = this.register(new ColorConfig("PlayersColor", "The render color for players", new Color(200, 60, 60), false, () -> this.playersConfig.getValue() != false || this.selfConfig.getValue() != false));
    Config<Boolean> monstersConfig = this.register(new BooleanConfig("Monsters", "Render monsters through walls", true));
    Config<Color> monstersColorConfig = this.register(new ColorConfig("MonstersColor", "The render color for monsters", new Color(200, 60, 60), false, () -> this.monstersConfig.getValue()));
    Config<Boolean> animalsConfig = this.register(new BooleanConfig("Animals", "Render animals through walls", true));
    Config<Color> animalsColorConfig = this.register(new ColorConfig("AnimalsColor", "The render color for animals", new Color(0, 200, 0), false, () -> this.animalsConfig.getValue()));
    Config<Boolean> vehiclesConfig = this.register(new BooleanConfig("Vehicles", "Render vehicles through walls", false));
    Config<Color> vehiclesColorConfig = this.register(new ColorConfig("VehiclesColor", "The render color for vehicles", new Color(200, 100, 0), false, () -> this.vehiclesConfig.getValue()));
    Config<Boolean> itemsConfig = this.register(new BooleanConfig("Items", "Render dropped items through walls", false));
    Config<Color> itemsColorConfig = this.register(new ColorConfig("ItemsColor", "The render color for items", new Color(200, 100, 0), false, () -> this.itemsConfig.getValue()));
    Config<Boolean> crystalsConfig = this.register(new BooleanConfig("EndCrystals", "Render end crystals through walls", false));
    Config<Color> crystalsColorConfig = this.register(new ColorConfig("EndCrystalsColor", "The render color for end crystals", new Color(200, 100, 200), false, () -> this.crystalsConfig.getValue()));

    public ESPModule() {
        super("ESP", "See entities and objects through walls", ModuleCategory.RENDER);
        INSTANCE = this;
    }

    public static ESPModule getInstance() {
        return INSTANCE;
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (this.modeConfig.getValue() != ESPMode.BOX) {
            return;
        }
        RenderBuffers.preRender();
        for (class_1297 entity : ESPModule.mc.field_1687.method_18112()) {
            if (entity == ESPModule.mc.field_1724 || !this.checkESP(entity)) continue;
            Color espColor = this.getESPColor(entity);
            class_238 box = Interpolation.getInterpolatedEntityBox(entity);
            if (this.fillConfig.getValue().booleanValue()) {
                RenderManager.renderBox(event.getMatrices(), box, ColorUtil.withAlpha(espColor.getRGB(), 60));
            }
            RenderManager.renderBoundingBox(event.getMatrices(), box, this.widthConfig.getValue().floatValue(), ColorUtil.withAlpha(espColor.getRGB(), 144));
        }
        RenderBuffers.postRender();
    }

    @EventListener
    public void onEntityOutline(EntityOutlineEvent event) {
        if (ESPModule.mc.field_1724 != null && this.modeConfig.getValue() == ESPMode.GLOW && this.checkESP(event.getEntity())) {
            if (ESPModule.mc.field_1724.method_5858(event.getEntity()) > ((NumberConfig)this.rangeConfig).getValueSq()) {
                return;
            }
            event.cancel();
        }
    }

    @EventListener
    public void onTeamColor(TeamColorEvent event) {
        if (ESPModule.mc.field_1724 != null && this.modeConfig.getValue() == ESPMode.GLOW && this.checkESP(event.getEntity())) {
            if (ESPModule.mc.field_1724.method_5858(event.getEntity()) > ((NumberConfig)this.rangeConfig).getValueSq()) {
                return;
            }
            event.cancel();
            event.setColor(this.getESPColor(event.getEntity()).getRGB());
        }
    }

    public Color getESPColor(class_1297 entity) {
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (Managers.SOCIAL.isFriend(player.method_5477())) {
                return SocialsModule.getInstance().getFriendColor();
            }
            return this.playersColorConfig.getValue();
        }
        if (EntityUtil.isMonster(entity)) {
            return this.monstersColorConfig.getValue();
        }
        if (EntityUtil.isNeutral(entity) || EntityUtil.isPassive(entity)) {
            return this.animalsColorConfig.getValue();
        }
        if (EntityUtil.isVehicle(entity)) {
            return this.vehiclesColorConfig.getValue();
        }
        if (entity instanceof class_1511) {
            return this.crystalsColorConfig.getValue();
        }
        if (entity instanceof class_1542) {
            return this.itemsColorConfig.getValue();
        }
        return null;
    }

    public boolean checkESP(class_1297 entity) {
        if (entity instanceof class_1657 && this.playersConfig.getValue().booleanValue()) {
            return this.selfConfig.getValue() != false || entity != ESPModule.mc.field_1724;
        }
        return EntityUtil.isMonster(entity) && this.monstersConfig.getValue() != false || (EntityUtil.isNeutral(entity) || EntityUtil.isPassive(entity)) && this.animalsConfig.getValue() != false || EntityUtil.isVehicle(entity) && this.vehiclesConfig.getValue() != false || entity instanceof class_1511 && this.crystalsConfig.getValue() != false || entity instanceof class_1542 && this.itemsConfig.getValue() != false;
    }

    public static enum ESPMode {
        BOX,
        GLOW;

    }
}
