package net.hachimi.client.impl.module.render;

import java.awt.Color;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.util.world.BlockUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_2769;
import net.minecraft.class_3532;
import net.minecraft.class_3866;

public class StorageESPModule
extends ToggleModule {
    private static StorageESPModule INSTANCE;
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "The ESP render range", Float.valueOf(10.0f), Float.valueOf(50.0f), Float.valueOf(200.0f)));
    Config<Boolean> fillConfig = this.register(new BooleanConfig("Fill", "Fills in the highlight", false));
    Config<Float> widthConfig = this.register(new NumberConfig<Float>("Width", "The line width of the highlight", Float.valueOf(1.0f), Float.valueOf(1.5f), Float.valueOf(5.0f)));
    Config<Boolean> chestsConfig = this.register(new BooleanConfig("Chests", "Render players through walls", true));
    Config<Color> chestsColorConfig = this.register(new ColorConfig("ChestsColor", "The render color for chests", new Color(200, 200, 101), false, false, () -> this.chestsConfig.getValue()));
    Config<Boolean> echestsConfig = this.register(new BooleanConfig("EnderChests", "Render players through walls", true));
    Config<Color> echestsColorConfig = this.register(new ColorConfig("EnderChestsColor", "The render color for ender chests", new Color(155, 0, 200), false, false, () -> this.echestsConfig.getValue()));
    Config<Boolean> shulkersConfig = this.register(new BooleanConfig("Shulkers", "Render players through walls", true));
    Config<Color> shulkersColorConfig = this.register(new ColorConfig("ShulkersColor", "The render color for shulkers", new Color(200, 0, 106), false, false, () -> this.shulkersConfig.getValue()));
    Config<Boolean> hoppersConfig = this.register(new BooleanConfig("Hoppers", "Render players through walls", false));
    Config<Color> hoppersColorConfig = this.register(new ColorConfig("HoppersColor", "The render color for hoppers", new Color(100, 100, 100), false, false, () -> this.hoppersConfig.getValue()));
    Config<Boolean> furnacesConfig = this.register(new BooleanConfig("Furnaces", "Render players through walls", false));
    Config<Color> furnacesColorConfig = this.register(new ColorConfig("FurnacesColor", "The render color for furnaces", new Color(100, 100, 100), false, false, () -> this.furnacesConfig.getValue()));

    public StorageESPModule() {
        super("StorageESP", "Highlights containers in the world", ModuleCategory.RENDER);
        INSTANCE = this;
    }

    public static StorageESPModule getInstance() {
        return INSTANCE;
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        RenderBuffers.preRender();
        for (class_2586 blockEntity : BlockUtil.blockEntities()) {
            double z2;
            double y2;
            double x2;
            double z1;
            double y1;
            Color color;
            double dist = StorageESPModule.mc.field_1724.method_5707(blockEntity.method_11016().method_46558());
            if (dist > ((NumberConfig)this.rangeConfig).getValueSq() || (color = this.getStorageESPColor(blockEntity)) == null) continue;
            class_243 vec3d = blockEntity.method_11016().method_46558();
            double alpha = (100.0 - StorageESPModule.mc.field_1724.method_5707(vec3d)) / 100.0;
            alpha = 1.0 - class_3532.method_15350((double)alpha, (double)0.0, (double)1.0);
            class_2338 blockPos = blockEntity.method_11016();
            if (blockEntity instanceof class_2595) {
                class_238 chestBox;
                int outlineColor;
                int fillColor;
                double x1 = (double)blockPos.method_10263() + 0.06;
                y1 = blockPos.method_10264();
                z1 = (double)blockPos.method_10260() + 0.06;
                x2 = (double)blockPos.method_10263() + 0.94;
                y2 = (double)blockPos.method_10264() + 0.875;
                z2 = (double)blockPos.method_10260() + 0.94;
                class_2680 state = blockEntity.method_11010();
                if (!state.method_28498((class_2769)class_2281.field_10770)) continue;
                class_2350 direction = (class_2350)state.method_11654((class_2769)class_2281.field_10768);
                class_2745 type = (class_2745)state.method_11654((class_2769)class_2281.field_10770);
                if (type == class_2745.field_12571) {
                    if ((direction = direction.method_10160()).method_10148() < 0) {
                        x1 += (double)direction.method_10148();
                    } else {
                        x2 += (double)direction.method_10148();
                    }
                    if (direction.method_10165() < 0) {
                        z1 += (double)direction.method_10165();
                    } else {
                        z2 += (double)direction.method_10165();
                    }
                    fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(30.0 * alpha)).getRGB();
                    outlineColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(72.0 * alpha)).getRGB();
                    chestBox = new class_238(x1, y1, z1, x2, y2, z2);
                    if (this.fillConfig.getValue().booleanValue()) {
                        RenderManager.renderBox(event.getMatrices(), chestBox, fillColor);
                    }
                    RenderManager.renderBoundingBox(event.getMatrices(), chestBox, this.widthConfig.getValue().floatValue(), outlineColor);
                    continue;
                }
                if (type == class_2745.field_12574) {
                    if ((direction = direction.method_10170()).method_10148() < 0) {
                        x1 += (double)direction.method_10148();
                    } else {
                        x2 += (double)direction.method_10148();
                    }
                    if (direction.method_10165() < 0) {
                        z1 += (double)direction.method_10165();
                    } else {
                        z2 += (double)direction.method_10165();
                    }
                    fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(30.0 * alpha)).getRGB();
                    outlineColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(72.0 * alpha)).getRGB();
                    chestBox = new class_238(x1, y1, z1, x2, y2, z2);
                    if (this.fillConfig.getValue().booleanValue()) {
                        RenderManager.renderBox(event.getMatrices(), chestBox, fillColor);
                    }
                    RenderManager.renderBoundingBox(event.getMatrices(), chestBox, this.widthConfig.getValue().floatValue(), outlineColor);
                    continue;
                }
                if (type != class_2745.field_12569) continue;
                fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(60.0 * alpha)).getRGB();
                outlineColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(145.0 * alpha)).getRGB();
                chestBox = new class_238(x1, y1, z1, x2, y2, z2);
                if (this.fillConfig.getValue().booleanValue()) {
                    RenderManager.renderBox(event.getMatrices(), chestBox, fillColor);
                }
                RenderManager.renderBoundingBox(event.getMatrices(), chestBox, this.widthConfig.getValue().floatValue(), outlineColor);
                continue;
            }
            if (blockEntity instanceof class_2611) {
                double x1 = (double)blockPos.method_10263() + 0.06;
                y1 = blockPos.method_10264();
                z1 = (double)blockPos.method_10260() + 0.06;
                x2 = (double)blockPos.method_10263() + 0.94;
                y2 = (double)blockPos.method_10264() + 0.875;
                z2 = (double)blockPos.method_10260() + 0.94;
                int fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(60.0 * alpha)).getRGB();
                int outlineColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(145.0 * alpha)).getRGB();
                class_238 chestBox = new class_238(x1, y1, z1, x2, y2, z2);
                if (this.fillConfig.getValue().booleanValue()) {
                    RenderManager.renderBox(event.getMatrices(), chestBox, fillColor);
                }
                RenderManager.renderBoundingBox(event.getMatrices(), chestBox, this.widthConfig.getValue().floatValue(), outlineColor);
                continue;
            }
            int fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(60.0 * alpha)).getRGB();
            int outlineColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(145.0 * alpha)).getRGB();
            if (this.fillConfig.getValue().booleanValue()) {
                RenderManager.renderBox(event.getMatrices(), blockPos, fillColor);
            }
            RenderManager.renderBoundingBox(event.getMatrices(), blockPos, this.widthConfig.getValue().floatValue(), outlineColor);
        }
        RenderBuffers.postRender();
    }

    public Color getStorageESPColor(class_2586 tileEntity) {
        if (tileEntity instanceof class_2595) {
            class_2595 chestBlockEntity = (class_2595)tileEntity;
            return this.chestsColorConfig.getValue();
        }
        if (tileEntity instanceof class_2611) {
            return this.echestsColorConfig.getValue();
        }
        if (tileEntity instanceof class_2627) {
            return this.shulkersColorConfig.getValue();
        }
        if (tileEntity instanceof class_2614) {
            return this.hoppersColorConfig.getValue();
        }
        if (tileEntity instanceof class_3866) {
            return this.furnacesColorConfig.getValue();
        }
        return null;
    }
}
