package net.hachimi.client.impl.module;

import java.util.Comparator;
import java.util.function.Predicate;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.impl.module.RotationModule;
import net.hachimi.client.init.Managers;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_742;
import net.minecraft.class_746;

public class CombatModule
extends RotationModule {
    protected Config<Boolean> multitaskConfig = this.register(new BooleanConfig("Multitask", "Allows actions while using items", false));

    public CombatModule(String name, String desc, ModuleCategory category) {
        super(name, desc, category);
    }

    public CombatModule(String name, String desc, ModuleCategory category, int rotationPriority) {
        super(name, desc, category, rotationPriority);
    }

    public class_1657 getClosestPlayer(double range) {
        return CombatModule.mc.field_1687.method_18456().stream().filter(e -> !(e instanceof class_746) && !e.method_7325()).filter(e -> CombatModule.mc.field_1724.method_5858((class_1297)e) <= range * range).filter(e -> !Managers.SOCIAL.isFriend(e.method_5477().getString())).min(Comparator.comparingDouble(e -> CombatModule.mc.field_1724.method_5858((class_1297)e))).orElse(null);
    }

    public class_1657 getClosestPlayer(Predicate<class_742> entityPredicate, double range) {
        return CombatModule.mc.field_1687.method_18456().stream().filter(e -> !(e instanceof class_746) && !e.method_7325()).filter(entityPredicate).filter(e -> CombatModule.mc.field_1724.method_5858((class_1297)e) <= range * range).filter(e -> !Managers.SOCIAL.isFriend(e.method_5477().getString())).min(Comparator.comparingDouble(e -> CombatModule.mc.field_1724.method_5858((class_1297)e))).orElse(null);
    }

    public boolean checkMultitask() {
        return this.checkMultitask(false);
    }

    public boolean checkMultitask(boolean checkOffhand) {
        if (checkOffhand && CombatModule.mc.field_1724.method_6058() != class_1268.field_5808) {
            return false;
        }
        return CombatModule.mc.field_1724.method_6115();
    }
}
