package net.hachimi.client.impl.module.player;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.MacroConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.macro.Macro;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.MouseUpdateEvent;
import net.hachimi.client.impl.event.PerspectiveEvent;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.camera.CameraPositionEvent;
import net.hachimi.client.impl.event.camera.CameraRotationEvent;
import net.hachimi.client.impl.event.camera.EntityCameraPositionEvent;
import net.hachimi.client.impl.event.entity.EntityDeathEvent;
import net.hachimi.client.impl.event.entity.EntityRotationVectorEvent;
import net.hachimi.client.impl.event.keyboard.KeyboardInputEvent;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.render.BobViewEvent;
import net.hachimi.client.impl.event.render.item.RenderFirstPersonEvent;
import net.hachimi.client.impl.manager.player.rotation.Rotation;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.player.RayCastUtil;
import net.hachimi.client.util.player.RotationUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_239;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_315;
import net.minecraft.class_3532;
import net.minecraft.class_743;

public class FreecamModule
extends ToggleModule {
    private static FreecamModule INSTANCE;
    Config<Float> speedConfig = this.register(new NumberConfig<Float>("Speed", "The move speed of the camera", Float.valueOf(0.1f), Float.valueOf(4.0f), Float.valueOf(10.0f)));
    Config<Macro> controlConfig = this.register(new MacroConfig("ControlKey", "", new Macro(this.getId() + "-control", 342, () -> {})));
    Config<Boolean> toggleControlConfig = this.register(new BooleanConfig("ToggleControl", "Allows toggling control key instead of holding", false));
    Config<Interact> interactConfig = this.register(new EnumConfig("Interact", "The interaction type of the camera", (Enum)Interact.CAMERA, (Enum[])Interact.values()));
    Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Rotate to the point of interaction", false));
    public class_243 position;
    public class_243 lastPosition;
    public float yaw;
    public float pitch;
    public boolean control = false;

    public FreecamModule() {
        super("Freecam", "Allows you to control the camera separately from the player", ModuleCategory.PLAYER);
        INSTANCE = this;
    }

    public static FreecamModule getInstance() {
        return INSTANCE;
    }

    @Override
    protected void onEnable() {
        if (FreecamModule.mc.field_1724 == null) {
            return;
        }
        this.control = false;
        this.lastPosition = this.position = FreecamModule.mc.field_1773.method_19418().method_19326();
        this.yaw = FreecamModule.mc.field_1724.method_36454();
        this.pitch = FreecamModule.mc.field_1724.method_36455();
        FreecamModule.mc.field_1724.field_3913 = new FreecamKeyboardInput(FreecamModule.mc.field_1690);
    }

    @Override
    protected void onDisable() {
        if (FreecamModule.mc.field_1724 == null) {
            return;
        }
        FreecamModule.mc.field_1724.field_3913 = new class_743(FreecamModule.mc.field_1690);
    }

    @EventListener
    public void onDeath(EntityDeathEvent event) {
        if (event.getEntity() == FreecamModule.mc.field_1724) {
            this.disable();
        }
    }

    @EventListener
    public void onKey(KeyboardInputEvent event) {
        if (event.getAction() != 2 && event.getKeycode() == this.controlConfig.getValue().getKeycode()) {
            if (!this.toggleControlConfig.getValue().booleanValue()) {
                this.control = event.getAction() == 1;
            } else if (event.getAction() == 1) {
                this.control = !this.control;
            }
        }
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        this.disable();
    }

    @EventListener
    public void onCameraPosition(CameraPositionEvent event) {
        event.setPosition(this.control ? this.position : this.lastPosition.method_35590(this.position, (double)event.getTickDelta()));
    }

    @EventListener
    public void onCameraRotation(CameraRotationEvent event) {
        event.setRotation(new class_241(this.yaw, this.pitch));
    }

    @EventListener
    public void onMouseUpdate(MouseUpdateEvent event) {
        if (!this.control) {
            event.cancel();
            this.changeLookDirection(event.getCursorDeltaX(), event.getCursorDeltaY());
        }
    }

    @EventListener
    public void onEntityCameraPosition(EntityCameraPositionEvent event) {
        if (event.getEntity() != FreecamModule.mc.field_1724) {
            return;
        }
        if (!this.control && this.interactConfig.getValue() == Interact.CAMERA) {
            event.setPosition(this.position);
        }
    }

    @EventListener
    public void onEntityRotation(EntityRotationVectorEvent event) {
        if (event.getEntity() != FreecamModule.mc.field_1724) {
            return;
        }
        if (!this.control && this.interactConfig.getValue() == Interact.CAMERA) {
            event.setPosition(RotationUtil.getRotationVector(this.pitch, this.yaw));
        }
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (!this.control && this.rotateConfig.getValue().booleanValue()) {
            float[] currentAngles = new float[]{this.yaw, this.pitch};
            class_243 eyePos = this.position;
            class_239 result = RayCastUtil.rayCast(FreecamModule.mc.field_1724.method_55754(), eyePos, currentAngles);
            if (result.method_17783() == class_239.class_240.field_1332) {
                float[] newAngles = RotationUtil.getRotationsTo(FreecamModule.mc.field_1724.method_33571(), result.method_17784());
                Managers.ROTATION.setRotation(new Rotation(1, newAngles[0], newAngles[1]));
            }
        }
    }

    @EventListener
    public void onPerspective(PerspectiveEvent event) {
        event.cancel();
    }

    @EventListener
    public void onRenderArm(RenderFirstPersonEvent.Head event) {
        event.cancel();
    }

    @EventListener
    public void onBob(BobViewEvent event) {
        if (this.control) {
            event.cancel();
        }
    }

    private float getMovementMultiplier(boolean positive, boolean negative) {
        if (positive == negative) {
            return 0.0f;
        }
        return positive ? 1.0f : -1.0f;
    }

    private class_241 handleVanillaMotion(float speed, float forward, float strafe) {
        if (forward == 0.0f && strafe == 0.0f) {
            return class_241.field_1340;
        }
        if (forward != 0.0f && strafe != 0.0f) {
            forward *= (float)Math.sin(0.7853981633974483);
            strafe *= (float)Math.cos(0.7853981633974483);
        }
        return new class_241((float)((double)(forward * speed) * -Math.sin(Math.toRadians(this.yaw)) + (double)(strafe * speed) * Math.cos(Math.toRadians(this.yaw))), (float)((double)(forward * speed) * Math.cos(Math.toRadians(this.yaw)) - (double)(strafe * speed) * -Math.sin(Math.toRadians(this.yaw))));
    }

    private void changeLookDirection(double cursorDeltaX, double cursorDeltaY) {
        float f = (float)cursorDeltaY * 0.15f;
        float g = (float)cursorDeltaX * 0.15f;
        this.pitch += f;
        this.yaw += g;
        this.pitch = class_3532.method_15363((float)this.pitch, (float)-90.0f, (float)90.0f);
    }

    public class_243 getCameraPosition() {
        return this.position;
    }

    public class_243 getLastCameraPosition() {
        return this.lastPosition;
    }

    public float[] getCameraRotations() {
        return new float[]{this.yaw, this.pitch};
    }

    public static enum Interact {
        PLAYER,
        CAMERA;

    }

    public class FreecamKeyboardInput
    extends class_743 {
        private final class_315 options;

        public FreecamKeyboardInput(class_315 options) {
            super(options);
            this.options = options;
        }

        public void method_3129(boolean slowDown, float slowDownFactor) {
            if (FreecamModule.this.control) {
                super.method_3129(slowDown, slowDownFactor);
            } else {
                this.unset();
                float speed = FreecamModule.this.speedConfig.getValue().floatValue() / 10.0f;
                float fakeMovementForward = FreecamModule.this.getMovementMultiplier(this.options.field_1894.method_1434(), this.options.field_1881.method_1434());
                float fakeMovementSideways = FreecamModule.this.getMovementMultiplier(this.options.field_1913.method_1434(), this.options.field_1849.method_1434());
                class_241 dir = FreecamModule.this.handleVanillaMotion(speed, fakeMovementForward, fakeMovementSideways);
                float y = 0.0f;
                if (this.options.field_1903.method_1434()) {
                    y += speed;
                } else if (this.options.field_1832.method_1434()) {
                    y -= speed;
                }
                FreecamModule.this.lastPosition = FreecamModule.this.position;
                FreecamModule.this.position = FreecamModule.this.position.method_1031((double)dir.field_1343, (double)y, (double)dir.field_1342);
            }
        }

        private void unset() {
            this.field_3910 = false;
            this.field_3909 = false;
            this.field_3908 = false;
            this.field_3906 = false;
            this.field_3905 = 0.0f;
            this.field_3907 = 0.0f;
            this.field_3904 = false;
            this.field_3903 = false;
        }
    }
}
