package net.hachimi.client.impl.module.player;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ColorConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.config.ConfigUpdateEvent;
import net.hachimi.client.impl.event.network.AttackBlockEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.CombatModule;
import net.hachimi.client.impl.module.client.AnticheatModule;
import net.hachimi.client.impl.module.player.AutoToolModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.mixin.accessor.AccessorClientPlayerInteractionManager;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.collection.FirstOutQueue;
import net.hachimi.client.util.player.EnchantmentUtil;
import net.hachimi.client.util.player.RotationUtil;
import net.hachimi.client.util.render.ColorUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_2626;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_8042;

public class SpeedmineModule
extends CombatModule {
    private static SpeedmineModule INSTANCE;
    Config<SpeedmineMode> modeConfig = this.register(new EnumConfig("Mode", "The mining mode for speedmine", (Enum)SpeedmineMode.PACKET, (Enum[])SpeedmineMode.values()));
    Config<Boolean> multitaskConfig = this.register(new BooleanConfig("Multitask", "Allows mining while using items", false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Boolean> doubleBreakConfig = this.register(new BooleanConfig("DoubleBreak", "Allows you to mine two blocks at once", false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "The range to mine blocks", Float.valueOf(0.1f), Float.valueOf(4.0f), Float.valueOf(6.0f), () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Float> speedConfig = this.register(new NumberConfig<Float>("Speed", "The speed to mine blocks", Float.valueOf(0.1f), Float.valueOf(1.0f), Float.valueOf(1.0f)));
    Config<Boolean> instantConfig = this.register(new BooleanConfig("Instant", "Instantly mines already broken blocks", false));
    Config<Swap> swapConfig = this.register(new EnumConfig("AutoSwap", "Swaps to the best tool once the mining is complete", (Enum)Swap.SILENT, (Enum[])Swap.values(), () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Boolean> rotateConfig = this.register(new BooleanConfig("Rotate", "Rotates when mining the block", true, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Boolean> switchResetConfig = this.register(new BooleanConfig("SwitchReset", "Resets mining after switching items", false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Boolean> grimConfig = this.register(new BooleanConfig("Grim", "Uses grim block breaking speeds", false));
    Config<Boolean> grimNewConfig = this.register(new BooleanConfig("GrimV3", "Uses new grim block breaking speeds", false, () -> this.grimConfig.getValue()));
    Config<Color> colorConfig = this.register(new ColorConfig("MineColor", "The mine render color", Color.RED, false, false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Color> colorDoneConfig = this.register(new ColorConfig("DoneColor", "The done render color", Color.GREEN, false, false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Boolean> smoothColorConfig = this.register(new BooleanConfig("ColorSmooth", "Interpolates from start to done color", false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<Boolean> renderConfig = this.register(new BooleanConfig("Render", "Renders the mining progress box", true, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET));
    Config<BoxMode> boxModeConfig = this.register(new EnumConfig("BoxMode", "Which boxes are rendered", (Enum)BoxMode.END, (Enum[])BoxMode.values(), () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false));
    Config<Color> startSideConfig = this.register(new ColorConfig("StartSide", "The fill color of the start box", new Color(255, 255, 0), false, false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false && (this.boxModeConfig.getValue() == BoxMode.BOTH || this.boxModeConfig.getValue() == BoxMode.START)));
    Config<Color> startLineConfig = this.register(new ColorConfig("StartLine", "The outline color of the start box", new Color(255, 255, 0), false, false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false && (this.boxModeConfig.getValue() == BoxMode.BOTH || this.boxModeConfig.getValue() == BoxMode.START)));
    Config<Easing> easingConfig = this.register(new EnumConfig("Easing", "The animation easing curve for the progress box", (Enum)Easing.LINEAR, (Enum[])Easing.values(), () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false));
    Config<Boolean> blockOutlineConfig = this.register(new BooleanConfig("BlockOutline", "Renders the outline of the mining boxes", true, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false));
    Config<Boolean> boxAnimationConfig = this.register(new BooleanConfig("BoxAnimation", "Animates the progress box size based on mining progress", true, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false));
    Config<Integer> fadeTimeConfig = this.register(new NumberConfig<Integer>("Fade-Time", "The time in milliseconds to fade the render in/out", Integer.valueOf(0), Integer.valueOf(250), Integer.valueOf(1000), () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false));
    Config<Boolean> showProgressConfig = this.register(new BooleanConfig("ShowProgress", "Shows the mining progress percentage above the block", false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false));
    Config<Boolean> progressBarConfig = this.register(new BooleanConfig("ProgressBar", "Shows a text-based progress bar with the percentage", false, () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false && this.showProgressConfig.getValue() != false));
    Config<Float> progressScaleConfig = this.register(new NumberConfig<Float>("ProgressScale", "The scale of the progress text", Float.valueOf(0.5f), Float.valueOf(1.0f), Float.valueOf(3.0f), () -> this.modeConfig.getValue() == SpeedmineMode.PACKET && this.renderConfig.getValue() != false && this.showProgressConfig.getValue() != false));
    private final Map<MiningData, Animation> fadeList = new HashMap<MiningData, Animation>();
    private FirstOutQueue<MiningData> miningQueue = new FirstOutQueue(2);
    private long lastBreak;

    public SpeedmineModule() {
        super("Speedmine", "Mines blocks faster", ModuleCategory.PLAYER, 900);
        INSTANCE = this;
    }

    public static SpeedmineModule getInstance() {
        return INSTANCE;
    }

    @Override
    public String getModuleData() {
        MiningData miningData;
        if (this.modeConfig.getValue() == SpeedmineMode.PACKET && (miningData = (MiningData)this.miningQueue.peek()) != null) {
            return String.format("%.1f", Float.valueOf(Math.min(miningData.getBlockDamage(), 1.0f)));
        }
        return super.getModuleData();
    }

    @Override
    protected void onDisable() {
        this.miningQueue.clear();
        this.fadeList.clear();
        Managers.INVENTORY.syncToClient();
    }

    @Override
    public void onEnable() {
        this.miningQueue = this.doubleBreakConfig.getValue() != false ? new FirstOutQueue(2) : new FirstOutQueue(1);
    }

    @EventListener
    public void onPlayerTick(TickEvent event) {
        if (SpeedmineModule.mc.field_1724.method_7337() || SpeedmineModule.mc.field_1724.method_7325() || event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (this.modeConfig.getValue() == SpeedmineMode.DAMAGE) {
            AccessorClientPlayerInteractionManager interactionManager = (AccessorClientPlayerInteractionManager)SpeedmineModule.mc.field_1761;
            if (interactionManager.hookGetCurrentBreakingProgress() >= this.speedConfig.getValue().floatValue()) {
                interactionManager.hookSetCurrentBreakingProgress(1.0f);
            }
            return;
        }
        if (this.miningQueue.isEmpty()) {
            return;
        }
        for (MiningData data : this.miningQueue) {
            if (data.getState().method_26215()) {
                data.resetBreakTime();
            }
            if (this.isDataPacketMine(data) && (data.getState().method_26215() || data.hasAttemptedBreak() && data.passedAttemptedBreakTime(500L))) {
                Managers.INVENTORY.syncToClient();
                this.miningQueue.remove(data);
                continue;
            }
            float damageDelta = this.calcBlockBreakingDelta(data.getState(), (class_1922)SpeedmineModule.mc.field_1687, data.getPos());
            data.damage(damageDelta);
            if (!this.isDataPacketMine(data) || !(data.getBlockDamage() >= 1.0f) || data.getSlot() == -1) continue;
            if (SpeedmineModule.mc.field_1724.method_6115() && !this.multitaskConfig.getValue().booleanValue()) {
                return;
            }
            if (data.getSlot() != Managers.INVENTORY.getServerSlot()) {
                Managers.INVENTORY.setSlot(data.getSlot());
            }
            if (data.hasAttemptedBreak()) continue;
            data.setAttemptedBreak(true);
        }
        MiningData miningData2 = this.miningQueue.getFirst();
        double distance = SpeedmineModule.mc.field_1724.method_33571().method_1025(miningData2.getPos().method_46558());
        if (distance > ((NumberConfig)this.rangeConfig).getValueSq()) {
            this.miningQueue.remove(miningData2);
            return;
        }
        if (miningData2.getState().method_26215()) {
            return;
        }
        if (miningData2.getBlockDamage() >= this.speedConfig.getValue().floatValue() && miningData2.hasAttemptedBreak() && miningData2.passedAttemptedBreakTime(500L)) {
            this.abortMining(miningData2);
            this.miningQueue.remove(miningData2);
        }
        if (miningData2.getBlockDamage() >= this.speedConfig.getValue().floatValue()) {
            if (SpeedmineModule.mc.field_1724.method_6115() && !this.multitaskConfig.getValue().booleanValue()) {
                return;
            }
            this.stopMining(miningData2);
            if (!this.instantConfig.getValue().booleanValue()) {
                this.miningQueue.remove(miningData2);
            }
            if (!miningData2.hasAttemptedBreak()) {
                miningData2.setAttemptedBreak(true);
            }
        }
    }

    @EventListener
    public void onAttackBlock(AttackBlockEvent event) {
        if (SpeedmineModule.mc.field_1724.method_7337() || SpeedmineModule.mc.field_1724.method_7325() || this.modeConfig.getValue() != SpeedmineMode.PACKET) {
            return;
        }
        event.cancel();
        if (event.getState().method_26204().method_36555() == -1.0f || event.getState().method_26215()) {
            return;
        }
        this.startManualMine(event.getPos(), event.getDirection());
        SpeedmineModule.mc.field_1724.method_6104(class_1268.field_5808);
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Outbound event) {
        class_2846 packet;
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2846 && (packet = (class_2846)class_25962).method_12363() == class_2846.class_2847.field_12973 && this.modeConfig.getValue() == SpeedmineMode.DAMAGE && this.grimConfig.getValue().booleanValue()) {
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, packet.method_12362().method_10086(500), packet.method_12360()));
        }
        if (event.getPacket() instanceof class_2868 && this.switchResetConfig.getValue().booleanValue() && this.modeConfig.getValue() == SpeedmineMode.PACKET) {
            for (MiningData data : this.miningQueue) {
                data.resetDamage();
            }
        }
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        if (SpeedmineModule.mc.field_1724 == null || this.modeConfig.getValue() != SpeedmineMode.PACKET) {
            return;
        }
        Object object = event.getPacket();
        if (object instanceof class_2626) {
            class_2626 packet = (class_2626)object;
            this.handleBlockUpdatePacket(packet);
        } else {
            object = event.getPacket();
            if (object instanceof class_8042) {
                class_8042 packet = (class_8042)object;
                for (class_2596 packet1 : packet.method_48324()) {
                    if (!(packet1 instanceof class_2626)) continue;
                    class_2626 packet2 = (class_2626)packet1;
                    this.handleBlockUpdatePacket(packet2);
                }
            }
        }
    }

    private void handleBlockUpdatePacket(class_2626 packet) {
        if (!packet.method_11308().method_26215()) {
            return;
        }
        for (MiningData data : this.miningQueue) {
            if (!data.hasAttemptedBreak() || !data.getPos().equals((Object)packet.method_11309())) continue;
            data.setAttemptedBreak(false);
        }
    }

    @EventListener
    public void onConfigUpdate(ConfigUpdateEvent event) {
        if (event.getStage() == StageEvent.EventStage.POST && event.getConfig() == this.doubleBreakConfig) {
            this.miningQueue = this.doubleBreakConfig.getValue() != false ? new FirstOutQueue(2) : new FirstOutQueue(1);
        }
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (SpeedmineModule.mc.field_1724.method_7337() || this.modeConfig.getValue() != SpeedmineMode.PACKET || !this.renderConfig.getValue().booleanValue()) {
            return;
        }
        RenderBuffers.preRender();
        for (Map.Entry<MiningData, Animation> set : this.fadeList.entrySet()) {
            String text;
            int lineColor;
            int sideColor;
            MiningData data = set.getKey();
            Animation animation = set.getValue();
            animation.setState(false);
            int boxAlpha = (int)(40.0 * animation.getFactor());
            int lineAlpha = (int)(100.0 * animation.getFactor());
            class_2338 mining = data.getPos();
            class_265 outlineShape = data.getState().method_26218((class_1922)SpeedmineModule.mc.field_1687, mining);
            outlineShape = outlineShape.method_1110() ? class_259.method_1077() : outlineShape;
            class_238 render1 = outlineShape.method_1107();
            class_238 render = new class_238((double)mining.method_10263() + render1.field_1323, (double)mining.method_10264() + render1.field_1322, (double)mining.method_10260() + render1.field_1321, (double)mining.method_10263() + render1.field_1320, (double)mining.method_10264() + render1.field_1325, (double)mining.method_10260() + render1.field_1324);
            class_243 center = render.method_1005();
            double dx = (render1.field_1320 - render1.field_1323) / 2.0;
            double dy = (render1.field_1325 - render1.field_1322) / 2.0;
            double dz = (render1.field_1324 - render1.field_1321) / 2.0;
            float total = this.isDataPacketMine(data) ? 1.0f : this.speedConfig.getValue().floatValue();
            float rawProgress = data.getState().method_26215() ? 1.0f : class_3532.method_15363((float)((data.getBlockDamage() + (data.getBlockDamage() - data.getLastDamage()) * event.getTickDelta()) / total), (float)0.0f, (float)1.0f);
            float progress = this.applyEasing(rawProgress);
            BoxMode boxMode = this.boxModeConfig.getValue();
            if (boxMode == BoxMode.BOTH || boxMode == BoxMode.START) {
                sideColor = ((ColorConfig)this.startSideConfig).getRgb(boxAlpha);
                lineColor = ((ColorConfig)this.startLineConfig).getRgb(lineAlpha);
                RenderManager.renderBox(event.getMatrices(), render, sideColor);
                if (this.blockOutlineConfig.getValue().booleanValue()) {
                    RenderManager.renderBoundingBox(event.getMatrices(), render, 1.5f, lineColor);
                }
            }
            if (boxMode == BoxMode.BOTH || boxMode == BoxMode.END) {
                if (this.smoothColorConfig.getValue().booleanValue()) {
                    sideColor = data.getState().method_26215() ? ((ColorConfig)this.colorDoneConfig).getRgb(boxAlpha) : ColorUtil.interpolateColor(Math.min(data.getBlockDamage(), 1.0f), ((ColorConfig)this.colorDoneConfig).getValue(boxAlpha), ((ColorConfig)this.colorConfig).getValue(boxAlpha)).getRGB();
                    lineColor = data.getState().method_26215() ? ((ColorConfig)this.colorDoneConfig).getRgb(lineAlpha) : ColorUtil.interpolateColor(Math.min(data.getBlockDamage(), 1.0f), ((ColorConfig)this.colorDoneConfig).getValue(lineAlpha), ((ColorConfig)this.colorConfig).getValue(lineAlpha)).getRGB();
                } else {
                    sideColor = data.getBlockDamage() >= 0.95f || data.getState().method_26215() ? ((ColorConfig)this.colorDoneConfig).getRgb(boxAlpha) : ((ColorConfig)this.colorConfig).getRgb(boxAlpha);
                    lineColor = data.getBlockDamage() >= 0.95f || data.getState().method_26215() ? ((ColorConfig)this.colorDoneConfig).getRgb(lineAlpha) : ((ColorConfig)this.colorConfig).getRgb(lineAlpha);
                }
                float scale = this.boxAnimationConfig.getValue() != false ? progress : 1.0f;
                class_238 scaled = new class_238(center, center).method_1009(dx * (double)scale, dy * (double)scale, dz * (double)scale);
                RenderManager.renderBox(event.getMatrices(), scaled, sideColor);
                if (this.blockOutlineConfig.getValue().booleanValue()) {
                    RenderManager.renderBoundingBox(event.getMatrices(), scaled, 1.5f, lineColor);
                }
            }
            if (!this.showProgressConfig.getValue().booleanValue()) continue;
            if (this.progressBarConfig.getValue().booleanValue()) {
                int barLength = 10;
                int filled = Math.round(rawProgress * (float)barLength);
                StringBuilder bar = new StringBuilder("[");
                for (int i = 0; i < barLength; ++i) {
                    bar.append(i < filled ? (char)'|' : ' ');
                }
                bar.append("] ").append(String.format("%.0f%%", Float.valueOf(rawProgress * 100.0f)));
                text = bar.toString();
            } else {
                text = String.format("%.0f%%", Float.valueOf(rawProgress * 100.0f));
            }
            class_243 textPos = center.method_1031(0.0, 0.0, 0.0);
            int textColor = ((ColorConfig)this.colorDoneConfig).getRgb(255);
            float scaling = 0.025f * this.progressScaleConfig.getValue().floatValue();
            RenderManager.renderSign(text, textPos, scaling, textColor);
        }
        for (MiningData data : this.miningQueue) {
            if (data.getState().method_26215()) continue;
            Animation animation = new Animation(true, this.fadeTimeConfig.getValue().intValue());
            this.fadeList.put(data, animation);
        }
        this.fadeList.entrySet().removeIf(e -> ((Animation)e.getValue()).getFactor() == 0.0);
        RenderBuffers.postRender();
    }

    private float applyEasing(float t) {
        t = class_3532.method_15363((float)t, (float)0.0f, (float)1.0f);
        return switch (this.easingConfig.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> t;
            case 1 -> t * t;
            case 2 -> 1.0f - (1.0f - t) * (1.0f - t);
            case 3 -> t < 0.5f ? 2.0f * t * t : 1.0f - (float)Math.pow(-2.0 * (double)t + 2.0, 2.0) / 2.0f;
        };
    }

    private void startManualMine(class_2338 pos, class_2350 direction) {
        this.clickMine(new MiningData(pos, direction));
    }

    public void clickMine(MiningData miningData) {
        int queueSize = this.miningQueue.size();
        if (queueSize <= 2) {
            this.queueMiningData(miningData);
        }
    }

    private void queueMiningData(MiningData data) {
        if (data.getState().method_26215()) {
            return;
        }
        if (this.startMining(data)) {
            if (this.miningQueue.stream().anyMatch(p1 -> data.getPos().equals((Object)p1.getPos()))) {
                return;
            }
            this.miningQueue.addFirst(data);
        }
    }

    private boolean startMining(MiningData data) {
        if (data.isStarted()) {
            return false;
        }
        data.setStarted();
        if (this.grimNewConfig.getValue().booleanValue()) {
            if (!AnticheatModule.getInstance().getMiningFix()) {
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, data.getPos(), data.getDirection()));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12968, data.getPos(), data.getDirection()));
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, data.getPos(), data.getDirection()));
            } else {
                Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12968, data.getPos(), data.getDirection()));
            }
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, data.getPos(), data.getDirection()));
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
            Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
            return true;
        }
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12968, data.getPos(), data.getDirection()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, data.getPos(), data.getDirection()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, data.getPos(), data.getDirection()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12968, data.getPos(), data.getDirection()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, data.getPos(), data.getDirection()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, data.getPos(), data.getDirection()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        return true;
    }

    private void abortMining(MiningData data) {
        if (!data.isStarted() || data.getState().method_26215()) {
            return;
        }
        Managers.NETWORK.sendSequencedPacket(id -> new class_2846(class_2846.class_2847.field_12971, data.getPos(), data.getDirection(), id));
        Managers.INVENTORY.syncToClient();
    }

    private void stopMining(MiningData data) {
        int slot;
        boolean canSwap;
        if (!data.isStarted() || data.getState().method_26215()) {
            return;
        }
        if (this.rotateConfig.getValue().booleanValue()) {
            float[] rotations = RotationUtil.getRotationsTo(SpeedmineModule.mc.field_1724.method_33571(), data.getPos().method_46558());
            if (this.grimConfig.getValue().booleanValue()) {
                this.setRotationSilent(rotations[0], rotations[1]);
            } else {
                this.setRotation(rotations[0], rotations[1]);
            }
        }
        boolean bl = canSwap = (slot = data.getSlot()) != -1 && slot != Managers.INVENTORY.getServerSlot();
        if (canSwap) {
            this.swapTo(slot);
        }
        this.stopMiningInternal(data);
        this.lastBreak = System.currentTimeMillis();
        if (canSwap) {
            this.swapSync(slot);
        }
        if (this.rotateConfig.getValue().booleanValue()) {
            Managers.ROTATION.setRotationSilentSync();
        }
    }

    private void swapTo(int slot) {
        switch (this.swapConfig.getValue().ordinal()) {
            case 0: {
                Managers.INVENTORY.setClientSlot(slot);
                break;
            }
            case 1: {
                Managers.INVENTORY.setSlot(slot);
                break;
            }
            case 2: {
                Managers.INVENTORY.setSlotAlt(slot);
            }
        }
    }

    private void swapSync(int slot) {
        switch (this.swapConfig.getValue().ordinal()) {
            case 1: {
                Managers.INVENTORY.syncToClient();
                break;
            }
            case 2: {
                Managers.INVENTORY.setSlotAlt(slot);
            }
        }
    }

    private void stopMiningInternal(MiningData data) {
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12973, data.getPos(), data.getDirection()));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2846(class_2846.class_2847.field_12971, data.getPos(), data.getDirection()));
    }

    public boolean isBlockDelayGrim() {
        return System.currentTimeMillis() - this.lastBreak <= 280L && this.grimConfig.getValue() != false;
    }

    private boolean isDataPacketMine(MiningData data) {
        return this.miningQueue.size() == 2 && data == this.miningQueue.getLast();
    }

    public float calcBlockBreakingDelta(class_2680 state, class_1922 world, class_2338 pos) {
        if (this.swapConfig.getValue() == Swap.OFF) {
            return state.method_26165((class_1657)SpeedmineModule.mc.field_1724, (class_1922)SpeedmineModule.mc.field_1687, pos);
        }
        float f = state.method_26214(world, pos);
        if (f == -1.0f) {
            return 0.0f;
        }
        int i = this.canHarvest(state) ? 30 : 100;
        return this.getBlockBreakingSpeed(state) / f / (float)i;
    }

    private float getBlockBreakingSpeed(class_2680 block) {
        class_1799 stack;
        int i;
        int tool = AutoToolModule.getInstance().getBestTool(block);
        float f = SpeedmineModule.mc.field_1724.method_31548().method_5438(tool).method_7924(block);
        if (f > 1.0f && (i = EnchantmentUtil.getLevel(stack = SpeedmineModule.mc.field_1724.method_31548().method_5438(tool), (class_5321<class_1887>)class_1893.field_9131)) > 0 && !stack.method_7960()) {
            f += (float)(i * i + 1);
        }
        if (class_1292.method_5576((class_1309)SpeedmineModule.mc.field_1724)) {
            f *= 1.0f + (float)(class_1292.method_5575((class_1309)SpeedmineModule.mc.field_1724) + 1) * 0.2f;
        }
        if (SpeedmineModule.mc.field_1724.method_6059(class_1294.field_5901)) {
            float g = switch (SpeedmineModule.mc.field_1724.method_6112(class_1294.field_5901).method_5578()) {
                case 0 -> 0.3f;
                case 1 -> 0.09f;
                case 2 -> 0.0027f;
                default -> 8.1E-4f;
            };
            f *= g;
        }
        if (!SpeedmineModule.mc.field_1724.method_24828()) {
            f /= 5.0f;
        }
        return f;
    }

    private boolean canHarvest(class_2680 state) {
        if (state.method_29291()) {
            int tool = AutoToolModule.getInstance().getBestTool(state);
            return SpeedmineModule.mc.field_1724.method_31548().method_5438(tool).method_7951(state);
        }
        return true;
    }

    public boolean isMining() {
        return !this.miningQueue.isEmpty();
    }

    public static enum SpeedmineMode {
        PACKET,
        DAMAGE;

    }

    public static enum Swap {
        NORMAL,
        SILENT,
        SILENT_ALT,
        OFF;

    }

    public static enum BoxMode {
        BOTH,
        START,
        END,
        NONE;

    }

    public static enum Easing {
        LINEAR,
        EASE_IN,
        EASE_OUT,
        EASE_IN_OUT;

    }

    public static class MiningData {
        private boolean attemptedBreak;
        private long breakTime;
        private final class_2338 pos;
        private final class_2350 direction;
        private float lastDamage;
        private float blockDamage;
        private boolean started;

        public MiningData(class_2338 pos, class_2350 direction) {
            this.pos = pos;
            this.direction = direction;
        }

        public void setAttemptedBreak(boolean attemptedBreak) {
            this.attemptedBreak = attemptedBreak;
            if (attemptedBreak) {
                this.resetBreakTime();
            }
        }

        public void resetBreakTime() {
            this.breakTime = System.currentTimeMillis();
        }

        public boolean hasAttemptedBreak() {
            return this.attemptedBreak;
        }

        public boolean passedAttemptedBreakTime(long time) {
            return System.currentTimeMillis() - this.breakTime >= time;
        }

        public float damage(float dmg) {
            this.lastDamage = this.blockDamage;
            this.blockDamage += dmg;
            return this.blockDamage;
        }

        public void setDamage(float blockDamage) {
            this.blockDamage = blockDamage;
        }

        public void resetDamage() {
            this.started = false;
            this.blockDamage = 0.0f;
        }

        public class_2338 getPos() {
            return this.pos;
        }

        public class_2350 getDirection() {
            return this.direction;
        }

        public int getSlot() {
            return AutoToolModule.getInstance().getBestToolNoFallback(this.getState());
        }

        public class_2680 getState() {
            return Globals.mc.field_1687.method_8320(this.pos);
        }

        public float getBlockDamage() {
            return this.blockDamage;
        }

        public float getLastDamage() {
            return this.lastDamage;
        }

        public boolean isStarted() {
            return this.started;
        }

        public void setStarted() {
            this.started = true;
        }
    }

    public static enum Selection {
        WHITELIST,
        BLACKLIST,
        ALL;

    }
}
