package net.hachimi.client.impl.module.player;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.entity.EntityDeathEvent;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.client.util.player.InventoryUtil;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_476;
import net.minecraft.class_490;
import net.minecraft.class_495;
import net.minecraft.class_746;

public class ReplenishModule
extends ToggleModule {
    private static ReplenishModule INSTANCE;
    Config<Integer> percentConfig = this.register(new NumberConfig<Integer>("Percent", "The minimum percent of total stack before replenishing", 1, 25, 80));
    Config<Boolean> resistantConfig = this.register(new BooleanConfig("AllowResistant", "Refills obsidian with other types of resistant blocks", false));
    private final Map<Integer, class_1799> hotbarCache = new ConcurrentHashMap<Integer, class_1799>();
    private final Timer lastDroppedTimer = new CacheTimer();

    public ReplenishModule() {
        super("Replenish", "Automatically replaces items in your hotbar", ModuleCategory.PLAYER);
        INSTANCE = this;
    }

    public static ReplenishModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        this.hotbarCache.clear();
    }

    @EventListener
    public void onDisconnect(DisconnectEvent event) {
        this.hotbarCache.clear();
    }

    @EventListener
    public void onEntityDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof class_746) {
            this.hotbarCache.clear();
        }
    }

    @EventListener
    public void onTick(PlayerTickEvent event) {
        class_1799 stack;
        int i;
        boolean pauseReplenish;
        if (ReplenishModule.mc.field_1690.field_1869.method_1434()) {
            this.lastDroppedTimer.reset();
        }
        boolean bl = pauseReplenish = this.isInInventoryScreen() || !this.lastDroppedTimer.passed(100);
        if (!pauseReplenish) {
            for (i = 0; i < 9; ++i) {
                double percentage;
                stack = ReplenishModule.mc.field_1724.method_31548().method_5438(i);
                if (stack.method_7960()) {
                    class_1799 cachedStack = this.hotbarCache.getOrDefault(i, null);
                    if (cachedStack == null || cachedStack.method_7960()) continue;
                    this.replenishStack(i, cachedStack);
                    break;
                }
                if (!stack.method_7946() || !((percentage = (double)stack.method_7947() / (double)stack.method_7914() * 100.0) <= (double)this.percentConfig.getValue().intValue())) continue;
                this.replenishStack(i, stack);
                break;
            }
        }
        for (i = 0; i < 9; ++i) {
            stack = ReplenishModule.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() && !pauseReplenish) continue;
            if (this.hotbarCache.containsKey(i)) {
                this.hotbarCache.replace(i, stack.method_7972());
                continue;
            }
            this.hotbarCache.put(i, stack.method_7972());
        }
    }

    public boolean isInInventoryScreen() {
        return ReplenishModule.mc.field_1755 instanceof class_476 || ReplenishModule.mc.field_1755 instanceof class_495 || ReplenishModule.mc.field_1755 instanceof class_490;
    }

    private void replenishStack(int slot, class_1799 stack) {
        int slot1 = -1;
        boolean outOfObsidian = stack.method_7909() == class_1802.field_8281 && InventoryUtil.count(class_1802.field_8281) <= 1;
        for (int i = 9; i < 36; ++i) {
            class_1799 itemStack = ReplenishModule.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960() || !this.isSame(stack, itemStack, outOfObsidian) || !itemStack.method_7946()) continue;
            slot1 = i;
        }
        if (slot1 != -1) {
            ReplenishModule.mc.field_1761.method_2906(0, slot1, 0, class_1713.field_7790, (class_1657)ReplenishModule.mc.field_1724);
            ReplenishModule.mc.field_1761.method_2906(0, slot + 36, 0, class_1713.field_7790, (class_1657)ReplenishModule.mc.field_1724);
            if (!ReplenishModule.mc.field_1724.field_7512.method_34255().method_7960()) {
                ReplenishModule.mc.field_1761.method_2906(0, slot1, 0, class_1713.field_7790, (class_1657)ReplenishModule.mc.field_1724);
            }
        }
    }

    public boolean isSame(class_1799 stack1, class_1799 stack2, boolean outOfObsidian) {
        block5: {
            block6: {
                if (this.resistantConfig.getValue().booleanValue() && stack1.method_7909() == class_1802.field_8281 && outOfObsidian) {
                    return stack2.method_7909() == class_1802.field_8466 || stack2.method_7909() == class_1802.field_22421;
                }
                class_1792 class_17922 = stack1.method_7909();
                if (!(class_17922 instanceof class_1747)) break block5;
                class_1747 blockItem = (class_1747)class_17922;
                class_17922 = stack2.method_7909();
                if (!(class_17922 instanceof class_1747)) break block6;
                class_1747 blockItem1 = (class_1747)class_17922;
                if (blockItem.method_7711() == blockItem1.method_7711()) break block5;
            }
            return false;
        }
        if (!stack1.method_7964().getString().equals(stack2.method_7964().getString())) {
            return false;
        }
        return stack1.method_7909().equals(stack2.method_7909());
    }
}
