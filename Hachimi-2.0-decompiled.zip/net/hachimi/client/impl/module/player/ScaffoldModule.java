package net.hachimi.client.impl.module.player;

import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BlockListConfig;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.render.RenderBuffers;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.module.BlockPlacerModule;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.position.PositionUtil;
import net.hachimi.client.util.player.MovementUtil;
import net.hachimi.client.util.player.RotationUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

public final class ScaffoldModule
extends BlockPlacerModule {
    Config<Boolean> rotateHoldConfig = this.register(new BooleanConfig("RotateHold", "Holds rotations to scaffold blocks", false, () -> (Boolean)this.rotateConfig.getValue()));
    Config<Boolean> grimConfig = this.register(new BooleanConfig("Grim", "Uses grim interactions", false));
    Config<Boolean> grimNewConfig = this.register(new BooleanConfig("GrimV3", "Uses grim new interactions", false));
    Config<Selection> selectionConfig = this.register(new EnumConfig("Selection", "The selection of blocks to use for scaffold", (Enum)Selection.ALL, (Enum[])Selection.values()));
    Config<List<class_2248>> whitelistConfig = this.register(new BlockListConfig("Whitelist", "Valid block whitelist", class_2246.field_10566, class_2246.field_10540));
    Config<List<class_2248>> blacklistConfig = this.register(new BlockListConfig("Blacklist", "Valid block blacklist", class_2246.field_10603));
    Config<Boolean> keepYConfig = this.register(new BooleanConfig("KeepY", "Keeps the same y-level", false));
    Config<Boolean> towerConfig = this.register(new BooleanConfig("Tower", "Goes up faster when holding down space", true, () -> this.grimNewConfig.getValue() == false));
    Config<BlockPicker> pickerConfig = this.register(new EnumConfig("BlockSelection", "How to pick a block from the hotbar", (Enum)BlockPicker.NORMAL, (Enum[])BlockPicker.values()));
    Config<Boolean> renderConfig = this.register(new BooleanConfig("Render", "Renders where scaffold is placing blocks", false));
    Config<Integer> fadeTimeConfig = this.register(new NumberConfig<Integer>("Fade-Time", "Timer for the fade", Integer.valueOf(0), Integer.valueOf(250), Integer.valueOf(1000), () -> false));
    Config<Boolean> stopMotionConfig = this.register(new BooleanConfig("StopMotion", "Stops player motion when placing blocks", false));
    private final Map<class_2338, Animation> fadeList = new HashMap<class_2338, Animation>();
    private BlockData blockData;
    private BlockData renderData;
    private float[] lastAngles;
    private int groundPosY;

    public ScaffoldModule() {
        super("Scaffold", "Places blocks at the players feet", ModuleCategory.PLAYER, 790);
    }

    @Override
    protected void onDisable() {
        if (ScaffoldModule.mc.field_1724 != null) {
            Managers.INVENTORY.syncToClient();
        }
        this.groundPosY = -1;
        this.lastAngles = null;
        this.blockData = null;
        this.renderData = null;
        this.fadeList.clear();
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (!((Boolean)this.multitaskConfig.getValue()).booleanValue() && this.checkMultitask()) {
            this.blockData = null;
            this.renderData = null;
            return;
        }
        BlockSlot blockSlot = this.getBlockSlot();
        int slot = blockSlot.slot();
        if (slot == -1) {
            this.blockData = null;
            this.renderData = null;
            return;
        }
        this.renderData = this.getBlockData(false);
        this.blockData = this.getBlockData(this.rotateHoldConfig.getValue());
        if (this.blockData == null) {
            if (this.grimNewConfig.getValue().booleanValue() && ((Boolean)this.rotateConfig.getValue()).booleanValue()) {
                float yaw = ScaffoldModule.mc.field_1724.method_36454();
                if (ScaffoldModule.mc.field_1690.field_1894.method_1434() && !ScaffoldModule.mc.field_1690.field_1881.method_1434()) {
                    if (ScaffoldModule.mc.field_1690.field_1913.method_1434() && !ScaffoldModule.mc.field_1690.field_1849.method_1434()) {
                        yaw -= 45.0f;
                    } else if (ScaffoldModule.mc.field_1690.field_1849.method_1434() && !ScaffoldModule.mc.field_1690.field_1913.method_1434()) {
                        yaw += 45.0f;
                    }
                } else if (ScaffoldModule.mc.field_1690.field_1881.method_1434() && !ScaffoldModule.mc.field_1690.field_1894.method_1434()) {
                    yaw += 180.0f;
                    if (ScaffoldModule.mc.field_1690.field_1913.method_1434() && !ScaffoldModule.mc.field_1690.field_1849.method_1434()) {
                        yaw += 45.0f;
                    } else if (ScaffoldModule.mc.field_1690.field_1849.method_1434() && !ScaffoldModule.mc.field_1690.field_1913.method_1434()) {
                        yaw -= 45.0f;
                    }
                } else if (ScaffoldModule.mc.field_1690.field_1913.method_1434() && !ScaffoldModule.mc.field_1690.field_1849.method_1434()) {
                    yaw -= 90.0f;
                } else if (ScaffoldModule.mc.field_1690.field_1849.method_1434() && !ScaffoldModule.mc.field_1690.field_1913.method_1434()) {
                    yaw += 90.0f;
                }
                this.setRotation(class_3532.method_15393((float)yaw), 90.0f);
            }
            return;
        }
        this.calcRotations(this.blockData);
        if (this.blockData.getAngles() == null) {
            if (!this.isGrim() && ((Boolean)this.rotateConfig.getValue()).booleanValue() && this.lastAngles != null) {
                this.setRotation(this.lastAngles[0], this.lastAngles[1]);
            }
            return;
        }
        if (!this.isGrim() && Managers.INVENTORY.getServerSlot() != slot) {
            Managers.INVENTORY.setSlot(slot);
        }
        class_243 prevMotion = ScaffoldModule.mc.field_1724.method_18798();
        if (this.stopMotionConfig.getValue().booleanValue()) {
            ScaffoldModule.mc.field_1724.method_18800(0.0, 0.0, 0.0);
        }
        boolean result = Managers.INTERACT.placeBlock(this.blockData.getBlockPos(), slot, false, false, false, (state, angles) -> {
            if (((Boolean)this.rotateConfig.getValue()).booleanValue()) {
                float[] rotations = this.blockData.getAngles();
                if (rotations == null) {
                    return;
                }
                this.lastAngles = rotations;
                if (state) {
                    if (this.grimConfig.getValue().booleanValue()) {
                        Managers.ROTATION.setRotationSilent(rotations[0], rotations[1]);
                    } else {
                        this.setRotation(rotations[0], rotations[1]);
                    }
                } else if (this.grimConfig.getValue().booleanValue()) {
                    Managers.ROTATION.setRotationSilentSync();
                }
            }
        });
        if (this.stopMotionConfig.getValue().booleanValue()) {
            ScaffoldModule.mc.field_1724.method_18799(prevMotion);
        }
        if (result && !this.isGrim() && this.towerConfig.getValue().booleanValue() && ScaffoldModule.mc.field_1690.field_1903.method_1434()) {
            class_243 velocity = ScaffoldModule.mc.field_1724.method_18798();
            double velocityY = velocity.field_1351;
            if (ScaffoldModule.mc.field_1724.method_24828() || velocityY < 0.1 || velocityY <= 0.16477328182606651) {
                ScaffoldModule.mc.field_1724.method_18800(velocity.field_1352, (double)0.42f, velocity.field_1350);
            }
        }
    }

    @EventListener
    public void onRenderWorld(RenderWorldEvent event) {
        if (this.renderConfig.getValue().booleanValue()) {
            RenderBuffers.preRender();
            for (Map.Entry<class_2338, Animation> set : this.fadeList.entrySet()) {
                set.getValue().setState(false);
                int boxAlpha = (int)(40.0 * set.getValue().getFactor());
                int lineAlpha = (int)(100.0 * set.getValue().getFactor());
                Color boxColor = ColorsModule.getInstance().getColor(boxAlpha);
                Color lineColor = ColorsModule.getInstance().getColor(lineAlpha);
                RenderManager.renderBox(event.getMatrices(), set.getKey(), boxColor.getRGB());
                RenderManager.renderBoundingBox(event.getMatrices(), set.getKey(), 1.5f, lineColor.getRGB());
            }
            RenderBuffers.postRender();
            if (this.renderData == null || this.renderData.getHitResult() == null) {
                return;
            }
            if (this.renderConfig.getValue().booleanValue()) {
                Animation animation = new Animation(true, this.fadeTimeConfig.getValue().intValue());
                this.fadeList.put(this.renderData.getBlockPos(), animation);
            }
            this.fadeList.entrySet().removeIf(e -> ((Animation)e.getValue()).getFactor() == 0.0);
        }
    }

    private void calcRotations(BlockData blockData) {
        class_2338 pos = blockData.getHitResult().method_17777();
        class_2350 side = blockData.getHitResult().method_17780();
        class_243 basicHitVec = pos.method_46558().method_1031((double)((float)side.method_10148() * 0.5f), (double)((float)side.method_10164() * 0.5f), (double)((float)side.method_10165() * 0.5f));
        blockData.setAngles(RotationUtil.getRotationsTo(ScaffoldModule.mc.field_1724.method_33571(), basicHitVec));
        blockData.setHitResult(new class_3965(basicHitVec, side, pos, false));
    }

    private BlockData getBlockData(boolean hold) {
        class_2338 neighbor;
        int posY = (int)Math.round(ScaffoldModule.mc.field_1724.method_23318()) - 1;
        if (this.keepYConfig.getValue().booleanValue() && MovementUtil.isInputtingMovement()) {
            if (ScaffoldModule.mc.field_1724.method_24828() || this.groundPosY == -1) {
                this.groundPosY = (int)Math.floor(ScaffoldModule.mc.field_1724.method_23318()) - 1;
            }
            posY = this.groundPosY;
        }
        class_2338 pos = PositionUtil.getRoundedBlockPos(ScaffoldModule.mc.field_1724.method_23317(), posY, ScaffoldModule.mc.field_1724.method_23321());
        if (!hold && !ScaffoldModule.mc.field_1687.method_8320(pos).method_45474()) {
            return null;
        }
        for (class_2350 direction : class_2350.values()) {
            neighbor = pos.method_10093(direction);
            if (ScaffoldModule.mc.field_1687.method_8320(neighbor).method_45474()) continue;
            return BlockData.basic(neighbor, direction.method_10153());
        }
        for (class_2350 direction : class_2350.values()) {
            neighbor = pos.method_10093(direction);
            if (!ScaffoldModule.mc.field_1687.method_8320(neighbor).method_45474()) continue;
            for (class_2350 direction1 : class_2350.values()) {
                class_2338 neighbor1 = neighbor.method_10093(direction1);
                if (ScaffoldModule.mc.field_1687.method_8320(neighbor1).method_45474()) continue;
                return BlockData.basic(neighbor1, direction1.method_10153());
            }
        }
        return null;
    }

    private BlockSlot getBlockSlot() {
        class_1747 blockItem;
        class_1792 class_17922;
        class_1799 serverStack = Managers.INVENTORY.getServerItem();
        if (!serverStack.method_7960() && (class_17922 = serverStack.method_7909()) instanceof class_1747 && this.validScaffoldBlock((blockItem = (class_1747)class_17922).method_7711())) {
            return new BlockSlot(blockItem.method_7711(), Managers.INVENTORY.getServerSlot());
        }
        class_2248 block = null;
        int blockSlot = -1;
        int count = 0;
        for (int i = 0; i < 9; ++i) {
            class_1747 blockItem2;
            class_1792 class_17923;
            class_1799 itemStack = ScaffoldModule.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960() || !((class_17923 = itemStack.method_7909()) instanceof class_1747) || !this.validScaffoldBlock((blockItem2 = (class_1747)class_17923).method_7711())) continue;
            if (this.pickerConfig.getValue() == BlockPicker.NORMAL) {
                return new BlockSlot(blockItem2.method_7711(), i);
            }
            if (blockSlot != -1 && itemStack.method_7947() <= count) continue;
            block = blockItem2.method_7711();
            blockSlot = i;
            count = itemStack.method_7947();
        }
        return new BlockSlot(block, blockSlot);
    }

    private boolean validScaffoldBlock(class_2248 block) {
        return switch (this.selectionConfig.getValue().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> ((BlockListConfig)this.whitelistConfig).contains(block);
            case 1 -> {
                if (!((BlockListConfig)this.blacklistConfig).contains(block)) {
                    yield true;
                }
                yield false;
            }
            case 2 -> true;
        };
    }

    public boolean isGrim() {
        return this.grimConfig.getValue() != false || this.grimNewConfig.getValue() != false;
    }

    public static enum Selection {
        WHITELIST,
        BLACKLIST,
        ALL;

    }

    private static enum BlockPicker {
        NORMAL,
        GREATEST;

    }

    private static class BlockData {
        private class_3965 hitResult;
        private float[] angles;

        public BlockData(class_3965 hitResult, float[] angles) {
            this.hitResult = hitResult;
            this.angles = angles;
        }

        public class_3965 getHitResult() {
            return this.hitResult;
        }

        public class_2338 getBlockPos() {
            return this.hitResult.method_17777().method_10093(this.hitResult.method_17780());
        }

        public void setHitResult(class_3965 hitResult) {
            this.hitResult = hitResult;
        }

        public float[] getAngles() {
            return this.angles;
        }

        public void setAngles(float[] angles) {
            this.angles = angles;
        }

        public static BlockData basic(class_2338 pos, class_2350 direction) {
            return new BlockData(new class_3965(pos.method_46558(), direction, pos, false), null);
        }
    }

    private record BlockSlot(class_2248 block, int slot) {
    }
}
