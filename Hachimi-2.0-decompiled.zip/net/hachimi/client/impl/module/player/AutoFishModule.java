package net.hachimi.client.impl.module.player;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.imixin.IMinecraftClient;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1536;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2767;
import net.minecraft.class_3417;
import net.minecraft.class_408;

public class AutoFishModule
extends ToggleModule {
    Config<Boolean> openInventoryConfig = this.register(new BooleanConfig("OpenInventory", "Allows you to fish while in the inventory", true));
    Config<Integer> castDelayConfig = this.register(new NumberConfig<Integer>("CastingDelay", "The delay between fishing rod casts", 10, 15, 25));
    Config<Float> maxSoundDistConfig = this.register(new NumberConfig<Float>("MaxSoundDist", "The maximum distance from the splash sound", Float.valueOf(0.0f), Float.valueOf(2.0f), Float.valueOf(5.0f)));
    private boolean autoReel;
    private int autoReelTicks;
    private int autoCastTicks;

    public AutoFishModule() {
        super("AutoFish", "Automatically casts and reels fishing rods", ModuleCategory.PLAYER);
    }

    @EventListener
    public void onPacketInbound(PacketEvent.Inbound event) {
        class_2767 packet;
        if (AutoFishModule.mc.field_1724 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2767 && (packet = (class_2767)class_25962).method_11894().comp_349() == class_3417.field_14660 && AutoFishModule.mc.field_1724.method_6047().method_7909() == class_1802.field_8378) {
            class_1536 fishHook = AutoFishModule.mc.field_1724.field_7513;
            if (fishHook == null || fishHook.method_6947() != AutoFishModule.mc.field_1724) {
                return;
            }
            double dist = fishHook.method_5649(packet.method_11890(), packet.method_11889(), packet.method_11893());
            if (dist <= (double)this.maxSoundDistConfig.getValue().floatValue()) {
                this.autoReel = true;
                this.autoReelTicks = 4;
            }
        }
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (AutoFishModule.mc.field_1755 == null || AutoFishModule.mc.field_1755 instanceof class_408 || this.openInventoryConfig.getValue().booleanValue()) {
            if (AutoFishModule.mc.field_1724.method_6047().method_7909() != class_1802.field_8378) {
                return;
            }
            class_1536 fishHook = AutoFishModule.mc.field_1724.field_7513;
            if ((fishHook == null || fishHook.method_26957() != null) && this.autoCastTicks <= 0) {
                ((IMinecraftClient)mc).rightClick();
                this.autoCastTicks = this.castDelayConfig.getValue();
                return;
            }
            if (this.autoReel) {
                if (this.autoReelTicks <= 0) {
                    ((IMinecraftClient)mc).rightClick();
                    this.autoReel = false;
                    return;
                }
                --this.autoReelTicks;
            }
        }
        --this.autoCastTicks;
    }
}
