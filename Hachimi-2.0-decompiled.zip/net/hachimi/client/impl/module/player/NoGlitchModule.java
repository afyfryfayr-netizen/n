package net.hachimi.client.impl.module.player;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.BreakBlockEvent;
import net.hachimi.client.impl.event.network.InteractBlockEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1747;
import net.minecraft.class_2885;

public class NoGlitchModule
extends ToggleModule {
    Config<Boolean> placeConfig = this.register(new BooleanConfig("Place", "Places blocks only after the server confirms", false));
    Config<Boolean> destroyConfig = this.register(new BooleanConfig("Destroy", "Destroys blocks only after the server confirms", false));

    public NoGlitchModule() {
        super("NoGlitch", "Prevents blocks from being glitched in the world", ModuleCategory.PLAYER);
    }

    @EventListener
    public void onInteractBlock(InteractBlockEvent event) {
        if (this.placeConfig.getValue().booleanValue() && NoGlitchModule.mc.field_1724.method_5998(event.getHand()).method_7909() instanceof class_1747 && !mc.method_1542()) {
            event.cancel();
            Managers.NETWORK.sendSequencedPacket(id -> new class_2885(event.getHand(), event.getHitResult(), id));
            NoGlitchModule.mc.field_1724.method_6104(event.getHand());
        }
    }

    @EventListener
    public void onBreakBlock(BreakBlockEvent event) {
        if (this.destroyConfig.getValue().booleanValue() && !mc.method_1542()) {
            event.cancel();
        }
    }
}
