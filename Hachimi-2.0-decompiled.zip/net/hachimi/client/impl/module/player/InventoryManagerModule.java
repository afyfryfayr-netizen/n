package net.hachimi.client.impl.module.player;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.List;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.ItemListConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.file.ConfigFile;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.TickEvent;
import net.hachimi.client.impl.module.misc.KitModule;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.hachimi.eventbus.annotation.EventListener;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class InventoryManagerModule
extends ToggleModule {
    private static InventoryManagerModule INSTANCE;
    private static final int HOTBAR_START = 0;
    private static final int INVENTORY_START = 9;
    private static final int INVENTORY_END = 35;
    Config<Boolean> stackConfig = this.register(new BooleanConfig("Stack", "Combines partial stacks of the same item into full stacks", true));
    Config<Boolean> kitModeConfig = this.register(new BooleanConfig("KitMode", "Throws any item not part of the currently loaded Kit (see Kit module) out of the inventory", true));
    Config<Boolean> sortConfig = this.register(new BooleanConfig("Sort", "Groups items of the same type next to each other", true));
    Config<Integer> sortDelayConfig = this.register(new NumberConfig<Integer>("SortDelay", "The delay in ticks between sort actions", 0, 0, 20));
    Config<Boolean> cleanerConfig = this.register(new BooleanConfig("Cleaner", "Automatically throws blacklisted items out of the inventory", true));
    Config<Boolean> renameConfig = this.register(new BooleanConfig("Rename", "Reserved for future use", false));
    Config<Boolean> hotbarConfig = this.register(new BooleanConfig("Hotbar", "Includes the hotbar slots when cleaning/sorting/stacking", true));
    Config<Integer> cleanerDelayConfig = this.register(new NumberConfig<Integer>("CleanerDelay", "The delay in ticks between cleaner actions", 0, 0, 20));
    Config<List<class_1792>> blacklistConfig = this.register(new ItemListConfig("Blacklist", "The items to throw out of the inventory", new class_1792[0]));
    Config<List<class_1792>> whitelistConfig = this.register(new ItemListConfig("WhiteList", "Items the Cleaner will never throw, even if also blacklisted", new class_1792[0]));
    private final Timer cleanerTimer = new CacheTimer();
    private final Timer sortTimer = new CacheTimer();

    public InventoryManagerModule() {
        super("InventoryManager", "Cleans, sorts, and stacks the player inventory", ModuleCategory.PLAYER);
    }

    public static InventoryManagerModule getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new InventoryManagerModule();
        }
        return INSTANCE;
    }

    @EventListener
    public void onTick(TickEvent event) {
        int lowerBound;
        if (event.getStage() != StageEvent.EventStage.PRE) {
            return;
        }
        if (InventoryManagerModule.mc.field_1724 == null || InventoryManagerModule.mc.field_1724.method_31548() == null) {
            return;
        }
        int n = lowerBound = this.hotbarConfig.getValue() != false ? 0 : 9;
        if ((this.cleanerConfig.getValue().booleanValue() || this.kitModeConfig.getValue().booleanValue()) && this.cleanerTimer.passed(this.cleanerDelayConfig.getValue() * 50) && this.cleanInventory(lowerBound)) {
            this.cleanerTimer.reset();
            return;
        }
        if ((this.stackConfig.getValue().booleanValue() || this.sortConfig.getValue().booleanValue()) && this.sortTimer.passed(this.sortDelayConfig.getValue() * 50)) {
            if (this.stackConfig.getValue().booleanValue() && this.stackInventory(lowerBound)) {
                this.sortTimer.reset();
                return;
            }
            if (this.sortConfig.getValue().booleanValue() && this.sortInventory(lowerBound)) {
                this.sortTimer.reset();
            }
        }
    }

    private boolean cleanInventory(int lowerBound) {
        for (int i = 35; i >= lowerBound; --i) {
            boolean notInKit;
            class_1799 stack = InventoryManagerModule.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960()) continue;
            boolean whitelisted = this.whitelistConfig.getValue().contains(stack.method_7909());
            boolean blacklisted = this.cleanerConfig.getValue() != false && !whitelisted && this.blacklistConfig.getValue().contains(stack.method_7909());
            boolean bl = notInKit = this.kitModeConfig.getValue() != false && !whitelisted && KitModule.getInstance() != null && !KitModule.getInstance().isPartOfKit(stack.method_7909());
            if (!blacklisted && !notInKit) continue;
            this.throwSlot(i);
            return true;
        }
        return false;
    }

    private boolean stackInventory(int lowerBound) {
        for (int i = lowerBound; i <= 35; ++i) {
            class_1799 from = InventoryManagerModule.mc.field_1724.method_31548().method_5438(i);
            if (from.method_7960() || from.method_7947() >= from.method_7914()) continue;
            for (int j = lowerBound; j <= 35; ++j) {
                class_1799 into;
                if (i == j || (into = InventoryManagerModule.mc.field_1724.method_31548().method_5438(j)).method_7960() || into.method_7947() >= into.method_7914() || !class_1799.method_7973((class_1799)from, (class_1799)into)) continue;
                this.clickSlot(j);
                this.clickSlot(i);
                this.clickSlot(j);
                return true;
            }
        }
        return false;
    }

    private boolean sortInventory(int lowerBound) {
        block0: for (int i = lowerBound; i < 35; ++i) {
            class_1799 current = InventoryManagerModule.mc.field_1724.method_31548().method_5438(i);
            for (int j = i + 1; j <= 35; ++j) {
                boolean shouldSwap;
                class_1799 next = InventoryManagerModule.mc.field_1724.method_31548().method_5438(j);
                if (next.method_7960()) continue;
                boolean bl = shouldSwap = current.method_7960() || current.method_7909() != next.method_7909() && this.shouldComeBefore(next, current, i, j, lowerBound);
                if (!shouldSwap) continue block0;
                this.swapSlots(i, j);
                return true;
            }
        }
        return false;
    }

    private boolean shouldComeBefore(class_1799 next, class_1799 current, int i, int j, int lowerBound) {
        if (current.method_7960()) {
            return true;
        }
        for (int k = lowerBound; k < i; ++k) {
            class_1799 stack = InventoryManagerModule.mc.field_1724.method_31548().method_5438(k);
            if (stack.method_7960() || stack.method_7909() != next.method_7909()) continue;
            return false;
        }
        class_2960 currentId = class_7923.field_41178.method_10221((Object)current.method_7909());
        class_2960 nextId = class_7923.field_41178.method_10221((Object)next.method_7909());
        return nextId.toString().compareTo(currentId.toString()) < 0;
    }

    private void throwSlot(int slot) {
        this.clickSlot(slot);
        InventoryManagerModule.mc.field_1761.method_2906(InventoryManagerModule.mc.field_1724.field_7512.field_7763, -999, 0, class_1713.field_7790, (class_1657)InventoryManagerModule.mc.field_1724);
    }

    private void clickSlot(int slot) {
        InventoryManagerModule.mc.field_1761.method_2906(InventoryManagerModule.mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7790, (class_1657)InventoryManagerModule.mc.field_1724);
    }

    private void swapSlots(int slotA, int slotB) {
        this.clickSlot(slotA);
        this.clickSlot(slotB);
        this.clickSlot(slotA);
    }

    public ConfigFile getBlacklistFile(Path clientDir) {
        return new InventoryManagerFile(clientDir);
    }

    public class InventoryManagerFile
    extends ConfigFile {
        public InventoryManagerFile(Path clientDir) {
            super(clientDir, "inventory-manager");
        }

        @Override
        public void save() {
            try {
                Path filepath = this.getFilepath();
                if (!Files.exists(filepath, new LinkOption[0])) {
                    Files.createFile(filepath, new FileAttribute[0]);
                }
                JsonObject json = new JsonObject();
                json.add("blacklist", this.itemListToJson(InventoryManagerModule.this.blacklistConfig.getValue()));
                json.add("whitelist", this.itemListToJson(InventoryManagerModule.this.whitelistConfig.getValue()));
                this.write(filepath, this.serialize(json));
            }
            catch (IOException e) {
                Hachimi.error("Could not save file for inventory manager!");
                e.printStackTrace();
            }
        }

        @Override
        public void load() {
            try {
                Path filepath = this.getFilepath();
                if (Files.exists(filepath, new LinkOption[0])) {
                    String content = this.read(filepath);
                    JsonObject object = this.parseObject(content);
                    if (object == null) {
                        return;
                    }
                    if (object.has("blacklist")) {
                        this.loadItemList(object.getAsJsonArray("blacklist"), InventoryManagerModule.this.blacklistConfig.getValue());
                    }
                    if (object.has("whitelist")) {
                        this.loadItemList(object.getAsJsonArray("whitelist"), InventoryManagerModule.this.whitelistConfig.getValue());
                    }
                }
            }
            catch (IOException e) {
                Hachimi.error("Could not read file for inventory manager!");
                e.printStackTrace();
            }
        }

        private JsonArray itemListToJson(List<class_1792> items) {
            JsonArray array = new JsonArray();
            for (class_1792 item : items) {
                class_2960 id = class_7923.field_41178.method_10221((Object)item);
                array.add(id.toString());
            }
            return array;
        }

        private void loadItemList(JsonArray jsonArray, List<class_1792> target) {
            target.clear();
            for (JsonElement element : jsonArray) {
                class_1792 item = (class_1792)class_7923.field_41178.method_10223(class_2960.method_60654((String)element.getAsString()));
                if (item == null || item == class_1802.field_8162) continue;
                target.add(item);
            }
        }
    }
}
