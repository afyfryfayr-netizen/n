package net.hachimi.client.impl.module.player;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.imixin.IPlayerInteractEntityC2SPacket;
import net.hachimi.client.util.network.InteractType;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1495;
import net.minecraft.class_1498;
import net.minecraft.class_1500;
import net.minecraft.class_1501;
import net.minecraft.class_1506;
import net.minecraft.class_1657;
import net.minecraft.class_2596;

public class AutoMountModule
extends ToggleModule {
    Config<Float> rangeConfig = this.register(new NumberConfig<Float>("Range", "The range to mount entities", Float.valueOf(0.1f), Float.valueOf(4.0f), Float.valueOf(6.0f)));
    Config<Boolean> forceConfig = this.register(new BooleanConfig("ForceMount", "Forces the mounting without packets", false));
    Config<Boolean> horseConfig = this.register(new BooleanConfig("Horse", "Mounts horses", true));
    Config<Boolean> donkeyConfig = this.register(new BooleanConfig("Donkey", "Mounts donkeys", true));
    Config<Boolean> muleConfig = this.register(new BooleanConfig("Mule", "Mounts mules", true));
    Config<Boolean> llamaConfig = this.register(new BooleanConfig("Llama", "Mounts llamas", false));

    public AutoMountModule() {
        super("AutoMount", "Mounts nearby entities", ModuleCategory.PLAYER);
    }

    @EventListener
    public void onPlayerTick(PlayerTickEvent event) {
        if (AutoMountModule.mc.field_1724.method_3144()) {
            return;
        }
        for (class_1297 entity : AutoMountModule.mc.field_1687.method_18112()) {
            double dist = AutoMountModule.mc.field_1724.method_33571().method_1022(entity.method_19538());
            if (dist > (double)this.rangeConfig.getValue().floatValue() || !this.checkMount(entity)) continue;
            AutoMountModule.mc.field_1761.method_2905((class_1657)AutoMountModule.mc.field_1724, entity, class_1268.field_5808);
            return;
        }
    }

    @EventListener
    public void onPacketOutbound(PacketEvent.Outbound event) {
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof IPlayerInteractEntityC2SPacket) {
            IPlayerInteractEntityC2SPacket packet = (IPlayerInteractEntityC2SPacket)class_25962;
            if (this.forceConfig.getValue().booleanValue() && packet.getType() == InteractType.INTERACT_AT && this.checkMount(packet.getEntity())) {
                event.cancel();
            }
        }
    }

    private boolean checkMount(class_1297 entity) {
        class_1501 llamaEntity;
        class_1498 horseEntity;
        return this.horseConfig.getValue() != false && (entity instanceof class_1498 && !(horseEntity = (class_1498)entity).method_6109() || entity instanceof class_1506) || this.donkeyConfig.getValue() != false && entity instanceof class_1495 || this.muleConfig.getValue() != false && entity instanceof class_1500 || this.llamaConfig.getValue() != false && entity instanceof class_1501 && !(llamaEntity = (class_1501)entity).method_6109();
    }
}
