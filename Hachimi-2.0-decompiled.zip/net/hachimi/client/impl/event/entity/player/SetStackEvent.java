package net.hachimi.client.impl.event.entity.player;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1799;

public class SetStackEvent
extends Event {
    private final int slot;
    private final class_1799 stack;

    public SetStackEvent(int slot, class_1799 stack) {
        this.slot = slot;
        this.stack = stack;
    }

    public class_1799 getStack() {
        return this.stack;
    }

    public int getSlot() {
        return this.slot;
    }
}
