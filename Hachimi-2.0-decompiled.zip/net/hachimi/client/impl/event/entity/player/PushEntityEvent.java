package net.hachimi.client.impl.event.entity.player;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1297;

@Cancelable
public class PushEntityEvent
extends Event {
    private final class_1297 pushed;
    private final class_1297 pusher;

    public PushEntityEvent(class_1297 pushed, class_1297 pusher) {
        this.pushed = pushed;
        this.pusher = pusher;
    }

    public class_1297 getPushed() {
        return this.pushed;
    }

    public class_1297 getPusher() {
        return this.pusher;
    }
}
