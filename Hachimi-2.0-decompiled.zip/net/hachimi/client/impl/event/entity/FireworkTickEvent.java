package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1671;

@Cancelable
public class FireworkTickEvent
extends Event {
    private final class_1671 fireworkRocketEntity;

    public FireworkTickEvent(class_1671 fireworkRocketEntity) {
        this.fireworkRocketEntity = fireworkRocketEntity;
    }

    public class_1671 getFireworkRocketEntity() {
        return this.fireworkRocketEntity;
    }
}
