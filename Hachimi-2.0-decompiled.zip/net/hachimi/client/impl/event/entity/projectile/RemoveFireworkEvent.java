package net.hachimi.client.impl.event.entity.projectile;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1671;

@Cancelable
public class RemoveFireworkEvent
extends Event {
    private final class_1671 rocketEntity;

    public RemoveFireworkEvent(class_1671 rocketEntity) {
        this.rocketEntity = rocketEntity;
    }

    public class_1671 getRocketEntity() {
        return this.rocketEntity;
    }
}
