package net.hachimi.client.impl.event.entity.projectile;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_5454;

@Cancelable
public class PearlTeleportEvent
extends Event {
    private final class_5454 teleportTarget;

    public PearlTeleportEvent(class_5454 teleportTarget) {
        this.teleportTarget = teleportTarget;
    }

    public class_5454 getTeleportTarget() {
        return this.teleportTarget;
    }
}
