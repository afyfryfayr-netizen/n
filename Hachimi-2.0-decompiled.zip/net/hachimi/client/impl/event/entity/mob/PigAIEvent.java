package net.hachimi.client.impl.event.entity.mob;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1452;

@Cancelable
public class PigAIEvent
extends Event {
    private final class_1452 pigEntity;

    public PigAIEvent(class_1452 pigEntity) {
        this.pigEntity = pigEntity;
    }

    public class_1452 getPigEntity() {
        return this.pigEntity;
    }
}
