package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_243;

@Cancelable
public class VelocityEvent
extends Event {
    private class_243 velocity;

    public VelocityEvent(class_243 velocity) {
        this.velocity = velocity;
    }

    public void setVelocity(class_243 velocity) {
        this.velocity = velocity;
    }

    public void setXYZ(double x, double y, double z) {
        this.velocity = new class_243(x, y, z);
    }

    public class_243 getVelocity() {
        return this.velocity;
    }
}
