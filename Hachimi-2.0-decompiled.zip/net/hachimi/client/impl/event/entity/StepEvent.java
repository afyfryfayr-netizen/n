package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1309;

@Cancelable
public class StepEvent
extends Event {
    private final class_1309 entity;
    private float stepHeight;

    public StepEvent(class_1309 entity, float stepHeight) {
        this.entity = entity;
        this.stepHeight = stepHeight;
    }

    public class_1309 getEntity() {
        return this.entity;
    }

    public void setStepHeight(float stepHeight) {
        this.stepHeight = stepHeight;
    }

    public float getStepHeight() {
        return this.stepHeight;
    }
}
