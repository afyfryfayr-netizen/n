package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2680;

@Cancelable
public class SlowMovementEvent
extends Event {
    private final class_2680 state;
    private float multiplier = 1.0f;

    public SlowMovementEvent(class_2680 state) {
        this.state = state;
    }

    public class_2680 getState() {
        return this.state;
    }

    public float getMultiplier() {
        return this.multiplier;
    }

    public void setMultiplier(float multiplier) {
        this.multiplier = multiplier;
    }
}
