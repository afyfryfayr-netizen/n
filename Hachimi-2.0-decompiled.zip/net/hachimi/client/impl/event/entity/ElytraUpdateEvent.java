package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1309;

@Cancelable
public class ElytraUpdateEvent
extends Event {
    private final class_1309 entity;
    private final boolean fallFlying;

    public ElytraUpdateEvent(class_1309 entity, boolean fallFlying) {
        this.entity = entity;
        this.fallFlying = fallFlying;
    }

    public class_1309 getEntity() {
        return this.entity;
    }

    public boolean isFallFlying() {
        return this.fallFlying;
    }
}
