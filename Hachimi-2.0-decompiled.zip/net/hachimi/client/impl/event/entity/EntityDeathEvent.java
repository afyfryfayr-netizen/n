package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1309;

public class EntityDeathEvent
extends Event {
    private final class_1309 entity;

    public EntityDeathEvent(class_1309 entity) {
        this.entity = entity;
    }

    public class_1309 getEntity() {
        return this.entity;
    }
}
