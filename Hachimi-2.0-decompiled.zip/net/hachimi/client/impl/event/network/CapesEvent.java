package net.hachimi.client.impl.event.network;

import com.mojang.authlib.GameProfile;
import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2960;

@Cancelable
public class CapesEvent
extends Event {
    private final GameProfile gameProfile;
    private class_2960 texture;
    private boolean optifine;

    public CapesEvent(GameProfile gameProfile) {
        this.gameProfile = gameProfile;
    }

    public GameProfile getGameProfile() {
        return this.gameProfile;
    }

    public void setTexture(class_2960 texture) {
        this.texture = texture;
    }

    public class_2960 getTexture() {
        return this.texture;
    }

    public void setShowOptifine(boolean optifine) {
        this.optifine = optifine;
    }

    public boolean getShowOptifine() {
        return this.optifine;
    }
}
