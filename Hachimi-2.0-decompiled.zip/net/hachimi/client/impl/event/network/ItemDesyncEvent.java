package net.hachimi.client.impl.event.network;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1799;

@Cancelable
public class ItemDesyncEvent
extends Event {
    private class_1799 stack;

    public void setStack(class_1799 stack) {
        this.stack = stack;
    }

    public class_1799 getServerItem() {
        return this.stack;
    }
}
