package net.hachimi.client.impl.event.network;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2649;

public class InventoryEvent
extends Event {
    private final class_2649 packet;

    public InventoryEvent(class_2649 packet) {
        this.packet = packet;
    }

    public class_2649 getPacket() {
        return this.packet;
    }
}
