package net.hachimi.client.impl.event.network;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2338;

@Cancelable
public class BreakBlockEvent
extends Event {
    private final class_2338 pos;

    public BreakBlockEvent(class_2338 pos) {
        this.pos = pos;
    }

    public class_2338 getPos() {
        return this.pos;
    }
}
