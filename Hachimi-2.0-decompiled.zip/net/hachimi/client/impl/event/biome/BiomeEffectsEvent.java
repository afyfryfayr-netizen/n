package net.hachimi.client.impl.event.biome;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_4761;

@Cancelable
public class BiomeEffectsEvent
extends Event {
    private class_4761 particleConfig;

    public class_4761 getParticleConfig() {
        return this.particleConfig;
    }

    public void setParticleConfig(class_4761 particleConfig) {
        this.particleConfig = particleConfig;
    }
}
