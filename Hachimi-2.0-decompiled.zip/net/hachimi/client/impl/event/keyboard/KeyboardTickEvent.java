package net.hachimi.client.impl.event.keyboard;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_744;

@Cancelable
public class KeyboardTickEvent
extends StageEvent {
    private final class_744 input;

    public KeyboardTickEvent(class_744 input) {
        this.input = input;
    }

    public class_744 getInput() {
        return this.input;
    }
}
