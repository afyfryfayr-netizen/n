package net.hachimi.client.impl.event.item;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1799;

public class FinishUsingEvent
extends Event {
    private final class_1799 stack;

    public FinishUsingEvent(class_1799 stack) {
        this.stack = stack;
    }

    public class_1799 getStack() {
        return this.stack;
    }
}
