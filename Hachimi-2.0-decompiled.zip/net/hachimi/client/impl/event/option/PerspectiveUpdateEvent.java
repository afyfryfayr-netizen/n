package net.hachimi.client.impl.event.option;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_5498;

public class PerspectiveUpdateEvent
extends Event {
    private final class_5498 perspective;

    public PerspectiveUpdateEvent(class_5498 perspective) {
        this.perspective = perspective;
    }

    public class_5498 getPerspective() {
        return this.perspective;
    }
}
