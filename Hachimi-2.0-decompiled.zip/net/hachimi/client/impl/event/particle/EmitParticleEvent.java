package net.hachimi.client.impl.event.particle;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2394;

@Cancelable
public class EmitParticleEvent
extends Event {
    private final class_2394 effect;
    private int particleCount;
    private int particleTime;

    public EmitParticleEvent(class_2394 effect, int particleCount, int particleTime) {
        this.effect = effect;
        this.particleCount = particleCount;
        this.particleTime = particleTime;
    }

    public class_2394 getParticleType() {
        return this.effect;
    }

    public int getParticleCount() {
        return this.particleCount;
    }

    public void setParticleCount(int particleCount) {
        this.particleCount = particleCount;
    }

    public int getParticleTime() {
        return this.particleTime;
    }

    public void setParticleTime(int particleTime) {
        this.particleTime = particleTime;
    }
}
