package net.hachimi.client.impl.event.world;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2791;

public class LoadChunkEvent
extends Event {
    private final class_2791 chunk;

    public LoadChunkEvent(class_2791 chunk) {
        this.chunk = chunk;
    }

    public class_2791 getChunk() {
        return this.chunk;
    }
}
