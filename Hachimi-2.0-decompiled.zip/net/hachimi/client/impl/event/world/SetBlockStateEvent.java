package net.hachimi.client.impl.event.world;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

@Cancelable
public class SetBlockStateEvent
extends Event {
    private final int flags;
    private final class_2338 pos;
    private final class_2680 state;

    public SetBlockStateEvent(int flags, class_2338 pos, class_2680 state) {
        this.flags = flags;
        this.pos = pos;
        this.state = state;
    }

    public int getFlags() {
        return this.flags;
    }

    public class_2338 getPos() {
        return this.pos;
    }

    public class_2680 getState() {
        return this.state;
    }
}
