package net.hachimi.client.impl.event.world;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class LoadChunkBlockEvent
extends Event {
    private final class_2338 pos;
    private final class_2680 state;

    public LoadChunkBlockEvent(class_2338 pos, class_2680 state) {
        this.pos = pos;
        this.state = state;
    }

    public class_2338 getPos() {
        return this.pos;
    }

    public class_2680 getState() {
        return this.state;
    }
}
