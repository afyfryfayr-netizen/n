package net.hachimi.client.impl.event;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_4184;

@Cancelable
public class PerspectiveEvent
extends Event {
    public class_4184 camera;

    public PerspectiveEvent(class_4184 camera) {
        this.camera = camera;
    }

    public class_4184 getCamera() {
        return this.camera;
    }
}
