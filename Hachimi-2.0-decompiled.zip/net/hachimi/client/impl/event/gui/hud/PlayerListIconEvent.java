package net.hachimi.client.impl.event.gui.hud;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;

@Cancelable
public class PlayerListIconEvent
extends Event {

    @Cancelable
    public static class Render
    extends PlayerListIconEvent {
        private final class_2561 playerName;
        private final class_332 context;
        private final class_327 textRenderer;
        private final double x;
        private final double y;
        private final int color;

        public Render(class_2561 playerName, class_332 context, class_327 textRenderer, double x, double y, int color) {
            this.context = context;
            this.textRenderer = textRenderer;
            this.playerName = playerName;
            this.x = x;
            this.y = y;
            this.color = color;
        }

        public class_332 getContext() {
            return this.context;
        }

        public class_4587 getMatrixStack() {
            return this.context.method_51448();
        }

        public class_327 getTextRenderer() {
            return this.textRenderer;
        }

        public double getX() {
            return this.x;
        }

        public double getY() {
            return this.y;
        }

        public int getColor() {
            return this.color;
        }

        public class_2561 getPlayerNameText() {
            return this.playerName;
        }
    }

    @Cancelable
    public static class Width
    extends PlayerListIconEvent {
        private final String text;

        public Width(String text) {
            this.text = text;
        }

        public String getText() {
            return this.text;
        }
    }
}
