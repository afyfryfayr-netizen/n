package net.hachimi.client.impl.event.gui.hud;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_332;

@Cancelable
public class RenderCrosshairEvent
extends Event {
    private final class_332 context;

    public RenderCrosshairEvent(class_332 context) {
        this.context = context;
    }

    public class_332 getContext() {
        return this.context;
    }
}
