package net.hachimi.client.impl.event.gui.hud;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_303;

public class ChatLineEvent
extends Event {
    private final class_303.class_7590 chatHudLine;
    private final double width;

    public ChatLineEvent(class_303.class_7590 chatHudLine, double width) {
        this.chatHudLine = chatHudLine;
        this.width = width;
    }

    public class_303.class_7590 getChatHudLine() {
        return this.chatHudLine;
    }

    public double getWidth() {
        return this.width;
    }
}
