package net.hachimi.client.impl.event.gui.hud;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2561;

@Cancelable
public class ChatMessageEvent
extends Event {
    private class_2561 text;

    public ChatMessageEvent(class_2561 text) {
        this.text = text;
    }

    public void setText(class_2561 text) {
        this.text = text;
    }

    public class_2561 getText() {
        return this.text;
    }
}
