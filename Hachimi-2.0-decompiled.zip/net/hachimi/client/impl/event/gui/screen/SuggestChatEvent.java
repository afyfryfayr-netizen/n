package net.hachimi.client.impl.event.gui.screen;

import com.mojang.brigadier.CommandDispatcher;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2172;

public class SuggestChatEvent
extends Event {
    private CommandDispatcher dispatcher;
    private class_2172 source;
    private String prefix;

    public String getPrefix() {
        return this.prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public class_2172 getSource() {
        return this.source;
    }

    public void setSource(class_2172 source) {
        this.source = source;
    }

    public void setDispatcher(CommandDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public CommandDispatcher getDispatcher() {
        return this.dispatcher;
    }
}
