package net.hachimi.client.impl.event.gui;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_4587;

public class RenderScreenEvent
extends Event {
    public final class_4587 matrixStack;

    public RenderScreenEvent(class_4587 matrixStack) {
        this.matrixStack = matrixStack;
    }
}
