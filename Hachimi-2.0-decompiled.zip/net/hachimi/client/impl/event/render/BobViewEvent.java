package net.hachimi.client.impl.event.render;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_4587;

@Cancelable
public class BobViewEvent
extends Event {
    private final class_4587 matrixStack;
    private final float tickDelta;
    private float y;

    public BobViewEvent(class_4587 matrixStack, float tickDelta) {
        this.matrixStack = matrixStack;
        this.tickDelta = tickDelta;
    }

    public float getY() {
        return this.y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public class_4587 getMatrixStack() {
        return this.matrixStack;
    }

    public float getTickDelta() {
        return this.tickDelta;
    }
}
