package net.hachimi.client.impl.event.render;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_4587;

@Cancelable
public class RenderShaderEvent
extends Event {
    private final class_4587 matrices;
    private final float tickDelta;

    public RenderShaderEvent(class_4587 matrices, float tickDelta) {
        this.matrices = matrices;
        this.tickDelta = tickDelta;
    }

    public class_4587 getMatrices() {
        return this.matrices;
    }

    public float getTickDelta() {
        return this.tickDelta;
    }

    public static class BlockEntities
    extends RenderShaderEvent {
        public BlockEntities(class_4587 matrices, float tickDelta) {
            super(matrices, tickDelta);
        }
    }
}
