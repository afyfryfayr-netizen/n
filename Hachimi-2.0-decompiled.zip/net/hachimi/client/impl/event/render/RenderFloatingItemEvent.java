package net.hachimi.client.impl.event.render;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

@Cancelable
public class RenderFloatingItemEvent
extends Event {
    private final class_1799 floatingItem;

    public RenderFloatingItemEvent(class_1799 floatingItem) {
        this.floatingItem = floatingItem;
    }

    public class_1792 getFloatingItem() {
        return this.floatingItem.method_7909();
    }

    public class_1799 getFloatingItemStack() {
        return this.floatingItem;
    }
}
