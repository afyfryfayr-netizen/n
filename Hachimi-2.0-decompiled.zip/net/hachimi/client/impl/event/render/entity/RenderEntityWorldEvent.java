package net.hachimi.client.impl.event.render.entity;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public class RenderEntityWorldEvent
extends Event {
    public final class_1297 entity;
    public final double cameraX;
    public final double cameraY;
    public final double cameraZ;
    public final float yaw;
    public final float tickDelta;
    public final class_4587 matrices;
    public final class_4597 vertexConsumers;

    public RenderEntityWorldEvent(class_1297 entity, double cameraX, double cameraY, double cameraZ, float yaw, float tickDelta, class_4587 matrices, class_4597 vertexConsumers) {
        this.entity = entity;
        this.cameraX = cameraX;
        this.cameraY = cameraY;
        this.cameraZ = cameraZ;
        this.yaw = yaw;
        this.tickDelta = tickDelta;
        this.matrices = matrices;
        this.vertexConsumers = vertexConsumers;
    }
}
