package net.hachimi.client.impl.event.render.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1309;

@Cancelable
public class RenderThroughWallsEvent
extends Event {
    private class_1309 entity;

    public RenderThroughWallsEvent(class_1309 entity) {
        this.entity = entity;
    }

    public class_1309 getEntity() {
        return this.entity;
    }
}
