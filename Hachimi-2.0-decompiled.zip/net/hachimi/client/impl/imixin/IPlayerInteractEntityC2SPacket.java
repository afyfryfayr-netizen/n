package net.hachimi.client.impl.imixin;

import net.hachimi.client.impl.imixin.IMixin;
import net.hachimi.client.util.network.InteractType;
import net.minecraft.class_1297;

@IMixin
public interface IPlayerInteractEntityC2SPacket {
    public class_1297 getEntity();

    public InteractType getType();
}
