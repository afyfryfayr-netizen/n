package net.hachimi.client.impl.imixin;

import net.hachimi.client.impl.imixin.IMixin;
import net.minecraft.class_2596;

@IMixin
public interface IClientPlayNetworkHandler {
    public void sendQuietPacket(class_2596<?> var1);
}
