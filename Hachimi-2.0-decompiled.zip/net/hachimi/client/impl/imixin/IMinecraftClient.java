package net.hachimi.client.impl.imixin;

import net.hachimi.client.impl.imixin.IMixin;

@IMixin
public interface IMinecraftClient {
    public void leftClick();

    public void rightClick();
}
