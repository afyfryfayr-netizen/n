package net.hachimi.client.impl.imixin;

import net.hachimi.client.impl.imixin.IMixin;

@IMixin
public interface IChatHudLineVisible {
    public int getId();

    public void setId(int var1);
}
