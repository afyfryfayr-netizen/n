package net.hachimi.client.impl.font;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.hachimi.client.mixin.accessor.AccessorTextRenderer;
import net.hachimi.client.util.Globals;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_377;
import net.minecraft.class_379;
import net.minecraft.class_382;
import net.minecraft.class_384;
import net.minecraft.class_389;
import net.minecraft.class_390;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5223;
import net.minecraft.class_5224;
import net.minecraft.class_5251;
import net.minecraft.class_8557;
import net.minecraft.class_9243;
import net.minecraft.class_9799;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

@Deprecated
public class VanillaTextRenderer
implements Globals {
    public static class_327 getTextRender(String fontName) throws IOException {
        ArrayList<class_390.class_9241> list = Lists.newArrayList();
        class_8557 loader = new class_8557(class_2960.method_60654((String)String.format("hachimi:%s.ttf", fontName)), 11.0f, 20.0f, class_8557.class_8558.field_44806, "");
        class_389.class_8539 loadable = (class_389.class_8539)loader.method_51734().orThrow();
        class_390 font = loadable.load(mc.method_1478());
        list.add(new class_390.class_9241(font, class_9243.class_9244.field_49118));
        class_377 storage = new class_377(mc.method_1531(), class_2960.method_60654((String)"hachimi:tr"));
        storage.method_2004(list, Collections.emptySet());
        return new class_327(id -> storage, true);
    }

    public void drawWithShadow(class_4587 matrices, String text, float x, float y, int color) {
        this.draw(matrices, text, x + 1.0f, y + 1.0f, color, true);
        this.draw(matrices, text, x, y, color, false);
    }

    public void draw(class_4587 matrices, String text, float x, float y, int color, boolean shadow) {
        this.draw(text, x, y, color, matrices.method_23760().method_23761(), shadow);
    }

    private void draw(String text, float x, float y, int color, Matrix4f matrix, boolean shadow) {
        if (text == null) {
            return;
        }
        class_4597.class_4598 immediate = class_4597.method_22991((class_9799)new class_9799(1536));
        this.draw(text, x, y, color, shadow, matrix, (class_4597)immediate, class_327.class_6415.field_33993, 0, 0xF000F0);
        immediate.method_22993();
    }

    public void draw(String text, float x, float y, int color, boolean shadow, Matrix4f matrix, class_4597 vertexConsumers, class_327.class_6415 layerType, int backgroundColor, int light) {
        this.drawInternal(text, x, y, color, shadow, matrix, vertexConsumers, layerType, backgroundColor, light);
    }

    private void drawInternal(String text, float x, float y, int color, boolean shadow, Matrix4f matrix, class_4597 vertexConsumers, class_327.class_6415 layerType, int backgroundColor, int light) {
        Matrix4f matrix4f = new Matrix4f((Matrix4fc)matrix);
        this.drawLayer(text, x, y, color, shadow, matrix4f, vertexConsumers, layerType, backgroundColor, light);
    }

    private void drawLayer(String text, float x, float y, int color, boolean shadow, Matrix4f matrix, class_4597 vertexConsumerProvider, class_327.class_6415 layerType, int underlineColor, int light) {
        Drawer drawer = new Drawer(vertexConsumerProvider, x, y, color, shadow, matrix, layerType, light);
        class_5223.method_27479((String)text, (class_2583)class_2583.field_24360, (class_5224)drawer);
        drawer.drawLayer();
    }

    public static class Drawer
    implements class_5224 {
        final class_4597 vertexConsumers;
        private final float brightnessMultiplier;
        private final float red;
        private final float green;
        private final float blue;
        private final float alpha;
        private final Matrix4f matrix;
        private final class_327.class_6415 layerType;
        private final int light;
        float x;
        float y;
        @Nullable
        private List<class_382.class_328> rectangles;

        public Drawer(class_4597 vertexConsumers, float x, float y, int color, boolean shadow, Matrix4f matrix, class_327.class_6415 layerType, int light) {
            this.vertexConsumers = vertexConsumers;
            this.x = x;
            this.y = y;
            this.brightnessMultiplier = shadow ? 0.25f : 1.0f;
            this.red = (float)(color >> 16 & 0xFF) / 255.0f * this.brightnessMultiplier;
            this.green = (float)(color >> 8 & 0xFF) / 255.0f * this.brightnessMultiplier;
            this.blue = (float)(color & 0xFF) / 255.0f * this.brightnessMultiplier;
            this.alpha = (float)(color >> 24 & 0xFF) / 255.0f;
            this.matrix = matrix;
            this.layerType = layerType;
            this.light = light;
        }

        public boolean accept(int i, class_2583 style, int j) {
            float l;
            float h;
            float g;
            class_377 fontStorage = ((AccessorTextRenderer)Globals.mc.field_1772).hookGetFontStorage(style.method_27708());
            class_379 glyph = fontStorage.method_2011(j, ((AccessorTextRenderer)Globals.mc.field_1772).hookGetValidateAdvance());
            class_382 glyphRenderer = style.method_10987() && j != 32 ? fontStorage.method_2013(glyph) : fontStorage.method_2014(j);
            boolean bl = style.method_10984();
            float f = this.alpha;
            class_5251 textColor = style.method_10973();
            if (textColor != null) {
                int k = textColor.method_27716();
                g = (float)(k >> 16 & 0xFF) / 255.0f * this.brightnessMultiplier;
                h = (float)(k >> 8 & 0xFF) / 255.0f * this.brightnessMultiplier;
                l = (float)(k & 0xFF) / 255.0f * this.brightnessMultiplier;
            } else {
                g = this.red;
                h = this.green;
                l = this.blue;
            }
            if (!(glyphRenderer instanceof class_384)) {
                float m = bl ? glyph.method_16799() : 0.0f;
                class_4588 vertexConsumer = this.vertexConsumers.getBuffer(glyphRenderer.method_24045(this.layerType));
                ((AccessorTextRenderer)Globals.mc.field_1772).hookDrawGlyph(glyphRenderer, bl, style.method_10966(), m, this.x, this.y, this.matrix, vertexConsumer, g, h, l, f, this.light);
            }
            float m = glyph.method_16798(bl);
            this.x += m;
            return true;
        }

        public void drawLayer() {
            if (this.rectangles != null) {
                class_382 glyphRenderer = ((AccessorTextRenderer)Globals.mc.field_1772).hookGetFontStorage(class_2583.field_24359).method_22943();
                class_4588 vertexConsumer = this.vertexConsumers.getBuffer(glyphRenderer.method_24045(this.layerType));
                for (class_382.class_328 rectangle : this.rectangles) {
                    glyphRenderer.method_22944(rectangle, this.matrix, vertexConsumer, this.light);
                }
            }
        }
    }
}
