package net.hachimi.client.impl.font;

import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import java.awt.Color;
import java.awt.Font;
import java.io.Closeable;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import net.hachimi.client.api.font.Glyph;
import net.hachimi.client.api.font.GlyphCache;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.impl.module.client.FontModule;
import net.hachimi.client.impl.module.client.SocialsModule;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.math.HexRandom;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public final class AWTFontRenderer
implements Closeable,
Globals {
    private Font font;
    private final float size;
    private int scale;
    private int lastScale;
    private static final Pattern PATTERN_CONTROL_CODE = Pattern.compile("(?i)\\u00A7[0-9A-FK-OG]");
    private final ObjectList<GlyphCache> caches = new ObjectArrayList();
    private final Char2ObjectArrayMap<Glyph> glyphs = new Char2ObjectArrayMap();
    private final Map<class_2960, ObjectList<CharLocation>> cache = new Object2ObjectOpenHashMap();

    public AWTFontRenderer(InputStream inputStream, float size) {
        try {
            this.font = Font.createFont(0, inputStream);
        }
        catch (Throwable t) {
            t.printStackTrace();
            this.font = new Font("Verdana", 0, Math.round(size));
        }
        this.size = size;
        this.createFont(this.font, size);
    }

    public static String stripControlCodes(String text) {
        return PATTERN_CONTROL_CODE.matcher(text).replaceAll("");
    }

    private void createFont(Font font, float size) {
        this.scale = this.lastScale = (int)mc.method_22683().method_4495();
        this.font = font.deriveFont(size * (float)this.scale);
    }

    public void drawStringWithShadow(class_4587 stack, String text, double x, double y, int color) {
        this.drawString(stack, text, x + 0.5, y + 0.5, color, true);
        this.drawString(stack, text, x, y, color, false);
    }

    public void drawString(class_4587 stack, String text, double x, double y, int color) {
        this.drawString(stack, text, x, y, color, false);
    }

    private void drawString(class_4587 stack, String text, double x, double y, int color, boolean shadow) {
        float brightnessMultiplier = shadow ? 0.25f : 1.0f;
        float r = (float)(color >> 16 & 0xFF) / 255.0f * brightnessMultiplier;
        float g = (float)(color >> 8 & 0xFF) / 255.0f * brightnessMultiplier;
        float b = (float)(color & 0xFF) / 255.0f * brightnessMultiplier;
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        this.drawString(stack, text, (float)x, (float)y, r, g, b, a, brightnessMultiplier);
    }

    public void drawString(class_4587 stack, String text, double x, double y, Color color) {
        this.drawString(stack, text, x, y, color, false);
    }

    public void drawString(class_4587 stack, String text, double x, double y, Color color, boolean shadow) {
        float brightnessMultiplier = shadow ? 0.25f : 1.0f;
        this.drawString(stack, text, (float)x, (float)y, (float)color.getRed() / 255.0f * brightnessMultiplier, (float)color.getGreen() / 255.0f * brightnessMultiplier, (float)color.getBlue() / 255.0f * brightnessMultiplier, color.getAlpha(), brightnessMultiplier);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void drawString(class_4587 stack, String text, float x, float y, float r, float g, float b, float a, float brightnessMultiplier) {
        int currentScale = (int)mc.method_22683().method_4495();
        if (currentScale != this.lastScale) {
            this.close();
            this.createFont(this.font, this.size);
        }
        float r2 = r;
        float g2 = g;
        float b2 = b;
        stack.method_22903();
        stack.method_46416(x, y -= 3.0f, 0.0f);
        stack.method_22905(1.0f / (float)this.scale, 1.0f / (float)this.scale, 0.0f);
        RenderSystem.setShader(class_757::method_34543);
        class_289 tessellator = class_289.method_1348();
        Matrix4f matrix4f = stack.method_23760().method_23761();
        char[] chars = text.toCharArray();
        float xOffset = 0.0f;
        float yOffset = 0.0f;
        boolean formatting = false;
        int lineStart = 0;
        this.glyphs.clear();
        Map<class_2960, ObjectList<CharLocation>> map = this.cache;
        synchronized (map) {
            for (int i = 0; i < chars.length; ++i) {
                char c = chars[i];
                if (formatting) {
                    formatting = false;
                    if (c == 'r') {
                        r2 = r;
                        g2 = g;
                        b2 = b;
                        continue;
                    }
                    int colorCode = this.getColorFromCode(c);
                    int[] col = this.toRgbComponents(colorCode);
                    r2 = (float)col[0] / 255.0f * brightnessMultiplier;
                    g2 = (float)col[1] / 255.0f * brightnessMultiplier;
                    b2 = (float)col[2] / 255.0f * brightnessMultiplier;
                    continue;
                }
                if (c == '\u00a7') {
                    formatting = true;
                    continue;
                }
                if (c == '\n') {
                    yOffset += this.getStringHeight(text.substring(lineStart, i)) * (float)this.scale;
                    xOffset = 0.0f;
                    lineStart = i + 1;
                    continue;
                }
                Glyph glyph = (Glyph)this.glyphs.computeIfAbsent(c, g1 -> this.getGlyphFromChar(g1));
                if (glyph == null) continue;
                if (glyph.value() != ' ') {
                    class_2960 i1 = glyph.owner().getId();
                    CharLocation entry = new CharLocation(xOffset, yOffset, r2, g2, b2, glyph);
                    this.cache.computeIfAbsent(i1, integer -> new ObjectArrayList()).add((Object)entry);
                }
                xOffset += (float)glyph.width();
            }
            for (class_2960 identifier : this.cache.keySet()) {
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.disableCull();
                RenderSystem.texParameter((int)3553, (int)10241, (int)9729);
                RenderSystem.texParameter((int)3553, (int)10240, (int)9729);
                try {
                    RenderSystem.setShaderTexture((int)0, (class_2960)identifier);
                }
                catch (Exception e) {
                    continue;
                }
                List objects = (List)this.cache.get(identifier);
                class_287 bufferBuilder = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1575);
                for (CharLocation object : objects) {
                    float xo = object.x;
                    float yo = object.y;
                    float cr = object.r;
                    float cg = object.g;
                    float cb = object.b;
                    Glyph glyph = object.glyph;
                    GlyphCache owner = glyph.owner();
                    float w = glyph.width();
                    float h = glyph.height();
                    float u1 = (float)glyph.textureWidth() / (float)owner.getWidth();
                    float v1 = (float)glyph.textureHeight() / (float)owner.getHeight();
                    float u2 = (float)(glyph.textureWidth() + glyph.width()) / (float)owner.getWidth();
                    float v2 = (float)(glyph.textureHeight() + glyph.height()) / (float)owner.getHeight();
                    bufferBuilder.method_22918(matrix4f, xo + 0.0f, yo + h, 0.0f).method_22915(cr, cg, cb, a).method_22913(u1, v2);
                    bufferBuilder.method_22918(matrix4f, xo + w, yo + h, 0.0f).method_22915(cr, cg, cb, a).method_22913(u2, v2);
                    bufferBuilder.method_22918(matrix4f, xo + w, yo + 0.0f, 0.0f).method_22915(cr, cg, cb, a).method_22913(u2, v1);
                    bufferBuilder.method_22918(matrix4f, xo + 0.0f, yo + 0.0f, 0.0f).method_22915(cr, cg, cb, a).method_22913(u1, v1);
                }
                class_286.method_43433((class_9801)bufferBuilder.method_60800());
                RenderSystem.disableBlend();
            }
            this.cache.clear();
        }
        stack.method_22909();
    }

    public void drawCenteredString(class_4587 stack, String text, double x, double y, int color) {
        this.drawString(stack, text, x, y, color, false);
    }

    public void drawCenteredString(class_4587 stack, String text, double x, double y, int color, boolean shadow) {
        float brightnessMultiplier = shadow ? 0.25f : 1.0f;
        float r = (float)(color >> 16 & 0xFF) / 255.0f * brightnessMultiplier;
        float g = (float)(color >> 8 & 0xFF) / 255.0f * brightnessMultiplier;
        float b = (float)(color & 0xFF) / 255.0f * brightnessMultiplier;
        float a = (color & 0xFF000000) != -16777216 ? 1.0f : (float)(color >> 24 & 0xFF) / 255.0f * brightnessMultiplier;
        this.drawString(stack, text, (float)(x - (double)(this.getStringWidth(text) / 2.0f)), (float)y, r, g, b, a, brightnessMultiplier);
    }

    public void drawCenteredString(class_4587 stack, String text, double x, double y, Color color) {
        this.drawString(stack, text, x, y, color, false);
    }

    public void drawCenteredString(class_4587 stack, String text, double x, double y, Color color, boolean shadow) {
        float brightnessMultiplier = shadow ? 0.25f : 1.0f;
        this.drawString(stack, text, (float)(x - (double)(this.getStringWidth(text) / 2.0f)), (float)y, (float)color.getRed() / 255.0f * brightnessMultiplier, (float)color.getGreen() / 255.0f * brightnessMultiplier, (float)color.getBlue() / 255.0f * brightnessMultiplier, (float)color.getAlpha() / 255.0f, brightnessMultiplier);
    }

    public float getStringWidth(String text) {
        char[] c = AWTFontRenderer.stripControlCodes(text).toCharArray();
        float currentLine = 0.0f;
        float maxPreviousLines = 0.0f;
        for (char c1 : c) {
            if (c1 == '\n') {
                maxPreviousLines = Math.max(currentLine, maxPreviousLines);
                currentLine = 0.0f;
                continue;
            }
            Glyph glyph = (Glyph)this.glyphs.computeIfAbsent(c1, g1 -> this.getGlyphFromChar(g1));
            float w = glyph == null ? 0.0f : (float)glyph.width();
            currentLine += w / (float)this.scale;
        }
        return Math.max(currentLine, maxPreviousLines);
    }

    public float getStringHeight(String text) {
        char[] c = AWTFontRenderer.stripControlCodes(text).toCharArray();
        if (c.length == 0) {
            c = new char[]{' '};
        }
        float currentLine = 0.0f;
        float previous = 0.0f;
        for (char c1 : c) {
            Glyph glyph;
            if (c1 == '\n') {
                if (currentLine == 0.0f) {
                    glyph = (Glyph)this.glyphs.computeIfAbsent(' ', g1 -> this.getGlyphFromChar(g1));
                    currentLine = (float)glyph.height() / (float)this.scale;
                }
                previous += currentLine;
                currentLine = 0.0f;
                continue;
            }
            glyph = (Glyph)this.glyphs.computeIfAbsent(c1, g1 -> this.getGlyphFromChar(g1));
            float h = glyph == null ? 0.0f : (float)glyph.height();
            currentLine = Math.max(h / (float)this.scale, currentLine);
        }
        return currentLine + previous;
    }

    public float getFontHeight() {
        return this.size;
    }

    private Glyph getGlyphFromChar(char c) {
        for (GlyphCache map : this.caches) {
            if (!map.contains(c)) continue;
            return map.getGlyph(c);
        }
        int base = 256 * (int)Math.floor((double)c / 256.0);
        GlyphCache glyphCache = new GlyphCache((char)base, (char)(base + 256), this.font, this.getGlyphIdentifier(), 5, FontModule.getInstance().getAntiAlias(), FontModule.getInstance().getFractionalMetrics());
        this.caches.add((Object)glyphCache);
        return glyphCache.getGlyph(c);
    }

    @Override
    public void close() {
        try {
            for (GlyphCache cache1 : this.caches) {
                cache1.clear();
            }
            this.caches.clear();
            this.glyphs.clear();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class_2960 getGlyphIdentifier() {
        return class_2960.method_60655((String)"hachimi", (String)("font/storage/" + HexRandom.generateRandomHex(32)));
    }

    public int[] toRgbComponents(int color) {
        float r = color >> 16 & 0xFF;
        float g = color >> 8 & 0xFF;
        float b = color & 0xFF;
        float a = (color & 0xFF000000) != -16777216 ? 255.0f : (float)(color >> 24 & 0xFF);
        return new int[]{(int)r, (int)g, (int)b, (int)a};
    }

    private int getColorFromCode(char code) {
        return switch (code) {
            case '0' -> Color.BLACK.getRGB();
            case '1' -> -16777046;
            case '2' -> -16733696;
            case '3' -> -16733526;
            case '4' -> -5636096;
            case '5' -> -5635926;
            case '6' -> -22016;
            case '7' -> -5592406;
            case '8' -> -11184811;
            case '9' -> -11184641;
            case 'a' -> -11141291;
            case 'b' -> -11141121;
            case 'c' -> -43691;
            case 'd' -> -43521;
            case 'e' -> -171;
            case 'f' -> -1;
            case 's' -> ColorsModule.getInstance().getRGB();
            case 'g' -> SocialsModule.getInstance().getFriendRGB();
            default -> -1;
        };
    }

    public record CharLocation(float x, float y, float r, float g, float b, Glyph glyph) {
    }
}
