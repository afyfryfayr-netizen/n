package net.hachimi.client.impl.gui.account.list;

import java.util.Objects;
import net.hachimi.client.api.account.type.MinecraftAccount;
import net.hachimi.client.api.account.type.impl.CrackedAccount;
import net.hachimi.client.api.account.type.impl.MicrosoftAccount;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.network.TextureDownloader;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_320;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4280;

public class AccountEntry
extends class_4280.class_4281<AccountEntry>
implements Globals {
    private static final TextureDownloader FACE_DOWNLOADER = new TextureDownloader();
    private final MinecraftAccount account;
    private long lastClickTime = -1L;

    public AccountEntry(MinecraftAccount account) {
        this.account = account;
    }

    public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
        MicrosoftAccount msa;
        MinecraftAccount minecraftAccount;
        class_327 class_3272 = AccountEntry.mc.field_1772;
        class_2561 class_25612 = class_2561.method_30163((String)this.account.username());
        int n = y + entryHeight / 2;
        Objects.requireNonNull(AccountEntry.mc.field_1772);
        context.method_27535(class_3272, class_25612, x + 20, n - 9 / 2, hovered ? 0x55FF55 : -1);
        if (this.account instanceof CrackedAccount || (minecraftAccount = this.account) instanceof MicrosoftAccount && (msa = (MicrosoftAccount)minecraftAccount).getUsernameOrNull() != null) {
            String id = "face_" + this.account.username().toLowerCase();
            if (!FACE_DOWNLOADER.exists(id)) {
                if (!FACE_DOWNLOADER.isDownloading(id)) {
                    FACE_DOWNLOADER.downloadTexture(id, "https://minotar.net/helm/" + this.account.username() + "/15", false);
                }
                return;
            }
            class_2960 texture = FACE_DOWNLOADER.get(id);
            if (texture != null) {
                context.method_25290(texture, x + 2, y + 2, 0.0f, 0.0f, 15, 15, 15, 15);
            }
        }
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            class_320 session;
            long time = System.currentTimeMillis() - this.lastClickTime;
            if (time > 0L && time < 500L && (session = this.account.login()) != null) {
                Managers.ACCOUNT.setSession(session);
            }
            this.lastClickTime = System.currentTimeMillis();
            return false;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    public class_2561 method_37006() {
        MicrosoftAccount msa;
        MinecraftAccount minecraftAccount = this.account;
        if (minecraftAccount instanceof MicrosoftAccount && (msa = (MicrosoftAccount)minecraftAccount).username() == null) {
            return null;
        }
        return class_2561.method_30163((String)this.account.username());
    }

    public MinecraftAccount getAccount() {
        return this.account;
    }
}
