package net.hachimi.client.impl.gui.account;

import java.util.Objects;
import net.hachimi.client.init.Managers;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;

public final class AccountEncryptionScreen
extends class_437 {
    private static final String SPECIAL_CHARACTERS = "!@#$%^&*()_+-={}[]\\|'\";:/?.>,<`";
    private static final String[] REQUIREMENTS = new String[]{"8+ Characters", "A Special Character", "A Number", "An Uppercase Letter"};
    private final class_437 parent;
    private class_342 passwordTextField;

    public AccountEncryptionScreen(class_437 parent) {
        super(class_2561.method_30163((String)"Account Encryption"));
        this.parent = parent;
    }

    protected void method_25426() {
        this.method_37067();
        this.passwordTextField = new class_342(this.field_22787.field_1772, 145, 20, (class_2561)class_2561.method_43473());
        this.passwordTextField.method_47404(class_2561.method_30163((String)"Enter Password..."));
        this.passwordTextField.method_48229(this.field_22789 / 2 - this.passwordTextField.method_25368() / 2, this.field_22790 / 2 - 60);
        this.method_37063((class_364)this.passwordTextField);
        this.method_37063((class_364)class_4185.method_46430((class_2561)class_2561.method_30163((String)"Encrypt"), action -> {}).method_46434(this.field_22789 / 2 - 72, this.passwordTextField.method_46427() + 90, 145, 20).method_46436(class_7919.method_47407((class_2561)class_2561.method_30163((String)"This will require you to enter a password every time you enter the account manager the first time!"))).method_46431());
        this.method_37063((class_364)class_4185.method_46430((class_2561)class_2561.method_30163((String)"Go Back"), action -> this.field_22787.method_1507(this.parent)).method_46434(this.field_22789 / 2 - 72, this.passwordTextField.method_46427() + 112, 145, 20).method_46431());
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_25300(this.field_22787.field_1772, "Encrypt Accounts (" + Managers.ACCOUNT.getAccounts().size() + ")", this.field_22789 / 2, this.field_22790 / 2 - 125, -1);
        class_327 class_3272 = this.field_22787.field_1772;
        String string = String.valueOf(this.isPasswordSecure(this.passwordTextField.method_1882()) ? class_124.field_1060 : class_124.field_1061) + "*";
        int n = this.field_22789 / 2 - this.passwordTextField.method_25368() / 2 - 6;
        int n2 = this.passwordTextField.method_46427() + 10;
        Objects.requireNonNull(this.field_22787.field_1772);
        context.method_25303(class_3272, string, n, n2 - 9 / 2, -1);
        context.method_25303(this.field_22787.field_1772, "Minimum Requirements:", this.passwordTextField.method_46426() + 1, this.passwordTextField.method_46427() + this.passwordTextField.method_25364() + 10, -1);
        for (int i = 0; i < REQUIREMENTS.length; ++i) {
            String requirement = REQUIREMENTS[i];
            class_327 class_3273 = this.field_22787.field_1772;
            String string2 = "- " + requirement;
            int n3 = this.passwordTextField.method_46426() + 6;
            int n4 = this.passwordTextField.method_46427() + this.passwordTextField.method_25364() + 10;
            Objects.requireNonNull(this.field_22793);
            context.method_25303(class_3273, string2, n3, n4 + (9 + 2) * (1 + i), -1);
        }
    }

    private boolean isPasswordSecure(String password) {
        char[] characters;
        if (password.length() < 8) {
            return false;
        }
        boolean hasUppercase = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        for (char c : characters = password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUppercase = true;
            }
            if (SPECIAL_CHARACTERS.indexOf(c) != -1) {
                hasSpecial = true;
            }
            if (c < '0' || c > '9') continue;
            hasNumber = true;
        }
        return hasUppercase && hasNumber && hasSpecial;
    }
}
