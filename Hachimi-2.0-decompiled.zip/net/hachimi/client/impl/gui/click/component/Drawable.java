package net.hachimi.client.impl.gui.click.component;

import net.minecraft.class_332;

public interface Drawable {
    public void render(class_332 var1, float var2, float var3, float var4);
}
