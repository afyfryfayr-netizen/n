package net.hachimi.client.impl.gui.click.impl.config.setting;

import net.hachimi.client.api.config.Config;
import net.hachimi.client.impl.gui.click.component.Button;
import net.hachimi.client.impl.gui.click.impl.config.CategoryFrame;
import net.hachimi.client.impl.gui.click.impl.config.ModuleButton;
import net.minecraft.class_332;

public abstract class ConfigButton<T>
extends Button {
    protected final Config<T> config;
    protected final ModuleButton moduleButton;

    public ConfigButton(CategoryFrame frame, ModuleButton moduleButton, Config<T> config, float x, float y) {
        super(frame, x, y, 99.0f, 13.0f);
        this.moduleButton = moduleButton;
        this.config = config;
    }

    @Override
    public void render(class_332 context, float mouseX, float mouseY, float delta) {
        this.render(context, this.x, this.y, mouseX, mouseY, delta);
    }

    public abstract void render(class_332 var1, float var2, float var3, float var4, float var5, float var6);

    public Config<T> getConfig() {
        return this.config;
    }
}
