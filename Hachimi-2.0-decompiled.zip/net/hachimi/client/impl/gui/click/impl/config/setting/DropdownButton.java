package net.hachimi.client.impl.gui.click.impl.config.setting;

import java.util.Arrays;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.EnumConfig;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.gui.click.impl.config.CategoryFrame;
import net.hachimi.client.impl.gui.click.impl.config.ModuleButton;
import net.hachimi.client.impl.gui.click.impl.config.setting.ConfigButton;
import net.hachimi.client.impl.manager.world.sound.SoundManager;
import net.hachimi.client.impl.module.client.ClickGuiModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.string.EnumFormatter;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public class DropdownButton
extends ConfigButton<Enum<?>> {
    private int index;
    private boolean open;
    private String[] values;

    public DropdownButton(CategoryFrame frame, ModuleButton moduleButton, Config<Enum<?>> config, float x, float y) {
        super(frame, moduleButton, config, x, y);
        this.cacheValues();
    }

    private void cacheValues() {
        Enum[] enumValues = ((EnumConfig)this.config).getValues();
        this.values = (String[])Arrays.stream(enumValues).map(Enum::name).toArray(String[]::new);
        Enum val = (Enum)this.config.getValue();
        if (val != null) {
            for (int i = 0; i < this.values.length; ++i) {
                if (!this.values[i].equals(val.name())) continue;
                this.index = i;
                break;
            }
        }
    }

    private float rowH() {
        return (float)RenderManager.textHeight() + 4.0f;
    }

    @Override
    public void render(class_332 context, float ix, float iy, float mouseX, float mouseY, float delta) {
        float s = ClickGuiModule.CLICK_GUI_SCALE;
        float base = this.rowH();
        float totalH = this.open ? base + (float)this.values.length * base : base;
        this.setHeight(totalH);
        this.x = ix;
        this.y = iy;
        String val = EnumFormatter.formatEnum((Enum)this.config.getValue());
        boolean over = this.isWithin(mouseX, mouseY);
        if (over != this.hoverAnimation.getState()) {
            this.hoverAnimation.setState(over);
        }
        int hoverAlpha = (int)(80.0 * class_3532.method_15350((double)this.hoverAnimation.getFactor(), (double)0.0, (double)1.0));
        this.fill(context, ix, iy, this.width * s, base * s, ClickGuiModule.getInstance().getColor(100 + hoverAlpha));
        this.drawStringScaled(context, this.config.getName(), ix + 2.0f * s, iy + 4.0f * s, -1);
        float nameW = (float)RenderManager.textWidth(this.config.getName()) * s;
        int valColor = ClickGuiModule.getInstance().getColor(255);
        this.drawStringScaled(context, " " + val, ix + 2.0f * s + nameW, iy + 4.0f * s, valColor);
        String arrow = this.open ? " \u25b2" : " \u25bc";
        float arrowW = (float)RenderManager.textWidth(this.config.getName() + " " + val) * s;
        this.drawStringScaled(context, arrow, ix + 2.0f * s + arrowW, iy + 4.0f * s, -5592406);
        if (this.open) {
            for (int i = 0; i < this.values.length; ++i) {
                float rowY = iy + base * s + (float)i * base * s;
                boolean rowOver = this.isMouseOver((double)mouseX, (double)mouseY, ix, rowY, this.width * s, base * s);
                int bgColor = i == this.index ? ClickGuiModule.getInstance().getColor(160) : (rowOver ? ClickGuiModule.getInstance().getColor(120) : ClickGuiModule.getInstance().getColor(70));
                this.fill(context, ix, rowY, this.width * s, base * s, bgColor);
                String label = EnumFormatter.formatEnum(Enum.valueOf(((Enum)this.config.getValue()).getClass(), this.values[i]));
                int textColor = i == this.index ? -1 : -3355444;
                this.drawStringScaled(context, " " + label, ix + 2.0f * s, rowY + 4.0f * s, textColor);
            }
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.isWithin(mouseX, mouseY) && !this.openAreaContains(mouseX, mouseY)) {
            if (this.open) {
                this.open = false;
            }
            return;
        }
        float s = ClickGuiModule.CLICK_GUI_SCALE;
        float base = this.rowH();
        if (button == 1) {
            if (this.isWithin(mouseX, mouseY)) {
                this.open = !this.open;
                this.playClick();
            }
            return;
        }
        if (button == 0) {
            if (this.open) {
                for (int i = 0; i < this.values.length; ++i) {
                    float rowY = this.y + base * s + (float)i * base * s;
                    if (!this.isMouseOver(mouseX, mouseY, this.x, rowY, this.width * s, base * s)) continue;
                    this.index = i;
                    this.config.setValue(Enum.valueOf(((Enum)this.config.getValue()).getClass(), this.values[i]));
                    this.open = false;
                    this.playClick();
                    return;
                }
                if (this.isWithin(mouseX, mouseY)) {
                    this.open = false;
                    this.playClick();
                }
            } else {
                this.index = this.index + 1 > this.values.length - 1 ? 0 : this.index + 1;
                this.config.setValue(Enum.valueOf(((Enum)this.config.getValue()).getClass(), this.values[this.index]));
                this.playClick();
            }
        }
    }

    private boolean openAreaContains(double mouseX, double mouseY) {
        if (!this.open) {
            return false;
        }
        float s = ClickGuiModule.CLICK_GUI_SCALE;
        float base = this.rowH();
        return this.isMouseOver(mouseX, mouseY, this.x, this.y + base * s, this.width * s, (float)this.values.length * base * s);
    }

    private boolean isMouseOver(double mx, double my, float rx, float ry, float rw, float rh) {
        return mx >= (double)rx && mx <= (double)(rx + rw) && my >= (double)ry && my <= (double)(ry + rh);
    }

    private void playClick() {
        if (ClickGuiModule.getInstance().getSounds()) {
            Managers.SOUND.playSound(SoundManager.GUI_CLICK);
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
    }

    @Override
    public void charTyped(char character, int modifiers) {
    }
}
