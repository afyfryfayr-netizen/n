package net.hachimi.client.impl.gui.click.impl.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.hachimi.client.api.config.Serializable;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.api.render.satin.ManagedShaderEffect;
import net.hachimi.client.impl.gui.click.ClickGuiScreen;
import net.hachimi.client.impl.gui.click.component.Frame;
import net.hachimi.client.impl.gui.click.impl.SearchButton;
import net.hachimi.client.impl.gui.click.impl.config.ModuleButton;
import net.hachimi.client.impl.gui.click.impl.config.setting.ColorButton;
import net.hachimi.client.impl.gui.click.impl.config.setting.ConfigButton;
import net.hachimi.client.impl.manager.world.sound.SoundManager;
import net.hachimi.client.impl.module.client.ClickGuiModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.render.animation.Easing;
import net.hachimi.client.util.string.EnumFormatter;
import net.minecraft.class_332;

public class CategoryFrame
extends Frame
implements Serializable<CategoryFrame> {
    private final String name;
    private final ModuleCategory category;
    private final List<ModuleButton> moduleButtons = new CopyOnWriteArrayList<ModuleButton>();
    private float off;
    private float inner;
    private boolean open;
    private boolean drag;
    private final Animation categoryAnimation = new Animation(false, 200.0f, Easing.CUBIC_IN_OUT);
    private SearchButton searchButton;

    public CategoryFrame(ModuleCategory category, float x, float y, float width, float height) {
        super(x, y, width, height);
        this.category = category;
        this.name = EnumFormatter.formatEnum(category);
        for (Module module : Managers.MODULE.getModules()) {
            if (module.getCategory() != category) continue;
            this.moduleButtons.add(new ModuleButton(module, this, x, y));
        }
        if (category == ModuleCategory.CLIENT) {
            this.searchButton = new SearchButton(this, x, y);
        }
        this.setOpen(true);
    }

    public CategoryFrame(ModuleCategory category, float x, float y) {
        this(category, x, y, 105.0f, 15.0f);
    }

    @Override
    public void render(class_332 context, float mouseX, float mouseY, float delta) {
        this.setHeight((float)RenderManager.textHeight() + 6.0f);
        if (this.drag) {
            this.x += (float)ClickGuiScreen.MOUSE_X - this.px;
            this.y += (float)ClickGuiScreen.MOUSE_Y - this.py;
        }
        this.fheight = 2.0f * ClickGuiModule.CLICK_GUI_SCALE;
        if (this.searchButton != null) {
            this.fheight += this.searchButton.getHeight() + 6.0f * ClickGuiModule.CLICK_GUI_SCALE;
        }
        for (ModuleButton moduleButton : this.moduleButtons) {
            this.fheight += moduleButton.getHeight() + ClickGuiModule.CLICK_GUI_SCALE;
            if (moduleButton.getScaledTime() < 0.01f) continue;
            this.fheight += 3.0f * ClickGuiModule.CLICK_GUI_SCALE * moduleButton.getScaledTime();
            for (ConfigButton<?> configButton : moduleButton.getConfigButtons()) {
                ColorButton colorPicker;
                if (!configButton.getConfig().isVisible()) continue;
                this.fheight += configButton.getHeight() * moduleButton.getScaledTime();
                if (!(configButton instanceof ColorButton) || !((colorPicker = (ColorButton)configButton).getScaledTime() > 0.01f)) continue;
                this.fheight += colorPicker.getPickerHeight() * colorPicker.getScaledTime() * moduleButton.getScaledTime();
            }
        }
        this.rect(context, ClickGuiModule.getInstance().fixTransparency(-301133801));
        this.fill(context, this.x, this.y, 2.0f * ClickGuiModule.CLICK_GUI_SCALE, this.height * ClickGuiModule.CLICK_GUI_SCALE, ClickGuiModule.getInstance().getColor(255));
        this.fill(context, this.x, this.y + (this.height - 1.0f) * ClickGuiModule.CLICK_GUI_SCALE, this.width * ClickGuiModule.CLICK_GUI_SCALE, ClickGuiModule.CLICK_GUI_SCALE, ClickGuiModule.getInstance().getColor(80));
        int whiteText = -1;
        this.drawStringScaled(context, this.name, this.x + 6.0f * ClickGuiModule.CLICK_GUI_SCALE, this.y + 4.0f * ClickGuiModule.CLICK_GUI_SCALE, whiteText);
        if (this.categoryAnimation.getFactor() > (double)0.01f) {
            boolean canScissor = ClickGuiModule.getInstance().getScaleFactor() == 1.0f;
            float y1 = this.y;
            if (this.searchButton != null) {
                y1 += this.searchButton.getHeight() + 6.0f * ClickGuiModule.CLICK_GUI_SCALE;
            }
            if (canScissor) {
                this.enableScissor(this.x, this.y + this.height * ClickGuiModule.CLICK_GUI_SCALE, this.x + this.width * ClickGuiModule.CLICK_GUI_SCALE, (double)(this.y + ClickGuiModule.CLICK_GUI_SCALE * this.height) + (double)this.fheight * this.categoryAnimation.getFactor());
            }
            int fillColor = ClickGuiModule.getInstance().fixTransparency(-586148840);
            this.fill(context, this.x, this.y + this.height * ClickGuiModule.CLICK_GUI_SCALE, this.width * ClickGuiModule.CLICK_GUI_SCALE, this.fheight, fillColor);
            if (ClickGuiModule.getInstance().getBlur() && ClickGuiModule.getInstance().getScaleFactor() == 1.0f) {
                Managers.SHADER.reloadShaders();
                ManagedShaderEffect blurEffect = Managers.SHADER.getBlurShaderEffect();
                if (blurEffect != null) {
                    float panelX = this.x;
                    float panelY = this.y;
                    float panelWidth = this.width * ClickGuiModule.CLICK_GUI_SCALE;
                    float panelHeight = (float)((double)(this.height * ClickGuiModule.CLICK_GUI_SCALE) + (double)this.fheight * this.categoryAnimation.getFactor());
                    blurEffect.setUniformValue("uLocation", panelX, panelY);
                    blurEffect.setUniformValue("uSize", panelWidth, panelHeight);
                    blurEffect.setUniformValue("uStrength", 5.0f);
                    blurEffect.setUniformValue("uRadius", 0.0f);
                    blurEffect.render(delta);
                }
            }
            if (this.searchButton != null) {
                this.searchButton.render(context, this.x + ClickGuiModule.CLICK_GUI_SCALE, this.y + this.height * ClickGuiModule.CLICK_GUI_SCALE + 4.0f * ClickGuiModule.CLICK_GUI_SCALE, mouseX, mouseY, delta);
            }
            this.inner = this.off = y1 + this.height * ClickGuiModule.CLICK_GUI_SCALE + ClickGuiModule.CLICK_GUI_SCALE;
            for (ModuleButton moduleButton : this.moduleButtons) {
                moduleButton.render(context, this.x + ClickGuiModule.CLICK_GUI_SCALE, this.inner + ClickGuiModule.CLICK_GUI_SCALE, mouseX, mouseY, delta);
                this.off += (float)((double)(moduleButton.getHeight() + ClickGuiModule.CLICK_GUI_SCALE) * this.categoryAnimation.getFactor());
                this.inner += moduleButton.getHeight() + ClickGuiModule.CLICK_GUI_SCALE;
            }
            if (canScissor) {
                this.disableScissor();
            }
        }
        this.px = ClickGuiScreen.MOUSE_X;
        this.py = ClickGuiScreen.MOUSE_Y;
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton == 1 && this.isWithin(mouseX, mouseY)) {
            this.open = !this.open;
            this.categoryAnimation.setState(this.open);
            if (ClickGuiModule.getInstance().getSounds()) {
                Managers.SOUND.playSound(SoundManager.GUI_CLICK);
            }
        }
        if (this.isOpen()) {
            for (ModuleButton button : this.moduleButtons) {
                button.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }
        if (this.searchButton != null) {
            this.searchButton.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int mouseButton) {
        super.mouseReleased(mouseX, mouseY, mouseButton);
        this.drag = false;
        if (this.isOpen()) {
            for (ModuleButton button : this.moduleButtons) {
                button.mouseReleased(mouseX, mouseY, mouseButton);
            }
        }
        if (this.searchButton != null) {
            this.searchButton.mouseReleased(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        super.keyPressed(keyCode, scanCode, modifiers);
        if (this.isOpen()) {
            for (ModuleButton button : this.moduleButtons) {
                button.keyPressed(keyCode, scanCode, modifiers);
            }
        }
        if (this.searchButton != null) {
            this.searchButton.keyPressed(keyCode, scanCode, modifiers);
        }
    }

    @Override
    public void charTyped(char character, int modifiers) {
        super.charTyped(character, modifiers);
        if (this.isOpen()) {
            for (ModuleButton button : this.moduleButtons) {
                button.charTyped(character, modifiers);
            }
        }
        if (this.searchButton != null) {
            this.searchButton.charTyped(character, modifiers);
        }
    }

    @Override
    public JsonObject toJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("category", this.category.name());
        obj.addProperty("x", Float.valueOf(this.getX()));
        obj.addProperty("y", Float.valueOf(this.getY()));
        obj.addProperty("open", this.isOpen());
        return obj;
    }

    @Override
    public CategoryFrame fromJson(JsonObject jsonObj) {
        if (jsonObj.has("x") && jsonObj.has("y") && jsonObj.has("open")) {
            JsonElement xElement = jsonObj.get("x");
            JsonElement yElement = jsonObj.get("y");
            JsonElement openElement = jsonObj.get("open");
            this.setPos(xElement.getAsFloat(), yElement.getAsFloat());
            this.setOpen(openElement.getAsBoolean());
        }
        return null;
    }

    public boolean isWithinTotal(float mx, float my) {
        return this.isMouseOver(mx, my, this.x, this.y, this.width * ClickGuiModule.CLICK_GUI_SCALE, this.getTotalHeight());
    }

    public void offset(float in) {
        this.off += in;
        this.inner += in;
    }

    public ModuleCategory getCategory() {
        return this.category;
    }

    public boolean isOpen() {
        return this.open && this.categoryAnimation.getFactor() > (double)0.1f;
    }

    public void setOpen(boolean open) {
        this.open = open;
        this.categoryAnimation.setState(open);
    }

    public float getTotalHeight() {
        return this.height * ClickGuiModule.CLICK_GUI_SCALE + this.fheight;
    }

    public List<ModuleButton> getModuleButtons() {
        return this.moduleButtons;
    }

    public void setDragging(boolean drag) {
        this.drag = drag;
    }

    public boolean isDragging() {
        return this.drag;
    }

    public SearchButton getSearchButton() {
        return this.searchButton;
    }
}
