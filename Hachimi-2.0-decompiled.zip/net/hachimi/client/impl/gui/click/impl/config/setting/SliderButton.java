package net.hachimi.client.impl.gui.click.impl.config.setting;

import java.math.BigDecimal;
import java.math.RoundingMode;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.NumberConfig;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.gui.click.ClickGuiScreen;
import net.hachimi.client.impl.gui.click.impl.config.CategoryFrame;
import net.hachimi.client.impl.gui.click.impl.config.ModuleButton;
import net.hachimi.client.impl.gui.click.impl.config.setting.ConfigButton;
import net.hachimi.client.impl.manager.world.sound.SoundManager;
import net.hachimi.client.impl.module.client.ClickGuiModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import org.apache.commons.lang3.ArrayUtils;

public class SliderButton<T extends Number>
extends ConfigButton<T> {
    private final int scale;
    private char[] buffer;
    private boolean typing;
    private boolean idling;
    private final Timer idleTimer = new CacheTimer();

    public SliderButton(CategoryFrame frame, ModuleButton moduleButton, Config<T> config, float x, float y) {
        super(frame, moduleButton, config, x, y);
        String sval = String.valueOf(config.getValue());
        this.scale = sval.substring(sval.indexOf(".") + 1).length();
        if (config.getValue() instanceof Integer) {
            this.buffer = String.valueOf(((Number)config.getValue()).intValue()).toCharArray();
        } else if (config.getValue() instanceof Float) {
            this.buffer = String.valueOf(((Number)config.getValue()).floatValue()).toCharArray();
        } else if (config.getValue() instanceof Double) {
            this.buffer = String.valueOf(((Number)config.getValue()).doubleValue()).toCharArray();
        }
    }

    @Override
    public void render(class_332 context, float ix, float iy, float mouseX, float mouseY, float delta) {
        this.setHeight((float)RenderManager.textHeight() + 4.0f);
        this.x = ix;
        this.y = iy;
        boolean state = this.isWithin(mouseX, mouseY);
        if (state != this.hoverAnimation.getState()) {
            this.hoverAnimation.setState(state);
        }
        int hoverAlpha = (int)(80.0 * class_3532.method_15350((double)this.hoverAnimation.getFactor(), (double)0.0, (double)1.0));
        Object min = ((NumberConfig)this.config).getMin();
        Object max = ((NumberConfig)this.config).getMax();
        if (this.isWithin(mouseX, mouseY) && ClickGuiScreen.MOUSE_LEFT_HOLD) {
            float fillv = (mouseX - ix) / (this.width * ClickGuiModule.CLICK_GUI_SCALE);
            if (this.config.getValue() instanceof Integer) {
                float val = ((Number)min).floatValue() + fillv * (float)(((Number)max).intValue() - ((Number)min).intValue());
                int bval = (int)class_3532.method_15363((float)val, (float)((Number)min).intValue(), (float)((Number)max).intValue());
                ((NumberConfig)this.config).setValue(bval);
            } else if (this.config.getValue() instanceof Float) {
                float val = ((Number)min).floatValue() + fillv * (((Number)max).floatValue() - ((Number)min).floatValue());
                float bval = class_3532.method_15363((float)val, (float)((Number)min).floatValue(), (float)((Number)max).floatValue());
                BigDecimal bigDecimal = new BigDecimal(bval);
                bval = bigDecimal.setScale(this.scale, RoundingMode.HALF_UP).floatValue();
                ((NumberConfig)this.config).setValue(Float.valueOf(bval));
            } else if (this.config.getValue() instanceof Double) {
                double val = ((Number)min).doubleValue() + (double)fillv * (((Number)max).doubleValue() - ((Number)min).doubleValue());
                double bval = class_3532.method_15350((double)val, (double)((Number)min).doubleValue(), (double)((Number)max).doubleValue());
                BigDecimal bigDecimal = new BigDecimal(bval);
                bval = bigDecimal.setScale(this.scale, RoundingMode.HALF_UP).doubleValue();
                ((NumberConfig)this.config).setValue(bval);
            }
            float lower = class_3532.method_15386((float)(this.x + ClickGuiModule.CLICK_GUI_SCALE));
            float upper = class_3532.method_15375((float)(this.x + this.width * ClickGuiModule.CLICK_GUI_SCALE - ClickGuiModule.CLICK_GUI_SCALE));
            if (mouseX < lower) {
                this.config.setValue(min);
            } else if (mouseX >= upper) {
                this.config.setValue(max);
            }
        }
        if (!this.typing) {
            if (this.config.getValue() instanceof Integer) {
                this.buffer = String.valueOf(((Number)this.config.getValue()).intValue()).toCharArray();
            } else if (this.config.getValue() instanceof Float) {
                this.buffer = String.valueOf(((Number)this.config.getValue()).floatValue()).toCharArray();
            } else if (this.config.getValue() instanceof Double) {
                this.buffer = String.valueOf(((Number)this.config.getValue()).doubleValue()).toCharArray();
            }
            float fill = (((Number)this.config.getValue()).floatValue() - ((Number)min).floatValue()) / (((Number)max).floatValue() - ((Number)min).floatValue());
            this.fill(context, ix, iy, fill * this.width * ClickGuiModule.CLICK_GUI_SCALE, this.height * ClickGuiModule.CLICK_GUI_SCALE, ClickGuiModule.getInstance().getColor(100 + hoverAlpha));
        }
        int whiteText = -1;
        this.drawStringScaled(context, (String)(this.typing ? new String(this.buffer) + this.getInsertionPoint() : this.config.getName()), ix + 2.0f * ClickGuiModule.CLICK_GUI_SCALE, iy + 4.0f * ClickGuiModule.CLICK_GUI_SCALE, whiteText);
        float textLeng = (float)RenderManager.textWidth(this.config.getName()) * ClickGuiModule.CLICK_GUI_SCALE;
        if (!this.typing) {
            int grayText = -5592406;
            this.drawStringScaled(context, " " + String.valueOf(this.config.getValue()), ix + 2.0f * ClickGuiModule.CLICK_GUI_SCALE + textLeng, iy + 4.0f * ClickGuiModule.CLICK_GUI_SCALE, grayText);
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isWithin(mouseX, mouseY)) {
            if (button == 1) {
                if (this.typing) {
                    String number = new String(this.buffer);
                    try {
                        if (this.config.getValue() instanceof Integer) {
                            ((NumberConfig)this.config).setValue(Integer.parseInt(number));
                        } else if (this.config.getValue() instanceof Float) {
                            ((NumberConfig)this.config).setValue(Float.valueOf(Float.parseFloat(number)));
                        } else if (this.config.getValue() instanceof Double) {
                            ((NumberConfig)this.config).setValue(Double.parseDouble(number));
                        }
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                    this.typing = false;
                } else {
                    this.typing = true;
                }
            }
            if (ClickGuiModule.getInstance().getSounds()) {
                Managers.SOUND.playSound(SoundManager.GUI_CLICK);
            }
        } else {
            this.typing = false;
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.typing) {
            switch (keyCode) {
                case 257: {
                    String number = new String(this.buffer);
                    try {
                        if (this.config.getValue() instanceof Integer) {
                            ((NumberConfig)this.config).setValue(Integer.parseInt(number));
                        } else if (this.config.getValue() instanceof Float) {
                            ((NumberConfig)this.config).setValue(Float.valueOf(Float.parseFloat(number)));
                        } else if (this.config.getValue() instanceof Double) {
                            ((NumberConfig)this.config).setValue(Double.parseDouble(number));
                        }
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                    if (this.config.getValue() instanceof Integer) {
                        this.buffer = String.valueOf(((Number)this.config.getValue()).intValue()).toCharArray();
                    } else if (this.config.getValue() instanceof Float) {
                        this.buffer = String.valueOf(((Number)this.config.getValue()).floatValue()).toCharArray();
                    } else if (this.config.getValue() instanceof Double) {
                        this.buffer = String.valueOf(((Number)this.config.getValue()).doubleValue()).toCharArray();
                    }
                    this.typing = false;
                    break;
                }
                case 259: {
                    if (this.buffer.length == 0) break;
                    this.buffer = ArrayUtils.remove((char[])this.buffer, (int)(this.buffer.length - 1));
                    break;
                }
                case 256: {
                    if (this.config.getValue() instanceof Integer) {
                        this.buffer = String.valueOf(((Number)this.config.getValue()).intValue()).toCharArray();
                    } else if (this.config.getValue() instanceof Float) {
                        this.buffer = String.valueOf(((Number)this.config.getValue()).floatValue()).toCharArray();
                    } else if (this.config.getValue() instanceof Double) {
                        this.buffer = String.valueOf(((Number)this.config.getValue()).doubleValue()).toCharArray();
                    }
                    this.typing = false;
                }
            }
        }
    }

    @Override
    public void charTyped(char character, int modifiers) {
        if (this.typing && (Character.isDigit(character) || character == '.')) {
            this.buffer = ArrayUtils.add((char[])this.buffer, (char)character);
        }
    }

    public String getInsertionPoint() {
        if (this.idleTimer.passed(250)) {
            this.idling = !this.idling;
            this.idleTimer.reset();
        }
        if (this.idling && this.typing) {
            return "_";
        }
        return "";
    }

    public void endTyping() {
        this.typing = false;
    }

    public boolean isTyping() {
        return this.typing;
    }
}
