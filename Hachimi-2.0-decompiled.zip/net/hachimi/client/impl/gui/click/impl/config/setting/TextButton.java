package net.hachimi.client.impl.gui.click.impl.config.setting;

import java.awt.Color;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.gui.click.impl.config.CategoryFrame;
import net.hachimi.client.impl.gui.click.impl.config.ModuleButton;
import net.hachimi.client.impl.gui.click.impl.config.setting.ConfigButton;
import net.hachimi.client.impl.manager.world.sound.SoundManager;
import net.hachimi.client.impl.module.client.ClickGuiModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.math.timer.CacheTimer;
import net.hachimi.client.util.math.timer.Timer;
import net.minecraft.class_124;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import org.apache.commons.lang3.ArrayUtils;

public class TextButton
extends ConfigButton<String> {
    private char[] buffer;
    private boolean typing;
    private boolean idling;
    private final Timer idleTimer = new CacheTimer();

    public TextButton(CategoryFrame frame, ModuleButton moduleButton, Config<String> config, float x, float y) {
        super(frame, moduleButton, config, x, y);
        this.buffer = config.getValue().toCharArray();
    }

    @Override
    public void render(class_332 context, float ix, float iy, float mouseX, float mouseY, float delta) {
        this.setHeight((float)RenderManager.textHeight() + 4.0f);
        this.x = ix;
        this.y = iy;
        int whiteText = -1;
        boolean state = this.isWithin(mouseX, mouseY);
        if (state != this.hoverAnimation.getState()) {
            this.hoverAnimation.setState(state);
        }
        int hoverAlpha = (int)(80.0 * class_3532.method_15350((double)this.hoverAnimation.getFactor(), (double)0.0, (double)1.0));
        this.rect(context, new Color(hoverAlpha, hoverAlpha, hoverAlpha, hoverAlpha).getRGB());
        String renderText = this.typing ? new String(this.buffer) + this.getInsertionPoint() : this.config.getName() + String.valueOf(class_124.field_1080) + " " + new String(this.buffer);
        this.drawStringScaled(context, renderText, ix + 2.0f * ClickGuiModule.CLICK_GUI_SCALE, iy + 4.0f * ClickGuiModule.CLICK_GUI_SCALE, whiteText);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isWithin(mouseX, mouseY)) {
            if (button == 0) {
                if (this.typing) {
                    this.config.setValue(new String(this.buffer));
                    this.typing = false;
                } else {
                    this.typing = true;
                }
                if (ClickGuiModule.getInstance().getSounds()) {
                    Managers.SOUND.playSound(SoundManager.GUI_CLICK);
                }
            }
        } else {
            this.endTyping();
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.typing) {
            switch (keyCode) {
                case 257: {
                    this.config.setValue(new String(this.buffer));
                    this.typing = false;
                    break;
                }
                case 259: {
                    if (this.buffer.length == 0) break;
                    this.buffer = ArrayUtils.remove((char[])this.buffer, (int)(this.buffer.length - 1));
                    break;
                }
                case 256: {
                    this.buffer = ((String)this.config.getValue()).toCharArray();
                    this.typing = false;
                }
            }
        }
    }

    @Override
    public void charTyped(char character, int modifiers) {
        if (this.typing) {
            this.buffer = ArrayUtils.add((char[])this.buffer, (char)character);
        }
    }

    public void endTyping() {
        this.typing = false;
    }

    public boolean isTyping() {
        return this.typing;
    }

    public String getInsertionPoint() {
        if (this.idleTimer.passed(250)) {
            this.idling = !this.idling;
            this.idleTimer.reset();
        }
        if (this.idling && this.typing) {
            return "_";
        }
        return "";
    }
}
