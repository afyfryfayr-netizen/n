package net.hachimi.client.api.account.type;

import com.google.gson.JsonObject;
import net.minecraft.class_320;

public interface MinecraftAccount {
    public class_320 login();

    public String username();

    default public JsonObject toJSON() {
        JsonObject object = new JsonObject();
        object.addProperty("username", this.username());
        return object;
    }
}
