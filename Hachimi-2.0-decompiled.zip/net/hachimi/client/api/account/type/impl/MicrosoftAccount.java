package net.hachimi.client.api.account.type.impl;

import com.google.gson.JsonObject;
import net.hachimi.client.api.account.msa.exception.MSAAuthException;
import net.hachimi.client.api.account.type.MinecraftAccount;
import net.hachimi.client.impl.manager.client.AccountManager;
import net.minecraft.class_320;

public final class MicrosoftAccount
implements MinecraftAccount {
    private final String email;
    private final String password;
    private String accessToken;
    private String username;

    public MicrosoftAccount(String accessToken) {
        this(null, null);
        if (accessToken == null || accessToken.isEmpty()) {
            throw new RuntimeException("Access token should not be null");
        }
        this.accessToken = accessToken;
    }

    public MicrosoftAccount(String email, String password) {
        this.email = email;
        this.password = password;
    }

    @Override
    public class_320 login() {
        class_320 session;
        block8: {
            session = null;
            try {
                if (this.email != null && this.password != null) {
                    try {
                        session = AccountManager.MSA_AUTHENTICATOR.loginWithCredentials(this.email, this.password);
                        break block8;
                    }
                    catch (MSAAuthException e) {
                        AccountManager.MSA_AUTHENTICATOR.setLoginStage(e.getMessage());
                        return null;
                    }
                }
                if (this.accessToken != null) {
                    if (this.accessToken.startsWith("M.")) {
                        this.accessToken = AccountManager.MSA_AUTHENTICATOR.getLoginToken(this.accessToken);
                    }
                    session = AccountManager.MSA_AUTHENTICATOR.loginWithToken(this.accessToken, true);
                }
            }
            catch (MSAAuthException e) {
                e.printStackTrace();
                AccountManager.MSA_AUTHENTICATOR.setLoginStage(e.getMessage());
                return null;
            }
        }
        if (session != null) {
            AccountManager.MSA_AUTHENTICATOR.setLoginStage("");
            this.username = session.method_1676();
            return session;
        }
        return null;
    }

    @Override
    public JsonObject toJSON() {
        JsonObject object = MinecraftAccount.super.toJSON();
        if (this.accessToken != null) {
            object.addProperty("token", this.accessToken);
        } else {
            if (this.email == null || this.password == null) {
                throw new RuntimeException("Email/Password & Access token is null for a MSA?");
            }
            object.addProperty("email", this.email);
            object.addProperty("password", this.password);
        }
        return object;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPassword() {
        return this.password;
    }

    @Override
    public String username() {
        if (this.username != null) {
            return this.username;
        }
        return this.email;
    }

    public String getUsernameOrNull() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAccessToken() {
        return this.accessToken;
    }
}
