package net.hachimi.client.api.account.type.impl;

import java.util.Optional;
import java.util.UUID;
import net.hachimi.client.api.account.type.MinecraftAccount;
import net.minecraft.class_320;

public record CrackedAccount(String username) implements MinecraftAccount
{
    @Override
    public class_320 login() {
        return new class_320(this.username(), UUID.randomUUID(), "", Optional.empty(), Optional.empty(), class_320.class_321.field_1990);
    }
}
