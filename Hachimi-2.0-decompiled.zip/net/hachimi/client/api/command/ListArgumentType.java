package net.hachimi.client.api.command;

import com.mojang.brigadier.ImmutableStringReader;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.concurrent.CompletableFuture;
import net.hachimi.client.api.command.ConfigArgumentType;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BlockListConfig;
import net.hachimi.client.api.config.setting.EntityListConfig;
import net.hachimi.client.api.config.setting.ItemListConfig;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ListArgumentType
implements ArgumentType<Object> {
    public static ListArgumentType list() {
        return new ListArgumentType();
    }

    public static Object getListItem(CommandContext<?> context, String name) {
        return context.getArgument(name, Object.class);
    }

    public Object parse(StringReader reader) throws CommandSyntaxException {
        String string = reader.readString();
        class_1792 item = (class_1792)class_7923.field_41178.method_10223(class_2960.method_60655((String)"minecraft", (String)string));
        if (item != class_1802.field_8162) {
            return item;
        }
        class_2248 block = (class_2248)class_7923.field_41175.method_10223(class_2960.method_60655((String)"minecraft", (String)string));
        if (block != class_2246.field_10124) {
            return block;
        }
        class_1299 entityType = (class_1299)class_7923.field_41177.method_10223(class_2960.method_60655((String)"minecraft", (String)string));
        if (string.equalsIgnoreCase("pig") || entityType != class_1299.field_6093) {
            return entityType;
        }
        throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.dispatcherParseException().createWithContext((ImmutableStringReader)reader, null);
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        Config<?> config = ConfigArgumentType.getConfig(context, "setting");
        String value = StringArgumentType.getString(context, (String)"value");
        if (!(value.equalsIgnoreCase("add") || value.equalsIgnoreCase("remove") || value.equalsIgnoreCase("del"))) {
            return builder.buildFuture();
        }
        if (config instanceof ItemListConfig) {
            for (class_1792 item : class_7923.field_41178) {
                builder.suggest(class_7923.field_41178.method_10221((Object)item).method_12832());
            }
        }
        if (config instanceof BlockListConfig) {
            for (class_2248 block : class_7923.field_41175) {
                builder.suggest(class_7923.field_41175.method_10221((Object)block).method_12832());
            }
        }
        if (config instanceof EntityListConfig) {
            for (class_1299 entityType : class_7923.field_41177) {
                builder.suggest(class_7923.field_41177.method_10221((Object)entityType).method_12832());
            }
        }
        return builder.buildFuture();
    }
}
