package net.hachimi.client.api;

public interface Invokable<T> {
    public void invoke(T var1);
}
