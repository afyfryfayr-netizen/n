package net.hachimi.client.api.file;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import net.hachimi.client.Hachimi;

public abstract class ConfigFile {
    protected static final Gson GSON = new GsonBuilder().setLenient().setPrettyPrinting().create();
    private final String fileName;
    private final Path filepath;

    public ConfigFile(Path dir, String path) {
        if (!Files.exists(dir, new LinkOption[0])) {
            try {
                Files.createDirectory(dir, new FileAttribute[0]);
            }
            catch (IOException e) {
                Hachimi.error("Could not create {} dir", dir);
                e.printStackTrace();
            }
        }
        this.fileName = dir.getFileName().toString();
        this.filepath = dir.resolve(this.toJsonPath(path));
    }

    protected String read(Path path) throws IOException {
        int b;
        StringBuilder content = new StringBuilder();
        InputStream in = Files.newInputStream(path, new OpenOption[0]);
        while ((b = in.read()) != -1) {
            content.append((char)b);
        }
        in.close();
        return content.toString();
    }

    protected String serialize(Object obj) {
        return GSON.toJson(obj);
    }

    protected JsonObject parseObject(String json) {
        return this.parse(json, JsonObject.class);
    }

    protected JsonArray parseArray(String json) {
        return this.parse(json, JsonArray.class);
    }

    protected <T> T parse(String json, Class<T> type) {
        try {
            return GSON.fromJson(json, type);
        }
        catch (JsonSyntaxException e) {
            Hachimi.error("Invalid json syntax!");
            e.printStackTrace();
            return null;
        }
    }

    protected void write(Path path, String content) throws IOException {
        OutputStream out = Files.newOutputStream(path, new OpenOption[0]);
        byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
        out.write(bytes, 0, bytes.length);
        out.close();
    }

    public String getFileName() {
        return this.fileName;
    }

    public Path getFilepath() {
        return this.filepath;
    }

    public abstract void save();

    public abstract void load();

    private String toJsonPath(String fileName) {
        return String.format("%s.json", fileName).toLowerCase();
    }
}
