package net.hachimi.client.api.file;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.file.ConfigFile;
import net.hachimi.client.api.font.FontFile;
import net.hachimi.client.api.macro.MacroFile;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.file.ModuleConfigFile;
import net.hachimi.client.api.module.file.ModuleFile;
import net.hachimi.client.api.social.SocialFile;
import net.hachimi.client.api.social.SocialRelation;
import net.hachimi.client.api.waypoint.WaypointFile;
import net.hachimi.client.impl.gui.click.ClickGuiFile;
import net.hachimi.client.impl.module.player.InventoryManagerModule;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.chat.ChatUtil;

public class ClientConfiguration
implements Globals {
    private final Set<ConfigFile> files = new HashSet<ConfigFile>();
    private Path clientDir;
    private ModuleConfigFile modulesFile;
    private MacroFile macrosFile;
    private final ClickGuiFile clickGuiFile;
    private final FontFile fontFile;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public ClientConfiguration() {
        Path runningDir = ClientConfiguration.mc.field_1697.toPath();
        try {
            File homeDir = new File(System.getProperty("user.home"));
            this.clientDir = homeDir.toPath();
        }
        catch (Exception e) {
            Hachimi.error("Could not access home dir, defaulting to running dir");
            e.printStackTrace();
            this.clientDir = runningDir;
        }
        finally {
            if (this.clientDir == null || !Files.exists(this.clientDir, new LinkOption[0]) || !Files.isWritable(this.clientDir)) {
                this.clientDir = runningDir;
            }
            this.clientDir = ClientConfiguration.mc.field_1697.toPath().resolve("hachimi");
            if (!Files.exists(this.clientDir, new LinkOption[0])) {
                try {
                    Files.createDirectory(this.clientDir, new FileAttribute[0]);
                }
                catch (IOException e) {
                    Hachimi.error("Could not create client dir");
                    e.printStackTrace();
                }
            }
            Path configDir = this.clientDir.resolve("Configs");
            Path keybindsDir = this.clientDir.resolve("Macros");
            if (!Files.exists(configDir, new LinkOption[0])) {
                try {
                    Files.createDirectory(configDir, new FileAttribute[0]);
                    Files.createDirectory(keybindsDir, new FileAttribute[0]);
                }
                catch (IOException e) {
                    Hachimi.error("Could not create config/macro dir");
                    e.printStackTrace();
                }
            }
        }
        this.files.add(new MacroFile(this.clientDir));
        for (Module module : Managers.MODULE.getModules()) {
            this.files.add(new ModuleFile(this.clientDir.resolve("Modules"), module));
        }
        this.files.add(InventoryManagerModule.getInstance().getBlacklistFile(this.clientDir));
        this.files.add(new WaypointFile(this.clientDir));
        for (SocialRelation relation : SocialRelation.values()) {
            this.files.add(new SocialFile(this.clientDir, relation));
        }
        this.clickGuiFile = new ClickGuiFile(this.clientDir);
        this.fontFile = new FontFile(this.clientDir);
    }

    public void saveClient() {
        for (ConfigFile file : this.files) {
            file.save();
        }
    }

    public void saveClientModules() {
        for (ConfigFile file : this.files) {
            if (!(file instanceof ModuleFile)) continue;
            file.save();
        }
    }

    public void loadClient() {
        this.executor.submit(() -> {
            for (ConfigFile file : this.files) {
                file.load();
            }
        });
    }

    public void loadClientModules() {
        this.executor.submit(() -> {
            for (ConfigFile file : this.files) {
                if (!(file instanceof ModuleFile)) continue;
                file.load();
            }
        });
    }

    public void saveModuleConfiguration(String configFile) {
        this.modulesFile = new ModuleConfigFile(this.clientDir.resolve("Configs"), configFile);
        this.modulesFile.save();
    }

    public boolean loadModuleConfiguration(String configFile) {
        Path configDir = this.clientDir.resolve("Configs");
        this.modulesFile = new ModuleConfigFile(configDir, configFile);
        if (!Files.exists(configDir.resolve(configFile + ".json"), new LinkOption[0])) {
            ChatUtil.error("Could not find config file: " + configFile);
            return false;
        }
        this.executor.submit(() -> this.modulesFile.load());
        return true;
    }

    public void saveKeybindConfiguration(String configFile) {
        this.macrosFile = new MacroFile(this.clientDir.resolve("Macros"), configFile);
        this.macrosFile.save();
    }

    public boolean loadKeybindConfiguration(String configFile) {
        Path macrosDir = this.clientDir.resolve("Macros");
        this.macrosFile = new MacroFile(macrosDir, configFile);
        if (!Files.exists(macrosDir.resolve(configFile + ".json"), new LinkOption[0])) {
            ChatUtil.error("Could not find config file: " + configFile);
            return false;
        }
        this.macrosFile.load();
        return true;
    }

    public void saveClickGui() {
        this.clickGuiFile.save();
    }

    public void loadClickGui() {
        this.clickGuiFile.load();
    }

    public void saveFonts() {
        this.fontFile.save();
    }

    public void loadFonts() {
        this.fontFile.load();
    }

    public Set<ConfigFile> getFiles() {
        return this.files;
    }

    public void addFile(ConfigFile configFile) {
        this.files.add(configFile);
    }

    public void removeFile(ConfigFile configFile) {
        this.files.remove(configFile);
    }

    public Path getClientDirectory() {
        return this.clientDir;
    }
}
