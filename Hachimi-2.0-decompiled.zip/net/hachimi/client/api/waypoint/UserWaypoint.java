package net.hachimi.client.api.waypoint;

import net.hachimi.client.api.waypoint.Waypoint;

public class UserWaypoint
extends Waypoint {
    public UserWaypoint(String name, String ip, int dimension, double x, double y, double z) {
        super(name, ip, dimension, x, y, z);
    }
}
