package net.hachimi.client.api.module.file;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import net.hachimi.client.api.file.ConfigFile;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.init.Managers;

public class ModuleConfigFile
extends ConfigFile {
    public ModuleConfigFile(Path dir, String path) {
        super(dir, path);
    }

    @Override
    public void save() {
        try {
            Path filepath = this.getFilepath();
            if (!Files.exists(filepath, new LinkOption[0])) {
                Files.createFile(filepath, new FileAttribute[0]);
            }
            JsonObject out = new JsonObject();
            out.addProperty("version", String.format("%s %s", "Hachimi", "2.0"));
            JsonArray array = new JsonArray();
            for (Module module : Managers.MODULE.getModules()) {
                array.add(module.toJson());
            }
            out.add("configs", array);
            this.write(filepath, this.serialize(out));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void load() {
        try {
            Path filepath = this.getFilepath();
            if (Files.exists(filepath, new LinkOption[0])) {
                String content = this.read(filepath);
                JsonObject in = this.parseObject(content);
                if (!in.has("configs")) {
                    return;
                }
                JsonArray array = in.getAsJsonArray("configs");
                for (JsonElement element : array.asList()) {
                    JsonObject object = element.getAsJsonObject();
                    if (!object.has("id")) continue;
                    Module module = Managers.MODULE.getModuleById(object.get("id").getAsString());
                    if (module == null) {
                        return;
                    }
                    module.fromJson(object);
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
