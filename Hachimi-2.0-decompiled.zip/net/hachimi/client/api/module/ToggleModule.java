package net.hachimi.client.api.module;

import net.hachimi.client.api.Hideable;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.MacroConfig;
import net.hachimi.client.api.config.setting.ToggleConfig;
import net.hachimi.client.api.macro.Macro;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ModuleCategory;
import net.hachimi.client.util.chat.ChatUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.render.animation.Easing;

public class ToggleModule
extends Module
implements Hideable {
    private final Animation animation = new Animation(false, 300.0f, Easing.CUBIC_IN_OUT);
    Config<Boolean> enabledConfig = this.register(new ToggleConfig("Enabled", "The module enabled state", false));
    Config<Macro> keybindingConfig = this.register(new MacroConfig("Keybind", "The keybind to toggle the module", new Macro(this.getId(), -1, () -> this.toggle())));
    Config<Boolean> hiddenConfig = this.register(new BooleanConfig("Hidden", "The hidden state of the module in the arraylist", true));
    Config<Boolean> notifyConfig = this.register(new BooleanConfig("Notify", "Notifies you when the module is toggled in chat", true, () -> false));

    public ToggleModule(String name, String desc, ModuleCategory category) {
        super(name, desc, category);
        this.register(this.keybindingConfig, this.enabledConfig, this.hiddenConfig);
    }

    public ToggleModule(String name, String desc, ModuleCategory category, Integer keycode) {
        this(name, desc, category);
        this.keybind(keycode);
    }

    @Override
    public boolean isHidden() {
        return this.hiddenConfig.getValue();
    }

    @Override
    public void setHidden(boolean hidden) {
        this.hiddenConfig.setValue(hidden);
    }

    public void toggle() {
        if (this.isEnabled()) {
            this.disable();
        } else {
            this.enable();
        }
    }

    public void enable() {
        this.enabledConfig.setValue(true);
        this.onEnable();
        if (this.notifyConfig.getValue().booleanValue() && ToggleModule.mc.field_1687 != null) {
            ChatUtil.clientSendMessage("\u00a7a[+] \u00a7f" + this.getName(), this.hashCode());
        }
    }

    public void disable() {
        this.enabledConfig.setValue(false);
        this.onDisable();
        if (this.notifyConfig.getValue().booleanValue() && ToggleModule.mc.field_1687 != null) {
            ChatUtil.clientSendMessage("\u00a7c[-] \u00a7f" + this.getName(), this.hashCode());
        }
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    public void keybind(int keycode) {
        this.keybindingConfig.setContainer(this);
        ((MacroConfig)this.keybindingConfig).setValue(keycode);
    }

    public boolean isEnabled() {
        return this.enabledConfig.getValue();
    }

    public Macro getKeybinding() {
        return this.keybindingConfig.getValue();
    }

    public void setNotify(boolean notify) {
        this.notifyConfig.setValue(notify);
    }

    public boolean getNotify() {
        return this.notifyConfig.getValue();
    }

    public Animation getAnimation() {
        return this.animation;
    }
}
