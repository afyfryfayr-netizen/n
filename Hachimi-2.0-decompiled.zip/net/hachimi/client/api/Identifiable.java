package net.hachimi.client.api;

public interface Identifiable {
    public String getId();
}
