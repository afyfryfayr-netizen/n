package net.hachimi.client.api.render.satin;

import net.hachimi.client.api.render.satin.uniform.UniformFinder;
import net.minecraft.class_5944;

public interface ManagedCoreShader
extends UniformFinder {
    public class_5944 getProgram();

    public void release();
}
