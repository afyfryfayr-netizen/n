package net.hachimi.client.api.render.satin;

import java.util.function.Consumer;
import net.hachimi.client.api.render.satin.ManagedCoreShader;
import net.hachimi.client.api.render.satin.ManagedShaderEffect;
import net.hachimi.client.api.render.satin.ReloadableShaderEffectManager;
import net.minecraft.class_293;
import net.minecraft.class_2960;

public interface ShaderEffectManager {
    public static ShaderEffectManager getInstance() {
        return ReloadableShaderEffectManager.INSTANCE;
    }

    public ManagedShaderEffect manage(class_2960 var1);

    public ManagedShaderEffect manage(class_2960 var1, Consumer<ManagedShaderEffect> var2);

    public ManagedCoreShader manageCoreShader(class_2960 var1);

    public ManagedCoreShader manageCoreShader(class_2960 var1, class_293 var2);

    public ManagedCoreShader manageCoreShader(class_2960 var1, class_293 var2, Consumer<ManagedCoreShader> var3);
}
