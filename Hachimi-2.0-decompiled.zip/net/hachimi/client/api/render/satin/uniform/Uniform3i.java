package net.hachimi.client.api.render.satin.uniform;

public interface Uniform3i {
    public void set(int var1, int var2, int var3);
}
