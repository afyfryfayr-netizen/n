package net.hachimi.client.api.render.satin.uniform;

import net.hachimi.client.api.render.satin.uniform.SamplerUniform;
import net.hachimi.client.api.render.satin.uniform.Uniform1f;
import net.hachimi.client.api.render.satin.uniform.Uniform1i;
import net.hachimi.client.api.render.satin.uniform.Uniform2f;
import net.hachimi.client.api.render.satin.uniform.Uniform2i;
import net.hachimi.client.api.render.satin.uniform.Uniform3f;
import net.hachimi.client.api.render.satin.uniform.Uniform3i;
import net.hachimi.client.api.render.satin.uniform.Uniform4f;
import net.hachimi.client.api.render.satin.uniform.Uniform4i;
import net.hachimi.client.api.render.satin.uniform.UniformMat4;

public interface UniformFinder {
    public Uniform1i findUniform1i(String var1);

    public Uniform2i findUniform2i(String var1);

    public Uniform3i findUniform3i(String var1);

    public Uniform4i findUniform4i(String var1);

    public Uniform1f findUniform1f(String var1);

    public Uniform2f findUniform2f(String var1);

    public Uniform3f findUniform3f(String var1);

    public Uniform4f findUniform4f(String var1);

    public UniformMat4 findUniformMat4(String var1);

    public SamplerUniform findSampler(String var1);
}
