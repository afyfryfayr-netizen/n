package net.hachimi.client.api.render.satin.uniform;

public interface Uniform2i {
    public void set(int var1, int var2);
}
