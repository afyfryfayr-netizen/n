package net.hachimi.client.api.render.satin.uniform;

public interface Uniform1f {
    public void set(float var1);
}
