package net.hachimi.client.api.render.satin.uniform;

public interface Uniform1i {
    public void set(int var1);
}
