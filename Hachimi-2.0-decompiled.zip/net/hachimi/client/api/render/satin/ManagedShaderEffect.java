package net.hachimi.client.api.render.satin;

import net.hachimi.client.api.render.satin.ManagedFramebuffer;
import net.hachimi.client.api.render.satin.uniform.SamplerUniformV2;
import net.hachimi.client.api.render.satin.uniform.UniformFinder;
import net.minecraft.class_279;

public interface ManagedShaderEffect
extends UniformFinder {
    public class_279 getShaderEffect();

    public void release();

    public void render(float var1);

    public ManagedFramebuffer getTarget(String var1);

    public void setUniformValue(String var1, int var2);

    public void setUniformValue(String var1, float var2);

    public void setUniformValue(String var1, float var2, float var3);

    public void setUniformValue(String var1, float var2, float var3, float var4);

    public void setUniformValue(String var1, float var2, float var3, float var4, float var5);

    @Override
    public SamplerUniformV2 findSampler(String var1);
}
