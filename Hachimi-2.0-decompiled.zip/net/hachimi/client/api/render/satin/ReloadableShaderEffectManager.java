package net.hachimi.client.api.render.satin;

import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Set;
import java.util.function.Consumer;
import net.hachimi.client.api.render.satin.ManagedCoreShader;
import net.hachimi.client.api.render.satin.ManagedShaderEffect;
import net.hachimi.client.api.render.satin.ResettableManagedCoreShader;
import net.hachimi.client.api.render.satin.ResettableManagedShaderBase;
import net.hachimi.client.api.render.satin.ResettableManagedShaderEffect;
import net.hachimi.client.api.render.satin.ShaderEffectManager;
import net.hachimi.client.impl.event.ResolutionEvent;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5912;

public final class ReloadableShaderEffectManager
implements ShaderEffectManager {
    public static final ReloadableShaderEffectManager INSTANCE = new ReloadableShaderEffectManager();
    private final Set<ResettableManagedShaderBase<?>> managedShaders = new ReferenceOpenHashSet();

    public ReloadableShaderEffectManager() {
        EventBus.INSTANCE.subscribe(this);
    }

    @EventListener
    public void onResolution(ResolutionEvent event) {
        this.onResolutionChanged(event.getWindow().method_4489(), event.getWindow().method_4506());
    }

    @Override
    public ManagedShaderEffect manage(class_2960 location) {
        return this.manage(location, s -> {});
    }

    @Override
    public ManagedShaderEffect manage(class_2960 location, Consumer<ManagedShaderEffect> initCallback) {
        ResettableManagedShaderEffect ret = new ResettableManagedShaderEffect(location, initCallback);
        this.managedShaders.add(ret);
        return ret;
    }

    @Override
    public ManagedCoreShader manageCoreShader(class_2960 location) {
        return this.manageCoreShader(location, class_290.field_1580);
    }

    @Override
    public ManagedCoreShader manageCoreShader(class_2960 location, class_293 vertexFormat) {
        return this.manageCoreShader(location, vertexFormat, s -> {});
    }

    @Override
    public ManagedCoreShader manageCoreShader(class_2960 location, class_293 vertexFormat, Consumer<ManagedCoreShader> initCallback) {
        ResettableManagedCoreShader ret = new ResettableManagedCoreShader(location, vertexFormat, initCallback);
        this.managedShaders.add(ret);
        return ret;
    }

    public void reload(class_5912 shaderResources) {
        for (ResettableManagedShaderBase<?> ss : this.managedShaders) {
            ss.initializeOrLog(shaderResources);
        }
    }

    public void onResolutionChanged(int newWidth, int newHeight) {
        this.runShaderSetup(newWidth, newHeight);
    }

    private void runShaderSetup(int newWidth, int newHeight) {
        if (!this.managedShaders.isEmpty()) {
            for (ResettableManagedShaderBase<?> ss : this.managedShaders) {
                if (!ss.isInitialized()) continue;
                ss.setup(newWidth, newHeight);
            }
        }
    }
}
