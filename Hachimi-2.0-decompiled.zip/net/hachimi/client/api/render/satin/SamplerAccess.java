package net.hachimi.client.api.render.satin;

import java.util.List;

public interface SamplerAccess {
    public boolean hasSampler(String var1);

    public List<String> getSamplerNames();

    public List<Integer> getSamplerShaderLocs();
}
