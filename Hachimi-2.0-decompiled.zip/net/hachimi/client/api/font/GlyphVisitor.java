package net.hachimi.client.api.font;

import net.hachimi.client.api.font.FontRenderer;

@FunctionalInterface
public interface GlyphVisitor {
    public int draw(FontRenderer var1, char var2, double var3, double var5, int var7, boolean var8);
}
