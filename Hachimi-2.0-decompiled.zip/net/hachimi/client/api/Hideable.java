package net.hachimi.client.api;

public interface Hideable {
    public boolean isHidden();

    public void setHidden(boolean var1);
}
