package net.hachimi.client.api.macro;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.file.ConfigFile;
import net.hachimi.client.api.macro.Macro;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.init.Managers;

public class MacroFile
extends ConfigFile {
    public MacroFile(Path dir) {
        super(dir, "macros");
    }

    public MacroFile(Path dir, String path) {
        super(dir, path);
    }

    @Override
    public void save() {
        try {
            Path filepath = this.getFilepath();
            if (!Files.exists(filepath, new LinkOption[0])) {
                Files.createFile(filepath, new FileAttribute[0]);
            }
            JsonArray object = new JsonArray();
            for (Macro macro : Managers.MACRO.getMacros()) {
                object.add(macro.toJson());
            }
            this.write(filepath, this.serialize(object));
        }
        catch (IOException e) {
            Hachimi.error("Could not save macro file!");
            e.printStackTrace();
        }
    }

    @Override
    public void load() {
        try {
            Path filepath = this.getFilepath();
            if (Files.exists(filepath, new LinkOption[0])) {
                String content = this.read(filepath);
                JsonArray object = this.parseArray(content);
                for (JsonElement element : object.getAsJsonArray()) {
                    String id;
                    Macro macro;
                    JsonObject jsonObject = element.getAsJsonObject();
                    if (!jsonObject.has("id") || (macro = Managers.MACRO.getMacro(arg_0 -> MacroFile.lambda$load$0(id = jsonObject.get("id").getAsString(), arg_0))) == null) continue;
                    macro.fromJson(jsonObject);
                    Module module = Managers.MODULE.getModuleById(id.substring(0, id.length() - 6));
                    if (!(module instanceof ToggleModule)) continue;
                    ToggleModule t = (ToggleModule)module;
                    t.keybind(jsonObject.get("value").getAsInt());
                }
            }
        }
        catch (IOException e) {
            Hachimi.error("Could not read macro file!");
            e.printStackTrace();
        }
    }

    private static /* synthetic */ boolean lambda$load$0(String id, Macro m) {
        return m.getId().equals(id);
    }
}
