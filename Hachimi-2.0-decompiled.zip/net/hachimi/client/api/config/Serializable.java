package net.hachimi.client.api.config;

import com.google.gson.JsonObject;

public interface Serializable<T> {
    public JsonObject toJson();

    public T fromJson(JsonObject var1);
}
