package net.hachimi.client.api.config.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.impl.event.config.ConfigUpdateEvent;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class BlockListConfig<T extends List<class_2248>>
extends Config<T> {
    public BlockListConfig(String name, String desc, class_2248 ... values) {
        super(name, desc, new ArrayList<class_2248>(Arrays.asList(values)));
    }

    public void add(class_2248 block) {
        ConfigUpdateEvent configUpdateEvent = new ConfigUpdateEvent(this);
        configUpdateEvent.setStage(StageEvent.EventStage.PRE);
        EventBus.INSTANCE.dispatch(configUpdateEvent);
        ((List)this.getValue()).add(block);
        configUpdateEvent.setStage(StageEvent.EventStage.POST);
        EventBus.INSTANCE.dispatch(configUpdateEvent);
    }

    public void remove(class_2248 block) {
        ConfigUpdateEvent configUpdateEvent = new ConfigUpdateEvent(this);
        configUpdateEvent.setStage(StageEvent.EventStage.PRE);
        EventBus.INSTANCE.dispatch(configUpdateEvent);
        ((List)this.getValue()).remove(block);
        configUpdateEvent.setStage(StageEvent.EventStage.POST);
        EventBus.INSTANCE.dispatch(configUpdateEvent);
    }

    public void clear() {
        ConfigUpdateEvent configUpdateEvent = new ConfigUpdateEvent(this);
        configUpdateEvent.setStage(StageEvent.EventStage.PRE);
        EventBus.INSTANCE.dispatch(configUpdateEvent);
        ((List)this.getValue()).clear();
        configUpdateEvent.setStage(StageEvent.EventStage.POST);
        EventBus.INSTANCE.dispatch(configUpdateEvent);
    }

    public boolean contains(Object obj) {
        if (obj instanceof class_2248) {
            class_2248 block = (class_2248)obj;
            return ((List)this.value).contains(block);
        }
        return false;
    }

    @Override
    public JsonObject toJson() {
        JsonObject jsonObj = super.toJson();
        JsonArray array = new JsonArray();
        for (class_2248 block : (List)this.getValue()) {
            class_2960 id = class_7923.field_41175.method_10221((Object)block);
            array.add(id.toString());
        }
        jsonObj.add("value", array);
        return jsonObj;
    }

    @Override
    public T fromJson(JsonObject jsonObj) {
        if (jsonObj.has("value")) {
            JsonElement element = jsonObj.get("value");
            ArrayList<class_2248> temp = new ArrayList<class_2248>();
            for (JsonElement je : element.getAsJsonArray()) {
                String val = je.getAsString();
                class_2248 block = (class_2248)class_7923.field_41175.method_10223(class_2960.method_60654((String)val));
                temp.add(block);
            }
            return (T)temp;
        }
        return null;
    }
}
