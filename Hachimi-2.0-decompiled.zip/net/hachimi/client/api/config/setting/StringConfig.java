package net.hachimi.client.api.config.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.function.Supplier;
import net.hachimi.client.api.config.Config;

public class StringConfig
extends Config<String> {
    public StringConfig(String name, String desc, String value) {
        super(name, desc, value);
    }

    public StringConfig(String name, String desc, String value, Supplier<Boolean> visible) {
        super(name, desc, value, visible);
    }

    @Override
    public JsonObject toJson() {
        JsonObject configObj = super.toJson();
        configObj.addProperty("value", (String)this.getValue());
        return configObj;
    }

    @Override
    public String fromJson(JsonObject jsonObj) {
        if (jsonObj.has("value")) {
            JsonElement element = jsonObj.get("value");
            return element.getAsString();
        }
        return null;
    }
}
