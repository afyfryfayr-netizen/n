package net.hachimi.client.mixin.toast;

import net.hachimi.client.impl.event.toast.RenderToastEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_332;
import net.minecraft.class_374;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_374.class})
public class MixinToastManager {
    @Inject(method={"draw"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookDraw(class_332 context, CallbackInfo ci) {
        RenderToastEvent renderToastEvent = new RenderToastEvent();
        EventBus.INSTANCE.dispatch(renderToastEvent);
        if (renderToastEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
