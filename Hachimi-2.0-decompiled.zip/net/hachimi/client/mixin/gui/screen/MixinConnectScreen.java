package net.hachimi.client.mixin.gui.screen;

import net.hachimi.client.impl.event.gui.screen.ConnectScreenEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_412.class})
public class MixinConnectScreen {
    @Inject(method={"connect(Lnet/minecraft/client/MinecraftClient;Lnet/minecraft/client/network/ServerAddress;Lnet/minecraft/client/network/ServerInfo;Lnet/minecraft/client/network/CookieStorage;)V"}, at={@At(value="HEAD")})
    private void onConnect(class_310 client, class_639 address, class_642 info, class_9112 cookieStorage, CallbackInfo ci) {
        ConnectScreenEvent connectScreenEvent = new ConnectScreenEvent(address, info);
        EventBus.INSTANCE.dispatch(connectScreenEvent);
    }
}
