package net.hachimi.client.mixin.gui.screen.slot;

import net.hachimi.client.impl.event.gui.screen.slot.ShulkerNestedEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1736;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1736.class})
public class MixinShulkerBoxSlot {
    @Inject(method={"canInsert"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookCanInsert(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        ShulkerNestedEvent shulkerNestedEvent = new ShulkerNestedEvent();
        EventBus.INSTANCE.dispatch(shulkerNestedEvent);
        if (shulkerNestedEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)true);
        }
    }
}
