package net.hachimi.client.mixin.gui.screen;

import net.minecraft.class_8519;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_8519.class})
public class MixinSplashTextRenderer {
    @Inject(method={"render"}, at={@At(value="HEAD")}, cancellable=true)
    private void hachimi$hideSplashText(CallbackInfo ci) {
        ci.cancel();
    }
}
