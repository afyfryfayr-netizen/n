package net.hachimi.client.mixin.gui.hud;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import java.util.List;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.impl.event.gui.chat.ChatHistoryEvent;
import net.hachimi.client.impl.event.gui.chat.ChatLengthEvent;
import net.hachimi.client.impl.event.gui.hud.ChatMessageEvent;
import net.hachimi.client.impl.event.gui.hud.ChatTextEvent;
import net.hachimi.client.impl.event.gui.hud.ChatTextRenderEvent;
import net.hachimi.client.impl.event.gui.hud.RenderChatHudEvent;
import net.hachimi.client.impl.event.gui.hud.SignatureIndicatorEvent;
import net.hachimi.client.impl.imixin.IChatHud;
import net.hachimi.client.impl.imixin.IChatHudLine;
import net.hachimi.client.impl.imixin.IChatHudLineVisible;
import net.hachimi.client.util.FormattingUtil;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_338;
import net.minecraft.class_341;
import net.minecraft.class_3532;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_338.class})
public abstract class MixinChatHud
implements IChatHud,
Globals {
    @Shadow
    @Final
    private List<class_303> field_2061;
    @Shadow
    @Final
    private List<class_303.class_7590> field_2064;
    @Shadow
    @Final
    private class_310 field_2062;
    @Shadow
    private boolean field_2067;
    @Shadow
    private int field_2066;
    @Unique
    private class_303.class_7590 current = null;
    @Unique
    private int currentId;

    @Shadow
    public abstract double method_1814();

    @Shadow
    public abstract int method_1811();

    @Shadow
    public abstract void method_1802(int var1);

    @Shadow
    public abstract boolean method_1819();

    @Shadow
    public abstract void method_44811(class_2561 var1, @Nullable class_7469 var2, @Nullable class_7591 var3);

    @Inject(method={"render"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/hud/ChatHudLine$Visible;addedTime()I")})
    private void hookTimeAdded(CallbackInfo ci, @Local(ordinal=13) int chatLineIndex) {
        try {
            this.current = this.field_2064.get(chatLineIndex);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Redirect(method={"render"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/OrderedText;III)I"))
    private int drawTextWithShadowHook(class_332 instance, class_327 textRenderer, class_5481 text, int x, int y, int color) {
        RenderChatHudEvent renderChatHudEvent = new RenderChatHudEvent(this.current);
        EventBus.INSTANCE.dispatch(renderChatHudEvent);
        ChatTextRenderEvent chatTextRenderEvent = new ChatTextRenderEvent();
        EventBus.INSTANCE.dispatch(chatTextRenderEvent);
        if (renderChatHudEvent.isCanceled()) {
            int color1;
            if (renderChatHudEvent.getAnimationMode()) {
                if (chatTextRenderEvent.isCanceled()) {
                    RenderManager.renderText(instance, FormattingUtil.toString(text), (int)renderChatHudEvent.getAnimation(), y, color);
                    return RenderManager.textWidth(FormattingUtil.toString(text));
                }
                return instance.method_35720(textRenderer, text, (int)renderChatHudEvent.getAnimation(), y, color);
            }
            float alpha = (float)class_3532.method_15350((double)renderChatHudEvent.getAnimation(), (double)0.0, (double)1.0);
            float colorAlpha = color >> 24 & 0xFF;
            alpha = Math.max(0.0f, Math.min(1.0f, alpha));
            int colorAlphaInt = Math.max(10, (int)(colorAlpha * alpha));
            int n = color1 = alpha == 1.0f ? color : colorAlphaInt << 24 | color & 0xFFFFFF;
            if (chatTextRenderEvent.isCanceled()) {
                RenderManager.renderText(instance, FormattingUtil.toString(text), 0.0f, y, color1);
                return RenderManager.textWidth(FormattingUtil.toString(text));
            }
            return instance.method_35720(textRenderer, text, 0, y, color1);
        }
        if (chatTextRenderEvent.isCanceled()) {
            RenderManager.renderText(instance, FormattingUtil.toString(text), 0.0f, y, color);
            return RenderManager.textWidth(FormattingUtil.toString(text));
        }
        return instance.method_35720(textRenderer, text, 0, y, color);
    }

    @ModifyExpressionValue(method={"render"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/hud/ChatHudLine$Visible;indicator()Lnet/minecraft/client/gui/hud/MessageIndicator;")})
    private class_7591 hookRender(class_7591 original) {
        SignatureIndicatorEvent signatureIndicatorEvent = new SignatureIndicatorEvent();
        EventBus.INSTANCE.dispatch(signatureIndicatorEvent);
        return signatureIndicatorEvent.isCanceled() ? null : original;
    }

    @Inject(method={"addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookAddMessage(class_2561 message, class_7469 signatureData, class_7591 indicator, CallbackInfo ci) {
        ci.cancel();
        try {
            this.field_2064.removeIf(msg -> ((IChatHudLineVisible)msg).getId() == this.currentId && this.currentId != 0);
            for (int i = this.field_2061.size() - 1; i > -1; --i) {
                if (((IChatHudLine)this.field_2061.get(i)).getId() != this.currentId || this.currentId == 0) continue;
                this.field_2061.remove(i);
            }
            ChatMessageEvent chatTextEvent = new ChatMessageEvent(message);
            EventBus.INSTANCE.dispatch(chatTextEvent);
            int i = class_3532.method_15357((double)((double)this.method_1811() / this.method_1814()));
            if (indicator != null && indicator.comp_900() != null) {
                i -= indicator.comp_900().field_39766 + 4 + 2;
            }
            List list = class_341.method_1850((class_5348)(chatTextEvent.isCanceled() ? chatTextEvent.getText() : message), (int)i, (class_327)this.field_2062.field_1772);
            boolean bl = this.method_1819();
            for (int j = 0; j < list.size(); ++j) {
                class_5481 orderedText = (class_5481)list.get(j);
                if (bl && this.field_2066 > 0) {
                    this.field_2067 = true;
                    this.method_1802(1);
                }
                ChatTextEvent chatMessageEvent = new ChatTextEvent(orderedText);
                EventBus.INSTANCE.dispatch(chatMessageEvent);
                boolean bl2 = j == list.size() - 1;
                class_303.class_7590 visibleLine = new class_303.class_7590(MixinChatHud.mc.field_1705.method_1738(), chatMessageEvent.isCanceled() ? chatMessageEvent.getText() : orderedText, indicator, bl2);
                ((IChatHudLineVisible)visibleLine).setId(this.currentId);
                this.field_2064.add(0, visibleLine);
            }
            ChatLengthEvent chatLengthEvent = new ChatLengthEvent();
            EventBus.INSTANCE.dispatch(chatLengthEvent);
            boolean bl1 = chatLengthEvent.isCanceled();
            if (!bl1) {
                while (this.field_2064.size() > 100) {
                    this.field_2064.remove(this.field_2064.size() - 1);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Inject(method={"clear"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookClear(boolean clearHistory, CallbackInfo ci) {
        ChatHistoryEvent chatHistoryEvent = new ChatHistoryEvent();
        EventBus.INSTANCE.dispatch(chatHistoryEvent);
        if (chatHistoryEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Override
    public void addMessage(class_2561 message, class_7591 messageIndicator, int id) {
        this.currentId = id;
        this.method_44811(message, null, messageIndicator);
        this.currentId = 0;
    }
}
