package net.hachimi.client.mixin.gui.hud;

import net.hachimi.client.impl.event.gui.hud.RenderOverlayEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1058;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_4603.class})
public class MixinInGameOverlayRenderer {
    @Inject(method={"renderFireOverlay"}, at={@At(value="HEAD")}, cancellable=true)
    private static void hookRenderFireOverlay(class_310 client, class_4587 matrices, CallbackInfo ci) {
        RenderOverlayEvent.Fire renderOverlayEvent = new RenderOverlayEvent.Fire(null);
        EventBus.INSTANCE.dispatch(renderOverlayEvent);
        if (renderOverlayEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"renderUnderwaterOverlay"}, at={@At(value="HEAD")}, cancellable=true)
    private static void hookRenderUnderwaterOverlay(class_310 client, class_4587 matrices, CallbackInfo ci) {
        RenderOverlayEvent.Water renderOverlayEvent = new RenderOverlayEvent.Water(null);
        EventBus.INSTANCE.dispatch(renderOverlayEvent);
        if (renderOverlayEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"renderInWallOverlay"}, at={@At(value="HEAD")}, cancellable=true)
    private static void hookRenderFireOverlay(class_1058 sprite, class_4587 matrices, CallbackInfo ci) {
        RenderOverlayEvent.Block renderOverlayEvent = new RenderOverlayEvent.Block(null);
        EventBus.INSTANCE.dispatch(renderOverlayEvent);
        if (renderOverlayEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
