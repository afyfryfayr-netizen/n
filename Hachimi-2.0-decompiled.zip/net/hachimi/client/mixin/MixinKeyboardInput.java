package net.hachimi.client.mixin;

import net.hachimi.client.impl.event.keyboard.KeyboardTickEvent;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_743.class})
public class MixinKeyboardInput {
    @Inject(method={"tick"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookTick$Pre(boolean slowDown, float slowDownFactor, CallbackInfo info) {
        KeyboardTickEvent event = new KeyboardTickEvent((class_744)this);
        event.setStage(StageEvent.EventStage.PRE);
        EventBus.INSTANCE.dispatch(event);
        if (event.isCanceled()) {
            info.cancel();
        }
    }

    @Inject(method={"tick"}, at={@At(value="FIELD", target="Lnet/minecraft/client/input/KeyboardInput;sneaking:Z", shift=At.Shift.BEFORE)}, cancellable=true)
    private void hookTick$Post(boolean slowDown, float f, CallbackInfo ci) {
        KeyboardTickEvent keyboardTickEvent = new KeyboardTickEvent((class_744)this);
        keyboardTickEvent.setStage(StageEvent.EventStage.POST);
        EventBus.INSTANCE.dispatch(keyboardTickEvent);
        if (keyboardTickEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
