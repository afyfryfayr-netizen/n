package net.hachimi.client.mixin.item;

import net.hachimi.client.impl.event.item.FinishUsingEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1792.class})
public class MixinItem {
    @Inject(method={"finishUsing"}, at={@At(value="HEAD")})
    private void hookFinishUsing(class_1799 stack, class_1937 world, class_1309 user, CallbackInfoReturnable<class_1799> cir) {
        FinishUsingEvent finishUsingEvent = new FinishUsingEvent(stack);
        EventBus.INSTANCE.dispatch(finishUsingEvent);
    }
}
