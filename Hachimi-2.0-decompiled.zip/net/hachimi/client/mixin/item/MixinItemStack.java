package net.hachimi.client.mixin.item;

import net.hachimi.client.impl.event.item.DurabilityEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1799.class})
public abstract class MixinItemStack {
    @Shadow
    public abstract int method_7919();

    @Shadow
    public abstract void method_7974(int var1);

    @Inject(method={"<init>(Lnet/minecraft/item/ItemConvertible;I)V"}, at={@At(value="RETURN")})
    private void hookInitItem(class_1935 item, int count, CallbackInfo ci) {
        if (EventBus.INSTANCE == null) {
            return;
        }
        DurabilityEvent durabilityEvent = new DurabilityEvent(this.method_7919());
        EventBus.INSTANCE.dispatch(durabilityEvent);
        if (durabilityEvent.isCanceled()) {
            this.method_7974(durabilityEvent.getDamage());
        }
    }
}
