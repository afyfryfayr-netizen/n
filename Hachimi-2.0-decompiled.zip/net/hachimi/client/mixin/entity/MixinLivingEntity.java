package net.hachimi.client.mixin.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.hachimi.client.impl.event.entity.ConsumeItemEvent;
import net.hachimi.client.impl.event.entity.ElytraUpdateEvent;
import net.hachimi.client.impl.event.entity.EntityTravelEvent;
import net.hachimi.client.impl.event.entity.JumpDelayEvent;
import net.hachimi.client.impl.event.entity.JumpRotationEvent;
import net.hachimi.client.impl.event.entity.LevitationEvent;
import net.hachimi.client.impl.event.entity.PlayerClimbEvent;
import net.hachimi.client.impl.event.entity.PlayerDamageEvent;
import net.hachimi.client.impl.event.entity.StatusEffectEvent;
import net.hachimi.client.impl.event.entity.StepEvent;
import net.hachimi.client.impl.event.entity.SwingSpeedEvent;
import net.hachimi.client.impl.event.entity.UpdateServerPositionEvent;
import net.hachimi.client.impl.event.network.SprintCancelEvent;
import net.hachimi.client.impl.event.render.entity.ElytraTransformEvent;
import net.hachimi.client.impl.module.movement.ElytraFlyModule;
import net.hachimi.client.impl.module.movement.FakeFlyModule;
import net.hachimi.client.mixin.entity.MixinEntity;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_4050;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1309.class})
public abstract class MixinLivingEntity
extends MixinEntity
implements Globals {
    @Shadow
    protected class_1799 field_6277;
    @Shadow
    private int field_6228;
    @Unique
    private boolean prevFlying;

    @Shadow
    public abstract float method_5705(float var1);

    @Shadow
    protected abstract float method_6106();

    @Shadow
    public abstract boolean method_6059(class_6880<class_1291> var1);

    @Shadow
    public abstract void method_5728(boolean var1);

    @Inject(method={"setSprinting"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookSetSprinting(boolean sprinting, CallbackInfo ci) {
        if (this != MixinLivingEntity.mc.field_1724) {
            return;
        }
        SprintCancelEvent sprintEvent = new SprintCancelEvent();
        EventBus.INSTANCE.dispatch(sprintEvent);
        if (sprintEvent.isCanceled()) {
            this.method_5728(true);
            ci.cancel();
        }
    }

    @Inject(method={"getHandSwingDuration"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetHandSwingDuration(CallbackInfoReturnable<Integer> cir) {
        SwingSpeedEvent swingSpeedEvent = new SwingSpeedEvent();
        EventBus.INSTANCE.dispatch(swingSpeedEvent);
        if (swingSpeedEvent.isCanceled()) {
            if (swingSpeedEvent.getSelfOnly() && this != MixinLivingEntity.mc.field_1724) {
                return;
            }
            cir.setReturnValue((Object)swingSpeedEvent.getSwingSpeed());
        }
    }

    @ModifyExpressionValue(method={"jump"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;getYaw()F")})
    private float hookJump$getYaw(float original) {
        if (this != MixinLivingEntity.mc.field_1724) {
            return original;
        }
        JumpRotationEvent jumpRotationEvent = new JumpRotationEvent(original);
        EventBus.INSTANCE.dispatch(jumpRotationEvent);
        return jumpRotationEvent.isCanceled() ? jumpRotationEvent.getYaw() : original;
    }

    @Redirect(method={"travel"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;hasStatusEffect(Lnet/minecraft/registry/entry/RegistryEntry;)Z"))
    private boolean hookHasStatusEffect(class_1309 instance, class_6880<class_1291> effect) {
        if (instance.equals((Object)MixinLivingEntity.mc.field_1724) && effect == class_1294.field_5902) {
            LevitationEvent levitationEvent = new LevitationEvent();
            EventBus.INSTANCE.dispatch(levitationEvent);
            return !levitationEvent.isCanceled() && this.method_6059(effect);
        }
        return this.method_6059(effect);
    }

    @Inject(method={"consumeItem"}, at={@At(value="INVOKE", target="Lnet/minecraft/item/ItemStack;finishUsing(Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;)Lnet/minecraft/item/ItemStack;", shift=At.Shift.AFTER)})
    private void hookConsumeItem(CallbackInfo ci) {
        if (this == MixinLivingEntity.mc.field_1724) {
            EventBus.INSTANCE.dispatch(new ConsumeItemEvent(this.field_6277));
        }
    }

    @Inject(method={"tickMovement"}, at={@At(value="HEAD")})
    private void hookTickMovement(CallbackInfo ci) {
        JumpDelayEvent jumpDelayEvent = new JumpDelayEvent();
        EventBus.INSTANCE.dispatch(jumpDelayEvent);
        if (jumpDelayEvent.isCanceled()) {
            this.field_6228 = 0;
        }
    }

    @Inject(method={"addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z"}, at={@At(value="HEAD")})
    private void hookAddStatusEffect(class_1293 effect, class_1297 source, CallbackInfoReturnable<Boolean> cir) {
        if (this == MixinLivingEntity.mc.field_1724) {
            EventBus.INSTANCE.dispatch(new StatusEffectEvent.Add(effect));
        }
    }

    @Inject(method={"setStatusEffect"}, at={@At(value="HEAD")})
    private void hookAddStatusEffect$1(class_1293 effect, class_1297 source, CallbackInfo ci) {
        if (this == MixinLivingEntity.mc.field_1724) {
            EventBus.INSTANCE.dispatch(new StatusEffectEvent.Add(effect));
        }
    }

    @Inject(method={"removeStatusEffectInternal"}, at={@At(value="HEAD")})
    private void hookRemoveStatusEffect(class_6880<class_1291> effect, CallbackInfoReturnable<class_1293> cir) {
        if (this == MixinLivingEntity.mc.field_1724) {
            EventBus.INSTANCE.dispatch(new StatusEffectEvent.Remove(effect));
        }
    }

    @Inject(method={"isFallFlying"}, at={@At(value="TAIL")}, cancellable=true)
    public void hookIsFallFlying(CallbackInfoReturnable<Boolean> cir) {
        boolean flying = (Boolean)cir.getReturnValue();
        if (ElytraFlyModule.getInstance().isEnabled() && this.prevFlying && !flying && MixinLivingEntity.mc.field_1724 != null) {
            MixinLivingEntity.mc.field_1724.method_23669();
            mc.method_1562().method_52787((class_2596)new class_2848((class_1297)MixinLivingEntity.mc.field_1724, class_2848.class_2849.field_12982));
            cir.setReturnValue((Object)true);
        }
        this.prevFlying = flying;
    }

    @Inject(method={"applyDamage"}, at={@At(value="HEAD")})
    private void hookDamage(class_1282 source, float amount, CallbackInfo ci) {
        if (MixinLivingEntity.mc.field_1724 != null && source.method_5529() != null && source.method_5529().method_5477().getString().equalsIgnoreCase(MixinLivingEntity.mc.field_1724.method_5477().getString())) {
            EventBus.INSTANCE.dispatch(new PlayerDamageEvent((class_1309)this));
        }
    }

    @Inject(method={"updateTrackedPositionAndAngles"}, at={@At(value="HEAD")})
    private void hookUpdateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps, CallbackInfo ci) {
        EventBus.INSTANCE.dispatch(new UpdateServerPositionEvent((class_1309)this, x, y, z, yaw, pitch));
    }

    @Inject(method={"travel"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookTravelPre(class_243 movementInput, CallbackInfo ci) {
        EntityTravelEvent entityTravelEvent = new EntityTravelEvent((class_1309)this, true);
        EventBus.INSTANCE.dispatch(entityTravelEvent);
        if (entityTravelEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"travel"}, at={@At(value="RETURN")})
    private void hookTravelPost(class_243 movementInput, CallbackInfo ci) {
        EventBus.INSTANCE.dispatch(new EntityTravelEvent((class_1309)this, false));
    }

    @Redirect(method={"tick"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;isFallFlying()Z"))
    private boolean hookTick(class_1309 instance) {
        boolean flying = instance.method_6128();
        ElytraTransformEvent elytraTransformEvent = new ElytraTransformEvent((class_1297)instance);
        EventBus.INSTANCE.dispatch(elytraTransformEvent);
        if (instance == MixinLivingEntity.mc.field_1724) {
            ElytraFlyModule ef;
            ElytraUpdateEvent elytraUpdateEvent = new ElytraUpdateEvent(instance, flying);
            EventBus.INSTANCE.dispatch(elytraUpdateEvent);
            FakeFlyModule lsmf = FakeFlyModule.getInstance();
            if (lsmf != null && lsmf.isEnabled()) {
                lsmf.setFallFlying(flying);
            }
            if ((ef = ElytraFlyModule.getInstance()) != null && ef.isEnabled()) {
                ef.setFallFlying(flying);
            }
            if (elytraUpdateEvent.isCanceled()) {
                instance.method_18380(class_4050.field_18076);
            }
        }
        return !elytraTransformEvent.isCanceled() && flying;
    }

    @Inject(method={"getStepHeight"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetStepHeight(CallbackInfoReturnable<Float> cir) {
        StepEvent stepEvent = new StepEvent((class_1309)this, cir.getReturnValueF());
        EventBus.INSTANCE.dispatch(stepEvent);
        if (stepEvent.isCanceled()) {
            cir.setReturnValue((Object)Float.valueOf(stepEvent.getStepHeight()));
        }
    }

    @Inject(method={"isClimbing"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookIsClimbing(CallbackInfoReturnable<Boolean> cir) {
        if (this != MixinLivingEntity.mc.field_1724) {
            return;
        }
        PlayerClimbEvent playerClimbEvent = new PlayerClimbEvent();
        EventBus.INSTANCE.dispatch(playerClimbEvent);
        if (playerClimbEvent.isCanceled()) {
            System.out.println("Baritone has been removed");
            cir.setReturnValue((Object)false);
        }
    }
}
