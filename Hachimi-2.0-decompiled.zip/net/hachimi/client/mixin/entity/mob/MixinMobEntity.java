package net.hachimi.client.mixin.entity.mob;

import net.hachimi.client.impl.event.entity.mob.PigAIEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1308;
import net.minecraft.class_1452;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1308.class})
public class MixinMobEntity {
    @Inject(method={"isAiDisabled"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookIsAiDisabled(CallbackInfoReturnable<Boolean> cir) {
        class_1308 mobEntity = (class_1308)this;
        if (mobEntity instanceof class_1452) {
            PigAIEvent pigAIEvent = new PigAIEvent((class_1452)mobEntity);
            EventBus.INSTANCE.dispatch(pigAIEvent);
            if (pigAIEvent.isCanceled()) {
                cir.cancel();
                cir.setReturnValue((Object)true);
            }
        }
    }
}
