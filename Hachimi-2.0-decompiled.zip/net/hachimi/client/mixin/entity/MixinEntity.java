package net.hachimi.client.mixin.entity;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.hachimi.client.impl.event.camera.EntityCameraPositionEvent;
import net.hachimi.client.impl.event.entity.EntityRotationVectorEvent;
import net.hachimi.client.impl.event.entity.LookDirectionEvent;
import net.hachimi.client.impl.event.entity.RenderFireEntityEvent;
import net.hachimi.client.impl.event.entity.SetBBEvent;
import net.hachimi.client.impl.event.entity.SlowMovementEvent;
import net.hachimi.client.impl.event.entity.UpdateVelocityEvent;
import net.hachimi.client.impl.event.entity.VelocityEvent;
import net.hachimi.client.impl.event.entity.VelocityMultiplierEvent;
import net.hachimi.client.impl.event.entity.decoration.TeamColorEvent;
import net.hachimi.client.impl.event.entity.player.PushEntityEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1297.class})
public abstract class MixinEntity
implements Globals {
    @Shadow
    public boolean field_6007;
    @Shadow
    private class_243 field_18276;
    @Shadow
    protected class_243 field_17046;
    @Shadow
    public float field_6017;

    @Shadow
    private static class_243 method_18795(class_243 movementInput, float speed, float yaw) {
        return null;
    }

    @Shadow
    public abstract class_238 method_5829();

    @Shadow
    public abstract class_243 method_18798();

    @Shadow
    public abstract void method_18799(class_243 var1);

    @Shadow
    public abstract boolean method_5624();

    @Inject(method={"getRotationVec"}, at={@At(value="RETURN")}, cancellable=true)
    public void hookGetCameraPosVec(float tickDelta, CallbackInfoReturnable<class_243> info) {
        EntityRotationVectorEvent event = new EntityRotationVectorEvent(tickDelta, (class_1297)this, (class_243)info.getReturnValue());
        EventBus.INSTANCE.dispatch(event);
        info.setReturnValue((Object)event.getPosition());
    }

    @Inject(method={"adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;"}, at={@At(value="HEAD")})
    public void hookMove(class_243 movement, CallbackInfoReturnable<class_243> cir) {
        if (this != MixinEntity.mc.field_1724) {
            // empty if block
        }
    }

    @Inject(method={"slowMovement"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookSlowMovement(class_2680 state, class_243 multiplier, CallbackInfo ci) {
        if (this != MixinEntity.mc.field_1724) {
            return;
        }
        SlowMovementEvent slowMovementEvent = new SlowMovementEvent(state);
        EventBus.INSTANCE.dispatch(slowMovementEvent);
        if (slowMovementEvent.isCanceled()) {
            ci.cancel();
            this.field_6017 = 0.0f;
            this.field_17046 = multiplier.method_1021((double)slowMovementEvent.getMultiplier());
        }
    }

    @WrapOperation(method={"getVelocityMultiplier"}, at={@At(value="INVOKE", target="Lnet/minecraft/block/BlockState;getBlock()Lnet/minecraft/block/Block;")})
    private class_2248 hookGetVelocityMultiplier(class_2680 instance, Operation<class_2248> original) {
        if (this != MixinEntity.mc.field_1724) {
            return (class_2248)original.call(new Object[]{instance});
        }
        VelocityMultiplierEvent velocityMultiplierEvent = new VelocityMultiplierEvent(instance);
        EventBus.INSTANCE.dispatch(velocityMultiplierEvent);
        if (velocityMultiplierEvent.isCanceled()) {
            return class_2246.field_10566;
        }
        return (class_2248)original.call(new Object[]{instance});
    }

    @Inject(method={"updateVelocity"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookUpdateVelocity(float speed, class_243 movementInput, CallbackInfo ci) {
        if (this == MixinEntity.mc.field_1724) {
            UpdateVelocityEvent updateVelocityEvent = new UpdateVelocityEvent(movementInput, speed, MixinEntity.mc.field_1724.method_36454(), MixinEntity.method_18795(movementInput, speed, MixinEntity.mc.field_1724.method_36454()));
            EventBus.INSTANCE.dispatch(updateVelocityEvent);
            if (updateVelocityEvent.isCanceled()) {
                ci.cancel();
                MixinEntity.mc.field_1724.method_18799(MixinEntity.mc.field_1724.method_18798().method_1019(updateVelocityEvent.getVelocity()));
            }
        }
    }

    @Inject(method={"pushAwayFrom"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookPushAwayFrom(class_1297 entity, CallbackInfo ci) {
        PushEntityEvent pushEntityEvent = new PushEntityEvent((class_1297)this, entity);
        EventBus.INSTANCE.dispatch(pushEntityEvent);
        if (pushEntityEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"getTeamColorValue"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetTeamColorValue(CallbackInfoReturnable<Integer> cir) {
        TeamColorEvent teamColorEvent = new TeamColorEvent((class_1297)this);
        EventBus.INSTANCE.dispatch(teamColorEvent);
        if (teamColorEvent.isCanceled()) {
            cir.setReturnValue((Object)teamColorEvent.getColor());
            cir.cancel();
        }
    }

    @Inject(method={"changeLookDirection"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookChangeLookDirection(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if (this == MixinEntity.mc.field_1724) {
            LookDirectionEvent lookDirectionEvent = new LookDirectionEvent((class_1297)this, cursorDeltaX, cursorDeltaY);
            EventBus.INSTANCE.dispatch(lookDirectionEvent);
            if (lookDirectionEvent.isCanceled()) {
                ci.cancel();
            }
        }
    }

    @Inject(method={"getCameraPosVec"}, at={@At(value="RETURN")}, cancellable=true)
    public void hookCameraPositionVec(float tickDelta, CallbackInfoReturnable<class_243> cir) {
        EntityCameraPositionEvent cameraPositionEvent = new EntityCameraPositionEvent((class_243)cir.getReturnValue(), (class_1297)this, tickDelta);
        EventBus.INSTANCE.dispatch(cameraPositionEvent);
        cir.setReturnValue((Object)cameraPositionEvent.getPosition());
    }

    @Inject(method={"setBoundingBox"}, at={@At(value="HEAD")})
    private void hookSetBoundingBox(class_238 boundingBox, CallbackInfo ci) {
        if (this == MixinEntity.mc.field_1724) {
            SetBBEvent setBBEvent = new SetBBEvent(boundingBox);
            EventBus.INSTANCE.dispatch(setBBEvent);
        }
    }

    @Inject(method={"doesRenderOnFire"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookDoesRenderOnFire(CallbackInfoReturnable<Boolean> cir) {
        RenderFireEntityEvent renderFireEntityEvent = new RenderFireEntityEvent();
        EventBus.INSTANCE.dispatch(renderFireEntityEvent);
        if (renderFireEntityEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)false);
        }
    }

    @Inject(method={"setVelocity(Lnet/minecraft/util/math/Vec3d;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookSetVelocity(class_243 velocity, CallbackInfo ci) {
        VelocityEvent velocityEvent = new VelocityEvent(velocity);
        EventBus.INSTANCE.dispatch(velocityEvent);
        if (velocityEvent.isCanceled()) {
            ci.cancel();
            this.field_18276 = velocityEvent.getVelocity();
        }
    }
}
