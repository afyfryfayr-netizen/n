package net.hachimi.client.mixin.entity.projectile;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.hachimi.client.impl.event.entity.FireworkTickEvent;
import net.hachimi.client.impl.event.entity.projectile.FireworkVelocityEvent;
import net.hachimi.client.impl.event.entity.projectile.RemoveFireworkEvent;
import net.hachimi.client.impl.module.movement.FakeFlyModule;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1671.class})
public class MixinFireworkRocketEntity
implements Globals {
    @Shadow
    private int field_7613;
    @Shadow
    private int field_7612;

    @Inject(method={"tick"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookTick(CallbackInfo ci) {
        FireworkTickEvent event = new FireworkTickEvent((class_1671)this);
        EventBus.INSTANCE.dispatch(event);
        if (event.isCanceled()) {
            ci.cancel();
        }
    }

    @Redirect(method={"tick"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;setVelocity(Lnet/minecraft/util/math/Vec3d;)V"))
    private void hookSetVelocity(class_1309 entity, class_243 velocity) {
        if (entity instanceof class_746) {
            FireworkVelocityEvent fireworkVelocityEvent = new FireworkVelocityEvent();
            EventBus.INSTANCE.dispatch(fireworkVelocityEvent);
            if (!fireworkVelocityEvent.isCanceled()) {
                entity.method_18799(velocity);
            }
        }
    }

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/projectile/FireworkRocketEntity;updateRotation()V", shift=At.Shift.AFTER)}, cancellable=true)
    private void hookTickPre(CallbackInfo ci) {
        if (this.field_7613 <= this.field_7612) {
            return;
        }
        class_1671 rocketEntity = (class_1671)this;
        RemoveFireworkEvent removeFireworkEvent = new RemoveFireworkEvent(rocketEntity);
        EventBus.INSTANCE.dispatch(removeFireworkEvent);
        if (removeFireworkEvent.isCanceled()) {
            ci.cancel();
            if (this.field_7613 == 0 && !rocketEntity.method_5701()) {
                MixinFireworkRocketEntity.mc.field_1687.method_43128(null, rocketEntity.method_23317(), rocketEntity.method_23318(), rocketEntity.method_23321(), class_3417.field_14702, class_3419.field_15256, 3.0f, 1.0f);
            }
            ++this.field_7613;
            if (MixinFireworkRocketEntity.mc.field_1687.field_9236 && this.field_7613 % 2 < 2) {
                MixinFireworkRocketEntity.mc.field_1687.method_8406((class_2394)class_2398.field_11248, rocketEntity.method_23317(), rocketEntity.method_23318(), rocketEntity.method_23321(), MixinFireworkRocketEntity.mc.field_1687.field_9229.method_43059() * 0.05, -rocketEntity.method_18798().field_1351 * 0.5, MixinFireworkRocketEntity.mc.field_1687.field_9229.method_43059() * 0.05);
            }
        }
    }

    @WrapOperation(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;")})
    private class_243 hookGetRotationVector(class_1309 instance, Operation<class_243> original) {
        FakeFlyModule lsmf = FakeFlyModule.getInstance();
        if (instance == MixinFireworkRocketEntity.mc.field_1724 && lsmf != null && lsmf.isEnabled() && lsmf.isGrimDurabilityMode() && lsmf.isControlEnabled()) {
            return instance.method_5631(lsmf.getModulePitch(), lsmf.getModuleYaw());
        }
        return (class_243)original.call(new Object[]{instance});
    }
}
