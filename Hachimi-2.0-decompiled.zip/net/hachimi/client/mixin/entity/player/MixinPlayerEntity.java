package net.hachimi.client.mixin.entity.player;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.hachimi.client.impl.event.entity.player.LedgeClipEvent;
import net.hachimi.client.impl.event.entity.player.PlayerJumpEvent;
import net.hachimi.client.impl.event.entity.player.PushFluidsEvent;
import net.hachimi.client.impl.event.entity.player.SprintResetEvent;
import net.hachimi.client.impl.event.entity.player.TravelEvent;
import net.hachimi.client.impl.event.network.ReachEvent;
import net.hachimi.client.impl.event.render.entity.ElytraTransformEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1657.class})
public abstract class MixinPlayerEntity
extends class_1309
implements Globals {
    protected MixinPlayerEntity(class_1299<? extends class_1309> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Shadow
    public abstract void method_6091(class_243 var1);

    @Inject(method={"travel"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookTravelHead(class_243 movementInput, CallbackInfo ci) {
        TravelEvent travelEvent = new TravelEvent(movementInput);
        EventBus.INSTANCE.dispatch(travelEvent);
        if (travelEvent.isCanceled()) {
            this.method_5784(class_1313.field_6308, this.method_18798());
            ci.cancel();
        }
    }

    @Inject(method={"isPushedByFluids"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookIsPushedByFluids(CallbackInfoReturnable<Boolean> cir) {
        if (this != MixinPlayerEntity.mc.field_1724) {
            return;
        }
        PushFluidsEvent pushFluidsEvent = new PushFluidsEvent();
        EventBus.INSTANCE.dispatch(pushFluidsEvent);
        if (pushFluidsEvent.isCanceled()) {
            cir.setReturnValue((Object)false);
            cir.cancel();
        }
    }

    @Inject(method={"jump"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookJumpPre(CallbackInfo ci) {
        if (this != MixinPlayerEntity.mc.field_1724) {
            return;
        }
        PlayerJumpEvent playerJumpEvent = new PlayerJumpEvent();
        playerJumpEvent.setStage(StageEvent.EventStage.PRE);
        EventBus.INSTANCE.dispatch(playerJumpEvent);
        if (playerJumpEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"jump"}, at={@At(value="RETURN")}, cancellable=true)
    private void hookJumpPost(CallbackInfo ci) {
        if (this != MixinPlayerEntity.mc.field_1724) {
            return;
        }
        PlayerJumpEvent playerJumpEvent = new PlayerJumpEvent();
        playerJumpEvent.setStage(StageEvent.EventStage.POST);
        EventBus.INSTANCE.dispatch(playerJumpEvent);
    }

    @WrapOperation(method={"attack"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/player/PlayerEntity;setVelocity(Lnet/minecraft/util/math/Vec3d;)V")})
    private void hookAttack(class_1657 playerEntity, class_243 movementInput, Operation<Void> original) {
        if (playerEntity instanceof class_746) {
            SprintResetEvent sprintResetEvent = new SprintResetEvent();
            EventBus.INSTANCE.dispatch(sprintResetEvent);
            if (!sprintResetEvent.isCanceled()) {
                original.call(new Object[]{playerEntity, MixinPlayerEntity.mc.field_1724.method_18798().method_18805(0.6, 1.0, 0.6)});
                return;
            }
            return;
        }
        original.call(new Object[]{playerEntity, movementInput});
    }

    @WrapOperation(method={"attack"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/player/PlayerEntity;setSprinting(Z)V")})
    private void hookAttack$1(class_1657 instance, boolean b, Operation<Void> original) {
        if (instance instanceof class_746) {
            SprintResetEvent sprintResetEvent = new SprintResetEvent();
            EventBus.INSTANCE.dispatch(sprintResetEvent);
            if (!sprintResetEvent.isCanceled()) {
                original.call(new Object[]{instance, false});
                return;
            }
            return;
        }
        original.call(new Object[]{instance, b});
    }

    @Inject(method={"clipAtLedge"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookClipAtLedge(CallbackInfoReturnable<Boolean> cir) {
        LedgeClipEvent ledgeClipEvent = new LedgeClipEvent();
        EventBus.INSTANCE.dispatch(ledgeClipEvent);
        if (ledgeClipEvent.isCanceled()) {
            cir.setReturnValue((Object)ledgeClipEvent.isClipped());
        }
    }

    @Redirect(method={"updatePose"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/player/PlayerEntity;isFallFlying()Z"))
    private boolean hookUpdatePose(class_1657 instance) {
        ElytraTransformEvent elytraTransformEvent = new ElytraTransformEvent((class_1297)instance);
        EventBus.INSTANCE.dispatch(elytraTransformEvent);
        if (elytraTransformEvent.isCanceled()) {
            return false;
        }
        return instance.method_6128();
    }

    @Inject(method={"getBlockInteractionRange"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetBlockInteractionRange(CallbackInfoReturnable<Double> cir) {
        ReachEvent.Block reachEvent = new ReachEvent.Block();
        EventBus.INSTANCE.dispatch(reachEvent);
        if (reachEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)reachEvent.getReach());
        }
    }

    @Inject(method={"getEntityInteractionRange"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetEntityInteractionRange(CallbackInfoReturnable<Double> cir) {
        ReachEvent.Entity reachEvent = new ReachEvent.Entity();
        EventBus.INSTANCE.dispatch(reachEvent);
        if (reachEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)reachEvent.getReach());
        }
    }
}
