package net.hachimi.client.mixin.entity.player;

import net.hachimi.client.impl.event.entity.player.SetStackEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1661.class})
public class MixinPlayerInventory {
    @Inject(method={"setStack"}, at={@At(value="HEAD")})
    private void hookSetStack(int slot, class_1799 stack, CallbackInfo ci) {
        SetStackEvent setStackEvent = new SetStackEvent(slot, stack);
        EventBus.INSTANCE.dispatch(setStackEvent);
    }
}
