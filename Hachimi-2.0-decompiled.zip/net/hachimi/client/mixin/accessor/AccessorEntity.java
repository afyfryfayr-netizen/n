package net.hachimi.client.mixin.accessor;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_1297.class})
public interface AccessorEntity {
    @Invoker(value="unsetRemoved")
    public void hookUnsetRemoved();

    @Invoker(value="setFlag")
    public void hookSetFlag(int var1, boolean var2);
}
