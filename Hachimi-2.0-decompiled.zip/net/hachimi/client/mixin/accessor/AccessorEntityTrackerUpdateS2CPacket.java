package net.hachimi.client.mixin.accessor;

import java.util.List;
import net.minecraft.class_2739;
import net.minecraft.class_2945;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_2739.class})
public interface AccessorEntityTrackerUpdateS2CPacket {
    @Accessor(value="trackedValues")
    @Mutable
    public void hookSetTrackedValues(List<class_2945.class_7834<?>> var1);
}
