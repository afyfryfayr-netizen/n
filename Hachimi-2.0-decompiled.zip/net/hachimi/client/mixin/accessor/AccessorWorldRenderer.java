package net.hachimi.client.mixin.accessor;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.util.Set;
import net.minecraft.class_2586;
import net.minecraft.class_3191;
import net.minecraft.class_4599;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_761.class})
public interface AccessorWorldRenderer {
    @Accessor(value="frustum")
    public class_4604 getFrustum();

    @Accessor(value="blockBreakingInfos")
    public Int2ObjectMap<class_3191> getBlockBreakingProgressions();

    @Accessor(value="bufferBuilders")
    public class_4599 hookGetBufferBuilders();

    @Accessor(value="noCullingBlockEntities")
    public Set<class_2586> hookGetNoCullingBlockEntities();
}
