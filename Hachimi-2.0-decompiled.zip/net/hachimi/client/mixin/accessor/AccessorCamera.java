package net.hachimi.client.mixin.accessor;

import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_4184.class})
public interface AccessorCamera {
    @Accessor(value="cameraY")
    public float getCameraY();

    @Accessor(value="lastCameraY")
    public float getLastCameraY();
}
