package net.hachimi.client.mixin.accessor;

import net.minecraft.class_4597;
import net.minecraft.class_4599;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_4599.class})
public interface AccessorBufferBuilderStorage {
    @Accessor(value="entityVertexConsumers")
    @Mutable
    public void hookSetEntityVertexConsumers(class_4597.class_4598 var1);
}
