package net.hachimi.client.mixin.accessor;

import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_1921.class_4687.class})
public interface AccessorMultiPhase {
    @Invoker(value="getPhases")
    public class_1921.class_4688 hookGetPhases();
}
