package net.hachimi.client.mixin.accessor;

import net.minecraft.class_1309;
import net.minecraft.class_1671;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_1671.class})
public interface AccessorFireworkRocketEntity {
    @Accessor(value="shooter")
    public class_1309 hookGetShooter();

    @Invoker(value="wasShotByEntity")
    public boolean hookWasShotByEntity();

    @Invoker(value="explodeAndRemove")
    public void hookExplodeAndRemove();
}
