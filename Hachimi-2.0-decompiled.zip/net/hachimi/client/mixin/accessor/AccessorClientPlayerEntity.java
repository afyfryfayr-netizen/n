package net.hachimi.client.mixin.accessor;

import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_746.class})
public interface AccessorClientPlayerEntity {
    @Accessor(value="lastX")
    public double getLastX();

    @Accessor(value="lastBaseY")
    public double getLastBaseY();

    @Accessor(value="lastZ")
    public double getLastZ();

    @Accessor(value="ticksSinceLastPositionPacketSent")
    public void hookSetTicksSinceLastPositionPacketSent(int var1);
}
