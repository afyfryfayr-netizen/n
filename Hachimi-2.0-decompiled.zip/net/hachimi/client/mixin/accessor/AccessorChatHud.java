package net.hachimi.client.mixin.accessor;

import net.minecraft.class_2561;
import net.minecraft.class_338;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_338.class})
public interface AccessorChatHud {
    @Invoker(value="addMessage")
    public void hookAddMessage(class_2561 var1, class_7469 var2, class_7591 var3);
}
