package net.hachimi.client.mixin.accessor;

import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_4668.class_5939.class})
public interface AccessorTextureBase {
    @Invoker(value="getId")
    public Optional<class_2960> hookGetId();
}
