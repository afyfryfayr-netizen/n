package net.hachimi.client.mixin.accessor;

import net.minecraft.class_342;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_408.class})
public interface AccessorChatScreen {
    @Accessor(value="chatField")
    public class_342 getChatField();
}
