package net.hachimi.client.mixin.accessor;

import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_765.class})
public interface AccessorLightmapTextureManager {
    @Accessor(value="dirty")
    public void setUpdateLightmap(boolean var1);
}
