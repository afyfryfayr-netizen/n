package net.hachimi.client.mixin.accessor;

import net.minecraft.class_8080;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_8080.class})
public interface AccessorLimbAnimator {
    @Accessor(value="pos")
    public void hookSetPos(float var1);

    @Accessor(value="speed")
    public void hookSetSpeed(float var1);
}
