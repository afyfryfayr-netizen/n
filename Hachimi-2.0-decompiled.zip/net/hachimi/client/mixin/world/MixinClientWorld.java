package net.hachimi.client.mixin.world;

import net.hachimi.client.impl.event.world.AddEntityEvent;
import net.hachimi.client.impl.event.world.PlaySoundEvent;
import net.hachimi.client.impl.event.world.RemoveEntityEvent;
import net.hachimi.client.impl.event.world.SetBlockStateEvent;
import net.hachimi.client.impl.event.world.SkyboxEvent;
import net.hachimi.client.impl.event.world.UnloadChunkBlocksEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5577;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_638.class})
public abstract class MixinClientWorld {
    @Shadow
    protected abstract class_5577<class_1297> method_31592();

    @Inject(method={"addEntity"}, at={@At(value="HEAD")})
    private void hookAddEntity(class_1297 entity, CallbackInfo ci) {
        AddEntityEvent addEntityEvent = new AddEntityEvent(entity);
        EventBus.INSTANCE.dispatch(addEntityEvent);
    }

    @Inject(method={"removeEntity"}, at={@At(value="HEAD")})
    private void hookRemoveEntity(int entityId, class_1297.class_5529 removalReason, CallbackInfo ci) {
        class_1297 entity = (class_1297)this.method_31592().method_31804(entityId);
        if (entity == null) {
            return;
        }
        RemoveEntityEvent removeEntityEvent = new RemoveEntityEvent(entity, removalReason);
        EventBus.INSTANCE.dispatch(removeEntityEvent);
    }

    @Inject(method={"getSkyColor"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetSkyColor(class_243 cameraPos, float tickDelta, CallbackInfoReturnable<class_243> cir) {
        SkyboxEvent.Sky skyboxEvent = new SkyboxEvent.Sky();
        EventBus.INSTANCE.dispatch(skyboxEvent);
        if (skyboxEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)skyboxEvent.getColorVec());
        }
    }

    @Inject(method={"getCloudsColor"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetCloudsColor(float tickDelta, CallbackInfoReturnable<class_243> cir) {
        SkyboxEvent.Cloud skyboxEvent = new SkyboxEvent.Cloud();
        EventBus.INSTANCE.dispatch(skyboxEvent);
        if (skyboxEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)skyboxEvent.getColorVec());
        }
    }

    @Inject(method={"playSound(DDDLnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FFZJ)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookPlaySound(double x, double y, double z, class_3414 event, class_3419 category, float volume, float pitch, boolean useDistance, long seed, CallbackInfo ci) {
        PlaySoundEvent playSoundEvent = new PlaySoundEvent(new class_243(x, y, z), event, category);
        EventBus.INSTANCE.dispatch(playSoundEvent);
        if (playSoundEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"setBlockState"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookSetBlockState(class_2338 pos, class_2680 state, int flags, int maxUpdateDepth, CallbackInfoReturnable<Boolean> cir) {
        SetBlockStateEvent setBlockStateEvent = new SetBlockStateEvent(flags, pos, state);
        EventBus.INSTANCE.dispatch(setBlockStateEvent);
        if (setBlockStateEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)false);
        }
    }

    @Inject(method={"unloadBlockEntities"}, at={@At(value="HEAD")})
    private void hookUnloadBlockEntities(class_2818 chunk, CallbackInfo ci) {
        UnloadChunkBlocksEvent unloadChunkBlocksEvent = new UnloadChunkBlocksEvent(chunk);
        EventBus.INSTANCE.dispatch(unloadChunkBlocksEvent);
    }
}
