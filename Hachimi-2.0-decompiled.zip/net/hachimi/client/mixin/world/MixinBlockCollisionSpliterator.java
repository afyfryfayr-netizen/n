package net.hachimi.client.mixin.world;

import net.hachimi.client.impl.event.world.BlockCollisionEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_5329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_5329.class})
public class MixinBlockCollisionSpliterator
implements Globals {
    @Redirect(method={"computeNext"}, at=@At(value="INVOKE", target="Lnet/minecraft/block/BlockState;getCollisionShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;"))
    private class_265 hookGetCollisionShape(class_2680 instance, class_1922 blockView, class_2338 blockPos, class_3726 shapeContext) {
        class_265 voxelShape = instance.method_26194(blockView, blockPos, shapeContext);
        if (blockView != MixinBlockCollisionSpliterator.mc.field_1687) {
            return voxelShape;
        }
        BlockCollisionEvent blockCollisionEvent = new BlockCollisionEvent(voxelShape, blockPos, instance);
        EventBus.INSTANCE.dispatch(blockCollisionEvent);
        if (blockCollisionEvent.isCanceled()) {
            return blockCollisionEvent.getVoxelShape();
        }
        return voxelShape;
    }
}
