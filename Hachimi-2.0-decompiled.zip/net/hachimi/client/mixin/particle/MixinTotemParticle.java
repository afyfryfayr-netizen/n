package net.hachimi.client.mixin.particle;

import java.awt.Color;
import net.hachimi.client.impl.event.particle.TotemParticleEvent;
import net.hachimi.client.mixin.particle.MixinParticle;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_734;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_734.class})
public abstract class MixinTotemParticle
extends MixinParticle {
    @Inject(method={"<init>"}, at={@At(value="TAIL")})
    private void hookInit(class_638 world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, class_4002 spriteProvider, CallbackInfo ci) {
        TotemParticleEvent totemParticleEvent = new TotemParticleEvent();
        EventBus.INSTANCE.dispatch(totemParticleEvent);
        if (totemParticleEvent.isCanceled()) {
            Color color = totemParticleEvent.getColor();
            this.method_3084((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f);
        }
    }
}
