package net.hachimi.client.mixin.particle;

import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.hachimi.client.impl.event.particle.BlockBreakParticleEvent;
import net.hachimi.client.impl.event.particle.ParticleEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2680;
import net.minecraft.class_5878;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_702.class})
public class MixinParticleManager {
    @Shadow
    @Final
    private Object2IntOpenHashMap<class_5878> field_29072;

    @Inject(method={"addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookAddParticle(class_2394 parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<class_703> cir) {
        ParticleEvent particleEvent = new ParticleEvent(parameters);
        EventBus.INSTANCE.dispatch(particleEvent);
        if (particleEvent.isCanceled()) {
            cir.setReturnValue(null);
            cir.cancel();
        }
    }

    @Inject(method={"addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookAddEmitter(class_1297 entity, class_2394 parameters, int maxAge, CallbackInfo ci) {
        ParticleEvent.Emitter particleEvent = new ParticleEvent.Emitter(parameters);
        EventBus.INSTANCE.dispatch(particleEvent);
        if (particleEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"addBlockBreakParticles"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAddBlockBreakParticles(class_2338 pos, class_2680 state, CallbackInfo ci) {
        BlockBreakParticleEvent blockBreakParticleEvent = new BlockBreakParticleEvent();
        EventBus.INSTANCE.dispatch(blockBreakParticleEvent);
        if (blockBreakParticleEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"addBlockBreakingParticles"}, at={@At(value="HEAD")}, cancellable=true)
    private void onAddBlockBreakingParticles(class_2338 pos, class_2350 direction, CallbackInfo ci) {
        BlockBreakParticleEvent blockBreakParticleEvent = new BlockBreakParticleEvent();
        EventBus.INSTANCE.dispatch(blockBreakParticleEvent);
        if (blockBreakParticleEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
