package net.hachimi.client.mixin.font;

import net.hachimi.client.impl.module.client.FontModule;
import net.minecraft.class_379;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_379.class})
public interface MixinGlyph {
    @Inject(method={"getShadowOffset"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetShadowOffset(CallbackInfoReturnable<Float> cir) {
        cir.cancel();
        cir.setReturnValue((Object)Float.valueOf(FontModule.getInstance().getVanillaShadow()));
    }
}
