package net.hachimi.client.mixin.text;

import net.hachimi.client.util.Globals;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets={"net.minecraft.text.PlainTextContent$Literal"})
public abstract class MixinPlainTextContent
implements Globals {
    @Inject(method={"string"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetString(CallbackInfoReturnable<String> cir) {
        if (mc == null || MixinPlainTextContent.mc.field_1724 == null) {
            cir.setReturnValue((Object)"");
        }
    }
}
