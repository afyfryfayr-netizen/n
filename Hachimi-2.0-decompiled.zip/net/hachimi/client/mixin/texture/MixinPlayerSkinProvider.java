package net.hachimi.client.mixin.texture;

import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import net.minecraft.class_1071;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={class_1071.class_8687.class})
public class MixinPlayerSkinProvider {
    @Shadow
    @Final
    private MinecraftProfileTexture.Type field_45641;
}
