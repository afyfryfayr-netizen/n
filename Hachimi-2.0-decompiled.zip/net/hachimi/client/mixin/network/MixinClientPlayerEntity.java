package net.hachimi.client.mixin.network;

import net.hachimi.client.impl.event.entity.SwingEvent;
import net.hachimi.client.impl.event.entity.player.PlayerMoveEvent;
import net.hachimi.client.impl.event.network.DismountVehicleEvent;
import net.hachimi.client.impl.event.network.EncodeYawEvent;
import net.hachimi.client.impl.event.network.MountJumpStrengthEvent;
import net.hachimi.client.impl.event.network.MovementPacketsEvent;
import net.hachimi.client.impl.event.network.MovementSlowdownEvent;
import net.hachimi.client.impl.event.network.PlayerTickEvent;
import net.hachimi.client.impl.event.network.PlayerUpdateEvent;
import net.hachimi.client.impl.event.network.PushOutOfBlocksEvent;
import net.hachimi.client.impl.event.network.SetCurrentHandEvent;
import net.hachimi.client.impl.event.network.TickMovementEvent;
import net.hachimi.client.impl.imixin.IClientPlayerEntity;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_634;
import net.minecraft.class_742;
import net.minecraft.class_744;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_746.class}, priority=1500)
public abstract class MixinClientPlayerEntity
extends class_742
implements Globals,
IClientPlayerEntity {
    @Shadow
    @Final
    public class_634 field_3944;
    @Shadow
    public double field_3926;
    @Shadow
    public double field_3940;
    @Shadow
    public double field_3924;
    @Shadow
    public class_744 field_3913;
    @Shadow
    @Final
    protected class_310 field_3937;
    @Shadow
    private boolean field_3936;
    @Shadow
    private float field_3941;
    @Shadow
    private float field_3925;
    @Shadow
    private boolean field_3920;
    @Shadow
    private int field_3923;
    @Shadow
    private boolean field_3927;
    @Unique
    private boolean ticking;

    public MixinClientPlayerEntity() {
        super(class_310.method_1551().field_1687, class_310.method_1551().field_1724.method_7334());
    }

    @Shadow
    protected abstract void method_46742();

    @Shadow
    public abstract boolean method_5715();

    @Shadow
    protected abstract boolean method_3134();

    @Shadow
    protected abstract void method_3148(float var1, float var2);

    @Shadow
    public abstract void method_5773();

    @Shadow
    protected abstract void method_3136();

    @Inject(method={"sendMovementPackets"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookSendMovementPackets(CallbackInfo ci) {
        PlayerUpdateEvent playerUpdateEvent = new PlayerUpdateEvent();
        playerUpdateEvent.setStage(StageEvent.EventStage.PRE);
        EventBus.INSTANCE.dispatch(playerUpdateEvent);
        MovementPacketsEvent movementPacketsEvent = new MovementPacketsEvent(MixinClientPlayerEntity.mc.field_1724.method_23317(), MixinClientPlayerEntity.mc.field_1724.method_23318(), MixinClientPlayerEntity.mc.field_1724.method_23321(), MixinClientPlayerEntity.mc.field_1724.method_36454(), MixinClientPlayerEntity.mc.field_1724.method_36455(), MixinClientPlayerEntity.mc.field_1724.method_24828());
        EventBus.INSTANCE.dispatch(movementPacketsEvent);
        double x = movementPacketsEvent.getX();
        double y = movementPacketsEvent.getY();
        double z = movementPacketsEvent.getZ();
        float yaw = movementPacketsEvent.getYaw();
        float pitch = movementPacketsEvent.getPitch();
        boolean ground = movementPacketsEvent.getOnGround();
        EncodeYawEvent encodeYawEvent = new EncodeYawEvent();
        EventBus.INSTANCE.dispatch(encodeYawEvent);
        if (encodeYawEvent.isCanceled()) {
            yaw += 3.6E7f;
        }
        if (movementPacketsEvent.isCanceled() || encodeYawEvent.isCanceled()) {
            ci.cancel();
            this.method_46742();
            boolean bl = this.method_5715();
            if (bl != this.field_3936) {
                this.field_3944.method_52787((class_2596)new class_2848((class_1297)this, bl ? class_2848.class_2849.field_12979 : class_2848.class_2849.field_12984));
                this.field_3936 = bl;
            }
            if (this.method_3134()) {
                boolean bl3;
                double d = x - this.field_3926;
                double e = y - this.field_3940;
                double f = z - this.field_3924;
                double g = yaw - this.field_3941;
                double h = pitch - this.field_3925;
                ++this.field_3923;
                boolean bl2 = class_3532.method_41190((double)d, (double)e, (double)f) > class_3532.method_33723((double)2.0E-4) || this.field_3923 >= 20;
                boolean bl4 = bl3 = g != 0.0 || h != 0.0;
                if (this.method_5765()) {
                    class_243 vec3d = this.method_18798();
                    this.field_3944.method_52787((class_2596)new class_2828.class_2830(vec3d.field_1352, -999.0, vec3d.field_1350, this.method_36454(), this.method_36455(), ground));
                    bl2 = false;
                } else if (bl2 && bl3) {
                    this.field_3944.method_52787((class_2596)new class_2828.class_2830(x, y, z, yaw, pitch, ground));
                } else if (bl2) {
                    this.field_3944.method_52787((class_2596)new class_2828.class_2829(x, y, z, ground));
                } else if (bl3) {
                    this.field_3944.method_52787((class_2596)new class_2828.class_2831(yaw, pitch, ground));
                } else if (this.field_3920 != this.method_24828()) {
                    this.field_3944.method_52787((class_2596)new class_2828.class_5911(ground));
                }
                if (bl2) {
                    this.field_3926 = x;
                    this.field_3940 = y;
                    this.field_3924 = z;
                    this.field_3923 = 0;
                }
                if (bl3) {
                    this.field_3941 = yaw;
                    this.field_3925 = pitch;
                }
                this.field_3920 = ground;
                this.field_3927 = (Boolean)this.field_3937.field_1690.method_42423().method_41753();
            }
        }
        playerUpdateEvent.setStage(StageEvent.EventStage.POST);
        EventBus.INSTANCE.dispatch(playerUpdateEvent);
    }

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V", shift=At.Shift.BEFORE, ordinal=0)})
    private void hookTickPre(CallbackInfo ci) {
        EventBus.INSTANCE.dispatch(new PlayerTickEvent());
    }

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;sendMovementPackets()V", ordinal=0, shift=At.Shift.AFTER)})
    private void hookTick(CallbackInfo ci) {
        if (this.ticking) {
            return;
        }
        TickMovementEvent tickMovementEvent = new TickMovementEvent();
        EventBus.INSTANCE.dispatch(tickMovementEvent);
        if (tickMovementEvent.isCanceled()) {
            for (int i = 0; i < tickMovementEvent.getIterations(); ++i) {
                this.ticking = true;
                this.method_5773();
                this.ticking = false;
                this.method_3136();
            }
        }
    }

    @Inject(method={"tickMovement"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/input/Input;tick(ZF)V", shift=At.Shift.AFTER)})
    private void hookTickMovementPost(CallbackInfo ci) {
        EventBus.INSTANCE.dispatch(new MovementSlowdownEvent(this.field_3913));
    }

    @Inject(method={"move"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookMove(class_1313 movementType, class_243 movement, CallbackInfo ci) {
        PlayerMoveEvent playerMoveEvent = new PlayerMoveEvent(movementType, movement);
        EventBus.INSTANCE.dispatch(playerMoveEvent);
        if (playerMoveEvent.isCanceled()) {
            ci.cancel();
            double d = this.method_23317();
            double e = this.method_23321();
            super.method_5784(movementType, playerMoveEvent.getMovement());
            this.method_3148((float)(this.method_23317() - d), (float)(this.method_23321() - e));
        }
    }

    @Inject(method={"pushOutOfBlocks"}, at={@At(value="HEAD")}, cancellable=true)
    private void onPushOutOfBlocks(double x, double z, CallbackInfo ci) {
        PushOutOfBlocksEvent pushOutOfBlocksEvent = new PushOutOfBlocksEvent();
        EventBus.INSTANCE.dispatch(pushOutOfBlocksEvent);
        if (pushOutOfBlocksEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"setCurrentHand"}, at={@At(value="HEAD")})
    private void hookSetCurrentHand(class_1268 hand, CallbackInfo ci) {
        EventBus.INSTANCE.dispatch(new SetCurrentHandEvent(hand));
    }

    @Inject(method={"getMountJumpStrength"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetMountJumpStrength(CallbackInfoReturnable<Float> cir) {
        MountJumpStrengthEvent mountJumpStrengthEvent = new MountJumpStrengthEvent();
        EventBus.INSTANCE.dispatch(mountJumpStrengthEvent);
        if (mountJumpStrengthEvent.isCanceled()) {
            cir.setReturnValue((Object)Float.valueOf(mountJumpStrengthEvent.getJumpStrength()));
        }
    }

    @Inject(method={"swingHand"}, at={@At(value="RETURN")})
    private void hookSwingHand(class_1268 hand, CallbackInfo ci) {
        EventBus.INSTANCE.dispatch(new SwingEvent(hand));
    }

    @Inject(method={"dismountVehicle"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookDismountVehicle(CallbackInfo ci) {
        DismountVehicleEvent dismountVehicleEvent = new DismountVehicleEvent();
        EventBus.INSTANCE.dispatch(dismountVehicleEvent);
        if (dismountVehicleEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Override
    public float getLastSpoofedYaw() {
        return this.field_3941;
    }

    @Override
    public float getLastSpoofedPitch() {
        return this.field_3925;
    }
}
