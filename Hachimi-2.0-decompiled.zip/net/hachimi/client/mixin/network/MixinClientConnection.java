package net.hachimi.client.mixin.network;

import io.netty.channel.ChannelHandlerContext;
import net.hachimi.client.impl.event.network.DecodePacketEvent;
import net.hachimi.client.impl.event.network.DisconnectEvent;
import net.hachimi.client.impl.event.network.PacketEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_7648;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_2535.class})
public class MixinClientConnection {
    @Shadow
    @Nullable
    private volatile class_2547 field_11652;
    @Shadow
    @Final
    private static Logger field_11642;

    @Inject(method={"exceptionCaught"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookExceptionCaught(ChannelHandlerContext context, Throwable ex, CallbackInfo ci) {
        DecodePacketEvent decodePacketEvent = new DecodePacketEvent();
        EventBus.INSTANCE.dispatch(decodePacketEvent);
        if (decodePacketEvent.isCanceled()) {
            field_11642.error("Exception caught on network thread:", ex);
            ci.cancel();
        }
    }

    @Inject(method={"sendImmediately"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookSendImmediately(class_2596<?> packet, @Nullable class_7648 callbacks, boolean flush, CallbackInfo ci) {
        PacketEvent.Outbound packetOutboundEvent = new PacketEvent.Outbound(packet);
        EventBus.INSTANCE.dispatch(packetOutboundEvent);
        if (packetOutboundEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"sendImmediately"}, at={@At(value="TAIL")}, cancellable=true)
    private void hookSendImmediately$2(class_2596<?> packet, @Nullable class_7648 callbacks, boolean flush, CallbackInfo ci) {
        PacketEvent.OutboundPost packetOutboundEvent = new PacketEvent.OutboundPost(packet);
        EventBus.INSTANCE.dispatch(packetOutboundEvent);
        if (packetOutboundEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookChannelRead0(ChannelHandlerContext channelHandlerContext, class_2596<?> packet, CallbackInfo ci) {
        class_2547 ownedPacketListener = this.field_11652;
        if (packet != null && ownedPacketListener != null && ownedPacketListener.method_52413(packet)) {
            PacketEvent.Inbound packetInboundEvent = new PacketEvent.Inbound(this.field_11652, packet);
            EventBus.INSTANCE.dispatch(packetInboundEvent);
            if (packetInboundEvent.isCanceled()) {
                ci.cancel();
            }
        }
    }

    @Inject(method={"disconnect"}, at={@At(value="HEAD")})
    private void hookDisconnect(class_2561 disconnectReason, CallbackInfo ci) {
        DisconnectEvent disconnectEvent = new DisconnectEvent();
        EventBus.INSTANCE.dispatch(disconnectEvent);
    }
}
