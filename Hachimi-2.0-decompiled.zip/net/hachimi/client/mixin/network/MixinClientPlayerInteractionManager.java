package net.hachimi.client.mixin.network;

import net.hachimi.client.impl.event.network.AttackBlockEvent;
import net.hachimi.client.impl.event.network.BreakBlockEvent;
import net.hachimi.client.impl.event.network.InteractBlockEvent;
import net.hachimi.client.impl.event.network.InteractBorderEvent;
import net.hachimi.client.impl.event.network.ItemDesyncEvent;
import net.hachimi.client.impl.event.network.PacketSneakingEvent;
import net.hachimi.client.impl.event.network.StrafeFixEvent;
import net.hachimi.client.impl.event.network.SyncSelectedSlotEvent;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2784;
import net.minecraft.class_2886;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_7204;
import net.minecraft.class_746;
import org.apache.commons.lang3.mutable.MutableObject;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_636.class})
public abstract class MixinClientPlayerInteractionManager
implements Globals {
    @Shadow
    private class_1934 field_3719;

    @Shadow
    protected abstract void method_2911();

    @Shadow
    protected abstract void method_41931(class_638 var1, class_7204 var2);

    @Inject(method={"attackBlock"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookAttackBlock(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        class_2680 state = MixinClientPlayerInteractionManager.mc.field_1687.method_8320(pos);
        AttackBlockEvent attackBlockEvent = new AttackBlockEvent(pos, state, direction);
        EventBus.INSTANCE.dispatch(attackBlockEvent);
        if (attackBlockEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)false);
        }
    }

    @Inject(method={"interactBlock"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookInteractBlock(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        InteractBlockEvent interactBlockEvent = new InteractBlockEvent(player, hand, hitResult);
        EventBus.INSTANCE.dispatch(interactBlockEvent);
        if (interactBlockEvent.isCanceled()) {
            cir.setReturnValue((Object)class_1269.field_5812);
            cir.cancel();
        }
    }

    @Redirect(method={"interactBlock"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/border/WorldBorder;contains(Lnet/minecraft/util/math/BlockPos;)Z"))
    private boolean hookInteractBlock$2(class_2784 worldBorder, class_2338 pos) {
        InteractBorderEvent interactBorderEvent = new InteractBorderEvent();
        EventBus.INSTANCE.dispatch(interactBorderEvent);
        if (interactBorderEvent.isCanceled()) {
            return true;
        }
        return worldBorder.method_11952(pos);
    }

    @Inject(method={"breakBlock"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookBreakBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        BreakBlockEvent breakBlockEvent = new BreakBlockEvent(pos);
        EventBus.INSTANCE.dispatch(breakBlockEvent);
        if (breakBlockEvent.isCanceled()) {
            cir.setReturnValue((Object)false);
            cir.cancel();
        }
    }

    @Inject(method={"interactItem"}, at={@At(value="HEAD")}, cancellable=true)
    public void hookInteractItem(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        StrafeFixEvent strafeFixEvent = new StrafeFixEvent();
        EventBus.INSTANCE.dispatch(strafeFixEvent);
        if (strafeFixEvent.isCanceled()) {
            cir.cancel();
            if (this.field_3719 == class_1934.field_9219) {
                cir.setReturnValue((Object)class_1269.field_5811);
                return;
            }
            this.method_2911();
            MutableObject mutableObject = new MutableObject();
            this.method_41931(MixinClientPlayerInteractionManager.mc.field_1687, sequence -> {
                class_2886 playerInteractItemC2SPacket = new class_2886(hand, sequence, Managers.ROTATION.isRotating() ? Managers.ROTATION.getRotationYaw() : player.method_36454(), Managers.ROTATION.isRotating() ? Managers.ROTATION.getRotationPitch() : player.method_36455());
                class_1799 itemStack = player.method_5998(hand);
                if (player.method_7357().method_7904(itemStack.method_7909())) {
                    mutableObject.setValue((Object)class_1269.field_5811);
                    return playerInteractItemC2SPacket;
                }
                class_1271 typedActionResult = itemStack.method_7913((class_1937)MixinClientPlayerInteractionManager.mc.field_1687, player, hand);
                class_1799 itemStack2 = (class_1799)typedActionResult.method_5466();
                if (itemStack2 != itemStack) {
                    player.method_6122(hand, itemStack2);
                }
                mutableObject.setValue((Object)typedActionResult.method_5467());
                return playerInteractItemC2SPacket;
            });
            cir.setReturnValue((Object)((class_1269)mutableObject.getValue()));
        }
    }

    @Redirect(method={"interactBlockInternal"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;shouldCancelInteraction()Z"))
    private boolean hookRedirectInteractBlockInternal$shouldCancelInteraction(class_746 player) {
        PacketSneakingEvent packetSneakingEvent = new PacketSneakingEvent();
        EventBus.INSTANCE.dispatch(packetSneakingEvent);
        return player.method_5715() || packetSneakingEvent.isCanceled();
    }

    @Redirect(method={"interactBlockInternal"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getStackInHand(Lnet/minecraft/util/Hand;)Lnet/minecraft/item/ItemStack;"))
    private class_1799 hookRedirectInteractBlockInternal$getStackInHand(class_746 entity, class_1268 hand) {
        if (hand.equals((Object)class_1268.field_5810)) {
            return entity.method_5998(hand);
        }
        ItemDesyncEvent itemDesyncEvent = new ItemDesyncEvent();
        EventBus.INSTANCE.dispatch(itemDesyncEvent);
        return itemDesyncEvent.isCanceled() ? itemDesyncEvent.getServerItem() : entity.method_5998(class_1268.field_5808);
    }

    @Redirect(method={"interactBlockInternal"}, at=@At(value="INVOKE", target="Lnet/minecraft/item/ItemStack;isEmpty()Z", ordinal=0))
    private boolean hookRedirectInteractBlockInternal$getMainHandStack(class_1799 instance) {
        ItemDesyncEvent itemDesyncEvent = new ItemDesyncEvent();
        EventBus.INSTANCE.dispatch(itemDesyncEvent);
        return itemDesyncEvent.isCanceled() ? itemDesyncEvent.getServerItem().method_7960() : instance.method_7960();
    }

    @Inject(method={"syncSelectedSlot"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookSyncSelectedSlot(CallbackInfo ci) {
        SyncSelectedSlotEvent syncSelectedSlotEvent = new SyncSelectedSlotEvent();
        EventBus.INSTANCE.dispatch(syncSelectedSlotEvent);
        if (syncSelectedSlotEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
