package net.hachimi.client.mixin.network.server;

import net.hachimi.client.impl.event.network.server.FinishMiningServerEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2338;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_3225.class})
public class MixinServerPlayerInteractionManager {
    @Inject(method={"finishMining"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookFinishMining(class_2338 pos, int sequence, String reason, CallbackInfo ci) {
        FinishMiningServerEvent finishMiningServerEvent = new FinishMiningServerEvent();
        EventBus.INSTANCE.dispatch(finishMiningServerEvent);
        if (finishMiningServerEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
