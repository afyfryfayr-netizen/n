package net.hachimi.client.mixin.network;

import net.hachimi.client.impl.event.world.LoadWorldEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_3222.class})
public class MixinServerPlayerEntity {
    @Inject(method={"worldChanged"}, at={@At(value="HEAD")})
    private void hookMoveToWorld(class_3218 origin, CallbackInfo ci) {
        LoadWorldEvent loadWorldEvent = new LoadWorldEvent();
        EventBus.INSTANCE.dispatch(loadWorldEvent);
    }
}
