package net.hachimi.client.mixin.render;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import java.util.SequencedMap;
import net.hachimi.client.api.render.layers.RenderLayersClient;
import net.minecraft.class_1088;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_4618;
import net.minecraft.class_4722;
import net.minecraft.class_750;
import net.minecraft.class_9799;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_4599.class})
public class MixinBufferBuilderStorage {
    @Shadow
    @Final
    private class_750 field_20956;
    @Final
    @Shadow
    @Mutable
    private class_4597.class_4598 field_46901;
    @Final
    @Shadow
    @Mutable
    private class_4618 field_20961;
    @Mutable
    @Shadow
    @Final
    private class_4597.class_4598 field_20959;

    @Inject(method={"<init>"}, at={@At(value="TAIL")})
    private void hookInit(int maxBlockBuildersPoolSize, CallbackInfo ci) {
        SequencedMap sequencedMap = (SequencedMap)class_156.method_654((Object)new Object2ObjectLinkedOpenHashMap(), map -> {
            map.put((Object)class_4722.method_24073(), (Object)this.field_20956.method_3154(class_1921.method_23577()));
            map.put((Object)class_4722.method_24074(), (Object)this.field_20956.method_3154(class_1921.method_23581()));
            map.put((Object)class_4722.method_24059(), (Object)this.field_20956.method_3154(class_1921.method_23579()));
            map.put((Object)class_4722.method_24076(), (Object)this.field_20956.method_3154(class_1921.method_23583()));
            map.put((Object)class_4722.method_24067(), (Object)new class_9799(class_4722.method_24069().method_22722()));
            map.put((Object)class_4722.method_24069(), (Object)new class_9799(class_4722.method_24069().method_22722()));
            map.put((Object)class_4722.method_24070(), (Object)new class_9799(class_4722.method_24070().method_22722()));
            map.put((Object)class_4722.method_24071(), (Object)new class_9799(class_4722.method_45783().method_22722()));
            map.put((Object)class_4722.method_45783(), (Object)new class_9799(class_4722.method_45783().method_22722()));
            map.put((Object)class_4722.method_24072(), (Object)new class_9799(786432));
            map.put((Object)class_1921.method_27949(), (Object)new class_9799(class_1921.method_27949().method_22722()));
            map.put((Object)class_1921.method_23590(), (Object)new class_9799(class_1921.method_27949().method_22722()));
            map.put((Object)class_1921.method_30676(), (Object)new class_9799(class_1921.method_30676().method_22722()));
            map.put((Object)class_1921.method_23591(), (Object)new class_9799(class_1921.method_23591().method_22722()));
            map.put((Object)class_1921.method_29707(), (Object)new class_9799(class_1921.method_29707().method_22722()));
            map.put((Object)class_1921.method_23589(), (Object)new class_9799(class_1921.method_23589().method_22722()));
            class_1088.field_21772.forEach(renderLayer -> map.put(renderLayer, (Object)new class_9799(renderLayer.method_22722())));
            map.put((Object)RenderLayersClient.GLINT, (Object)new class_9799(RenderLayersClient.GLINT.method_22722()));
        });
        this.field_20959 = class_4597.method_22991((class_9799)new class_9799(1536));
        this.field_46901 = class_4597.method_22992((SequencedMap)sequencedMap, (class_9799)new class_9799(786432));
        this.field_20961 = new class_4618(this.field_46901);
    }
}
