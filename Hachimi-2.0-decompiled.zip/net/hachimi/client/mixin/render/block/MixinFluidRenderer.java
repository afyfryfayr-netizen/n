package net.hachimi.client.mixin.render.block;

import net.minecraft.class_775;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_775.class}, priority=0x7FFFFFFF)
public class MixinFluidRenderer {
    @ModifyVariable(method={"render"}, at=@At(value="CONSTANT", args={"intValue=16"}, ordinal=0, shift=At.Shift.BEFORE), ordinal=0)
    private int hookI(int i) {
        return i;
    }
}
