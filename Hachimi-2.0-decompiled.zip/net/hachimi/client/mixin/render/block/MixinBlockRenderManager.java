package net.hachimi.client.mixin.render.block;

import net.hachimi.client.impl.event.render.block.RenderBlockEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_776.class})
public class MixinBlockRenderManager {
    @Inject(method={"renderBlock"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookRenderBlock(class_2680 state, class_2338 pos, class_1920 world, class_4587 matrices, class_4588 vertexConsumer, boolean cull, class_5819 random, CallbackInfo ci) {
        RenderBlockEvent renderBlockEvent = new RenderBlockEvent(state, pos);
        EventBus.INSTANCE.dispatch(renderBlockEvent);
        if (renderBlockEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
