package net.hachimi.client.mixin.render.block.entity;

import net.hachimi.client.impl.event.render.block.entity.RenderBlockEntityEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2586;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_824.class})
public class MixinBlockEntityRenderDispatcher {
    @Inject(method={"render(Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V"}, at={@At(value="HEAD")})
    private void hookRender(class_2586 blockEntity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        RenderBlockEntityEvent renderBlockEntityEvent = new RenderBlockEntityEvent(blockEntity);
        EventBus.INSTANCE.dispatch(renderBlockEntityEvent);
    }
}
