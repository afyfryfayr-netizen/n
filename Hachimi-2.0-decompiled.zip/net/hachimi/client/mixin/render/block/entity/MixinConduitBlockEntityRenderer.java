package net.hachimi.client.mixin.render.block.entity;

import java.util.function.Function;
import net.hachimi.client.api.render.layers.RenderLayersClient;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_829;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_829.class})
public class MixinConduitBlockEntityRenderer {
    @Redirect(method={"render(Lnet/minecraft/block/entity/ConduitBlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/SpriteIdentifier;getVertexConsumer(Lnet/minecraft/client/render/VertexConsumerProvider;Ljava/util/function/Function;)Lnet/minecraft/client/render/VertexConsumer;", ordinal=0))
    private class_4588 hookRender(class_4730 instance, class_4597 vertexConsumers, Function<class_2960, class_1921> layerFactory) {
        return instance.method_24145(vertexConsumers, RenderLayersClient.ENTITY_SOLID);
    }

    @Redirect(method={"render(Lnet/minecraft/block/entity/ConduitBlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/SpriteIdentifier;getVertexConsumer(Lnet/minecraft/client/render/VertexConsumerProvider;Ljava/util/function/Function;)Lnet/minecraft/client/render/VertexConsumer;", ordinal=1))
    private class_4588 hookRender$1(class_4730 instance, class_4597 vertexConsumers, Function<class_2960, class_1921> layerFactory) {
        return instance.method_24145(vertexConsumers, RenderLayersClient.ENTITY_CUTOUT_NO_CULL);
    }

    @Redirect(method={"render(Lnet/minecraft/block/entity/ConduitBlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/SpriteIdentifier;getVertexConsumer(Lnet/minecraft/client/render/VertexConsumerProvider;Ljava/util/function/Function;)Lnet/minecraft/client/render/VertexConsumer;", ordinal=2))
    private class_4588 hookRender$2(class_4730 instance, class_4597 vertexConsumers, Function<class_2960, class_1921> layerFactory) {
        return instance.method_24145(vertexConsumers, RenderLayersClient.ENTITY_CUTOUT_NO_CULL);
    }

    @Redirect(method={"render(Lnet/minecraft/block/entity/ConduitBlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/SpriteIdentifier;getVertexConsumer(Lnet/minecraft/client/render/VertexConsumerProvider;Ljava/util/function/Function;)Lnet/minecraft/client/render/VertexConsumer;", ordinal=3))
    private class_4588 hookRender$3(class_4730 instance, class_4597 vertexConsumers, Function<class_2960, class_1921> layerFactory) {
        return instance.method_24145(vertexConsumers, RenderLayersClient.ENTITY_CUTOUT_NO_CULL);
    }
}
