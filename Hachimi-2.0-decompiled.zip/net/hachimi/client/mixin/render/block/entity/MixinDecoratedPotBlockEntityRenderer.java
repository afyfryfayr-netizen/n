package net.hachimi.client.mixin.render.block.entity;

import java.util.function.Function;
import net.hachimi.client.api.render.layers.RenderLayersClient;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_8188;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_8188.class})
public class MixinDecoratedPotBlockEntityRenderer {
    @Redirect(method={"render(Lnet/minecraft/block/entity/DecoratedPotBlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/SpriteIdentifier;getVertexConsumer(Lnet/minecraft/client/render/VertexConsumerProvider;Ljava/util/function/Function;)Lnet/minecraft/client/render/VertexConsumer;"))
    private class_4588 hookRender(class_4730 instance, class_4597 vertexConsumers, Function<class_2960, class_1921> layerFactory) {
        return instance.method_24145(vertexConsumers, RenderLayersClient.ENTITY_SOLID);
    }

    @Redirect(method={"renderDecoratedSide"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/SpriteIdentifier;getVertexConsumer(Lnet/minecraft/client/render/VertexConsumerProvider;Ljava/util/function/Function;)Lnet/minecraft/client/render/VertexConsumer;"))
    private class_4588 hookRenderDecoratedSide(class_4730 instance, class_4597 vertexConsumers, Function<class_2960, class_1921> layerFactory) {
        return instance.method_24145(vertexConsumers, RenderLayersClient.ENTITY_SOLID);
    }
}
