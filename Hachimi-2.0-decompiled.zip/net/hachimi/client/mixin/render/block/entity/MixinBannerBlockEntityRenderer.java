package net.hachimi.client.mixin.render.block.entity;

import java.util.function.Function;
import net.hachimi.client.api.render.layers.RenderLayersClient;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_823;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_823.class})
public class MixinBannerBlockEntityRenderer {
    @Redirect(method={"renderCanvas(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/model/ModelPart;Lnet/minecraft/client/util/SpriteIdentifier;ZLnet/minecraft/util/DyeColor;Lnet/minecraft/component/type/BannerPatternsComponent;Z)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/util/SpriteIdentifier;getVertexConsumer(Lnet/minecraft/client/render/VertexConsumerProvider;Ljava/util/function/Function;Z)Lnet/minecraft/client/render/VertexConsumer;"))
    private static class_4588 hookRenderCanvas(class_4730 instance, class_4597 vertexConsumers, Function<class_2960, class_1921> layerFactory, boolean bl) {
        return instance.method_24145(vertexConsumers, RenderLayersClient.ENTITY_SOLID);
    }
}
