package net.hachimi.client.mixin.render;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.blaze3d.systems.RenderSystem;
import net.hachimi.client.impl.event.PerspectiveEvent;
import net.hachimi.client.impl.event.render.RenderEntityInWorldEvent;
import net.hachimi.client.impl.event.render.RenderShaderEvent;
import net.hachimi.client.impl.event.render.RenderWorldBorderEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1297;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_761.class})
public class MixinWorldRenderer
implements Globals {
    @Inject(method={"render"}, at={@At(value="RETURN")})
    private void hookRender(class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightmapTextureManager, Matrix4f matrix4f, Matrix4f matrix4f2, CallbackInfo ci) {
        class_4587 matrixStack = new class_4587();
        RenderSystem.getModelViewStack().pushMatrix().mul((Matrix4fc)matrixStack.method_23760().method_23761());
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        RenderSystem.applyModelViewMatrix();
        RenderWorldEvent renderWorldEvent = new RenderWorldEvent(matrixStack, tickCounter.method_60637(true));
        EventBus.INSTANCE.dispatch(renderWorldEvent);
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();
    }

    @Inject(method={"render"}, at={@At(value="RETURN")})
    private void hookRender$1(class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightmapTextureManager, Matrix4f matrix4f, Matrix4f matrix4f2, CallbackInfo ci) {
        class_4587 matrixStack = new class_4587();
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        RenderShaderEvent renderOutlineShaderEvent = new RenderShaderEvent(matrixStack, tickCounter.method_60637(true));
        EventBus.INSTANCE.dispatch(renderOutlineShaderEvent);
    }

    @Inject(method={"renderWorldBorder"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookRenderWorldBorder(class_4184 camera, CallbackInfo ci) {
        RenderWorldBorderEvent renderWorldBorderEvent = new RenderWorldBorderEvent();
        EventBus.INSTANCE.dispatch(renderWorldBorderEvent);
        if (renderWorldBorderEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @ModifyExpressionValue(method={"render"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/Camera;isThirdPerson()Z")})
    private boolean hookIsThirdPerson(boolean original, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera) {
        PerspectiveEvent perspectiveEvent = new PerspectiveEvent(camera);
        EventBus.INSTANCE.dispatch(perspectiveEvent);
        if (perspectiveEvent.isCanceled()) {
            return true;
        }
        return original;
    }

    @Inject(method={"renderEntity"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookRenderEntity(class_1297 entity, double cameraX, double cameraY, double cameraZ, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        RenderEntityInWorldEvent renderEntityInWorldEvent = new RenderEntityInWorldEvent(entity);
        EventBus.INSTANCE.dispatch(renderEntityInWorldEvent);
        if (renderEntityInWorldEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
