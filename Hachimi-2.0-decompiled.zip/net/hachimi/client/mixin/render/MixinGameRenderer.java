package net.hachimi.client.mixin.render;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.hachimi.client.api.render.satin.ReloadableShaderEffectManager;
import net.hachimi.client.impl.event.network.ReachEvent;
import net.hachimi.client.impl.event.render.BobViewEvent;
import net.hachimi.client.impl.event.render.FovEvent;
import net.hachimi.client.impl.event.render.HurtCamEvent;
import net.hachimi.client.impl.event.render.LightmapInitEvent;
import net.hachimi.client.impl.event.render.LightmapTickEvent;
import net.hachimi.client.impl.event.render.LightmapUpdateEvent;
import net.hachimi.client.impl.event.render.LoadProgramsEvent;
import net.hachimi.client.impl.event.render.RenderBlockOutlineEvent;
import net.hachimi.client.impl.event.render.RenderFloatingItemEvent;
import net.hachimi.client.impl.event.render.RenderNauseaEvent;
import net.hachimi.client.impl.event.render.RenderWorldEvent;
import net.hachimi.client.impl.event.render.TargetEntityEvent;
import net.hachimi.client.impl.event.world.UpdateCrosshairTargetEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4599;
import net.minecraft.class_5912;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_759;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(value={class_757.class})
public class MixinGameRenderer
implements Globals {
    @Shadow
    @Final
    class_310 field_4015;
    @Shadow
    private float field_3999;
    @Shadow
    private float field_4019;

    @Inject(method={"<init>"}, at={@At(value="RETURN")})
    private void hookInit(class_310 client, class_759 heldItemRenderer, class_3300 resourceManager, class_4599 buffers, CallbackInfo ci) {
        LightmapInitEvent lightmapInitEvent = new LightmapInitEvent();
        EventBus.INSTANCE.dispatch(lightmapInitEvent);
    }

    @Inject(method={"renderWorld"}, at={@At(value="INVOKE_STRING", target="Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V", args={"ldc=hand"})}, locals=LocalCapture.CAPTURE_FAILEXCEPTION)
    private void hookRenderWorld(class_9779 tickCounter, CallbackInfo ci, @Local(ordinal=1) Matrix4f matrix4f2, @Local(ordinal=1) float tickDelta, @Local class_4587 matrixStack) {
        RenderWorldEvent.Game renderWorldEvent = new RenderWorldEvent.Game(matrixStack, tickDelta);
        EventBus.INSTANCE.dispatch(renderWorldEvent);
    }

    @Inject(method={"renderWorld"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/GameRenderer;renderHand(Lnet/minecraft/client/render/Camera;FLorg/joml/Matrix4f;)V", shift=At.Shift.AFTER)})
    public void hookRenderWorld$2(class_9779 tickCounter, CallbackInfo ci, @Local(ordinal=1) Matrix4f matrix4f2, @Local(ordinal=1) float tickDelta, @Local class_4587 matrixStack) {
        RenderWorldEvent.Hand reloadShaderEvent = new RenderWorldEvent.Hand(matrixStack, tickDelta);
        EventBus.INSTANCE.dispatch(reloadShaderEvent);
    }

    @Inject(method={"renderWorld"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/LightmapTextureManager;update(F)V")})
    private void hookRenderWorld$3(class_9779 tickCounter, CallbackInfo ci) {
        LightmapUpdateEvent lightmapUpdateEvent = new LightmapUpdateEvent(tickCounter.method_60637(true));
        EventBus.INSTANCE.dispatch(lightmapUpdateEvent);
    }

    @WrapOperation(method={"renderWorld"}, at={@At(value="INVOKE", target="Lnet/minecraft/util/math/MathHelper;lerp(FFF)F")})
    private float hookLerpNausea(float delta, float start, float end, Operation<Float> original) {
        RenderNauseaEvent renderNauseaEvent = new RenderNauseaEvent();
        EventBus.INSTANCE.dispatch(renderNauseaEvent);
        if (renderNauseaEvent.isCanceled()) {
            return 0.0f;
        }
        return ((Float)original.call(new Object[]{Float.valueOf(delta), Float.valueOf(start), Float.valueOf(end)})).floatValue();
    }

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/LightmapTextureManager;tick()V")})
    private void hookTick(CallbackInfo ci) {
        LightmapTickEvent lightmapTickEvent = new LightmapTickEvent();
        EventBus.INSTANCE.dispatch(lightmapTickEvent);
    }

    @Inject(method={"updateCrosshairTarget"}, at={@At(value="INVOKE", target="Lnet/minecraft/util/profiler/Profiler;push(Ljava/lang/String;)V", shift=At.Shift.AFTER)})
    private void hookUpdateTargetedEntity$1(float tickDelta, CallbackInfo info) {
        UpdateCrosshairTargetEvent event = new UpdateCrosshairTargetEvent(tickDelta, this.field_4015.method_1560());
        EventBus.INSTANCE.dispatch(event);
    }

    @Inject(method={"tiltViewWhenHurt"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookTiltViewWhenHurt(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        HurtCamEvent hurtCamEvent = new HurtCamEvent();
        EventBus.INSTANCE.dispatch(hurtCamEvent);
        if (hurtCamEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"showFloatingItem"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookShowFloatingItem(class_1799 floatingItem, CallbackInfo ci) {
        RenderFloatingItemEvent renderFloatingItemEvent = new RenderFloatingItemEvent(floatingItem);
        EventBus.INSTANCE.dispatch(renderFloatingItemEvent);
        if (renderFloatingItemEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"renderNausea"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookRenderNausea(class_332 context, float distortionStrength, CallbackInfo ci) {
        RenderNauseaEvent renderNauseaEvent = new RenderNauseaEvent();
        EventBus.INSTANCE.dispatch(renderNauseaEvent);
        if (renderNauseaEvent.isCanceled()) {
            ci.cancel();
        }
    }

    @Inject(method={"shouldRenderBlockOutline"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> cir) {
        RenderBlockOutlineEvent renderBlockOutlineEvent = new RenderBlockOutlineEvent();
        EventBus.INSTANCE.dispatch(renderBlockOutlineEvent);
        if (renderBlockOutlineEvent.isCanceled()) {
            cir.setReturnValue((Object)false);
            cir.cancel();
        }
    }

    @Inject(method={"updateCrosshairTarget"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/render/GameRenderer;findCrosshairTarget(Lnet/minecraft/entity/Entity;DDF)Lnet/minecraft/util/hit/HitResult;")}, cancellable=true)
    private void hookUpdateTargetedEntity$2(float tickDelta, CallbackInfo info) {
        TargetEntityEvent targetEntityEvent = new TargetEntityEvent();
        EventBus.INSTANCE.dispatch(targetEntityEvent);
        if (targetEntityEvent.isCanceled() && this.field_4015.field_1765 != null && this.field_4015.field_1765.method_17783() == class_239.class_240.field_1332) {
            this.field_4015.method_16011().method_15407();
            info.cancel();
        }
    }

    @Redirect(method={"updateCrosshairTarget"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getEntityInteractionRange()D"))
    private double updateTargetedEntityModifySquaredMaxReach(class_746 instance) {
        ReachEvent.Entity reachEvent = new ReachEvent.Entity();
        EventBus.INSTANCE.dispatch(reachEvent);
        return reachEvent.isCanceled() ? reachEvent.getReach() : instance.method_55755();
    }

    @Redirect(method={"updateCrosshairTarget"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getBlockInteractionRange()D"))
    private double updateTargetedEntityModifySquaredMaxReach$1(class_746 instance) {
        ReachEvent.Block reachEvent = new ReachEvent.Block();
        EventBus.INSTANCE.dispatch(reachEvent);
        return reachEvent.isCanceled() ? reachEvent.getReach() : instance.method_55754();
    }

    @Inject(method={"bobView"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookBobView(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        BobViewEvent bobViewEvent = new BobViewEvent(matrices, tickDelta);
        EventBus.INSTANCE.dispatch(bobViewEvent);
        if (bobViewEvent.isCanceled()) {
            ci.cancel();
            matrices.method_46416(0.0f, bobViewEvent.getY(), 0.0f);
        }
    }

    @Inject(method={"getFov"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetFov(class_4184 camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        FovEvent fovEvent = new FovEvent();
        EventBus.INSTANCE.dispatch(fovEvent);
        if (fovEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue((Object)(fovEvent.getFov() * (double)class_3532.method_16439((float)tickDelta, (float)this.field_3999, (float)this.field_4019)));
        }
    }

    @Inject(method={"loadPrograms"}, at={@At(value="INVOKE", target="Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal=0)}, locals=LocalCapture.CAPTURE_FAILHARD)
    private void initPrograms(class_5912 factory, CallbackInfo ci) {
        LoadProgramsEvent loadProgramsEvent = new LoadProgramsEvent();
        EventBus.INSTANCE.dispatch(loadProgramsEvent);
    }

    @Inject(method={"loadPrograms"}, at={@At(value="RETURN")})
    private void loadSatinPrograms(class_5912 factory, CallbackInfo ci) {
        ReloadableShaderEffectManager.INSTANCE.reload(factory);
    }
}
