package net.hachimi.client.mixin.render.entity;

import net.hachimi.client.impl.event.render.entity.RenderItemFrameEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1799;
import net.minecraft.class_915;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_915.class})
public class MixinItemFrameEntityRenderer {
    @Redirect(method={"render(Lnet/minecraft/entity/decoration/ItemFrameEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/item/ItemStack;isEmpty()Z"))
    private boolean redirectIsEmpty(class_1799 itemStack) {
        RenderItemFrameEvent renderItemFrameEvent = new RenderItemFrameEvent();
        EventBus.INSTANCE.dispatch(renderItemFrameEvent);
        if (renderItemFrameEvent.isCanceled()) {
            return true;
        }
        return itemStack.method_7960();
    }
}
