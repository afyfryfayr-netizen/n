package net.hachimi.client.mixin.render.entity;

import net.hachimi.client.impl.event.render.entity.RenderWitherSkullEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1687;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_966.class})
public class MixinWitherSkullEntityRenderer {
    @Inject(method={"render(Lnet/minecraft/entity/projectile/WitherSkullEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookRender(class_1687 witherSkullEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo ci) {
        RenderWitherSkullEvent renderWitherSkullEvent = new RenderWitherSkullEvent();
        EventBus.INSTANCE.dispatch(renderWitherSkullEvent);
        if (renderWitherSkullEvent.isCanceled()) {
            ci.cancel();
        }
    }
}
