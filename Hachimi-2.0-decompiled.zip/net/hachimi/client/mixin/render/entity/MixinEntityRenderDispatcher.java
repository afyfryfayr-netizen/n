package net.hachimi.client.mixin.render.entity;

import net.hachimi.client.impl.event.render.entity.RenderEntityWorldEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_898.class})
public class MixinEntityRenderDispatcher {
    @Inject(method={"render"}, at={@At(value="RETURN")})
    private void hookRender(class_1297 entity, double x, double y, double z, float yaw, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        RenderEntityWorldEvent renderEntityEvent = new RenderEntityWorldEvent(entity, x, y, z, yaw, tickDelta, matrices, vertexConsumers);
        EventBus.INSTANCE.dispatch(renderEntityEvent);
    }
}
