package net.hachimi.client.mixin.render;

import java.awt.Color;
import net.hachimi.client.impl.event.world.SkyboxEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_5294;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_5294.class})
public class MixinDimensionEffects {
    @Inject(method={"getFogColorOverride"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetFogColorOverride(float skyAngle, float tickDelta, CallbackInfoReturnable<float[]> cir) {
        SkyboxEvent.Fog skyboxEvent = new SkyboxEvent.Fog(tickDelta);
        EventBus.INSTANCE.dispatch(skyboxEvent);
        if (skyboxEvent.isCanceled()) {
            Color color = skyboxEvent.getColor();
            cir.cancel();
            cir.setReturnValue((Object)new float[]{(float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, 1.0f});
        }
    }
}
