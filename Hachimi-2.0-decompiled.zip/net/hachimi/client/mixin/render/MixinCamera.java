package net.hachimi.client.mixin.render;

import net.hachimi.client.impl.event.camera.CameraPositionEvent;
import net.hachimi.client.impl.event.camera.CameraRotationEvent;
import net.hachimi.client.impl.event.gui.hud.RenderOverlayEvent;
import net.hachimi.client.impl.event.render.CameraClipEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_4184.class})
public abstract class MixinCamera {
    @Shadow
    private float field_47549;

    @Shadow
    protected abstract void method_19327(double var1, double var3, double var5);

    @Shadow
    protected abstract void method_19325(float var1, float var2);

    @Inject(method={"getSubmersionType"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookGetSubmersionType(CallbackInfoReturnable<class_5636> cir) {
        RenderOverlayEvent.Water renderOverlayEvent = new RenderOverlayEvent.Water(null);
        EventBus.INSTANCE.dispatch(renderOverlayEvent);
        if (renderOverlayEvent.isCanceled()) {
            cir.setReturnValue((Object)class_5636.field_27888);
            cir.cancel();
        }
    }

    @Inject(method={"clipToSpace"}, at={@At(value="HEAD")}, cancellable=true)
    private void hookClipToSpace(float f, CallbackInfoReturnable<Float> cir) {
        CameraClipEvent cameraClipEvent = new CameraClipEvent(f);
        EventBus.INSTANCE.dispatch(cameraClipEvent);
        if (cameraClipEvent.isCanceled()) {
            cir.setReturnValue((Object)Float.valueOf(cameraClipEvent.getDistance()));
            cir.cancel();
        }
    }

    @Redirect(method={"update"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/render/Camera;setPos(DDD)V"))
    private void hookUpdatePosition(class_4184 instance, double x, double y, double z) {
        CameraPositionEvent cameraPositionEvent = new CameraPositionEvent(x, y, z, this.field_47549);
        EventBus.INSTANCE.dispatch(cameraPositionEvent);
        this.method_19327(cameraPositionEvent.getX(), cameraPositionEvent.getY(), cameraPositionEvent.getZ());
    }

    @Redirect(method={"update"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/render/Camera;setRotation(FF)V"))
    private void hookUpdateRotation(class_4184 instance, float yaw, float pitch) {
        CameraRotationEvent cameraRotationEvent = new CameraRotationEvent(yaw, pitch, this.field_47549);
        EventBus.INSTANCE.dispatch(cameraRotationEvent);
        this.method_19325(cameraRotationEvent.getYaw(), cameraRotationEvent.getPitch());
    }
}
