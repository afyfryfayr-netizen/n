package net.hachimi.client.util.math.position;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public class DirectionUtil {
    public static class_243 getDirectionOffsetPos(class_2338 pos, class_2350 direction) {
        class_243 pos1 = pos.method_46558();
        return switch (direction) {
            default -> throw new MatchException(null, null);
            case class_2350.field_11036 -> pos1.method_1031(0.0, 0.5, 0.0);
            case class_2350.field_11033 -> pos1.method_1031(0.0, -0.5, 0.0);
            case class_2350.field_11043 -> pos1.method_1031(0.0, 0.0, -0.5);
            case class_2350.field_11035 -> pos1.method_1031(0.0, 0.0, 0.5);
            case class_2350.field_11039 -> pos1.method_1031(-0.5, 0.0, 0.0);
            case class_2350.field_11034 -> pos1.method_1031(0.5, 0.0, 0.0);
        };
    }
}
