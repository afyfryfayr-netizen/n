package net.hachimi.client.util.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public final class TextureUtil {
    private TextureUtil() {
    }

    public static void drawScaled(class_332 context, class_2960 texture, int x, int y, int width, int height) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture((int)0, (class_2960)texture);
        Matrix4f matrix = context.method_51448().method_23760().method_23761();
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        buffer.method_22918(matrix, (float)x, (float)y, 0.0f).method_22913(0.0f, 0.0f);
        buffer.method_22918(matrix, (float)x, (float)(y + height), 0.0f).method_22913(0.0f, 1.0f);
        buffer.method_22918(matrix, (float)(x + width), (float)(y + height), 0.0f).method_22913(1.0f, 1.0f);
        buffer.method_22918(matrix, (float)(x + width), (float)y, 0.0f).method_22913(1.0f, 0.0f);
        class_286.method_43433((class_9801)buffer.method_60800());
    }
}
