package net.hachimi.client.util.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import net.hachimi.client.api.render.RenderManager;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.render.ColorUtilPlus;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5348;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class Render3DUtilPlus
implements Globals {
    public static final long INIT_TIME = System.currentTimeMillis();

    public static void endBuilding(class_287 bb) {
        class_9801 built = bb.method_60794();
        if (built != null) {
            class_286.method_43433((class_9801)built);
        }
    }

    public static class_4587 matrixFrom(double x, double y, double z) {
        class_4587 matrices = new class_4587();
        class_4184 camera = Render3DUtilPlus.mc.field_1773.method_19418();
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        matrices.method_22904(x - camera.method_19326().field_1352, y - camera.method_19326().field_1351, z - camera.method_19326().field_1350);
        return matrices;
    }

    public static float getTickDelta() {
        return mc.method_60646().method_60637(true);
    }

    public static void drawText3D(String text, class_243 pos, Color color) {
        Render3DUtilPlus.drawText3D(class_2561.method_30163((String)text), pos.field_1352, pos.field_1351, pos.field_1350, 0.0, 0.0, 1.0, color.getRGB());
    }

    public static void drawText3D(String text, class_243 pos, int color) {
        Render3DUtilPlus.drawText3D(class_2561.method_30163((String)text), pos.field_1352, pos.field_1351, pos.field_1350, 0.0, 0.0, 1.0, color);
    }

    public static void drawText3D(class_2561 text, class_243 pos, double offX, double offY, double scale, Color color) {
        Render3DUtilPlus.drawText3D(text, pos.field_1352, pos.field_1351, pos.field_1350, offX, offY, scale, color.getRGB());
    }

    public static void drawText3D(class_2561 text, double x, double y, double z, double offX, double offY, double scale, int color) {
        RenderSystem.disableDepthTest();
        class_4587 matrices = Render3DUtilPlus.matrixFrom(x, y, z);
        class_4184 camera = Render3DUtilPlus.mc.field_1773.method_19418();
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        RenderSystem.enableBlend();
        matrices.method_22904(offX, offY, 0.0);
        matrices.method_22905(-0.025f * (float)scale, -0.025f * (float)scale, 1.0f);
        int halfWidth = Render3DUtilPlus.mc.field_1772.method_27525((class_5348)text) / 2;
        class_4597.class_4598 immediate = class_4597.method_22991((class_9799)new class_9799(1536));
        Render3DUtilPlus.mc.field_1772.method_1724(text.getString(), (float)(-halfWidth), 0.0f, -1, true, matrices.method_23760().method_23761(), (class_4597)immediate, class_327.class_6415.field_33994, 0, 0xF000F0);
        immediate.method_22993();
        Render3DUtilPlus.mc.field_1772.method_30882((class_2561)text.method_27661(), (float)(-halfWidth), 0.0f, color, false, matrices.method_23760().method_23761(), (class_4597)immediate, class_327.class_6415.field_33994, 0, 0xF000F0);
        immediate.method_22993();
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
    }

    public static void drawFill(class_4587 matrices, class_238 box, Color color) {
        RenderManager.renderBox(matrices, box, color.getRGB());
    }

    public static void drawBox(class_4587 matrices, class_238 box, Color color) {
        RenderManager.renderBoundingBox(matrices, box, 1.5f, color.getRGB());
    }

    public static void drawBox(class_4587 matrices, class_238 box, Color color, float lineWidth) {
        RenderManager.renderBoundingBox(matrices, box, lineWidth, color.getRGB());
    }

    public static void drawFadeFill(class_4587 stack, class_238 box, Color c, Color c1) {
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(class_757::method_34540);
        class_243 cam = Render3DUtilPlus.mc.method_1561().field_4686.method_19326();
        float minX = (float)(box.field_1323 - cam.field_1352);
        float maxX = (float)(box.field_1320 - cam.field_1352);
        float minY = (float)(box.field_1322 - cam.field_1351);
        float maxY = (float)(box.field_1325 - cam.field_1351);
        float minZ = (float)(box.field_1321 - cam.field_1350);
        float maxZ = (float)(box.field_1324 - cam.field_1350);
        class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        Matrix4f m = stack.method_23760().method_23761();
        buf.method_22918(m, minX, minY, minZ).method_39415(c.getRGB());
        buf.method_22918(m, maxX, minY, minZ).method_39415(c.getRGB());
        buf.method_22918(m, maxX, minY, maxZ).method_39415(c.getRGB());
        buf.method_22918(m, minX, minY, maxZ).method_39415(c.getRGB());
        buf.method_22918(m, minX, minY, minZ).method_39415(c.getRGB());
        buf.method_22918(m, minX, maxY, minZ).method_39415(c1.getRGB());
        buf.method_22918(m, maxX, maxY, minZ).method_39415(c1.getRGB());
        buf.method_22918(m, maxX, minY, minZ).method_39415(c.getRGB());
        buf.method_22918(m, maxX, minY, minZ).method_39415(c.getRGB());
        buf.method_22918(m, maxX, maxY, minZ).method_39415(c1.getRGB());
        buf.method_22918(m, maxX, maxY, maxZ).method_39415(c1.getRGB());
        buf.method_22918(m, maxX, minY, maxZ).method_39415(c.getRGB());
        buf.method_22918(m, minX, minY, maxZ).method_39415(c.getRGB());
        buf.method_22918(m, maxX, minY, maxZ).method_39415(c.getRGB());
        buf.method_22918(m, maxX, maxY, maxZ).method_39415(c1.getRGB());
        buf.method_22918(m, minX, maxY, maxZ).method_39415(c1.getRGB());
        buf.method_22918(m, minX, minY, minZ).method_39415(c.getRGB());
        buf.method_22918(m, minX, minY, maxZ).method_39415(c.getRGB());
        buf.method_22918(m, minX, maxY, maxZ).method_39415(c1.getRGB());
        buf.method_22918(m, minX, maxY, minZ).method_39415(c1.getRGB());
        buf.method_22918(m, minX, maxY, minZ).method_39415(c1.getRGB());
        buf.method_22918(m, minX, maxY, maxZ).method_39415(c1.getRGB());
        buf.method_22918(m, maxX, maxY, maxZ).method_39415(c1.getRGB());
        buf.method_22918(m, maxX, maxY, minZ).method_39415(c1.getRGB());
        Render3DUtilPlus.endBuilding(buf);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void drawLine(class_243 start, class_243 end, Color color) {
        RenderManager.renderLine(new class_4587(), start, end, 1.0f, color.getRGB());
    }

    public static void drawLine(class_243 start, class_243 end, Color color, float width) {
        RenderManager.renderLine(new class_4587(), start, end, width, color.getRGB());
    }

    public static void vertexLine(class_4587 matrices, class_4588 buffer, double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
        Matrix4f model = matrices.method_23760().method_23761();
        class_4587.class_4665 entry = matrices.method_23760();
        Vector3f normal = Render3DUtilPlus.getNormal((float)x1, (float)y1, (float)z1, (float)x2, (float)y2, (float)z2);
        buffer.method_22918(model, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_60831(entry, normal.x(), normal.y(), normal.z());
        buffer.method_22918(model, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_60831(entry, normal.x(), normal.y(), normal.z());
    }

    public static Vector3f getNormal(float x1, float y1, float z1, float x2, float y2, float z2) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float len = class_3532.method_15355((float)(dx * dx + dy * dy + dz * dz));
        return new Vector3f(dx / len, dy / len, dz / len);
    }

    public static void drawTargetEsp(class_4587 stack, class_1297 target, Color color) {
        float alpha;
        int j;
        ArrayList<class_243> v0 = new ArrayList<class_243>();
        ArrayList<class_243> v1 = new ArrayList<class_243>();
        ArrayList<class_243> v2 = new ArrayList<class_243>();
        double x = target.field_6014 + (target.method_23317() - target.field_6014) * (double)Render3DUtilPlus.getTickDelta() - Render3DUtilPlus.mc.method_1561().field_4686.method_19326().method_10216();
        double y = target.field_6036 + (target.method_23318() - target.field_6036) * (double)Render3DUtilPlus.getTickDelta() - Render3DUtilPlus.mc.method_1561().field_4686.method_19326().method_10214();
        double z = target.field_5969 + (target.method_23321() - target.field_5969) * (double)Render3DUtilPlus.getTickDelta() - Render3DUtilPlus.mc.method_1561().field_4686.method_19326().method_10215();
        double height = target.method_17682();
        for (int i = 0; i <= 361; ++i) {
            double sin = Math.sin(Math.toRadians(i));
            double cos = Math.cos(Math.toRadians(i));
            v0.add(new class_243(cos * 0.5, height, sin * 0.5));
            double sin1 = Math.sin(Math.toRadians((i + 120) % 360));
            double cos1 = Math.cos(Math.toRadians(i + 120) % 360.0);
            v1.add(new class_243(cos1 * 0.5, height, sin1 * 0.5));
            double sin2 = Math.sin(Math.toRadians((i + 240) % 360));
            double cos2 = Math.cos(Math.toRadians((i + 240) % 360));
            v2.add(new class_243(cos2 * 0.5, height, sin2 * 0.5));
            height -= (double)0.004f;
        }
        stack.method_22903();
        stack.method_22904(x, y, z);
        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(class_757::method_34540);
        Matrix4f matrix = stack.method_23760().method_23761();
        float timeOffset = (float)(System.currentTimeMillis() - INIT_TIME) / 5.0f;
        class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (j = 0; j < v0.size() - 1; ++j) {
            alpha = 1.0f - ((float)j + timeOffset) % 360.0f / 60.0f;
            int pulsed = ColorUtilPlus.injectAlpha(ColorUtilPlus.pulseColor(color, (int)((float)j / 20.0f), 10, 1.0).getRGB(), (int)(alpha * 255.0f));
            buf.method_22918(matrix, (float)((class_243)v0.get((int)j)).field_1352, (float)((class_243)v0.get((int)j)).field_1351, (float)((class_243)v0.get((int)j)).field_1350).method_39415(pulsed);
            buf.method_22918(matrix, (float)((class_243)v0.get((int)(j + 1))).field_1352, (float)((class_243)v0.get((int)(j + 1))).field_1351 + 0.1f, (float)((class_243)v0.get((int)(j + 1))).field_1350).method_39415(ColorUtilPlus.injectAlpha(ColorUtilPlus.pulseColor(color, (int)((float)j / 20.0f), 10, 1.0).getRGB(), (int)(alpha * 255.0f)));
        }
        Render3DUtilPlus.endBuilding(buf);
        RenderSystem.setShader(class_757::method_34540);
        buf = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (j = 0; j < v1.size() - 1; ++j) {
            alpha = 1.0f - ((float)j + timeOffset) % 360.0f / 60.0f;
            buf.method_22918(matrix, (float)((class_243)v1.get((int)j)).field_1352, (float)((class_243)v1.get((int)j)).field_1351, (float)((class_243)v1.get((int)j)).field_1350).method_39415(ColorUtilPlus.injectAlpha(ColorUtilPlus.pulseColor(color, (int)((float)j / 20.0f), 10, 1.0).getRGB(), (int)(alpha * 255.0f)));
            buf.method_22918(matrix, (float)((class_243)v1.get((int)(j + 1))).field_1352, (float)((class_243)v1.get((int)(j + 1))).field_1351 + 0.1f, (float)((class_243)v1.get((int)(j + 1))).field_1350).method_39415(ColorUtilPlus.injectAlpha(ColorUtilPlus.pulseColor(color, (int)((float)j / 20.0f), 10, 1.0).getRGB(), (int)(alpha * 255.0f)));
        }
        Render3DUtilPlus.endBuilding(buf);
        RenderSystem.setShader(class_757::method_34540);
        buf = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (j = 0; j < v2.size() - 1; ++j) {
            alpha = 1.0f - ((float)j + timeOffset) % 360.0f / 60.0f;
            buf.method_22918(matrix, (float)((class_243)v2.get((int)j)).field_1352, (float)((class_243)v2.get((int)j)).field_1351, (float)((class_243)v2.get((int)j)).field_1350).method_39415(ColorUtilPlus.injectAlpha(ColorUtilPlus.pulseColor(color, (int)((float)j / 20.0f), 10, 1.0).getRGB(), (int)(alpha * 255.0f)));
            buf.method_22918(matrix, (float)((class_243)v2.get((int)(j + 1))).field_1352, (float)((class_243)v2.get((int)(j + 1))).field_1351 + 0.1f, (float)((class_243)v2.get((int)(j + 1))).field_1350).method_39415(ColorUtilPlus.injectAlpha(ColorUtilPlus.pulseColor(color, (int)((float)j / 20.0f), 10, 1.0).getRGB(), (int)(alpha * 255.0f)));
        }
        Render3DUtilPlus.endBuilding(buf);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        stack.method_22909();
    }
}
