package net.hachimi.client.util;

import com.google.common.collect.ImmutableMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.impl.module.client.SocialsModule;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5481;

public class FormattingUtil {
    private static final Map<Integer, class_124> COLOR_TO_FORMATTING = Stream.of(class_124.values()).filter(class_124::method_543).collect(ImmutableMap.toImmutableMap(class_124::method_532, Function.identity()));

    public static String toString(class_2561 text) {
        StringBuilder builder = new StringBuilder();
        text.method_27658((styleOverride, message) -> {
            if (!message.isEmpty()) {
                if (styleOverride.method_10973() != null) {
                    int rgb = styleOverride.method_10973().method_27716();
                    if (rgb == (ColorsModule.getInstance().getRGB() & 0xFFFFFF)) {
                        builder.append('\u00a7').append("s");
                    } else if (rgb == (SocialsModule.getInstance().getFriendRGB() & 0xFFFFFF)) {
                        builder.append('\u00a7').append("g");
                    } else {
                        class_124 formatting = COLOR_TO_FORMATTING.get(rgb);
                        if (formatting != null) {
                            builder.append('\u00a7').append(formatting.method_36145());
                        }
                    }
                } else if (styleOverride.method_10987()) {
                    builder.append('\u00a7').append("k");
                } else if (styleOverride.method_10984()) {
                    builder.append('\u00a7').append("l");
                } else if (styleOverride.method_10986()) {
                    builder.append('\u00a7').append("m");
                } else if (styleOverride.method_10965()) {
                    builder.append('\u00a7').append("n");
                } else if (styleOverride.method_10966()) {
                    builder.append('\u00a7').append("o");
                } else {
                    builder.append('\u00a7').append("r");
                }
                builder.append(message);
            }
            return Optional.empty();
        }, class_2583.field_24360);
        return builder.toString();
    }

    public static String toString(class_5481 text) {
        StringBuilder builder = new StringBuilder();
        text.accept((index, style, codePoint) -> {
            if (style.method_10973() != null) {
                int rgb = style.method_10973().method_27716();
                if (rgb == (ColorsModule.getInstance().getRGB() & 0xFFFFFF)) {
                    builder.append('\u00a7').append("s");
                } else if (rgb == (SocialsModule.getInstance().getFriendRGB() & 0xFFFFFF)) {
                    builder.append('\u00a7').append("g");
                } else {
                    class_124 formatting = COLOR_TO_FORMATTING.get(rgb);
                    if (formatting != null) {
                        builder.append('\u00a7').append(formatting.method_36145());
                    }
                }
            } else if (style.method_10987()) {
                builder.append('\u00a7').append("k");
            } else if (style.method_10984()) {
                builder.append('\u00a7').append("l");
            } else if (style.method_10986()) {
                builder.append('\u00a7').append("m");
            } else if (style.method_10965()) {
                builder.append('\u00a7').append("n");
            } else if (style.method_10966()) {
                builder.append('\u00a7').append("o");
            } else {
                builder.append('\u00a7').append("r");
            }
            builder.appendCodePoint(codePoint);
            return true;
        });
        return builder.toString();
    }
}
