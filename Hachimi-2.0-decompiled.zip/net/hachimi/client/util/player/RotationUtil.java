package net.hachimi.client.util.player;

import net.hachimi.client.util.Globals;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class RotationUtil
implements Globals {
    public static float[] getRotationsTo(class_243 src, class_243 dest) {
        float yaw = (float)(Math.toDegrees(Math.atan2(dest.method_1020((class_243)src).field_1350, dest.method_1020((class_243)src).field_1352)) - 90.0);
        float pitch = (float)Math.toDegrees(-Math.atan2(dest.method_1020((class_243)src).field_1351, Math.hypot(dest.method_1020((class_243)src).field_1352, dest.method_1020((class_243)src).field_1350)));
        return new float[]{class_3532.method_15393((float)yaw), class_3532.method_15393((float)pitch)};
    }

    public static float[] smooth(float[] target, float[] previous, float rotationSpeed) {
        float speed = (1.0f - class_3532.method_15363((float)(rotationSpeed / 100.0f), (float)0.1f, (float)0.9f)) * 10.0f;
        float[] rotations = new float[]{previous[0] + (float)(-RotationUtil.getAngleDifference(previous[0], target[0]) / (double)speed), previous[1] + -(previous[1] - target[1]) / speed};
        rotations[1] = class_3532.method_15363((float)rotations[1], (float)-90.0f, (float)90.0f);
        return rotations;
    }

    public static double getAngleDifference(float client, float yaw) {
        return ((double)(client - yaw) % 360.0 + 540.0) % 360.0 - 180.0;
    }

    public static double getAnglePitchDifference(float client, float pitch) {
        return ((double)(client - pitch) % 180.0 + 270.0) % 180.0 - 90.0;
    }

    public static class_243 getRotationVector(float pitch, float yaw) {
        float f = pitch * ((float)Math.PI / 180);
        float g = -yaw * ((float)Math.PI / 180);
        float h = class_3532.method_15362((float)g);
        float i = class_3532.method_15374((float)g);
        float j = class_3532.method_15362((float)f);
        float k = class_3532.method_15374((float)f);
        return new class_243((double)(i * j), (double)(-k), (double)(h * j));
    }
}
