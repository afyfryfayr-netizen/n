package net.hachimi.client.util.player;

import net.hachimi.client.util.Globals;
import net.hachimi.client.util.player.EnchantmentUtil;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_5321;

public class InventoryUtil
implements Globals {
    public static boolean isHolding32k() {
        return InventoryUtil.isHolding32k(1000);
    }

    public static boolean isHolding32k(int lvl) {
        class_1799 mainhand = InventoryUtil.mc.field_1724.method_6047();
        return EnchantmentUtil.getLevel(mainhand, (class_5321<class_1887>)class_1893.field_9118) >= lvl;
    }

    public static boolean hasItemInInventory(class_1792 item, boolean hotbar) {
        int startSlot;
        for (int i = startSlot = hotbar ? 0 : 9; i < 36; ++i) {
            class_1799 itemStack = InventoryUtil.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960() || itemStack.method_7909() != item) continue;
            return true;
        }
        return false;
    }

    public static boolean hasItemInHotbar(class_1792 item) {
        for (int i = 0; i < 9; ++i) {
            class_1799 itemStack = InventoryUtil.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960() || itemStack.method_7909() != item) continue;
            return true;
        }
        return false;
    }

    public static int count(class_1792 item) {
        if (InventoryUtil.mc.field_1724 == null) {
            return 0;
        }
        class_1799 offhandStack = InventoryUtil.mc.field_1724.method_6079();
        int itemCount = offhandStack.method_7909() == item ? offhandStack.method_7947() : 0;
        for (int i = 0; i < 36; ++i) {
            class_1799 slot = InventoryUtil.mc.field_1724.method_31548().method_5438(i);
            if (slot.method_7909() != item) continue;
            itemCount += slot.method_7947();
        }
        return itemCount;
    }
}
