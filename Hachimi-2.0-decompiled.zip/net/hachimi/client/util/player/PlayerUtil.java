package net.hachimi.client.util.player;

import net.hachimi.client.util.Globals;
import net.hachimi.client.util.math.position.PositionUtil;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2560;
import net.minecraft.class_2680;
import net.minecraft.class_304;
import net.minecraft.class_3483;
import net.minecraft.class_3532;

public final class PlayerUtil
implements Globals {
    public static float getLocalPlayerHealth() {
        return PlayerUtil.mc.field_1724.method_6032() + PlayerUtil.mc.field_1724.method_6067();
    }

    public static int computeFallDamage(float fallDistance, float damageMultiplier) {
        if (PlayerUtil.mc.field_1724.method_5864().method_20210(class_3483.field_42971)) {
            return 0;
        }
        class_1293 statusEffectInstance = PlayerUtil.mc.field_1724.method_6112(class_1294.field_5913);
        float f = statusEffectInstance == null ? 0.0f : (float)(statusEffectInstance.method_5578() + 1);
        return class_3532.method_15386((float)((fallDistance - 3.0f - f) * damageMultiplier));
    }

    public static boolean isHolding(class_1792 item) {
        class_1799 itemStack = PlayerUtil.mc.field_1724.method_6047();
        if (!itemStack.method_7960() && itemStack.method_7909() == item) {
            return true;
        }
        itemStack = PlayerUtil.mc.field_1724.method_6079();
        return !itemStack.method_7960() && itemStack.method_7909() == item;
    }

    public static boolean isHotbarKeysPressed() {
        for (class_304 binding : PlayerUtil.mc.field_1690.field_1852) {
            if (!binding.method_1434()) continue;
            return true;
        }
        return false;
    }

    public static boolean inWeb(double expandBb) {
        for (class_2338 blockPos : PositionUtil.getAllInBox(PlayerUtil.mc.field_1724.method_5829().method_1014(expandBb))) {
            class_2680 state = PlayerUtil.mc.field_1687.method_8320(blockPos);
            if (!(state.method_26204() instanceof class_2560)) continue;
            return true;
        }
        return false;
    }
}
