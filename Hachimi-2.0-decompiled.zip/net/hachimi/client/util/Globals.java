package net.hachimi.client.util;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_310;

public interface Globals {
    public static final class_310 mc = class_310.method_1551();
    public static final Random RANDOM = ThreadLocalRandom.current();
}
