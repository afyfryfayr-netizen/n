package net.hachimi.client.util.chat;

import net.hachimi.client.impl.imixin.IChatHud;
import net.hachimi.client.impl.module.client.ColorsModule;
import net.hachimi.client.util.Globals;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_7591;

public class ChatUtil
implements Globals {
    public static final String PREFIX = "\u00a7s[Hachimi] \u00a7r";

    public static void clientSendMessage(String message) {
        ChatUtil.clientSendMessage(message, 0);
    }

    public static void clientSendMessage(String message, int id) {
        class_7591 messageIndicator = new class_7591(ColorsModule.getInstance().getRGB().intValue(), null, (class_2561)class_2561.method_43473(), "Hachimi");
        ((IChatHud)ChatUtil.mc.field_1705.method_1743()).addMessage(class_2561.method_30163((String)(PREFIX + message)), messageIndicator, id);
    }

    public static void clientSendMessage(String message, Object ... params) {
        ChatUtil.clientSendMessage(String.format(message, params));
    }

    public static void clientSendMessageRaw(String message) {
        ChatUtil.clientSendMessageRaw(message, 0);
    }

    public static void clientSendMessageRaw(String message, int id) {
        class_7591 messageIndicator = new class_7591(ColorsModule.getInstance().getRGB().intValue(), null, (class_2561)class_2561.method_43473(), "Hachimi");
        ((IChatHud)ChatUtil.mc.field_1705.method_1743()).addMessage(class_2561.method_30163((String)message), messageIndicator, id);
    }

    public static void clientSendMessageRaw(String message, Object ... params) {
        ChatUtil.clientSendMessageRaw(String.format(message, params));
    }

    public static void serverSendMessage(String message) {
        if (ChatUtil.mc.field_1724 != null) {
            ChatUtil.mc.field_1724.field_3944.method_45729(message);
        }
    }

    public static void serverSendCommand(String message) {
        if (ChatUtil.mc.field_1724 != null) {
            ChatUtil.mc.field_1724.field_3944.method_45730(message);
        }
    }

    public static void serverSendMessage(class_1657 player, String message) {
        if (ChatUtil.mc.field_1724 != null) {
            String reply = "/msg " + player.method_5477().getString() + " ";
            ChatUtil.mc.field_1724.field_3944.method_45729(reply + message);
        }
    }

    public static void serverSendMessage(class_1657 player, String message, Object ... params) {
        ChatUtil.serverSendMessage(player, String.format(message, params));
    }

    public static void error(String message) {
        ChatUtil.clientSendMessage(String.valueOf(class_124.field_1061) + message);
    }

    public static void error(String message, Object ... params) {
        ChatUtil.clientSendMessage(String.valueOf(class_124.field_1061) + message, params);
    }
}
