package net.hachimi.client.util.world;

import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public class ItemUtil {
    private static final Set<class_1792> SHULKERS = Set.of(class_1802.field_8545, class_1802.field_8722, class_1802.field_8451, class_1802.field_8627, class_1802.field_8268, class_1802.field_8584, class_1802.field_8676, class_1802.field_8380, class_1802.field_8271, class_1802.field_8548, class_1802.field_8461, class_1802.field_8213, class_1802.field_8829, class_1802.field_8350, class_1802.field_8816, class_1802.field_8520, class_1802.field_8050);

    public static boolean isShulker(class_1792 item) {
        return SHULKERS.contains(item);
    }
}
