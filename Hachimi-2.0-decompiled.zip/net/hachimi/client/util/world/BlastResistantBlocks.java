package net.hachimi.client.util.world;

import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.Set;
import net.hachimi.client.util.Globals;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BlastResistantBlocks
implements Globals {
    private static final Set<class_2248> BLAST_RESISTANT = new ReferenceOpenHashSet(Set.of(class_2246.field_10540, class_2246.field_10535, class_2246.field_10485, class_2246.field_10443, class_2246.field_10327));
    private static final Set<class_2248> UNBREAKABLE = new ReferenceOpenHashSet(Set.of(class_2246.field_9987, class_2246.field_10525, class_2246.field_10395, class_2246.field_10398, class_2246.field_10499));

    public static boolean isBreakable(class_2338 pos) {
        if (BlastResistantBlocks.mc.field_1687 == null) {
            return false;
        }
        return BlastResistantBlocks.isBreakable(BlastResistantBlocks.mc.field_1687.method_8320(pos).method_26204());
    }

    public static boolean isBreakable(class_2248 block) {
        return !UNBREAKABLE.contains(block);
    }

    public static boolean isUnbreakable(class_2338 pos) {
        if (BlastResistantBlocks.mc.field_1687 == null) {
            return false;
        }
        return BlastResistantBlocks.isUnbreakable(BlastResistantBlocks.mc.field_1687.method_8320(pos).method_26204());
    }

    public static boolean isUnbreakable(class_2248 block) {
        return UNBREAKABLE.contains(block);
    }

    public static boolean isBlastResistant(class_2338 pos) {
        if (BlastResistantBlocks.mc.field_1687 == null) {
            return false;
        }
        return BlastResistantBlocks.isBlastResistant(BlastResistantBlocks.mc.field_1687.method_8320(pos).method_26204());
    }

    public static boolean isBlastResistant(class_2680 state) {
        return BlastResistantBlocks.isBlastResistant(state.method_26204());
    }

    public static boolean isBlastResistant(class_2248 block) {
        return BLAST_RESISTANT.contains(block);
    }
}
