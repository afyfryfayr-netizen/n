package net.hachimi.client.util.world;

import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public class SneakBlocks {
    private static final Set<class_2248> SNEAK_BLOCKS = Set.of(class_2246.field_10034, class_2246.field_10443, class_2246.field_10380, class_2246.field_9980, class_2246.field_10181, class_2246.field_16333, class_2246.field_16331, class_2246.field_16336, class_2246.field_10485, class_2246.field_16329, class_2246.field_16335, class_2246.field_10223, class_2246.field_10179, class_2246.field_10603, class_2246.field_10371, class_2246.field_10605, class_2246.field_10203, class_2246.field_10055, class_2246.field_10532, class_2246.field_10373, class_2246.field_10140, class_2246.field_10320, class_2246.field_10275, class_2246.field_10063, class_2246.field_10407, class_2246.field_10051, class_2246.field_10268, class_2246.field_10068, class_2246.field_10199, class_2246.field_10600, class_2246.field_10608, class_2246.field_40285, class_2246.field_10486, class_2246.field_42740, class_2246.field_47048, class_2246.field_47049, class_2246.field_47050, class_2246.field_47052, class_2246.field_47053, class_2246.field_47062, class_2246.field_47051, class_2246.field_10323, class_2246.field_22095, class_2246.field_10453, class_2246.field_10246, class_2246.field_10017, class_2246.field_37555, class_2246.field_10137, class_2246.field_22094);

    public static boolean isSneakBlock(class_2680 state) {
        return SneakBlocks.isSneakBlock(state.method_26204());
    }

    public static boolean isSneakBlock(class_2248 block) {
        return SNEAK_BLOCKS.contains(block);
    }
}
