package net.hachimi.client.util.world;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.Globals;
import net.hachimi.client.util.player.RotationUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1683;
import net.minecraft.class_1922;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class BlockUtilPlus
implements Globals {
    public static final CopyOnWriteArrayList<class_2338> placeList = new CopyOnWriteArrayList();
    private static final double MIN_EYE_HEIGHT = 0.4;
    private static final double MAX_EYE_HEIGHT = 1.62;
    private static final double MOVEMENT_THRESHOLD = 2.0E-4;
    public static final List<class_2248> SHIFT_BLOCKS = Arrays.asList(class_2246.field_10443, class_2246.field_10034, class_2246.field_10380, class_2246.field_9980, class_2246.field_10535, class_2246.field_10333, class_2246.field_10312, class_2246.field_10228, class_2246.field_10200, class_2246.field_10485, class_2246.field_10486, class_2246.field_40285, class_2246.field_10246, class_2246.field_42740, class_2246.field_10608, class_2246.field_10199, class_2246.field_10407, class_2246.field_10063, class_2246.field_10203, class_2246.field_10600, class_2246.field_10275, class_2246.field_10051, class_2246.field_10140, class_2246.field_10532, class_2246.field_10268, class_2246.field_10605, class_2246.field_10373, class_2246.field_10055, class_2246.field_10068, class_2246.field_10371);

    public static boolean isGrimDirection(class_2338 pos, class_2350 direction) {
        boolean bl;
        block10: {
            block9: {
                class_238 combined = BlockUtilPlus.getCombinedBox(pos);
                class_238 eyeBox = new class_238(BlockUtilPlus.mc.field_1724.method_23317(), BlockUtilPlus.mc.field_1724.method_23318() + 0.4, BlockUtilPlus.mc.field_1724.method_23321(), BlockUtilPlus.mc.field_1724.method_23317(), BlockUtilPlus.mc.field_1724.method_23318() + 1.62, BlockUtilPlus.mc.field_1724.method_23321()).method_1014(2.0E-4);
                if (BlockUtilPlus.isIntersected(eyeBox, combined)) {
                    return true;
                }
                switch (direction) {
                    default: {
                        throw new MatchException(null, null);
                    }
                    case field_11043: {
                        if (!(eyeBox.field_1321 > combined.field_1321)) break;
                        break block9;
                    }
                    case field_11035: {
                        if (!(eyeBox.field_1324 < combined.field_1324)) break;
                        break block9;
                    }
                    case field_11034: {
                        if (!(eyeBox.field_1320 < combined.field_1320)) break;
                        break block9;
                    }
                    case field_11039: {
                        if (!(eyeBox.field_1323 > combined.field_1323)) break;
                        break block9;
                    }
                    case field_11036: {
                        if (!(eyeBox.field_1325 < combined.field_1325)) break;
                        break block9;
                    }
                    case field_11033: {
                        if (eyeBox.field_1322 > combined.field_1322) break block9;
                    }
                }
                bl = true;
                break block10;
            }
            bl = false;
        }
        return bl;
    }

    public static class_2350 getClickSideStrict(class_2338 pos) {
        class_2350 best = null;
        double minDist = Double.MAX_VALUE;
        for (class_2350 dir : class_2350.values()) {
            double dist;
            if (!BlockUtilPlus.isGrimDirection(pos, dir) || !((dist = BlockUtilPlus.mc.field_1724.method_33571().method_1025(pos.method_10093(dir).method_46558())) < minDist)) continue;
            minDist = dist;
            best = dir;
        }
        return best;
    }

    public static class_2350 getClickSide(class_2338 pos) {
        double dist;
        class_2350 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_2350 dir : class_2350.values()) {
            if (!BlockUtilPlus.canSee(pos, dir) || !((dist = BlockUtilPlus.mc.field_1724.method_33571().method_1025(pos.method_10093(dir).method_46558())) < bestDist)) continue;
            bestDist = dist;
            best = dir;
        }
        if (best != null) {
            return best;
        }
        bestDist = Double.MAX_VALUE;
        best = class_2350.field_11036;
        for (class_2350 dir : class_2350.values()) {
            if (!BlockUtilPlus.isGrimDirection(pos, dir) || !((dist = BlockUtilPlus.mc.field_1724.method_33571().method_1025(pos.method_10093(dir).method_46558())) < bestDist)) continue;
            bestDist = dist;
            best = dir;
        }
        return best;
    }

    public static class_2350 getPlaceSide(class_2338 pos, Predicate<class_2350> filter) {
        return BlockUtilPlus.getPlaceSide(pos, filter, false);
    }

    public static class_2350 getPlaceSide(class_2338 pos, Predicate<class_2350> filter, boolean ignoreSneak) {
        if (pos == null) {
            return null;
        }
        double bestDist = Double.MAX_VALUE;
        class_2350 best = null;
        for (class_2350 dir : class_2350.values()) {
            double dist;
            class_2338 neighbor;
            if (filter != null && !filter.test(dir) || !BlockUtilPlus.canClick(neighbor = pos.method_10093(dir), ignoreSneak) || BlockUtilPlus.mc.field_1687.method_8320(neighbor).method_45474() || !BlockUtilPlus.isGrimDirection(neighbor, dir.method_10153()) || !((dist = BlockUtilPlus.mc.field_1724.method_33571().method_1025(pos.method_46558().method_1031((double)dir.method_10148() * 0.5, (double)dir.method_10164() * 0.5, (double)dir.method_10165() * 0.5))) < bestDist)) continue;
            bestDist = dist;
            best = dir;
        }
        return best;
    }

    public static List<class_2350> getPlaceSides(class_2338 pos, Predicate<class_2350> filter) {
        return BlockUtilPlus.getPlaceSides(pos, filter, false);
    }

    public static List<class_2350> getPlaceSides(class_2338 pos, Predicate<class_2350> filter, boolean ignoreSneak) {
        ArrayList<class_2350> sides = new ArrayList<class_2350>();
        if (pos == null) {
            return sides;
        }
        for (class_2350 dir : class_2350.values()) {
            if (filter != null && !filter.test(dir)) continue;
            class_2338 neighbor = pos.method_10093(dir);
            class_2680 neighborState = BlockUtilPlus.mc.field_1687.method_8320(neighbor);
            if (!BlockUtilPlus.canClick(neighbor, ignoreSneak) || neighborState.method_45474() || !BlockUtilPlus.isGrimDirection(neighbor, dir.method_10153())) continue;
            sides.add(dir);
        }
        return sides;
    }

    public static boolean canClick(class_2338 pos) {
        return BlockUtilPlus.canClick(pos, false);
    }

    public static boolean canClick(class_2338 pos, boolean ignoreSneak) {
        class_2680 state = BlockUtilPlus.mc.field_1687.method_8320(pos);
        class_2248 block = state.method_26204();
        boolean needsShift = SHIFT_BLOCKS.contains(block) || block instanceof class_2244;
        return state.method_51367() && (!needsShift || BlockUtilPlus.mc.field_1724.method_5715() || ignoreSneak);
    }

    public static boolean canReplace(class_2338 pos) {
        if (pos.method_10264() >= 320) {
            return false;
        }
        return BlockUtilPlus.mc.field_1687.method_8320(pos).method_45474();
    }

    public static boolean canPlace(class_2338 pos) {
        return BlockUtilPlus.canPlace(pos, null);
    }

    public static boolean canPlace(class_2338 pos, Predicate<class_2350> filter) {
        if (BlockUtilPlus.getPlaceSide(pos, filter) == null) {
            return false;
        }
        if (!BlockUtilPlus.canReplace(pos)) {
            return false;
        }
        return !BlockUtilPlus.hasEntity(pos, false);
    }

    public static boolean clientCanPlace(class_2338 pos, boolean ignoreCrystal) {
        if (!BlockUtilPlus.canReplace(pos)) {
            return false;
        }
        return !BlockUtilPlus.hasEntity(pos, ignoreCrystal);
    }

    public static boolean canPlaceCrystal(class_2338 pos) {
        if (!BlockUtilPlus.mc.field_1687.method_22347(pos)) {
            return false;
        }
        class_2338 basePos = pos.method_10074();
        class_2248 base = BlockUtilPlus.mc.field_1687.method_8320(basePos).method_26204();
        if (base != class_2246.field_10540 && base != class_2246.field_9987) {
            return false;
        }
        if (BlockUtilPlus.getClickSideStrict(basePos) == null) {
            return false;
        }
        class_2338 abovePos = pos.method_10084();
        if (!BlockUtilPlus.mc.field_1687.method_22347(abovePos)) {
            return false;
        }
        return !BlockUtilPlus.hasEntityBlockCrystal(pos, false) && !BlockUtilPlus.hasEntityBlockCrystal(abovePos, false);
    }

    public static boolean hasCrystalPlace(class_2338 pos) {
        for (class_1511 crystal : BlockUtilPlus.getEndCrystals(new class_238(pos))) {
            if (!crystal.method_5805() || !crystal.method_24515().equals((Object)pos)) continue;
            return true;
        }
        return false;
    }

    public static boolean hasEntity(class_2338 pos, boolean ignoreCrystal) {
        for (class_1297 entity : BlockUtilPlus.getEntities(new class_238(pos))) {
            if (!entity.method_5805() || entity instanceof class_1542 || entity instanceof class_1303 || entity instanceof class_1683 || entity instanceof class_1667 || ignoreCrystal && entity instanceof class_1511) continue;
            return true;
        }
        return false;
    }

    public static boolean hasEntity(class_2338 pos, boolean ignoreCrystal, boolean ignorePlayer) {
        for (class_1297 entity : BlockUtilPlus.getEntities(new class_238(pos))) {
            if (!entity.method_5805() || entity instanceof class_1542 || entity instanceof class_1303 || entity instanceof class_1683 || entity instanceof class_1667 || ignoreCrystal && entity instanceof class_1511 || ignorePlayer && entity instanceof class_1657) continue;
            return true;
        }
        return false;
    }

    public static boolean hasEntityBlockCrystal(class_2338 pos, boolean ignoreCrystal) {
        for (class_1297 entity : BlockUtilPlus.getEntities(new class_238(pos))) {
            if (!entity.method_5805() || ignoreCrystal && entity instanceof class_1511) continue;
            return true;
        }
        return false;
    }

    public static boolean noEntityBlockCrystal(class_2338 pos, boolean ignoreCrystal, boolean ignoreItem) {
        for (class_1297 entity : BlockUtilPlus.getEntities(new class_238(pos))) {
            if (!entity.method_5805() || ignoreItem && entity instanceof class_1542 || ignoreCrystal && entity instanceof class_1511) continue;
            return false;
        }
        return true;
    }

    public static boolean hasPlayerEntity(class_2338 pos) {
        for (class_1297 entity : BlockUtilPlus.getEntities(new class_238(pos))) {
            if (!(entity instanceof class_1657)) continue;
            return true;
        }
        return false;
    }

    public static boolean hasCrystal(class_2338 pos) {
        for (class_1511 crystal : BlockUtilPlus.getEndCrystals(new class_238(pos))) {
            if (!crystal.method_5805()) continue;
            return true;
        }
        return false;
    }

    public static boolean hasCrystalAt(class_2338 pos) {
        for (class_1511 crystal : BlockUtilPlus.getEndCrystals(new class_238(pos))) {
            if (!crystal.method_5805() || !crystal.method_24515().equals((Object)pos)) continue;
            return true;
        }
        return false;
    }

    public static List<class_1297> getEntities(class_238 box) {
        ArrayList<class_1297> list = new ArrayList<class_1297>();
        for (class_1297 entity : BlockUtilPlus.mc.field_1687.method_18112()) {
            if (entity == null || !entity.method_5829().method_994(box)) continue;
            list.add(entity);
        }
        return list;
    }

    public static List<class_1511> getEndCrystals(class_238 box) {
        ArrayList<class_1511> list = new ArrayList<class_1511>();
        for (class_1297 entity : BlockUtilPlus.mc.field_1687.method_18112()) {
            class_1511 crystal;
            if (!(entity instanceof class_1511) || !(crystal = (class_1511)entity).method_5829().method_994(box)) continue;
            list.add(crystal);
        }
        return list;
    }

    public static List<class_2338> getSphere(double range) {
        return BlockUtilPlus.getSphere(range, BlockUtilPlus.mc.field_1724.method_33571());
    }

    public static List<class_2338> getSphere(double range, class_243 origin) {
        ArrayList<class_2338> list = new ArrayList<class_2338>();
        for (double x = origin.field_1352 - range; x < origin.field_1352 + range; x += 1.0) {
            for (double z = origin.field_1350 - range; z < origin.field_1350 + range; z += 1.0) {
                for (double y = origin.field_1351 - range; y < origin.field_1351 + range; y += 1.0) {
                    class_2338 cur = class_2338.method_49637((double)x, (double)y, (double)z);
                    if (!(cur.method_46558().method_1022(origin) <= range) || list.contains(cur)) continue;
                    list.add(cur);
                }
            }
        }
        return list;
    }

    public static void placeBlock(class_2338 pos, class_2350 side, boolean rotate) {
        BlockUtilPlus.clickBlock(pos.method_10093(side), side.method_10153(), rotate);
    }

    public static void clickBlock(class_2338 pos, class_2350 face, boolean rotate) {
        class_243 hitVec = new class_243((double)pos.method_10263() + 0.5 + (double)face.method_10148() * 0.5, (double)pos.method_10264() + 0.5 + (double)face.method_10164() * 0.5, (double)pos.method_10260() + 0.5 + (double)face.method_10165() * 0.5);
        if (rotate) {
            float[] rot = RotationUtil.getRotationsTo(BlockUtilPlus.mc.field_1724.method_33571(), hitVec);
            Managers.ROTATION.setRotationSilent(rot[0], rot[1]);
        }
        class_3965 result = new class_3965(hitVec, face, pos, false);
        Managers.NETWORK.sendSequencedPacket(id -> new class_2885(class_1268.field_5808, result, id));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        placeList.add(pos);
    }

    public static boolean placeAuto(class_2338 pos, boolean rotate) {
        return BlockUtilPlus.placeAuto(pos, null, rotate);
    }

    public static boolean placeAuto(class_2338 pos, Predicate<class_2350> filter, boolean rotate) {
        class_2350 side = BlockUtilPlus.getPlaceSide(pos, filter);
        if (side == null) {
            return false;
        }
        BlockUtilPlus.placeBlock(pos, side, rotate);
        return true;
    }

    public static void clickSlabBlock(class_2338 pos, class_2350 face, class_2350 slabSide, boolean rotate) {
        double yOffset = 0.5;
        if (slabSide == class_2350.field_11036) {
            yOffset += 0.1;
        }
        if (slabSide == class_2350.field_11033) {
            yOffset -= 0.1;
        }
        class_243 hitVec = new class_243((double)pos.method_10263() + 0.5 + (double)face.method_10148() * 0.5, (double)pos.method_10264() + yOffset + (double)face.method_10164() * 0.5, (double)pos.method_10260() + 0.5 + (double)face.method_10165() * 0.5);
        if (rotate) {
            float[] rot = RotationUtil.getRotationsTo(BlockUtilPlus.mc.field_1724.method_33571(), hitVec);
            Managers.ROTATION.setRotationSilent(rot[0], rot[1]);
        }
        class_3965 result = new class_3965(hitVec, face, pos, false);
        Managers.NETWORK.sendSequencedPacket(id -> new class_2885(class_1268.field_5808, result, id));
        Managers.NETWORK.sendPacket((class_2596<?>)new class_2879(class_1268.field_5808));
        placeList.add(pos);
    }

    public static boolean canSee(class_2338 pos, class_2350 side) {
        class_243 target = pos.method_46558().method_1031((double)side.method_10148() * 0.5, (double)side.method_10164() * 0.5, (double)side.method_10165() * 0.5);
        class_3965 result = BlockUtilPlus.mc.field_1687.method_17742(new class_3959(BlockUtilPlus.mc.field_1724.method_33571(), target, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)BlockUtilPlus.mc.field_1724));
        return result == null || result.method_17783() == class_239.class_240.field_1333;
    }

    public static class_2248 getBlock(class_2338 pos) {
        return BlockUtilPlus.mc.field_1687.method_8320(pos).method_26204();
    }

    public static boolean needSneak(class_2248 block) {
        return SHIFT_BLOCKS.contains(block) || block instanceof class_2244;
    }

    public static class_243 getClosestPoint(class_1297 entity) {
        return BlockUtilPlus.getClosestPointToBox(BlockUtilPlus.mc.field_1724.method_33571(), entity.method_5829());
    }

    public static class_243 getClosestPointToBox(class_243 pos, class_238 box) {
        return new class_243(class_3532.method_15350((double)pos.field_1352, (double)box.field_1323, (double)box.field_1320), class_3532.method_15350((double)pos.field_1351, (double)box.field_1322, (double)box.field_1325), class_3532.method_15350((double)pos.field_1350, (double)box.field_1321, (double)box.field_1324));
    }

    private static class_238 getCombinedBox(class_2338 pos) {
        class_238 combined = new class_238(pos);
        for (class_238 box : BlockUtilPlus.mc.field_1687.method_8320(pos).method_26220((class_1922)BlockUtilPlus.mc.field_1687, pos).method_1096((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260()).method_1090()) {
            double minX = Math.max(box.field_1323, combined.field_1323);
            double minY = Math.max(box.field_1322, combined.field_1322);
            double minZ = Math.max(box.field_1321, combined.field_1321);
            double maxX = Math.min(box.field_1320, combined.field_1320);
            double maxY = Math.min(box.field_1325, combined.field_1325);
            double maxZ = Math.min(box.field_1324, combined.field_1324);
            combined = new class_238(minX, minY, minZ, maxX, maxY, maxZ);
        }
        return combined;
    }

    private static boolean isIntersected(class_238 a, class_238 b) {
        return b.field_1320 - 1.0E-7 > a.field_1323 && b.field_1323 + 1.0E-7 < a.field_1320 && b.field_1325 - 1.0E-7 > a.field_1322 && b.field_1322 + 1.0E-7 < a.field_1325 && b.field_1324 - 1.0E-7 > a.field_1321 && b.field_1321 + 1.0E-7 < a.field_1324;
    }
}
