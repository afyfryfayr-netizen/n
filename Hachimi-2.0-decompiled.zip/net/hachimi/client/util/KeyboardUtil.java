package net.hachimi.client.util;

import org.lwjgl.glfw.GLFW;

public class KeyboardUtil {
    public static String getKeyName(int keycode, int scancode) {
        return switch (keycode) {
            case 344 -> "RSHIFT";
            case 340 -> "LSHIFT";
            case 32 -> "SPACE";
            case 341 -> "LCONTROL";
            case 345 -> "RCONTROL";
            case 342 -> "LALT";
            case 346 -> "RALT";
            case 257 -> "ENTER";
            case 258 -> "TAB";
            case 259 -> "BACKSPACE";
            case 261 -> "DELETE";
            case 260 -> "INSERT";
            case 280 -> "CAPS_LOCK";
            case 266 -> "PAGE_UP";
            case 267 -> "PAGE_DOWN";
            case 268 -> "HOME";
            case 269 -> "END";
            case 263 -> "LEFT";
            case 262 -> "RIGHT";
            case 265 -> "UP";
            case 264 -> "DOWN";
            case 1000 -> "MOUSE0";
            case 1001 -> "MOUSE1";
            case 1002 -> "MOUSE2";
            case 1003 -> "MOUSE3";
            case 1004 -> "MOUSE4";
            case 1005 -> "MOUSE5";
            case 1006 -> "MOUSE6";
            case 1007 -> "MOUSE7";
            default -> GLFW.glfwGetKeyName((int)keycode, (int)scancode);
        };
    }

    public static String getKeyName(int keycode) {
        return KeyboardUtil.getKeyName(keycode, keycode < 1000 ? GLFW.glfwGetKeyScancode((int)keycode) : 0);
    }

    public static int getKeyCode(String key) {
        int i;
        if (key.equalsIgnoreCase("NONE")) {
            return -1;
        }
        for (i = 32; i < 97; ++i) {
            if (!key.equalsIgnoreCase(KeyboardUtil.getKeyName(i, GLFW.glfwGetKeyScancode((int)i)))) continue;
            return i;
        }
        for (i = 256; i < 349; ++i) {
            if (!key.equalsIgnoreCase(KeyboardUtil.getKeyName(i, GLFW.glfwGetKeyScancode((int)i)))) continue;
            return i;
        }
        for (i = 1000; i < 1010; ++i) {
            if (!key.equalsIgnoreCase(KeyboardUtil.getKeyName(i, GLFW.glfwGetKeyScancode((int)i)))) continue;
            return i;
        }
        return -1;
    }
}
