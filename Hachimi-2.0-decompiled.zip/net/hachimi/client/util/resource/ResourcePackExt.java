package net.hachimi.client.util.resource;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import net.fabricmc.fabric.api.resource.ModResourcePack;
import net.fabricmc.fabric.impl.resource.loader.ModNioResourcePack;
import net.fabricmc.loader.api.metadata.ModMetadata;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3270;
import net.minecraft.class_7367;
import net.minecraft.class_9224;
import org.jetbrains.annotations.Nullable;

public final class ResourcePackExt
implements class_3262,
ModResourcePack {
    public static final Set<String> REGISTERED_SOUND_FILES = new HashSet<String>();
    private final ModNioResourcePack parent;

    public ResourcePackExt(ModNioResourcePack parent) {
        this.parent = parent;
    }

    @Nullable
    public class_7367<InputStream> method_14410(String ... segments) {
        return this.parent.method_14410(segments);
    }

    @Nullable
    public class_7367<InputStream> method_14405(class_3264 type, class_2960 id) {
        String formattedName = String.format("assets/hachimiclient/%s", id.method_12832());
        InputStream is = (InputStream)this.getResourceInternal(formattedName);
        if (is != null) {
            return () -> is;
        }
        return this.parent.method_14405(type, id);
    }

    private Object getResourceInternal(String name) {
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(name);
        if (is == null) {
            if (name.startsWith("assets/")) {
                is = this.getClass().getClassLoader().getResourceAsStream(name.substring(7));
            }
            if (is == null && !name.startsWith("/")) {
                is = this.getClass().getClassLoader().getResourceAsStream("/" + name);
            }
        }
        return is;
    }

    public void method_14408(class_3264 type, String namespace, String prefix, class_3262.class_7664 consumer) {
        if (prefix.equals("sounds")) {
            for (String soundFile : REGISTERED_SOUND_FILES) {
                String formattedName = String.format("assets/hachimiclient/sounds/%s", soundFile);
                InputStream is = (InputStream)this.getResourceInternal(formattedName);
                if (is == null) continue;
                class_2960 id = class_2960.method_60655((String)"hachimi", (String)String.format("sounds/%s", soundFile));
                consumer.accept((Object)id, () -> is);
            }
        }
        this.parent.method_14408(type, namespace, prefix, consumer);
    }

    public Set<String> method_14406(class_3264 type) {
        return this.parent.method_14406(type);
    }

    @Nullable
    public <T> T method_14407(class_3270<T> metaReader) throws IOException {
        return (T)this.parent.method_14407(metaReader);
    }

    public class_9224 method_56926() {
        return this.parent.method_56926();
    }

    public ModMetadata getFabricModMetadata() {
        return this.parent.getFabricModMetadata();
    }

    public ModResourcePack createOverlay(String overlay) {
        return this.parent.createOverlay(overlay);
    }

    public void close() {
        this.parent.close();
    }
}
