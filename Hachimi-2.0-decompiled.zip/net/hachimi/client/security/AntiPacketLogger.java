package net.hachimi.client.security;

import io.netty.buffer.Unpooled;
import net.minecraft.class_2540;
import net.minecraft.class_2596;

public class AntiPacketLogger {
    public void convertMinecraftProtocol(class_2596<?> packet) {
        class_2540 packetByteBuf = new class_2540(Unpooled.buffer());
    }
}
